package com.lingxu.zhiying.core

import android.content.Context

/**
 * 管线自检诊断
 *
 * 「一个顺序都没排对」几乎总是因为特征提取整条链路没出结果，
 * 而不是算法排错了。所以每一环都要能被量化检查：
 *
 *   抽帧 → 字幕带检测 → OCR → 音频提纯 → ASR → 文本比对 → DP
 *
 * 任何一环断了，得分矩阵就是全 0，DP 输出的顺序等同于随机。
 * 这个类把每一环的成败计数收集起来，直接在 App 里给出结论和修复建议，
 * 不用再连电脑看 logcat。
 */
object Diagnostics {

    data class Report(
        val totalClips: Int,
        val probedOk: Int,
        val framesOk: Int,
        val subtitleBandFound: Int,
        val ocrNonEmpty: Int,
        val asrAvailable: Boolean,
        val asrNonEmpty: Int,
        val audioExtractOk: Int,
        val llmAvailable: Boolean,
        val matched: Int,
        val modelFiles: List<String>,
        val notes: MutableList<String> = mutableListOf(),
        val ffmpegReady: Boolean = FFmpegRuntime.ready,
        val ffmpegVersion: String = FFmpegRuntime.version,
        val ffmpegError: String = FFmpegRuntime.error,
        val ffmpegNativeErrors: List<String> = FFmpegRuntime.recentErrors
    ) {
        /** 结论：链路哪一环断了 */
        fun verdict(): String {
            if (totalClips == 0) return "没有素材"
            if (!ffmpegReady) {
                return "❌ 第 0 环就断了：FFmpeg 引擎不可用 —— $ffmpegError\n" +
                        "（这会导致抽帧、音频提取、拼接全部失败，与素材和权限无关）"
            }
            if (probedOk == 0) return "❌ 第 1 环断了：读不到视频文件（权限或路径问题）"
            if (framesOk == 0) return "❌ 第 2 环断了：FFmpeg 抽帧全部失败"
            if (ocrNonEmpty == 0 && asrNonEmpty == 0) {
                return if (!asrAvailable) {
                    "❌ 第 3+4 环都断了：OCR 没读到任何字幕，且 ASR 引擎不可用"
                } else {
                    "❌ 第 3+4 环都断了：OCR 没读到字幕，ASR 也没听写到内容"
                }
            }
            if (ocrNonEmpty == 0) return "⚠️ OCR 全程无输出，只靠语音在对齐（准确率会明显下降）"
            if (asrNonEmpty == 0) return "⚠️ ASR 全程无输出，只靠字幕在对齐"
            if (matched == 0) return "❌ 特征都提取到了，但没有一句匹配上剧本（检查剧本格式/语言）"
            return "✅ 链路正常"
        }

        fun advice(): List<String> {
            val a = ArrayList<String>()
            if (!ffmpegReady) {
                a.add("先解决 FFmpeg：确认 ffmpeg-kit-full 的 .so 进了 APK（解包看 lib/arm64-v8a/ 下应有 libffmpegkit.so 与 libavcodec.so 等），" +
                        "以及 abiFilters 是否包含本机架构")
            }
            if (probedOk < totalClips) a.add("有 ${totalClips - probedOk} 个片段读不到，检查存储权限与素材是否被移动")
            if (framesOk < probedOk) a.add("有 ${probedOk - framesOk} 个片段抽帧失败，可能是编码格式不支持")
            if (subtitleBandFound == 0 && totalClips > 0) {
                a.add("一次都没检测到字幕带：素材可能没有硬字幕，或字幕是软字幕/花字。此时只能靠语音")
            }
            if (ocrNonEmpty == 0 && subtitleBandFound > 0) {
                a.add("检测到字幕带但 OCR 全空：ML Kit 中文模型可能未随包安装，或字幕太小/太花")
            }
            if (!asrAvailable) {
                a.add("ASR 引擎不可用：检查 assets/models 下是否有 model.int8.onnx 与 tokens.txt，" +
                        "以及 app/libs 下是否有 sherpa-onnx AAR（缺 .so 会 UnsatisfiedLinkError）")
            }
            if (asrAvailable && asrNonEmpty == 0 && audioExtractOk > 0) {
                a.add("音频提取成功但听写为空：SenseVoice 模型可能未正确加载，或素材是纯 BGM 无人声")
            }
            if (audioExtractOk == 0 && totalClips > 0) a.add("所有片段的音频都提取失败，素材可能没有音轨")
            if (!llmAvailable) a.add("大模型仲裁不可用（不影响主流程，模糊片段将无法二次判定）")
            if (matched == 0 && (ocrNonEmpty > 0 || asrNonEmpty > 0)) {
                a.add("提取到文字却一句都没匹配上：检查剧本是否粘贴完整、是否为同一部片子、" +
                        "或剧本里混入了大量非台词行")
            }
            if (modelFiles.isEmpty()) a.add("assets/models 目录是空的：模型没被打进 APK")
            return a
        }

        fun render(): String {
            val sb = StringBuilder()
            sb.append("【管线自检】\n")
            sb.append(verdict()).append("\n\n")
            sb.append("FFmpeg 引擎     : ").append(if (ffmpegReady) "可用" else "不可用").append("\n")
            sb.append("FFmpeg 版本     : ").append(ffmpegVersion.ifBlank { "（取不到）" }).append("\n")
            if (ffmpegError.isNotBlank()) sb.append("FFmpeg 错误     : ").append(ffmpegError).append("\n")
            if (ffmpegNativeErrors.isNotEmpty()) {
                sb.append("\n【FFmpeg 调用异常】\n")
                ffmpegNativeErrors.forEach { sb.append("· ").append(it).append("\n") }
            }
            sb.append("\n")
            sb.append("素材总数        : $totalClips\n")
            sb.append("读取成功        : $probedOk\n")
            sb.append("抽帧成功        : $framesOk\n")
            sb.append("检测到字幕带    : $subtitleBandFound\n")
            sb.append("OCR 有输出      : $ocrNonEmpty\n")
            sb.append("音频提取成功    : $audioExtractOk\n")
            sb.append("ASR 引擎可用    : ${if (asrAvailable) "是" else "否"}\n")
            sb.append("ASR 有输出      : $asrNonEmpty\n")
            sb.append("大模型可用      : ${if (llmAvailable) "是" else "否"}\n")
            sb.append("命中剧本        : $matched\n\n")
            sb.append("assets/models   : ${if (modelFiles.isEmpty()) "（空）" else modelFiles.joinToString(", ")}\n")
            if (notes.isNotEmpty()) {
                sb.append("\n【过程记录】\n")
                notes.take(12).forEach { sb.append("· ").append(it).append("\n") }
            }
            val adv = advice()
            if (adv.isNotEmpty()) {
                sb.append("\n【修复建议】\n")
                adv.forEach { sb.append("→ ").append(it).append("\n") }
            }
            return sb.toString().trim()
        }
    }

    fun listModels(context: Context): List<String> {
        return try {
            context.assets.list("models")?.toList() ?: emptyList()
        } catch (e: Throwable) {
            emptyList()
        }
    }
}
