package com.lingxu.zhiying.model

import android.graphics.Bitmap

/** 剧本单句 */
data class ScriptLine(
    val index: Int,
    val text: String,
    val role: String = ""
)

/** 一个视频切片的多模态特征 */
data class ClipFeature(
    val id: Int,
    val uri: String,
    val displayName: String,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    /** OCR 抽帧识别到的字幕文本（合并去重） */
    var ocrText: String = "",
    /** ASR 听写文本 */
    var asrText: String = "",
    /** 首帧感知哈希 aHash（64bit） */
    var headHash: Long = 0L,
    /** 尾帧感知哈希 aHash（64bit） */
    var tailHash: Long = 0L,
    /** 是否检测到字幕带 */
    var hasSubtitleBand: Boolean = false,
    /** 抽帧数量 */
    var frameCount: Int = 0,
    /** 静音检测给出的建议入点（毫秒），0 表示不裁 */
    var suggestTrimIn: Long = 0L,
    /** 静音检测给出的建议出点（毫秒），0 表示不裁 */
    var suggestTrimOut: Long = 0L,
    /** 场景指纹聚类得到的组号，-1 表示未分组（用于区分同词不同人） */
    var sceneGroup: Int = -1,
    /** 所属集数/文件夹名，多集素材用 */
    var episode: String = "",
    /** 场景指纹（色彩直方图 + aHash），用于区分同词不同人 */
    var scene: com.lingxu.zhiying.core.SceneFingerprint.Scene =
        com.lingxu.zhiying.core.SceneFingerprint.Scene(FloatArray(32), 0L, 0L),
    /** 在文件名自然序中的位置 */
    var naturalPosRef: Int = 0
)

/** 对齐结果卡片 */
data class AlignedClip(
    var order: Int,
    val feature: ClipFeature,
    /** 命中的剧本句序号，-1 表示未命中 */
    var scriptIndex: Int = -1,
    /** 视觉（OCR）匹配度 0f..1f */
    var visualScore: Float = 0f,
    /** 听觉（ASR）匹配度 0f..1f */
    var audioScore: Float = 0f,
    /** 综合匹配度 0f..1f */
    var finalScore: Float = 0f,
    /** 是否由大模型仲裁得出 */
    var byLlm: Boolean = false,
    /** 是否由帧哈希视觉归位得出 */
    var byHash: Boolean = false,
    /** 用户手动锁定，涟漪重排时跳过 */
    var locked: Boolean = false,
    /** 裁剪入点（毫秒），-1 表示从头开始 */
    var trimInMs: Long = -1L,
    /** 裁剪出点（毫秒），-1 表示到结尾 */
    var trimOutMs: Long = -1L,
    /** 是否被判定为重复片段（重复的不参与拼接） */
    var isDuplicate: Boolean = false,
    /** 与哪一张卡片重复 */
    var duplicateOf: Int = -1,
    /** 该片段在文件名自然序中的位置（作为 DP 的弱先验） */
    var naturalPos: Int = 0,
    /** 命中的剧本原文 */
    var matchedScriptText: String = "",
    /** 从视频里截出的、与剧本句对应的那一段台词（多余内容已剔除） */
    var matchedExtract: String = ""
) {
    val confidenceLevel: Level
        get() = when {
            finalScore >= 0.65f -> Level.HIGH
            finalScore >= 0.35f -> Level.MID
            else -> Level.LOW
        }

    enum class Level { HIGH, MID, LOW }
}

/** 对齐流水线进度 */
data class AlignProgress(
    val stage: String,
    val current: Int,
    val total: Int,
    val message: String = ""
) {
    val ratio: Float
        get() = if (total <= 0) 0f else current.toFloat() / total.toFloat()
}

/** 视觉指纹缩略信息，用于卡片展示 */
data class VisualFingerprint(
    val hashHex: String,
    val thumbnail: Bitmap? = null
)
