package com.lingxu.zhiying.core

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 音频提纯与识别管线
 *
 * FFmpeg 高级滤镜链：
 *   highpass=f=180      去除低频轰鸣
 *   lowpass=f=3600      去除高频电流声
 *   afftdn=nf=-25       频谱降噪
 *   acompressor         动态范围压缩
 *   loudnorm            响度归一化
 * 输出 16kHz 单声道 pcm_s16le WAV，剥离 44 字节头后转 FloatArray 推入 Sherpa-ONNX。
 */
class AudioPipeline(private val context: Context) {

    companion object {
        const val SAMPLE_RATE = 16000
        private const val WAV_HEADER_SIZE = 44

        /** 极致提纯滤镜链（🎙️ 语音智能增益 开启时挂载） */
        const val PURE_FILTER_CHAIN =
            "highpass=f=180,lowpass=f=3600,afftdn=nf=-25," +
                    "acompressor=threshold=-18dB:ratio=3:attack=20:release=250," +
                    "loudnorm=I=-16:TP=-1.5:LRA=11"

        /** 关闭增益时的轻量链路，仅做带通与归一化 */
        const val LIGHT_FILTER_CHAIN = "highpass=f=120,loudnorm=I=-16:TP=-1.5:LRA=11"

        /** 滑动窗口：单窗 25 秒，重叠 1 秒，防止超长音频把内存打爆 */
        const val WINDOW_SECONDS = 25
        const val OVERLAP_SECONDS = 1
    }

    private val workDir: File
        get() = File(context.cacheDir, "audio").apply { if (!exists()) mkdirs() }

    /**
     * 提取并提纯音频
     * @param gainEnabled 🎙️ 语音智能增益开关
     * @return WAV 文件，失败返回 null
     */
    fun extract(videoPath: String, clipId: Int, gainEnabled: Boolean): File? {
        val out = File(workDir, "a_$clipId.wav")
        if (out.exists()) out.delete()
        val filter = if (gainEnabled) PURE_FILTER_CHAIN else LIGHT_FILTER_CHAIN
        val cmd = "-hide_banner -loglevel error -y -i \"$videoPath\" " +
                "-vn -af \"$filter\" -ar $SAMPLE_RATE -ac 1 -c:a pcm_s16le \"${out.absolutePath}\""
        val session = FFmpegKit.execute(cmd)
        if (!ReturnCode.isSuccess(session.returnCode)) {
            FFmpegRuntime.recordError(
                "AudioPipeline.filterChain",
                RuntimeException("滤镜链失败: ${(session.output ?: "").take(300)}")
            )
            LogX.w("AudioPipeline", "滤镜链失败，降级为直出: ${session.output}")
            val fallback = "-hide_banner -loglevel error -y -i \"$videoPath\" " +
                    "-vn -ar $SAMPLE_RATE -ac 1 -c:a pcm_s16le \"${out.absolutePath}\""
            val s2 = FFmpegKit.execute(fallback)
            if (!ReturnCode.isSuccess(s2.returnCode)) {
                FFmpegRuntime.recordError(
                    "AudioPipeline.extract",
                    RuntimeException("音频提取失败: ${(s2.output ?: "").take(300)}")
                )
                return null
            }
        }
        return if (out.exists() && out.length() > WAV_HEADER_SIZE) out else null
    }

    /** 读取 WAV，剥离 44 字节头，转 FloatArray（-1f..1f） */
    fun readPcm(wav: File): FloatArray {
        val bytes = wav.readBytes()
        if (bytes.size <= WAV_HEADER_SIZE) return FloatArray(0)
        val headerSkip = locateDataChunk(bytes)
        val payload = bytes.size - headerSkip
        if (payload <= 1) return FloatArray(0)
        val buffer = ByteBuffer.wrap(bytes, headerSkip, payload).order(ByteOrder.LITTLE_ENDIAN)
        val count = payload / 2
        val out = FloatArray(count)
        for (i in 0 until count) {
            out[i] = buffer.short / 32768.0f
        }
        return out
    }

    /**
     * 标准 WAV 头是 44 字节，但 FFmpeg 可能插入 LIST/fact 等扩展块，
     * 这里真正定位到 "data" 块，避免把元数据当采样送进模型。
     */
    private fun locateDataChunk(bytes: ByteArray): Int {
        if (bytes.size < 12) return WAV_HEADER_SIZE
        var pos = 12
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4, Charsets.US_ASCII)
            val size = ByteBuffer.wrap(bytes, pos + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (id == "data") return pos + 8
            pos += 8 + size + (size and 1)
            if (size <= 0) break
        }
        return WAV_HEADER_SIZE
    }

    /** 滑动窗口切分，返回每个窗口的采样片段 */
    fun windows(pcm: FloatArray): List<FloatArray> {
        if (pcm.isEmpty()) return emptyList()
        val win = WINDOW_SECONDS * SAMPLE_RATE
        val step = (WINDOW_SECONDS - OVERLAP_SECONDS) * SAMPLE_RATE
        if (pcm.size <= win) return listOf(pcm)
        val out = ArrayList<FloatArray>()
        var start = 0
        while (start < pcm.size) {
            val end = minOf(pcm.size, start + win)
            out.add(pcm.copyOfRange(start, end))
            if (end >= pcm.size) break
            start += step
        }
        return out
    }

    fun clean(clipId: Int) {
        File(workDir, "a_$clipId.wav").delete()
    }

    fun cleanAll() {
        workDir.deleteRecursively()
    }
}
