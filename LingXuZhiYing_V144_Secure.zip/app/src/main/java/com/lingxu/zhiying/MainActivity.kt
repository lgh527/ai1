package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class FolderInfo(val name: String, val videos: MutableList<Map<String, Any>>)

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainScrollView: ScrollView
    private lateinit var calibrateLayout: LinearLayout

    private val REQ_CODE_PERM = 100

    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private lateinit var btnActivate: Button
    private var deviceId: String = ""
    private var isAuthVerified = false

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnStitch: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private lateinit var tvStats: TextView
    private lateinit var btnGoCalibrate: Button

    private lateinit var recyclerView: RecyclerView
    private lateinit var cardAdapter: ClipAdapter
    private lateinit var calibProgressBar: ProgressBar
    private lateinit var calibStatus: TextView
    private lateinit var btnCalibrate: Button
    private lateinit var btnLockGreen: Button
    private lateinit var btnUnlockAll: Button

    private var calibrateRound = 0
    private var isCalibrating = false
    private var isModelsReady = false
    private var currentJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            // 【加固点1】反调试检测
            if (isDebuggable(this) || isDebuggerConnected()) {
                AlertDialog.Builder(this).setTitle("安全拦截").setMessage("检测到非法调试环境，程序即将退出。").setCancelable(false)
                    .setPositiveButton("退出", {_,_ -> finish()}).show()
                return
            }

            checkPermissions()
            setupBaseUI()

            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }

            isAuthVerified = prefs.getBoolean("is_activated", false)
            if (isAuthVerified) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString())
                .setPositiveButton("关闭", null).show()
        }
    }

    // 检查是否处于调试模式
    private fun isDebuggable(context: Context): Boolean {
        return (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    // 检查是否连接了调试器
    private fun isDebuggerConnected(): Boolean {
        return android.os.Debug.isDebuggerConnected()
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun setupBaseUI() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(80, 200, 80, 80)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val tvTip = TextView(this).apply { text = "首次使用请复制下方设备码发给卖家获取激活码"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) }
        tvDeviceCode = TextView(this).apply {
            text = deviceId
            setTextColor(Color.parseColor("#10B981"))
            textSize = 28f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "设备码已复制", Toast.LENGTH_SHORT).show()
            }
        }
        etActivationCode = EditText(this).apply {
            hint = "请输入 32 位激活码"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(30, 30, 30, 30)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        btnActivate = Button(this).apply {
            text = "立即激活"
            setBackgroundColor(Color.parseColor("#2563EB"))
            setTextColor(Color.WHITE)
            setPadding(0, 30, 0, 30)
            setOnClickListener { verifyActivation() }
        }
        authLayout.addView(title); authLayout.addView(tvTip); authLayout.addView(tvDeviceCode); authLayout.addView(etActivationCode); authLayout.addView(btnActivate)
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "激活码格式错误，应为 32 位", Toast.LENGTH_SHORT).show(); return }
        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decrypted = ByteArray(obfuscatedBytes.size) { i -> (obfuscatedBytes[i].toInt() xor xorKey).toByte() }
        val realKey = String(decrypted)
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(realKey.toByteArray(), "HmacSHA256"))
            val hashBytes = mac.doFinal(deviceId.toByteArray())
            val expected = hashBytes.joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expected) {
                Toast.makeText(this, "激活成功，永久有效！", Toast.LENGTH_LONG).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                isAuthVerified = true
                authLayout.visibility = View.GONE
                showMainApp()
            } else Toast.makeText(this, "激活码错误，请核对后重试", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun showMainApp() {
        if (::mainScrollView.isInitialized) { mainScrollView.visibility = View.VISIBLE; return }

        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        
        val mainLayout = LinearLayout(this).apply { 
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(40, 60, 40, 60) 
        }

        val title = TextView(this).apply { text = "灵序织影 · 导演台"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 20) }

        val tvStep1 = TextView(this).apply { text = "第一步：输入剧情脚本"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, 8) }
        etScript = EditText(this).apply { 
            hint = "长文直接粘贴 (若不填则默认按文件名顺序极速直拼)"; 
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(24, 20, 24, 20)
            minLines = 3
            maxLines = 6 
            gravity = Gravity.TOP 
            isVerticalScrollBarEnabled = true
        }
        
        val tvStep2 = TextView(this).apply { text = "第二步：导入视频素材"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnImport = Button(this).apply { text = "📥 导入视频素材"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        tvClipCount = TextView(this).apply { text = "已导入素材：0 个"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 12f; setPadding(0, 8, 0, 8) }

        val tvStep3 = TextView(this).apply { text = "第三步：AI 对齐与校对"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        
        val matchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,0,0,8) }
        btnMatch = Button(this).apply { 
            text = "🧠 开始对齐/拼接"; 
            setBackgroundColor(Color.parseColor("#2563EB")); 
            setTextColor(Color.WHITE); 
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply{ marginEnd = 8 }
            setOnClickListener { showMatchingModeDialog() } 
        }
        btnGoCalibrate = Button(this).apply { 
            text = "📝 进入校对工作台"; 
            setBackgroundColor(Color.parseColor("#7C3AED")); 
            setTextColor(Color.WHITE);
            isEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { 
                mainScrollView.visibility = View.GONE
                calibrateLayout.visibility = View.VISIBLE
            } 
        }
        matchRow.addView(btnMatch)
        matchRow.addView(btnGoCalibrate)

        tvStats = TextView(this).apply {
            text = "等待智能对齐..."
            setTextColor(Color.parseColor("#F59E0B"))
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }

        val tvStep4 = TextView(this).apply { text = "第四步：渲染与导出"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnStitch = Button(this).apply { text = "🎬 渲染完整视频 (原画质)"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); setPadding(0, 24, 0, 24); setOnClickListener { tryStartStitching() } }
        btnSave = Button(this).apply { text = "💾 保存至相册 (MP4)"; setBackgroundColor(Color.parseColor("#D97706")); setTextColor(Color.WHITE); setPadding(0, 24, 0, 24); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0, 16, 0, 16) }
        tvStatus = TextView(this).apply { text = "准备就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 13f; gravity = Gravity.CENTER }

        mainLayout.addView(title)
        mainLayout.addView(tvStep1); mainLayout.addView(etScript)
        mainLayout.addView(tvStep2); mainLayout.addView(btnImport); mainLayout.addView(tvClipCount)
        mainLayout.addView(tvStep3); mainLayout.addView(matchRow); mainLayout.addView(tvStats)
        mainLayout.addView(tvStep4); mainLayout.addView(btnStitch); mainLayout.addView(btnSave)
        mainLayout.addView(progressBar); mainLayout.addView(tvStatus)

        mainScrollView = ScrollView(this).apply { 
            isFillViewport = true
            addView(mainLayout) 
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        rootLayout.addView(mainScrollView)

        calibrateLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(40, 60, 40, 60)
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val calibTitleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0,0,0,16) }
        val btnBack = Button(this).apply { 
            text = "🔙 返回主页"; 
            setBackgroundColor(Color.parseColor("#64748B")); 
            setTextColor(Color.WHITE); 
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setOnClickListener {
                calibrateLayout.visibility = View.GONE
                mainScrollView.visibility = View.VISIBLE
            } 
        }
        val calibTitle = TextView(this).apply { text = " 校对工作台"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 20f; typeface = Typeface.DEFAULT_BOLD }
        calibTitleRow.addView(btnBack)
        calibTitleRow.addView(calibTitle)

        val calibBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
        btnCalibrate = Button(this).apply {
            text = "🔄 智能校对"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#7C3AED"))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { runCalibration() }
        }
        btnLockGreen = Button(this).apply {
            text = "🔒 锁绿"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#059669"))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { lockGreens() }
        }
        btnUnlockAll = Button(this).apply {
            text = "🔓 解锁"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { unlockAll() }
        }
        calibBtnRow.addView(btnCalibrate); calibBtnRow.addView(btnLockGreen); calibBtnRow.addView(btnUnlockAll)

        calibProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0, 8, 0, 8) }
        calibStatus = TextView(this).apply { text = "等待操作..."; setTextColor(Color.parseColor("#F59E0B")); textSize = 12f; gravity = Gravity.CENTER; setPadding(0,0,0,8) }

        recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            cardAdapter = ClipAdapter()
            adapter = cardAdapter
        }

        calibrateLayout.addView(calibTitleRow)
        calibrateLayout.addView(calibBtnRow)
        calibrateLayout.addView(calibProgressBar)
        calibrateLayout.addView(calibStatus)
        calibrateLayout.addView(recyclerView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        rootLayout.addView(calibrateLayout)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎加载成功"
            }
        }
    }

    inner class ClipAdapter : RecyclerView.Adapter<ClipAdapter.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 10, 16, 10)
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 }
            }
            val header = TextView(this@MainActivity).apply { textSize = 12f; setTypeface(null, Typeface.BOLD) }
            val visualInfo = TextView(this@MainActivity).apply { textSize = 11f; setPadding(0, 2, 0, 2); setTextColor(Color.parseColor("#F59E0B")) }
            val heardLine = TextView(this@MainActivity).apply { textSize = 12f; setPadding(0, 4, 0, 4); setLineSpacing(0f, 1.2f) }
            val scriptLine = TextView(this@MainActivity).apply { textSize = 12f; setLineSpacing(0f, 1.2f) }
            
            val btnUp = Button(this@MainActivity).apply { text = "⬆️ 上移"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#3B82F6")); setTextColor(Color.WHITE) }
            val btnDown = Button(this@MainActivity).apply { text = "⬇️ 下移"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#3B82F6")); setTextColor(Color.WHITE) }
            val lockBtn = Button(this@MainActivity).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setPadding(16, 4, 16, 4); setTextColor(Color.WHITE) }
            
            val btnRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, 8, 0, 0) }
            btnUp.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            btnDown.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            lockBtn.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            
            btnRow.addView(btnUp)
            btnRow.addView(btnDown)
            btnRow.addView(lockBtn)
            
            card.addView(header)
            card.addView(visualInfo)
            card.addView(heardLine)
            card.addView(scriptLine)
            card.addView(btnRow)
            return ViewHolder(card, header, visualInfo, heardLine, scriptLine, lockBtn, btnUp, btnDown)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val m = bridge.allMatches[position]
            val isGreen = m.score >= AndroidBridge.GREEN_THRESHOLD
            val scoreColor = when {
                m.locked -> "#38BDF8"
                isGreen -> "#10B981"
                m.score >= AndroidBridge.YELLOW_THRESHOLD -> "#F59E0B"
                else -> "#EF4444"
            }
            val bgColor = if (m.locked) "#1E293B" else "#0F172A"
            val lockIcon = if (m.locked) "🔒" else if (isGreen) "✅" else "❌"

            holder.card.setBackgroundColor(Color.parseColor(bgColor))
            holder.header.text = "$lockIcon 第${position+1}段 · 匹配度 ${String.format("%.2f", m.score)} · 坐标 ${m.coord}"
            holder.header.setTextColor(Color.parseColor(scoreColor))
            
            holder.visualInfo.text = "👁️ 视觉指纹: ${if (m.visualHash.isEmpty()) "无特征" else m.visualHash}"
            
            if (isGreen || m.locked) {
                holder.heardLine.text = "🎤 视频内容：\n${if (m.heardText.isBlank()) "(无)" else m.heardText}"
                holder.heardLine.setTextColor(Color.parseColor("#94A3B8"))
                holder.scriptLine.text = "📖 剧本匹配：\n${if (m.scriptText.isBlank()) "(未匹配)" else m.scriptText}"
                holder.scriptLine.setTextColor(Color.parseColor("#7DD3FC"))
            } else {
                holder.heardLine.text = "🎤 视频内容诊断：\n${if (m.heardClean.isBlank()) "【纯伴奏/静音片段】" else "【乱码过长已过滤/无法匹配】"}"
                holder.heardLine.setTextColor(Color.parseColor("#F87171"))
                holder.scriptLine.text = "📖 剧本匹配：\n【未找到匹配项，请结合画面手动微调】"
                holder.scriptLine.setTextColor(Color.parseColor("#F87171"))
            }

            holder.lockBtn.text = if (m.locked) "🔓 解锁" else "🔒 锁定"
            holder.lockBtn.setBackgroundColor(Color.parseColor(scoreColor))
            
            holder.btnUp.isEnabled = position > 0
            holder.btnUp.alpha = if (position > 0) 1.0f else 0.5f
            holder.btnUp.setOnClickListener {
                CoroutineScope(Dispatchers.Main).launch {
                    bridge.moveUp(position)
                    bridge.recalculateMatchAt(position)
                    if (position - 1 >= 0) bridge.recalculateMatchAt(position - 1)
                    notifyItemMoved(position, position - 1)
                    notifyItemChanged(position - 1)
                    notifyItemChanged(position)
                    updateStats()
                }
            }

            holder.btnDown.isEnabled = position < bridge.allMatches.size - 1
            holder.btnDown.alpha = if (position < bridge.allMatches.size - 1) 1.0f else 0.5f
            holder.btnDown.setOnClickListener {
                CoroutineScope(Dispatchers.Main).launch {
                    bridge.moveDown(position)
                    bridge.recalculateMatchAt(position)
                    if (position + 1 < bridge.allMatches.size) bridge.recalculateMatchAt(position + 1)
                    notifyItemMoved(position, position + 1)
                    notifyItemChanged(position)
                    notifyItemChanged(position + 1)
                    updateStats()
                }
            }

            holder.lockBtn.setOnClickListener {
                CoroutineScope(Dispatchers.Main).launch {
                    bridge.toggleLock(position)
                    if (position - 1 >= 0) bridge.recalculateMatchAt(position - 1)
                    if (position + 1 < bridge.allMatches.size) bridge.recalculateMatchAt(position + 1)
                    
                    notifyItemChanged(position)
                    if (position - 1 >= 0) notifyItemChanged(position - 1)
                    if (position + 1 < bridge.allMatches.size) notifyItemChanged(position + 1)
                    updateStats()
                }
            }
        }

        override fun getItemCount(): Int = bridge.allMatches.size

        inner class ViewHolder(val card: LinearLayout, val header: TextView, val visualInfo: TextView, val heardLine: TextView, val scriptLine: TextView, val lockBtn: Button, val btnUp: Button, val btnDown: Button) : RecyclerView.ViewHolder(card)
    }

    private fun resetButtonStates() {
        btnImport.isEnabled = true
        btnMatch.isEnabled = true
        btnMatch.text = "🧠 开始对齐/拼接"
        btnStitch.isEnabled = true
        btnCalibrate.isEnabled = true
        btnCalibrate.text = "🔄 智能校对"
        btnGoCalibrate.isEnabled = bridge.allMatches.isNotEmpty()
        progressBar.visibility = View.GONE
        isCalibrating = false
    }

    private fun showMatchingModeDialog() {
        if (bridge.uploadedClips.isEmpty()) { Toast.makeText(this, "请先导入视频素材", Toast.LENGTH_SHORT).show(); return }
        val script = etScript.text.toString().trim()

        if (script.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("未输入剧本")
                .setMessage("您未粘贴剧本，是否直接按文件名顺序 (如 1, 2, 3...) 极速拼接视频？\n\n(前提：您的视频切片文件名已经按正确剧情顺序排列)")
                .setPositiveButton("确认极速拼接") { _, _ -> executeMatching("", true) }
                .setNegativeButton("取消", null)
                .show()
            return
        }

        if (!isModelsReady) { Toast.makeText(this, "AI 引擎尚未就绪，请稍候", Toast.LENGTH_SHORT).show(); return }

        val options = arrayOf(
            "🚀 极速直通模式（信任文件名数字顺序）",
            "🧠 AI 视听时间轴交叉验证（双轨互相印证 + 大模型判定）"
        )
        AlertDialog.Builder(this)
            .setTitle("请选择对齐模式")
            .setItems(options) { _, which ->
                val forceAI = (which == 1)
                executeMatching(script, forceAI)
            }
            .show()
    }

    private fun executeMatching(script: String, forceAI: Boolean) {
        Toast.makeText(this, if(script.isEmpty()) "启动：无剧本文件名极速盲拼..." else if(forceAI) "启动：AI 视听大模型深度校验..." else "启动：文件名极速排位...", Toast.LENGTH_SHORT).show()
        
        btnMatch.isEnabled = false; btnMatch.text = "🧠 正在处理..."
        btnStitch.isEnabled = false; btnImport.isEnabled = false; btnGoCalibrate.isEnabled = false
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = if(script.isEmpty()) "正在按文件名顺序极速拼接..." else if(forceAI) "AI 正在并行提取画面与语音，调用大模型深度校验..." else "正在解析文件名坐标..."
        calibrateRound = 0
        
        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                bridge.initialMatch(script, forceAI, onProgress = { p, msg ->
                    progressBar.progress = (p * 0.7).toInt()
                    tvStatus.text = msg
                }, onSuccess = {
                    tvStatus.text = "对齐/拼接完毕！"
                    progressBar.progress = 100
                    cardAdapter.notifyDataSetChanged()
                    updateStats()
                    Toast.makeText(this@MainActivity, "✅ 处理完成", Toast.LENGTH_LONG).show()
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                    
                    if (script.isEmpty()) {
                        Toast.makeText(this@MainActivity, "已按文件名排好，请直接点击渲染", Toast.LENGTH_LONG).show()
                    }
                }, onError = { err ->
                    tvStatus.text = "失败：$err"
                    tvStatus.setTextColor(Color.parseColor("#EF4444"))
                })
            } finally {
                launch {
                    delay(500)
                    resetButtonStates()
                }
            }
        }
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        currentJob?.cancel()
        Toast.makeText(this, "正在扫描相册文件夹...", Toast.LENGTH_SHORT).show()
        
        btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        tvStatus.text = "正在读取本地视频..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val folderMap = mutableMapOf<String, FolderInfo>()
                val projection = arrayOf(
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.BUCKET_DISPLAY_NAME
                )
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                cursor?.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                        val name = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        val folderName = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)) ?: "默认文件夹"
                        
                        val videoMap = mapOf("id" to id, "name" to name)
                        
                        if (!folderMap.containsKey(folderName)) {
                            folderMap[folderName] = FolderInfo(folderName, mutableListOf())
                        }
                        folderMap[folderName]?.videos?.add(videoMap)
                    }
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (folderMap.isEmpty()) { tvStatus.text = "未找到视频"; return@withContext }
                    showFolderSelectionDialog(folderMap.values.toList())
                }
            } catch (e: Throwable) { 
                withContext(Dispatchers.Main) { btnImport.isEnabled = true; tvStatus.text = "读取失败" } 
            }
        }
    }

    private fun showFolderSelectionDialog(folders: List<FolderInfo>) {
        val folderNames = folders.map { "${it.name} (${it.videos.size} 个视频)" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("请选择视频所在的文件夹")
            .setItems(folderNames) { _, which ->
                showVideoSelectionDialog(folders[which])
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showVideoSelectionDialog(folderInfo: FolderInfo) {
        val names = folderInfo.videos.map { it["name"] as String }.toTypedArray()
        val checkedItems = BooleanArray(folderInfo.videos.size)
        val checkBoxes = mutableListOf<CheckBox>()

        val scrollView = ScrollView(this)
        val listLayout = LinearLayout(this).apply { 
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 10)
            setBackgroundColor(Color.WHITE)
        }
        
        for (i in names.indices) {
            val cb = CheckBox(this).apply {
                text = names[i]
                setTextColor(Color.BLACK)
                textSize = 14f
                isChecked = false
                setOnCheckedChangeListener { _, isChecked -> checkedItems[i] = isChecked }
            }
            checkBoxes.add(cb)
            listLayout.addView(cb)
        }
        scrollView.addView(listLayout)
        
        val container = LinearLayout(this).apply { 
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        
        val cbAll = CheckBox(this).apply {
            text = "全选 / 取消全选"
            setTextColor(Color.BLACK)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(40, 20, 40, 10)
            setOnCheckedChangeListener { _, isChecked ->
                for (i in checkBoxes.indices) {
                    checkBoxes[i].isChecked = isChecked
                    checkedItems[i] = isChecked
                }
            }
        }
        
        container.addView(cbAll)
        container.addView(scrollView)

        AlertDialog.Builder(this)
            .setTitle("文件夹【${folderInfo.name}】中的视频")
            .setView(container)
            .setPositiveButton("确定导入") { _, _ ->
                val selected = mutableListOf<Map<String, Any>>()
                for (i in checkedItems.indices) if (checkedItems[i]) selected.add(folderInfo.videos[i])
                if (selected.isNotEmpty()) downloadSelectedVideos(selected)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun downloadSelectedVideos(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        btnImport.isEnabled = false
        tvStatus.text = "正在导入素材..."
        
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val successful = mutableListOf<String>()
            for (i in videos.indices) {
                val id = videos[i]["id"] as Long
                val name = videos[i]["name"] as String
                withContext(Dispatchers.Main) {
                    tvStatus.text = "正在处理 (${i+1}/${videos.size}): ${name.take(20)}"
                    progressBar.progress = ((i.toFloat() / videos.size) * 100).toInt()
                }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val destFile = File(bridge.uploadDir, name)
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
                    successful.add(name)
                } catch (e: Throwable) { }
                delay(1)
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                btnImport.isEnabled = true
                if (successful.isNotEmpty()) {
                    bridge.uploadedClips.clear()
                    bridge.uploadedClips.addAll(successful)
                    bridge.resetMatches()
                    
                    btnSave.visibility = View.GONE
                    btnSave.tag = null
                    btnGoCalibrate.isEnabled = false
                    
                    tvClipCount.text = "已导入素材：${successful.size} 个"
                    tvStatus.text = "素材导入成功，请点击对齐或盲拼"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                    
                    calibrateRound = 0
                    cardAdapter.notifyDataSetChanged()
                    updateStats()
                    resetButtonStates()
                }
            }
        }
    }

    private fun runCalibration() {
        if (isCalibrating || bridge.allMatches.isEmpty()) return
        
        Toast.makeText(this, "已点击，正在执行智能校对...", Toast.LENGTH_SHORT).show()
        isCalibrating = true
        btnCalibrate.isEnabled = false
        btnCalibrate.text = "🔄 计算中..."
        
        calibProgressBar.visibility = View.VISIBLE
        calibProgressBar.progress = 0
        calibStatus.text = "正在区间内重新真实比对..."
        calibStatus.setTextColor(Color.parseColor("#F59E0B"))

        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                val progressAnim = launch {
                    for (i in 1..90) {
                        delay(50)
                        calibProgressBar.progress = i
                    }
                }

                val result = withTimeoutOrNull(15000) { 
                    withContext(Dispatchers.Default) { bridge.smartCalibrateOnce() } 
                }
                
                progressAnim.cancel()
                calibProgressBar.progress = 100
                calibrateRound++
                cardAdapter.notifyDataSetChanged()
                updateStats()

                if (result != null && result.improvedCount > 0) {
                    Toast.makeText(this@MainActivity, "✅ 校对完成，更新了 ${result.improvedCount} 项位置", Toast.LENGTH_SHORT).show()
                    calibStatus.text = "第 ${calibrateRound} 轮：校准 ${result.improvedCount} 项 | 🟢绿 ${result.stillGreen} 🔴红 ${result.stillRed}"
                    calibStatus.setTextColor(Color.parseColor("#10B981"))
                } else {
                    Toast.makeText(this@MainActivity, "当前片段已校准完毕（或超时跳过），请手动微调剩余红项", Toast.LENGTH_LONG).show()
                    calibStatus.text = "第 ${calibrateRound} 轮：自动校准完成"
                    calibStatus.setTextColor(Color.parseColor("#F59E0B"))
                }
            } catch (e: Throwable) {
                calibStatus.text = "校准失败：${e.message}"
                calibStatus.setTextColor(Color.parseColor("#EF4444"))
            } finally {
                delay(500) 
                isCalibrating = false
                btnCalibrate.isEnabled = true
                btnCalibrate.text = "🔄 智能校对"
                calibProgressBar.visibility = View.GONE
            }
        }
    }

    private fun lockGreens() {
        val count = bridge.lockGreenItems()
        Toast.makeText(this, if (count > 0) "已锁定 $count 个绿项" else "没有未锁定的绿项", Toast.LENGTH_SHORT).show()
        cardAdapter.notifyDataSetChanged()
        updateStats()
    }

    private fun unlockAll() {
        val count = bridge.unlockAll()
        Toast.makeText(this, "已解锁 $count 项", Toast.LENGTH_SHORT).show()
        cardAdapter.notifyDataSetChanged()
        updateStats()
    }

    private fun updateStats() {
        if (bridge.allMatches.isEmpty()) {
            tvStats.text = "等待智能对齐..."
            return
        }
        val green = bridge.allMatches.count { it.score >= AndroidBridge.GREEN_THRESHOLD }
        val red = bridge.allMatches.size - green
        val locked = bridge.allMatches.count { it.locked }
        tvStats.text = "总计 ${bridge.allMatches.size} 段 | 🟢绿 $green 🔴红 $red | 🔒锁定 $locked"
        
        if (red == 0) {
            tvStats.setTextColor(Color.parseColor("#10B981"))
        } else {
            tvStats.setTextColor(Color.parseColor("#F59E0B"))
        }
    }

    private fun tryStartStitching() {
        if (bridge.allMatches.isEmpty()) { Toast.makeText(this, "请先完成对齐", Toast.LENGTH_SHORT).show(); return }
        
        val redCount = bridge.allMatches.count { it.score < AndroidBridge.GREEN_THRESHOLD && !it.locked }
        if (redCount > 0) {
            AlertDialog.Builder(this)
                .setTitle("⚠️ 存在未确认的片段")
                .setMessage("当前还有 $redCount 个红色片段未对齐。\n\n你可以进入校对台锁定，或者点击下方的【强行渲染】。\n强行渲染将按照当前的UI顺序直接拼接（请确保红项已手动移到正确位置）。")
                .setPositiveButton("去校对") { _, _ ->
                    mainScrollView.visibility = View.GONE
                    calibrateLayout.visibility = View.VISIBLE
                }
                .setNeutralButton("⚠️ 强行渲染") { _, _ ->
                    startStitchRenderingProcess()
                }
                .setNegativeButton("取消", null)
                .show()
            return
        }
        
        startStitchRenderingProcess()
    }

    private fun startStitchRenderingProcess() {
        // 【加固点2】渲染前二次验证授权，防止破解者通过修改内存绕过启动页
        if (!isAuthVerified) {
            Toast.makeText(this, "授权校验失败，禁止导出。", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        Toast.makeText(this, "已启动：正在渲染视频...", Toast.LENGTH_SHORT).show()
        
        btnStitch.isEnabled = false; btnMatch.isEnabled = false; btnImport.isEnabled = false; btnGoCalibrate.isEnabled = false
        btnSave.visibility = View.GONE
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "正在渲染原画质视频..."

        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                bridge.stitchVideo(bridge.buildEpisodesJsonByUIOrder(), onProgress = { p, msg ->
                    progressBar.progress = p; tvStatus.text = msg
                }, onSuccess = { finalFilePath ->
                    btnSave.visibility = View.VISIBLE; btnSave.tag = finalFilePath
                    btnSave.isEnabled = true
                    tvStatus.text = "渲染完成！请保存至相册"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                }, onError = { err ->
                    btnSave.visibility = View.GONE
                    tvStatus.text = "渲染失败：$err"
                    tvStatus.setTextColor(Color.parseColor("#EF4444"))
                })
            } finally {
                resetButtonStates()
            }
        }
    }

    private fun saveToGallery() {
        val filePath = btnSave.tag as? String
        if (filePath == null) return
        val sourceFile = File(filePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            Toast.makeText(this, "视频文件丢失，请重新渲染", Toast.LENGTH_SHORT).show()
            return
        }
        
        btnSave.isEnabled = false
        tvStatus.text = "正在保存 MP4..."
        
        CoroutineScope(Dispatchers.Main).launch {
            try {
                withContext(Dispatchers.IO) {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影")
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                    }
                    val resolver = contentResolver
                    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    val uri = resolver.insert(collection, contentValues)
                    uri?.let {
                        resolver.openOutputStream(it)?.use { output -> FileInputStream(sourceFile).use { input -> input.copyTo(output) } }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            contentValues.clear(); contentValues.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, contentValues, null, null)
                        }
                    }
                }
                Toast.makeText(this@MainActivity, "视频已保存至相册", Toast.LENGTH_LONG).show()
                btnSave.visibility = View.GONE
                tvStatus.text = "视频已保存至相册"
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "保存失败: ${e.message}", Toast.LENGTH_LONG).show()
                tvStatus.text = "保存失败"
            } finally {
                btnSave.isEnabled = true
            }
        }
    }
}