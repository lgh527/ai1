# ====== 加固专属混淆规则 ======
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontpreverify
-verbose

# 保留核心入口，防止混淆后闪退
-keep class com.lingxu.zhiying.MainActivity { *; }
-keep class com.lingxu.zhiying.AndroidBridge { *; }

# AI 模型与 FFmpeg 强制防混淆（这些库包含大量 JNI 反射）
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.google.gson.** { *; }
-keep class com.google.mlkit.** { *; }
-keep class com.google.mediapipe.** { *; }

# 防止 Activity 生命周期被混淆
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service

# 移除日志（防止破解者看日志找线索）
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}