package com.lingxu.zhiying.core

import android.content.Context
import com.lingxu.zhiying.model.AlignProgress
import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ClipFeature
import com.lingxu.zhiying.model.ScriptLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 对齐流水线总调度
 *
 * 视觉通道（抽帧 → 字幕带检测 → 动态放大 → ML Kit OCR）
 * 听觉通道（FFmpeg 提纯滤镜链 → PCM → 滑窗 → Sherpa-ONNX SenseVoice）
 * 逻辑通道（DP 全局时序对齐 → Gemma 深水区仲裁 → 帧哈希视觉归位）
 *
 * 全流程端侧离线，断网可用。
 */
class AlignOrchestrator(private val context: Context) {

    /** 一次完整对齐的产物，matrix 需保留给涟漪重排复用 */
    class AlignResult(
        val clips: MutableList<AlignedClip>,
        val matrix: Array<Array<DpAligner.Cell>>,
        val lines: List<ScriptLine>,
        val stats: Stats,
        val diagnostics: Diagnostics.Report? = null,
        val naturalMap: Map<Int, Int> = emptyMap()
    )

    data class Stats(
        val totalClips: Int,
        val matched: Int,
        val byLlm: Int,
        val byHash: Int,
        val asrAvailable: Boolean,
        val llmAvailable: Boolean
    )

    /** 可变计数器，特征提取时逐片段累加 */
    class DiagCounter {
        var probedOk = 0
        var probeFail = 0
        var readFail = 0
        val notes = ArrayList<String>()
        var framesOk = 0
        var subtitleBandFound = 0
        var ocrNonEmpty = 0
        var audioExtractOk = 0
        var asrNonEmpty = 0
    }

    companion object {
        /** 单个片段最多分析的帧数，控制耗时与内存 */
        private const val MAX_FRAMES_PER_CLIP = 24
    }

    private val frameExtractor = FrameExtractor(context)
    private val audioPipeline = AudioPipeline(context)
    private val concatEngine = ConcatEngine(context)

    fun run(
        selectedUris: List<String>,
        lines: List<ScriptLine>,
        subtitleZoomEnabled: Boolean,
        audioGainEnabled: Boolean,
        enableLlm: Boolean,
        autoSilenceTrim: Boolean = false,
        episodeNames: List<String> = emptyList()
    ): Flow<AlignProgress> = flow {
        val total = selectedUris.size
        if (total == 0) {
            emit(AlignProgress("结束", 0, 0, "没有选中任何素材"))
            return@flow
        }

        // ---------- 极速直拼：没有剧本时按文件名自然序直接出片 ----------
        if (lines.isEmpty()) {
            emit(AlignProgress("极速直拼", 0, total, "未提供剧本，按文件名自然序排列"))
            val order = NaturalOrder.sortedIndices(selectedUris.map { it.substringAfterLast('/') })
            val quick = order.mapIndexed { newIdx, oldIdx ->
                val name = selectedUris[oldIdx].substringAfterLast('/')
                AlignedClip(
                    order = newIdx + 1,
                    feature = ClipFeature(newIdx, selectedUris[oldIdx], name),
                    naturalPos = newIdx
                )
            }.toMutableList()
            lastResult = AlignResult(
                quick, Array(quick.size) { arrayOf(DpAligner.Cell(1f, 0f, 0f)) }, lines,
                Stats(total, 0, 0, 0, false, false)
            )
            emit(AlignProgress("完成", total, total, "极速直拼就绪：$total 个片段按自然序排列，可直接渲染导出"))
            return@flow
        }

        // ---------- 阶段 0：初始化模型 ----------
        emit(AlignProgress("初始化", 0, total, "加载端侧 OCR 引擎…"))
        OcrEngine.init(context)

        emit(AlignProgress("初始化", 0, total, "加载 SenseVoice 语音模型…"))
        val asrOk = withContext(Dispatchers.IO) { AsrEngine.init(context) }

        var llmOk = false
        if (enableLlm) {
            emit(AlignProgress("初始化", 0, total, "加载 Gemma-2B-IT 端侧大模型…"))
            llmOk = withContext(Dispatchers.IO) {
                LlmArbiter.init(context) { msg -> LogX.i("LlmArbiter", msg) }
            }
        }

        // ---------- 阶段 1：逐片段提取多模态特征 ----------
        // 先按文件名自然序排一遍：切片命名通常接近剧情顺序，这个先验能显著降低误判
        MediaResolver.resetStats()
        val diag = DiagCounter()
        val naturalOrder = NaturalOrder.sortedIndices(selectedUris.map { it.substringAfterLast('/') })
        val features = ArrayList<ClipFeature>(total)
        naturalOrder.forEachIndexed { idx, srcIdx ->
            val uriStr = selectedUris[srcIdx]
            val name = uriStr.substringAfterLast('/')
            emit(AlignProgress("特征提取", idx + 1, total, "正在分析 ${idx + 1}/$total：$name"))

            val feature = withContext(Dispatchers.IO) {
                extractOne(uriStr, idx, subtitleZoomEnabled, audioGainEnabled, asrOk, autoSilenceTrim, diag)
            }
            feature.episode = episodeNames.getOrElse(srcIdx) { "" }
            features.add(feature)
            // 及时释放帧缓存，避免手机存储被打满
            frameExtractor.clean(idx)
        }
        val naturalPos = IntArray(features.size) { it }

        // ---------- 阶段 1.5：失败快停 ----------
        // 如果 OCR 和 ASR 一条都没出来，得分矩阵必然全 0，DP 排出来的顺序等同于随机。
        // 这种情况下继续往下走只会交付一份"看起来是结果"的乱序，必须立刻停下并给出诊断。
        val anyOcr = features.any { it.ocrText.isNotBlank() }
        val anyAsr = features.any { it.asrText.isNotBlank() }
        if (!anyOcr && !anyAsr) {
            val rep = Diagnostics.Report(
                totalClips = total,
                probedOk = diag.probedOk,
                framesOk = diag.framesOk,
                subtitleBandFound = diag.subtitleBandFound,
                ocrNonEmpty = 0,
                asrAvailable = asrOk,
                asrNonEmpty = 0,
                audioExtractOk = diag.audioExtractOk,
                llmAvailable = false,
                matched = 0,
                modelFiles = Diagnostics.listModels(context),
                notes = (listOf(
                    "读取失败 ${diag.readFail} / 探针失败 ${diag.probeFail} / 共 $total",
                    "SAF 直读模式 ${MediaResolver.contentModeCount} 个",
                    "MediaResolver: ${MediaResolver.lastError}",
                    AsrEngine.unavailableReason.ifBlank { "ASR 引擎状态未知" },
                    "OCR 有输出片段数 = 0，ASR 有输出片段数 = 0"
                ) + diag.notes).filter { it.isNotBlank() }.toMutableList()
            )
            diagReport = rep
            lastResult = null
            emit(AlignProgress("已中止", total, total,
                "特征提取全空，已停止对齐（避免把随机顺序当成结果）。\n" + rep.verdict()))
            return@flow
        }

        // ---------- 阶段 2：DP 全局时序对齐 ----------
        emit(AlignProgress("时序对齐", total, total, "构建二维得分矩阵并求解全局最优路径…"))
        val matrix = DpAligner.buildMatrix(features, lines, naturalPos)
        val assignment = DpAligner.solve(matrix)

        val clips = features.mapIndexed { i, f ->
            AlignedClip(
                order = i + 1,
                feature = f,
                trimInMs = f.suggestTrimIn,
                trimOutMs = f.suggestTrimOut,
                naturalPos = i
            )
        }.toMutableList()
        DpAligner.apply(clips, matrix, assignment)

        // ---------- 阶段 3：大模型深水区仲裁 ----------
        var byLlm = 0
        if (llmOk) {
            val ambiguous = clips.indices.filter { i ->
                val s = clips[i].finalScore
                LlmArbiter.needArbitration(s) && clips[i].extractedText().isNotBlank() && lines.isNotEmpty()
            }
            ambiguous.forEachIndexed { k, i ->
                emit(AlignProgress("大模型仲裁", k + 1, ambiguous.size, "第 ${i + 1} 个片段得分模糊，交由 Gemma 判断…"))
                val clip = clips[i]
                val current = clip.scriptIndex
                val window = candidateWindow(current, lines.size)
                val candidates = window.map { j -> LlmArbiter.Candidate(j, lines[j].text, lines[j].role) }
                val verdict = withContext(Dispatchers.IO) {
                    LlmArbiter.arbitrate(clip.extractedText(), candidates)
                }
                // 冲突检查：目标坐标若已被「锁定」或「高置信」片段占用，则不改判，避免越修越乱
                val occupied = verdict != null && clips.any { other ->
                    other !== clip && other.scriptIndex == verdict &&
                            (other.locked || other.finalScore >= 0.65f)
                }
                if (verdict != null && verdict in lines.indices && !occupied) {
                    clip.scriptIndex = verdict
                    clip.byLlm = true
                    clip.finalScore = (clip.finalScore + 0.25f).coerceAtMost(1f)
                    if (verdict < matrix[i].size) {
                        val cell = matrix[i][verdict]
                        clip.visualScore = cell.visual
                        clip.audioScore = cell.audio
                    }
                    byLlm++
                }
            }
        }

        // ---------- 阶段 4：静音/无字幕片段的视觉归位 ----------
        var byHash = 0
        val sortedForAnchor = clips.sortedBy { if (it.scriptIndex < 0) Int.MAX_VALUE else it.scriptIndex }
        val empties = clips.filter { it.scriptIndex < 0 && it.feature.ocrText.isBlank() && it.feature.asrText.isBlank() }
        empties.forEachIndexed { k, target ->
            emit(AlignProgress("视觉归位", k + 1, maxOf(1, empties.size), "第 ${target.order} 个片段无文本信号，比对帧哈希…"))
            val anchors = sortedForAnchor.filter { it !== target && it.scriptIndex >= 0 && it.feature.headHash != 0L }
            val placement = HashAnchor.place(target, anchors)
            if (placement != null) {
                val near = anchors.getOrElse(placement.position - 1) { anchors.firstOrNull() }
                if (near != null) {
                    target.scriptIndex = near.scriptIndex
                    target.byHash = true
                    target.finalScore = placement.similarity
                    byHash++
                }
            }
        }

        // ---------- 阶段 4.5：场景聚类 + 同词不同人的先后排序 ----------
        emit(AlignProgress("场景辨识", total, total, "用色彩直方图区分同词不同人的先后…"))
        val scenes = features.map { it.scene }
        val groups = if (scenes.any { it.histogram.sum() > 0f }) {
            SceneFingerprint.cluster(scenes)
        } else IntArray(features.size) { -1 }
        features.forEachIndexed { i, f -> f.sceneGroup = groups.getOrElse(i) { -1 } }
        clips.forEach { c ->
            val gi = features.indexOfFirst { it.id == c.feature.id }
            if (gi >= 0) c.feature.sceneGroup = groups.getOrElse(gi) { -1 }
        }
        val naturalMap = HashMap<Int, Int>()
        naturalOrder.forEachIndexed { pos, srcIdx -> naturalMap[srcIdx] = pos }
        features.forEach { f -> naturalMap[f.id]?.let { f.naturalPosRef = it } }
        val reorderedGroups = SameCoordOrderer.applyAll(clips, naturalMap)

        // ---------- 阶段 4.6：重复片段检测（拼接不能有重复画面） ----------
        val duplicates = DuplicateDetector.scan(clips)

        // ---------- 阶段 5：按剧本坐标排序输出 ----------
        emit(AlignProgress("整理顺序", total, total, "按剧情时间线重排卡片…"))
        clips.forEachIndexed { i, c -> c.order = i + 1 }
        clips.sortWith(compareBy({ if (it.scriptIndex < 0) 1 else 0 }, { it.scriptIndex }, { it.order }))
        clips.forEachIndexed { i, c -> c.order = i + 1 }
        // 矩阵行必须跟随卡片一起移动，涟漪重排才能拿到正确得分
        reorderMatrix(matrix, clips, features)
        clips.forEach { c ->
            if (c.scriptIndex in lines.indices) {
                c.matchedScriptText = lines[c.scriptIndex].text
                // 只保留与这句剧本对应的那段提取文本，其余一律不显示
                val extracted = if (c.feature.asrText.isNotBlank()) c.feature.asrText else c.feature.ocrText
                c.matchedExtract = TextSimilarity.bestSpan(c.matchedScriptText, extracted)
            } else {
                c.matchedScriptText = ""
                c.matchedExtract = ""
            }
        }

        val matched = clips.count { it.scriptIndex >= 0 }
        val report = CoverageChecker.check(clips, lines)
        coverageReport = report
        diagReport = Diagnostics.Report(
            totalClips = total,
            probedOk = diag.probedOk,
            framesOk = diag.framesOk,
            subtitleBandFound = diag.subtitleBandFound,
            ocrNonEmpty = diag.ocrNonEmpty,
            asrAvailable = asrOk,
            asrNonEmpty = diag.asrNonEmpty,
            audioExtractOk = diag.audioExtractOk,
            llmAvailable = llmOk,
            matched = matched,
            modelFiles = Diagnostics.listModels(context),
            notes = (listOf(
                "读取失败 ${diag.readFail} 个，探针失败 ${diag.probeFail} 个",
                "SAF 直读模式 ${MediaResolver.contentModeCount} 个",
                MediaResolver.lastError,
                "场景分组 ${groups.filter { it >= 0 }.distinct().size} 个",
                "同词片段重排 $reorderedGroups 组",
                "检出重复片段 ${duplicates.size} 段"
            ) + diag.notes).filter { it.isNotBlank() }.toMutableList()
        )
        emit(
            AlignProgress(
                "完成", total, total,
                "对齐完成：$matched/$total 命中剧本，仲裁 $byLlm 处，帧归位 $byHash 处\n" +
                        report.summary(lines)
            )
        )
        lastResult = AlignResult(
            clips, matrix, lines,
            Stats(total, matched, byLlm, byHash, asrOk, llmOk),
            diagReport,
            naturalMap
        )
    }.flowOn(Dispatchers.Default)

    /** 供 UI 层取回最近一次对齐结果 */
    var lastResult: AlignResult? = null
        private set

    /** 最近一次覆盖率报告，UI 的「📊 对齐体检」按钮直接读它 */
    var coverageReport: CoverageChecker.Report? = null
        private set

    /** 最近一次管线自检报告，UI 的「🩺 为什么没排对」按钮读它 */
    var diagReport: Diagnostics.Report? = null
        private set

    /** 最近一次检出的重复片段 */
    var duplicates: List<DuplicateDetector.Duplicate> = emptyList()
        private set

    private fun extractOne(
        uriStr: String,
        clipId: Int,
        subtitleZoom: Boolean,
        audioGain: Boolean,
        asrOk: Boolean,
        autoSilenceTrim: Boolean,
        diag: DiagCounter,
        episode: String = ""
    ): ClipFeature {
        // content:// 既可能走本地复制路径，也可能直接交给 FFmpegKit 的 SAF 通道
        val resolved = if (uriStr.startsWith("content://")) {
            MediaResolver.resolve(context, android.net.Uri.parse(uriStr))
        } else {
            MediaResolver.Resolved(uriStr, uriStr.substringAfterLast('/'), 0L, true)
        }
        if (resolved == null) {
            diag.readFail++
            diag.notes.add("片段#$clipId 读取失败：${MediaResolver.lastError}")
            LogX.e("Align", "片段#$clipId 读取失败：${MediaResolver.lastError}")
            return ClipFeature(
                id = clipId, uri = uriStr,
                displayName = uriStr.substringAfterLast('/')
            )
        }
        val path = resolved.path

        val info = VideoProbe.probe(path)
        if (info.width > 0 || info.durationMs > 0) {
            diag.probedOk++
        } else {
            diag.probeFail++
            diag.notes.add("片段#$clipId 探针失败（FFmpeg 打不开 ${if (resolved.isLocalFile) "本地文件" else "SAF URI"}）")
        }
        val feature = ClipFeature(
            id = clipId,
            uri = uriStr,
            displayName = uriStr.substringAfterLast('/'),
            episode = episode,
            durationMs = info.durationMs,
            width = info.width,
            height = info.height
        )

        // 首尾帧 aHash + 场景指纹（用于区分「同一句歌词、不同人先后演唱」）
        try {
            val (head, tail) = frameExtractor.extractHeadTail(path, clipId)
            feature.headHash = PerceptualHash.aHash(head)
            feature.tailHash = if (tail != null) PerceptualHash.aHash(tail) else feature.headHash
            feature.scene = SceneFingerprint.of(head, tail, feature.headHash, feature.tailHash)
            head?.recycle(); tail?.recycle()
        } catch (e: Throwable) {
            LogX.w("Align", "aHash / 场景指纹提取失败: ${e.message}")
        }

        // 抽帧 + 字幕带跨帧投票 + OCR
        try {
            val frames = frameExtractor.extract(path, clipId).take(MAX_FRAMES_PER_CLIP)
            feature.frameCount = frames.size
            val bitmaps = ArrayList<android.graphics.Bitmap>()
            var sheet: SubtitleBand.VoteSheet? = null
            frames.forEach { file ->
                val bmp = frameExtractor.decodeSampled(file.absolutePath, 720) ?: return@forEach
                if (sheet == null) sheet = SubtitleBand.VoteSheet(bmp.height)
                sheet?.accumulate(bmp)
                bitmaps.add(bmp)
            }
            // 字幕在整段视频里位置固定，用累计票数最高的行带，比逐帧判定稳得多
            val band = sheet?.bestBand() ?: bitmaps.firstOrNull()?.let { SubtitleBand.detect(it) }
            feature.hasSubtitleBand = band != null
            val texts = ArrayList<String>()
            bitmaps.forEachIndexed { i, bmp ->
                val t = if (band != null) {
                    val enhanced = SubtitleBand.cropAndEnhance(bmp, band, subtitleZoom)
                    val r = OcrEngine.recognize(enhanced)
                    if (enhanced !== bmp) enhanced.recycle()
                    r
                } else if (i % 4 == 0) {
                    OcrEngine.recognize(bmp)   // 无字幕带时隔几帧做一次全屏兜底
                } else ""
                if (t.isNotBlank()) texts.add(t)
                bmp.recycle()
            }
            feature.ocrText = OcrEngine.mergeFrames(texts)
            if (frames.isNotEmpty()) diag.framesOk++
            if (feature.hasSubtitleBand) diag.subtitleBandFound++
            if (feature.ocrText.isNotBlank()) diag.ocrNonEmpty++
        } catch (e: Throwable) {
            LogX.e("Align", "视觉管线失败", e)
        }

        // 音频提纯 + ASR
        if (asrOk) {
            try {
                val wav = audioPipeline.extract(path, clipId, audioGain)
                if (wav != null) {
                    diag.audioExtractOk++
                    val pcm = audioPipeline.readPcm(wav)
                    val windows = audioPipeline.windows(pcm)
                    feature.asrText = AsrEngine.transcribeWithWindows(windows)
                    if (feature.asrText.isNotBlank()) diag.asrNonEmpty++
                }
            } catch (e: Throwable) {
                LogX.e("Align", "听觉管线失败", e)
            } finally {
                audioPipeline.clean(clipId)
            }
        }

        // 自动去静音：给出建议入出点，用户仍可在校对卡片上手动改
        if (autoSilenceTrim) {
            try {
                SilenceTrimmer.detect(path)?.let { t ->
                    feature.suggestTrimIn = t.inMs
                    feature.suggestTrimOut = t.outMs
                }
            } catch (e: Throwable) {
                LogX.w("Align", "静音检测失败: ${e.message}")
            }
        }

        LogX.i(
            "Align",
            "片段#$clipId 时长${info.durationMs}ms OCR=${feature.ocrText.length}字 ASR=${feature.asrText.length}字 " +
                    "字幕带=${feature.hasSubtitleBand} aHash=${PerceptualHash.toHex(feature.headHash)}"
        )
        return feature
    }

    /** 取仲裁候选窗口：当前句前后各 2 句 */
    private fun candidateWindow(current: Int, lineCount: Int): List<Int> {
        val center = current.coerceIn(0, maxOf(0, lineCount - 1))
        val lo = (center - 2).coerceAtLeast(0)
        val hi = (center + 2).coerceAtMost(lineCount - 1)
        return (lo..hi).toList()
    }

    /** 按 clips 的新顺序重排 matrix 行 */
    private fun reorderMatrix(
        matrix: Array<Array<DpAligner.Cell>>,
        clips: List<AlignedClip>,
        features: List<ClipFeature>
    ) {
        val idToRow = HashMap<Int, Int>()
        features.forEachIndexed { row, f -> idToRow[f.id] = row }
        val order = clips.mapNotNull { idToRow[it.feature.id] }
        if (order.size != matrix.size) return
        val snapshot = matrix.map { it.clone() }.toTypedArray()
        order.forEachIndexed { newRow, oldRow ->
            if (oldRow in snapshot.indices && newRow in matrix.indices) {
                matrix[newRow] = snapshot[oldRow]
            }
        }
    }

    private fun AlignedClip.extractedText(): String =
        if (feature.asrText.isNotBlank()) feature.asrText else feature.ocrText

    /** 第四步：渲染导出（自动应用卡片上的裁剪入出点） */
    suspend fun renderAndExport(
        items: List<ConcatEngine.TrimItem>,
        mode: ConcatEngine.Mode = ConcatEngine.Mode.AUTO
    ): Pair<android.net.Uri?, File?> = withContext(Dispatchers.IO) {
        val out = concatEngine.concatTrimmed(items, mode) { msg -> LogX.i("Render", msg) }
        if (out == null) return@withContext null to null
        val uri = GalleryExporter.export(context, out)
        uri to out
    }

    /**
     * 🔬 单片段试跑（排障利器）
     *
     * 只处理一个视频，把每一环的中间产物全部摊开：
     * 探针 → 抽帧数 → 字幕带位置 → 原始 OCR 文本 → WAV 体积 → PCM 采样数 → ASR 文本 → aHash。
     * 哪一环是空的，一眼就能看出来，不用再连电脑看 logcat。
     */
    suspend fun selfTest(uriStr: String): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        try {
            val path = if (uriStr.startsWith("content://")) {
                MediaResolver.resolve(context, android.net.Uri.parse(uriStr))?.path
            } else uriStr
            if (path == null) return@withContext "❌ 第 0 环就断了：无法把 Uri 解析成可读文件路径\n$uriStr"
            val f = java.io.File(path)
            sb.append("【文件】\n").append(path).append("\n")
            sb.append("存在=").append(f.exists()).append(" 可读=").append(f.canRead())
            sb.append(" 大小=").append(f.length() / 1024).append("KB\n\n")

            val info = VideoProbe.probe(path)
            sb.append("【探针】\n时长=${info.durationMs}ms 分辨率=${info.width}x${info.height}")
            sb.append(" 视频编码=${info.vCodec} 音频编码=${info.aCodec}\n")
            if (info.width <= 0) sb.append("⚠️ 探针拿不到分辨率，FFmpeg/FFprobe 可能没正常工作\n")
            sb.append("\n")

            OcrEngine.init(context)
            val frames = frameExtractor.extract(path, 9999)
            sb.append("【抽帧】fps=2 实际得到 ").append(frames.size).append(" 张\n")
            if (frames.isEmpty()) {
                sb.append("❌ 抽帧为 0，后面的 OCR 不可能有结果\n")
            } else {
                val sheet = SubtitleBand.VoteSheet(
                    frameExtractor.decodeSampled(frames[0].absolutePath, 720)?.height ?: 720
                )
                val bitmaps = ArrayList<android.graphics.Bitmap>()
                frames.take(12).forEach { file ->
                    frameExtractor.decodeSampled(file.absolutePath, 720)?.let { bmp ->
                        sheet.accumulate(bmp); bitmaps.add(bmp)
                    }
                }
                val band = sheet.bestBand()
                sb.append("【字幕带】投票帧数=").append(sheet.frames)
                sb.append(" 结果=").append(
                    if (band == null) "未检测到" else "top=${band.top} bottom=${band.bottom} 高=${band.height} 票数=${band.votes}"
                ).append("\n")
                sb.append("【OCR 原文】\n")
                bitmaps.forEachIndexed { i, bmp ->
                    val raw = if (band != null) {
                        val e = SubtitleBand.cropAndEnhance(bmp, band, true)
                        OcrEngine.recognize(e).also { if (e !== bmp) e.recycle() }
                    } else OcrEngine.recognize(bmp)
                    if (raw.isNotBlank() || i < 3) sb.append("  帧").append(i + 1).append(": ").append(raw.ifBlank { "（空）" }).append("\n")
                    bmp.recycle()
                }
                sb.append("合并去重后: ").append(
                    OcrEngine.mergeFrames(bitmaps.map { "" }).ifBlank { "（无）" }
                ).append("\n")
            }
            sb.append("\n")

            val asrOk = AsrEngine.init(context)
            sb.append("【ASR 引擎】可用=").append(asrOk)
            if (!asrOk) sb.append(" 原因=").append(AsrEngine.unavailableReason)
            sb.append("\n")
            if (asrOk) {
                val wav = audioPipeline.extract(path, 9999, true)
                sb.append("【音频】WAV=").append(if (wav == null) "提取失败" else "${wav.length() / 1024}KB").append("\n")
                if (wav != null) {
                    val pcm = audioPipeline.readPcm(wav)
                    sb.append("PCM 采样数=").append(pcm.size)
                    sb.append(" ≈").append(pcm.size / 16000).append("秒\n")
                    val windows = audioPipeline.windows(pcm)
                    sb.append("滑窗数=").append(windows.size).append("\n")
                    sb.append("【ASR 结果】").append(AsrEngine.transcribeWithWindows(windows).ifBlank { "（空）" }).append("\n")
                }
                audioPipeline.clean(9999)
            }

            val (head, tail) = frameExtractor.extractHeadTail(path, 9999)
            sb.append("\n【视觉指纹】首帧 aHash=").append(PerceptualHash.toHex(PerceptualHash.aHash(head)))
            sb.append(" 尾帧=").append(PerceptualHash.toHex(PerceptualHash.aHash(tail))).append("\n")
            head?.recycle(); tail?.recycle()
            frameExtractor.clean(9999)
        } catch (e: Throwable) {
            sb.append("\n❌ 试跑异常：").append(e.javaClass.simpleName).append(" ").append(e.message)
            LogX.e("SelfTest", "异常", e)
        }
        sb.toString()
    }

    fun cleanup() {
        frameExtractor.cleanAll()
        audioPipeline.cleanAll()
        concatEngine.cleanAll()
    }
}
