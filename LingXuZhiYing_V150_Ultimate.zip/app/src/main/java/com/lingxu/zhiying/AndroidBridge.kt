package com.lingxu.zhiying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

data class ClipMatch(
    val id: Int,
    val clipName: String,
    val heardText: String,
    val heardClean: String,
    var scriptText: String,
    var coord: Int,
    var score: Float,
    var locked: Boolean = false,
    val rawOcr: String = "",
    val rawAsr: String = "",
    val visualHash: String = "",
    val firstFrameHash: String = "",
    val lastFrameHash: String = "",
    val durationSec: Float = 0f
)

data class CalibrateResult(val improvedCount: Int, val stillRed: Int, val stillGreen: Int)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.60f
        const val YELLOW_THRESHOLD = 0.30f
        const val IMPROVE_EPSILON = 0.03f
        const val STRICT_CHAR_THRESHOLD = 0.60f
        const val STRICT_PINYIN_THRESHOLD = 0.55f
        const val STRICT_SCORE_THRESHOLD = 0.70f
        const val CONFLICT_WINDOW = 50
        const val LLM_MAX_CLIPS = 12
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()

    private var scriptClean: String = ""
    private var scriptFull: String = ""
    private var speakerLines: List<Pair<String, String>> = emptyList()

    private var enableZoom = true
    private var enableAudioBoost = true

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null
    private val vocabMap = mutableMapOf<String, Int>()
    private val textRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private var llmInference: LlmInference? = null
    private var isLlmReady = false
    private var calibratePass = 0

    init {
        scope.launch {
            try {
                copyLargeModelFromAssets(); copyAssetsToFiles(); loadVocab(); initASR(); initLLM()
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            }
        }
    }

    fun setEnhanceOptions(zoom: Boolean, audio: Boolean) {
        enableZoom = zoom
        enableAudioBoost = audio
    }

    private fun copyLargeModelFromAssets() {
        val modelName = "gemma-2b-it-gpu-int4.bin"
        val outFile = File(modelDir, modelName)
        if (outFile.exists() && outFile.length() > 0) return
        try {
            context.assets.open("models/$modelName").use { input -> FileOutputStream(outFile).use { input.copyTo(it) } }
        } catch (e: Throwable) { }
    }

    private fun initLLM() {
        try {
            val modelFile = File(modelDir, "gemma-2b-it-gpu-int4.bin")
            if (modelFile.exists()) {
                val options = LlmInferenceOptions.builder().setModelPath(modelFile.absolutePath).setMaxTokens(512).build()
                llmInference = LlmInference.createFromOptions(context, options)
                isLlmReady = true
            }
        } catch (e: Throwable) { isLlmReady = false }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach {
                    if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_") || it.name.startsWith("ocr_") || it.name.startsWith("asr_") || it.name.startsWith("zoom_")) it.delete()
                }
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) { }
        }
    }

    fun resetMatches() { allMatches.clear(); scriptClean = ""; scriptFull = ""; speakerLines = emptyList(); calibratePass = 0 }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        for (file in listOf("model.int8.onnx", "tokens.txt")) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try { assets.open("models/$file").use { input -> FileOutputStream(outFile).use { output -> input.copyTo(output) } } } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun loadVocab() {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            if (!tokensFile.exists()) return
            tokensFile.forEachLine { line ->
                val parts = line.trim().split(" ")
                if (parts.size >= 2) vocabMap[parts[0]] = parts[1].toIntOrNull() ?: 0
            }
        } catch (e: Throwable) { }
    }

    private fun cleanAndFilterText(text: String): String {
        var cleaned = text.replace(Regex("[^\\u4e00-\\u9fa5a-zA-Z]"), "")
        val watermarks = listOf("抖音","快手","号","aqwbQ","安庆晚报","字幕组","关注","点赞",
            "转发","评论","完整版","致谢","宣传部","政府","促进会","作词","作曲",
            "原唱","音乐人","安庆","官方","版权","中共","市委","文化","有限","公司")
        for (wm in watermarks) cleaned = cleaned.replace(wm, "")
        return cleaned
    }

    private fun parseScript(raw: String): Pair<String, List<Pair<String, String>>> {
        val result = mutableListOf<Pair<String, String>>()
        val pureLines = mutableListOf<String>()
        val bracketRegex = Regex("""^\s*[【\[]([^】\]\s]{1,6})[】\]]\s*(.+)$""")
        val colonRegex = Regex("""^\s*([\u4e00-\u9fa5A-Za-z]{1,6})\s*[:：]\s*(.+)$""")
        raw.lines().forEach { rawLine ->
            val line = rawLine.trim()
            if (line.isEmpty()) return@forEach
            val bs = bracketRegex.find(line)
            if (bs != null) {
                val sp = bs.groupValues[1].trim()
                val tx = cleanAndFilterText(bs.groupValues[2])
                if (tx.isNotEmpty()) { result.add(sp to tx); pureLines.add(tx) }
                return@forEach
            }
            val cs = colonRegex.find(line)
            if (cs != null) {
                val sp = cs.groupValues[1].trim()
                val tx = cleanAndFilterText(cs.groupValues[2])
                if (tx.isNotEmpty()) { result.add(sp to tx); pureLines.add(tx) }
                return@forEach
            }
            val tx = cleanAndFilterText(line)
            if (tx.isNotEmpty()) { result.add("" to tx); pureLines.add(tx) }
        }
        return pureLines.joinToString("") to result
    }

    private fun convertToPinyin(text: String): String {
        val sb = StringBuilder()
        for (char in text) {
            if (char.code in 0x4E00..0x9FFF) {
                val py = android.icu.text.Transliterator.getInstance("Han-Latin/Names; Latin-ASCII; Lower").transliterate(char.toString())
                sb.append(py.replace(" ", ""))
            } else sb.append(char.lowercaseChar())
        }
        return sb.toString()
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) dp[cur][j] = if (s1[i - 1] == s2[j - 1]) dp[prev][j - 1] + 1 else maxOf(dp[prev][j], dp[cur][j - 1])
        }
        return dp[m % 2][n]
    }

    private fun lcsEndOffset(heard: String, window: String): Int {
        val m = heard.length; val n = window.length
        if (m == 0 || n == 0) return 0
        val dp = Array(m + 1) { IntArray(n + 1) }
        var endJ = 0; var maxV = 0
        for (i in 1..m) for (j in 1..n) {
            dp[i][j] = if (heard[i - 1] == window[j - 1]) dp[i - 1][j - 1] + 1 else maxOf(dp[i - 1][j], dp[i][j - 1])
            if (dp[i][j] > maxV) { maxV = dp[i][j]; endJ = j }
        }
        return endJ
    }

    private fun hammingDistance(h1: String, h2: String): Int {
        if (h1.length != 64 || h2.length != 64) return 64
        var d = 0
        for (i in 0 until 64) if (h1[i] != h2[i]) d++
        return d
    }

    private fun adjacencyScore(prevLast: String, currFirst: String): Float {
        if (prevLast.length != 64 || currFirst.length != 64) return 0.5f
        return 1f - hammingDistance(prevLast, currFirst) / 64f
    }

    data class PosScore(val pos: Int, val score: Float, val window: String)
    private data class FusionResult(val pos: Int, val score: Float, val source: String, val window: String)

    private fun searchInRangeStrict(
        longText: String, script: String, hint: Int,
        rangeMin: Int, rangeMax: Int, isCalibration: Boolean
    ): List<PosScore> {
        if (longText.length < 3) return emptyList()
        val heardLen = longText.length
        val heardPinyin = convertToPinyin(longText)
        if (heardPinyin.isEmpty()) return emptyList()

        val results = mutableListOf<PosScore>()
        val step = if (isCalibration) 1 else 2

        val chunks: List<String> = if (heardLen <= 20) listOf(longText)
        else (0 until heardLen step 15).mapNotNull { start ->
            val end = minOf(start + 15, heardLen)
            if (end - start >= 3) longText.substring(start, end) else null
        }

        for (chunk in chunks) {
            val chunkPinyin = convertToPinyin(chunk)
            if (chunkPinyin.isEmpty()) continue
            val windowSize = minOf(chunk.length + 15, script.length - rangeMin)
            if (windowSize < (chunk.length * 0.7f).toInt()) continue
            var pos = rangeMin
            val maxPos = minOf(rangeMax - windowSize, script.length - windowSize)
            while (pos <= maxPos) {
                val window = script.substring(pos, pos + windowSize)
                val lenRatio = minOf(chunk.length, windowSize).toFloat() / maxOf(chunk.length, windowSize)
                if (lenRatio >= 0.6f) {
                    val windowPinyin = convertToPinyin(window)
                    val scoreText = lcsLength(chunk, window).toFloat() / chunk.length
                    val scorePinyin = lcsLength(chunkPinyin, windowPinyin).toFloat() / chunkPinyin.length
                    val strictScore = if (scoreText >= STRICT_CHAR_THRESHOLD && scorePinyin >= STRICT_PINYIN_THRESHOLD) {
                        (scoreText + scorePinyin) / 2f
                    } else maxOf(scoreText, scorePinyin) * 0.7f
                    if (strictScore >= 0.4f) results.add(PosScore(pos, strictScore, window))
                }
                pos += step
            }
        }

        return results.sortedByDescending { it.score }.distinctBy { it.pos / 15 }.take(3)
    }

    private suspend fun llmArbitrate(ocr: String, asr: String, candidates: List<PosScore>, prevContext: String, nextContext: String): PosScore? = withContext(Dispatchers.Default) {
        if (!isLlmReady || llmInference == null || candidates.isEmpty()) return@withContext null
        try {
            val optionsText = candidates.mapIndexed { idx, it -> "候选${idx+1}:${it.window}" }.joinToString("\n")
            val prompt = """
                你是影视台词逻辑大师。请严格判断哪个候选段落与视频内容完全对应。
                【上下文】前:${if (prevContext.isBlank()) "无" else prevContext.take(40)}
                后:${if (nextContext.isBlank()) "无" else nextContext.take(40)}
                【画面字幕】:${if (ocr.isBlank()) "无" else ocr.take(60)}
                【语音台词】:${if (asr.isBlank()) "无" else asr.take(60)}
                【剧本候选】:
                $optionsText
                请选择最匹配编号(1/2/3),若都不能严格对应输出0。只输出数字。
            """.trimIndent()
            val response = withTimeoutOrNull(6000) { llmInference?.generateResponse(prompt) } ?: ""
            val match = Regex("[0-3]").find(response)
            if (match != null) {
                val index = match.value.toInt() - 1
                if (index in candidates.indices) return@withContext candidates[index].copy(score = 1.0f)
            }
        } catch (e: Throwable) { return@withContext null }
        return@withContext null
    }

    private suspend fun llmGlobalOrder(clips: List<ClipMatch>): List<Int>? = withContext(Dispatchers.Default) {
        if (!isLlmReady || llmInference == null || clips.size > LLM_MAX_CLIPS) return@withContext null
        try {
            val clipDesc = clips.mapIndexed { i, c ->
                "片段$i: OCR=[${c.rawOcr.take(40)}] ASR=[${c.rawAsr.take(40)}]"
            }.joinToString("\n")
            val prompt = """
                你是影视导演。以下 ${clips.size} 个视频片段是无序的,请根据提取的台词和下面的剧本,推理出它们在剧本中的正确播放顺序。
                【所有片段】:
                $clipDesc
                【完整剧本】:${scriptFull.take(1500)}
                请输出 JSON,格式:{"order": [片段编号按正确顺序]},只需输出 JSON,不要解释。
            """.trimIndent()
            val response = withTimeoutOrNull(15000) { llmInference?.generateResponse(prompt) } ?: ""
            val jsonMatch = Regex("\\{[\\s\\S]*\\}").find(response) ?: return@withContext null
            val rootObj = JsonParser.parseString(jsonMatch.value).asJsonObject
            val orderArr = rootObj.getAsJsonArray("order") ?: return@withContext null
            val order = orderArr.map { it.asInt }
            if (order.size != clips.size || order.toSet() != (0 until clips.size).toSet()) return@withContext null
            order
        } catch (e: Throwable) { return@withContext null }
    }

    /**
     * V147 顺序推进核心 + V150 严格判定
     * 只在 [searchMin, searchMax] 内搜,保证不回退
     */
    private suspend fun crossValidationLocateOrdered(
        ocrText: String, asrText: String,
        searchMin: Int, searchMax: Int,
        isCalibration: Boolean, prevCtx: String, nextCtx: String
    ): FusionResult {
        val hasOcr = ocrText.length >= 2
        val hasAsr = asrText.length >= 2
        if (!hasOcr && !hasAsr) return FusionResult(searchMin, 0f, "无信号", "")

        val ocrCands = if (hasOcr) searchInRangeStrict(ocrText, scriptClean, searchMin, searchMin, searchMax, isCalibration) else emptyList()
        val asrCands = if (hasAsr) searchInRangeStrict(asrText, scriptClean, searchMin, searchMin, searchMax, isCalibration) else emptyList()

        val bestOcr = ocrCands.firstOrNull()
        val bestAsr = asrCands.firstOrNull()

        // 双轨强印证
        if (bestOcr != null && bestAsr != null &&
            bestOcr.score >= STRICT_SCORE_THRESHOLD && bestAsr.score >= STRICT_SCORE_THRESHOLD &&
            abs(bestOcr.pos - bestAsr.pos) <= 30) {
            return FusionResult(bestOcr.pos, minOf(1f, (bestOcr.score + bestAsr.score) / 2f + 0.1f), "视听双轨强印证", bestOcr.window)
        }

        // 单轨取高
        val bestSingle = if ((bestOcr?.score ?: 0f) >= (bestAsr?.score ?: 0f)) bestOcr else bestAsr
        if (bestSingle == null) return FusionResult(searchMin, 0f, "无效", "")

        if (bestSingle.score >= STRICT_SCORE_THRESHOLD) {
            return FusionResult(bestSingle.pos, bestSingle.score,
                if (bestSingle == bestOcr) "画面严格匹配" else "语音严格匹配", bestSingle.window)
        }

        // 中等分 0.45~0.7 → 保留(不判死红),MV 场景救星
        if (bestSingle.score >= 0.45f) {
            return FusionResult(bestSingle.pos, bestSingle.score,
                if (bestSingle == bestOcr) "画面中等匹配" else "语音中等匹配", bestSingle.window)
        }

        // 低分 → 判红,坐标不动(保留顺序推进)
        return FusionResult(searchMin, bestSingle.score, "低分需校对", bestSingle.window)
    }

    private fun naturalCompare(a: String, b: String): Int {
        val regex = Regex("(\\d+)|(\\D+)")
        val aParts = regex.findAll(a).map { it.value }.toList()
        val bParts = regex.findAll(b).map { it.value }.toList()
        for (i in 0 until minOf(aParts.size, bParts.size)) {
            val p1 = aParts[i]; val p2 = bParts[i]
            val isNum1 = p1.all { it.isDigit() }; val isNum2 = p2.all { it.isDigit() }
            if (isNum1 && isNum2) { val cmp = (p1.toLongOrNull() ?: 0L).compareTo(p2.toLongOrNull() ?: 0L); if (cmp != 0) return cmp }
            else { val cmp = p1.compareTo(p2); if (cmp != 0) return cmp }
        }
        return aParts.size - bParts.size
    }

    private fun isFileNameSequential(files: List<String>): Boolean {
        val numbers = mutableListOf<Long>(); var found = 0
        for (f in files) {
            val nums = Regex("\\d+").findAll(f).mapNotNull { it.value.toLongOrNull() }.toList()
            if (nums.isNotEmpty()) { found++; numbers.add(nums.last()) }
        }
        if (found >= files.size * 0.8) {
            var dec = 0
            for (i in 0 until numbers.size - 1) if (numbers[i] >= numbers[i + 1]) dec++
            return dec <= numbers.size * 0.2
        }
        return false
    }

    // ============ 字幕超分识别 ============
    private fun tryOcrBand(frameFile: File, topPct: Float, bottomPct: Float, scaleMode: String, scale: Int): String {
        val outFile = File(workDir, "zoom_${System.currentTimeMillis()}_${topPct}_$scaleMode.jpg")
        try {
            val probe = FFmpegKit.execute("-i \"${frameFile.absolutePath}\"")
            val probeOut = probe.output ?: ""
            val dimRegex = Regex("(\\d{2,5})x(\\d{2,5})")
            val dimMatch = dimRegex.find(probeOut) ?: return ""
            val w = dimMatch.groupValues[1].toIntOrNull() ?: return ""
            val h = dimMatch.groupValues[2].toIntOrNull() ?: return ""
            val cropTop = (h * topPct).toInt()
            val cropH = ((bottomPct - topPct) * h).toInt()
            if (cropH <= 0) return ""
            val filterStr = "crop=${w}:${cropH}:0:${cropTop},scale=${w*scale}:${cropH*scale}:flags=$scaleMode"
            val session = FFmpegKit.execute("-y -i \"${frameFile.absolutePath}\" -vf \"$filterStr\" -q:v 1 \"${outFile.absolutePath}\"")
            if (!ReturnCode.isSuccess(session.returnCode) || !outFile.exists()) return ""
            val bitmap = BitmapFactory.decodeFile(outFile.absolutePath) ?: return ""
            val image = InputImage.fromBitmap(bitmap, 0)
            val visionText = Tasks.await(textRecognizer.process(image))
            val result = visionText.textBlocks.flatMap { it.lines }.joinToString(" ") { it.text }
            bitmap.recycle()
            return result
        } catch (e: Throwable) {
            return ""
        } finally {
            if (outFile.exists()) outFile.delete()
        }
    }

    private fun recognizeSubtitleWithZoom(frameFile: File): String {
        if (!enableZoom) {
            // 关闭超分:走原简单路径
            val bmp = BitmapFactory.decodeFile(frameFile.absolutePath) ?: return ""
            val sw = maxOf(1, bmp.width / 2); val sh = maxOf(1, bmp.height / 2)
            val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
            if (bmp != scaled) bmp.recycle()
            val cropTop = (sh * 0.55f).toInt()
            val cropBottom = minOf(sh, (sh * 0.95f).toInt())
            val cropped = if (cropBottom > cropTop) Bitmap.createBitmap(scaled, 0, cropTop, sw, cropBottom - cropTop) else scaled
            val image = InputImage.fromBitmap(cropped, 0)
            val vt = Tasks.await(textRecognizer.process(image))
            if (cropped != scaled) cropped.recycle()
            scaled.recycle()
            return vt.textBlocks.flatMap { it.lines }.joinToString(" ") { it.text }
        }
        val bands = listOf(Pair(0.60f, 0.75f), Pair(0.72f, 0.88f), Pair(0.84f, 0.99f))
        var bestCount = 0; var bestResult = ""
        for ((topPct, bottomPct) in bands) {
            val text = tryOcrBand(frameFile, topPct, bottomPct, "neighbor", 2)
            val clean = cleanAndFilterText(text)
            if (clean.length > bestCount) { bestCount = clean.length; bestResult = clean }
        }
        if (bestCount < 3) {
            for ((topPct, bottomPct) in bands) {
                val text = tryOcrBand(frameFile, topPct, bottomPct, "lanczos", 3)
                val clean = cleanAndFilterText(text)
                if (clean.length > bestCount) { bestCount = clean.length; bestResult = clean }
            }
        }
        return bestResult
    }

    private fun extractAllSignals(videoFile: File): Triple<Triple<String, String, String>, String, Float> {
        val tempDir = File(workDir, "ocr_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        val framesTextList = mutableListOf<List<String>>()
        var firstHash = ""; var lastHash = ""
        var durationSec = 0f
        try {
            val probe = FFmpegKit.execute("-i \"${videoFile.absolutePath}\"")
            val probeOut = probe.output ?: ""
            Regex("Duration: (\\d+):(\\d+):(\\d+\\.\\d+)").find(probeOut)?.let {
                durationSec = it.groupValues[1].toFloat() * 3600 + it.groupValues[2].toFloat() * 60 + it.groupValues[3].toFloat()
            }
            val session = FFmpegKit.execute("-y -i \"${videoFile.absolutePath}\" -vf fps=1 -q:v 2 \"${tempDir.absolutePath}/frame_%04d.jpg\"")
            if (ReturnCode.isSuccess(session.returnCode)) {
                val frames = tempDir.listFiles()?.sortedBy { it.name } ?: emptyList()
                var processed = 0
                for ((fi, frame) in frames.withIndex()) {
                    val fullBitmap = BitmapFactory.decodeFile(frame.absolutePath) ?: continue
                    val resized = Bitmap.createScaledBitmap(fullBitmap, 8, 8, true)
                    val pixels = IntArray(64); resized.getPixels(pixels, 0, 8, 0, 0, 8, 8)
                    var avg = 0
                    for (p in pixels) avg += ((p shr 16 and 0xff) + (p shr 8 and 0xff) + (p and 0xff)) / 3
                    avg /= 64
                    val sb = StringBuilder()
                    for (p in pixels) {
                        val g = ((p shr 16 and 0xff) + (p shr 8 and 0xff) + (p and 0xff)) / 3
                        sb.append(if (g >= avg) "1" else "0")
                    }
                    if (resized != fullBitmap) resized.recycle()
                    if (fi == 0) firstHash = sb.toString()
                    if (fi == frames.size - 1) lastHash = sb.toString()

                    val subtitleText = try { recognizeSubtitleWithZoom(frame) } catch (e: Throwable) { "" }
                    val currentFrameTexts = mutableListOf<String>()
                    if (subtitleText.length >= 2) {
                        val badWords = listOf("原唱","作词","作曲","音乐人","安庆","官方","抖音","快手","字幕组","号","版权","未经","允许","中共","市委","文化","有限","公司")
                        if (badWords.none { subtitleText.contains(it) }) currentFrameTexts.add(subtitleText)
                    }
                    framesTextList.add(currentFrameTexts)
                    if (++processed % 20 == 0) System.gc()
                }
                val textFreq = mutableMapOf<String, Int>()
                framesTextList.forEach { ft -> ft.distinct().forEach { t -> textFreq[t] = (textFreq[t] ?: 0) + 1 } }
                val finalValidTexts = mutableListOf<String>()
                for ((text, freq) in textFreq) if (freq < frames.size * 0.3) finalValidTexts.add(text)
                val finalText = finalValidTexts.distinct().joinToString(" ").trim()
                return Triple(Triple(finalText, firstHash, lastHash), "", durationSec)
            }
        } catch (e: Throwable) {
        } finally {
            tempDir.listFiles()?.forEach { it.delete() }
            tempDir.delete()
        }
        return Triple(Triple("", "", ""), "", durationSec)
    }

    // ============ 语音智能增益 ============
    private fun extractFullAsr(videoFile: File, durationSec: Float): String {
        val recognizer = asrRecognizer ?: return ""
        if (durationSec <= 0f) return ""
        val chunkSec = 25
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < durationSec.toInt()) {
            val end = minOf(start + chunkSec, durationSec.toInt() + 1)
            val wavFile = File(workDir, "asr_${System.currentTimeMillis()}_$start.wav")
            try {
                if (enableAudioBoost) {
                    val audioFilter = listOf(
                        "highpass=f=180", "lowpass=f=3600",
                        "afftdn=nf=-25",
                        "acompressor=threshold=-20dB:ratio=3:attack=20:release=200",
                        "loudnorm=I=-16:LRA=11:TP=-1.5"
                    ).joinToString(",")
                    val session = FFmpegKit.execute(
                        "-y -vn -ss $start -to $end -i \"${videoFile.absolutePath}\" " +
                        "-af \"$audioFilter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                    )
                    if (ReturnCode.isSuccess(session.returnCode) && wavFile.exists()) {
                        val text = recognizeAudio(wavFile)
                        if (text.isNotBlank()) chunks.add(text)
                    } else {
                        // 降级
                        val fb = FFmpegKit.execute(
                            "-y -vn -ss $start -to $end -i \"${videoFile.absolutePath}\" " +
                            "-af \"highpass=f=200,lowpass=f=3400,volume=1.8\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                        )
                        if (ReturnCode.isSuccess(fb.returnCode) && wavFile.exists()) {
                            val text = recognizeAudio(wavFile)
                            if (text.isNotBlank()) chunks.add(text)
                        }
                    }
                } else {
                    val session = FFmpegKit.execute(
                        "-y -vn -ss $start -to $end -i \"${videoFile.absolutePath}\" " +
                        "-af \"highpass=f=200,lowpass=f=3400,volume=1.8\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                    )
                    if (ReturnCode.isSuccess(session.returnCode) && wavFile.exists()) {
                        val text = recognizeAudio(wavFile)
                        if (text.isNotBlank()) chunks.add(text)
                    }
                }
            } catch (e: Throwable) { } finally { wavFile.delete() }
            start += chunkSec
        }
        return chunks.joinToString(" ")
    }

    suspend fun initialMatch(script: String, forceAI: Boolean, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sortedClips = uploadedClips.toList().sortedWith { o1, o2 -> naturalCompare(o1, o2) }
            if (sortedClips.isEmpty()) throw Exception("没有找到视频文件")
            scriptFull = script
            val parsed = parseScript(script)
            scriptClean = parsed.first
            speakerLines = parsed.second
            allMatches.clear()
            calibratePass = 0
            val totalClips = sortedClips.size

            if (scriptClean.isEmpty()) {
                for ((index, clip) in sortedClips.withIndex()) {
                    allMatches.add(ClipMatch(id = index, clipName = clip, heardText = "【极速直拼】", heardClean = "",
                        scriptText = "【直接拼接】", coord = index, score = 1.0f, locked = true))
                }
                withContext(Dispatchers.Main) { onSuccess() }; return
            }

            val isDirectSequence = if (forceAI) false else isFileNameSequential(sortedClips)

            // 采集信号
            val signalResults = mutableListOf<Triple<Triple<String, String, String>, String, Float>>()
            val asrResults = mutableListOf<String>()
            for ((index, clip) in sortedClips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / totalClips * 100).toInt(), "采集信号 ${index + 1}/${totalClips}: ${clip.take(15)}")
                }
                val videoFile = File(uploadDir, clip)
                val signals = withContext(Dispatchers.IO) { extractAllSignals(videoFile) }
                val fullAsr = withContext(Dispatchers.IO) { extractFullAsr(videoFile, signals.third) }
                signalResults.add(signals)
                asrResults.add(fullAsr)
                delay(5)
            }

            // ============ V147 顺序推进核心 ============
            var currentScriptPos = 0
            for ((index, clip) in sortedClips.withIndex()) {
                val signals = signalResults[index]
                val (ocrText, firstHash, lastHash) = signals.first
                val durationSec = signals.third
                val fullAsr = asrResults[index]
                val cleanOcr = cleanAndFilterText(ocrText)
                val cleanAsr = cleanAndFilterText(fullAsr)

                if (isDirectSequence) {
                    val remainClips = totalClips - index
                    val remainLen = scriptClean.length - currentScriptPos
                    val expectedLen = maxOf(1, remainLen / remainClips)
                    val finalCoord = currentScriptPos
                    val actualEnd = minOf(finalCoord + expectedLen, scriptClean.length)
                    val finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, actualEnd) else ""
                    allMatches.add(ClipMatch(
                        id = index, clipName = clip, heardText = "【文件名直通】", heardClean = "",
                        scriptText = finalWindow, coord = finalCoord, score = 0.8f,
                        firstFrameHash = firstHash, lastFrameHash = lastHash, durationSec = durationSec
                    ))
                    currentScriptPos = actualEnd
                    continue
                }

                // 顺序推进:只从 currentScriptPos 往后搜
                val remainClips = totalClips - index
                val remainLen = scriptClean.length - currentScriptPos
                val expectedLen = maxOf(1, remainLen / remainClips)
                val searchMin = currentScriptPos
                val searchMax = minOf(scriptClean.length, currentScriptPos + expectedLen * 3)

                val fusion = crossValidationLocateOrdered(cleanOcr, cleanAsr, searchMin, searchMax, false, "", "")

                if (fusion.score >= GREEN_THRESHOLD) {
                    val finalCoord = maxOf(currentScriptPos, fusion.pos)
                    val heardForAdvance = if (cleanOcr.isNotBlank() && cleanAsr.isNotBlank()) fusion.window
                        else if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr
                    val advancedPos = minOf(scriptClean.length, finalCoord + lcsEndOffset(heardForAdvance, fusion.window))
                    allMatches.add(ClipMatch(
                        id = index, clipName = clip,
                        heardText = buildDisplayText(cleanOcr, cleanAsr),
                        heardClean = if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr,
                        scriptText = fusion.window, coord = finalCoord, score = fusion.score, locked = false,
                        rawOcr = cleanOcr, rawAsr = cleanAsr,
                        visualHash = firstHash, firstFrameHash = firstHash, lastFrameHash = lastHash,
                        durationSec = durationSec
                    ))
                    currentScriptPos = advancedPos
                } else {
                    // 失败:往前推 expectedLen,保持顺序不乱
                    val fallbackCoord = currentScriptPos
                    val finalWindow = if (fallbackCoord < scriptClean.length) scriptClean.substring(fallbackCoord, minOf(fallbackCoord + 50, scriptClean.length)) else ""
                    allMatches.add(ClipMatch(
                        id = index, clipName = clip,
                        heardText = buildDisplayText(cleanOcr, cleanAsr),
                        heardClean = if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr,
                        scriptText = finalWindow, coord = fallbackCoord, score = fusion.score, locked = false,
                        rawOcr = cleanOcr, rawAsr = cleanAsr,
                        visualHash = firstHash, firstFrameHash = firstHash, lastFrameHash = lastHash,
                        durationSec = durationSec
                    ))
                    currentScriptPos = minOf(scriptClean.length, currentScriptPos + expectedLen)
                }
            }

            // 首次后的轻量视觉修补(只交换视觉连续性极差的相邻,不动分数)
            lightVisualPatch()

            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    private fun buildDisplayText(ocr: String, asr: String): String {
        val a = if (ocr.isNotBlank()) "【画面】${ocr.take(30)}" else ""
        val b = if (asr.isNotBlank()) "【语音】${asr.take(30)}" else ""
        return if (a.isBlank() && b.isBlank()) "无有效台词-需视觉救援" else "$a\n$b"
    }

    private fun lightVisualPatch() {
        if (allMatches.size < 3) return
        for (i in 0 until allMatches.size - 2) {
            val a = allMatches[i]; val b = allMatches[i + 1]; val c = allMatches[i + 2]
            if (a.locked || b.locked || c.locked) continue
            if (a.lastFrameHash.isEmpty() || b.firstFrameHash.isEmpty() || c.firstFrameHash.isEmpty()) continue
            val adjNow = adjacencyScore(a.lastFrameHash, b.firstFrameHash)
            if (adjNow > 0.6f) continue
            val adjSwap = adjacencyScore(a.lastFrameHash, c.firstFrameHash)
            if (adjSwap > adjNow + 0.2f) {
                allMatches[i + 1] = c
                allMatches[i + 2] = b
            }
        }
    }

    private fun visualContinuityRepair() {
        if (allMatches.size < 2) return
        for (pass in 0 until 3) {
            var swapped = 0
            for (i in 0 until allMatches.size - 1) {
                val a = allMatches[i]; val b = allMatches[i + 1]
                if (a.locked || b.locked) continue
                if (a.lastFrameHash.isEmpty() || b.firstFrameHash.isEmpty()) continue
                val adjNow = adjacencyScore(a.lastFrameHash, b.firstFrameHash)
                if (adjNow < 0.3f) {
                    val prevAdj = if (i > 0) adjacencyScore(allMatches[i - 1].lastFrameHash, b.firstFrameHash) else 0.5f
                    val nextAdj = if (i + 2 < allMatches.size) adjacencyScore(a.lastFrameHash, allMatches[i + 2].firstFrameHash) else 0.5f
                    val adjSwapped = (prevAdj + nextAdj) / 2f
                    if (adjSwapped > adjNow + 0.15f) {
                        allMatches[i] = b; allMatches[i + 1] = a
                        swapped++
                    }
                }
            }
            if (swapped == 0) break
        }
    }

    private fun enforceOrderAndUniqueness() {
        if (allMatches.size < 2) return
        val sortedByScore = allMatches.indices.sortedByDescending { allMatches[it].score }
        val usedCoords = mutableSetOf<Int>()
        val conflictIds = mutableSetOf<Int>()
        for (idx in sortedByScore) {
            val m = allMatches[idx]
            if (m.locked || m.score < YELLOW_THRESHOLD) continue
            val conflict = usedCoords.any { abs(it - m.coord) < CONFLICT_WINDOW }
            if (conflict) conflictIds.add(idx) else usedCoords.add(m.coord)
        }
        for (idx in conflictIds) {
            val m = allMatches[idx]
            allMatches[idx] = m.copy(score = m.score * 0.5f)
        }
        for (i in 1 until allMatches.size) {
            if (allMatches[i].locked || allMatches[i - 1].locked) continue
            if (allMatches[i].coord <= allMatches[i - 1].coord) {
                val m = allMatches[i]
                allMatches[i] = m.copy(score = minOf(m.score, 0.55f))
            }
        }
    }

    // ============ 校对闭环(点一次必变) ============
    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) return@withContext CalibrateResult(0, 0, 0)
        calibratePass++
        var improved = 0

        // 每轮强制重算所有未锁片段(不用缓存)
        for (i in allMatches.indices) {
            val m = allMatches[i]
            if (m.locked) continue
            if (m.rawOcr.isBlank() && m.rawAsr.isBlank()) continue
            val fusion = crossValidationLocateOrdered(m.rawOcr, m.rawAsr, 0, scriptClean.length, true, "", "")
            if (fusion.score > m.score + IMPROVE_EPSILON) {
                allMatches[i] = m.copy(scriptText = fusion.window, coord = fusion.pos, score = fusion.score)
                improved++
            }
            yield()
        }

        // 策略轮换
        when (calibratePass % 5) {
            0 -> {
                if (allMatches.size <= LLM_MAX_CLIPS && isLlmReady) {
                    val llmOrder = llmGlobalOrder(allMatches.toList())
                    if (llmOrder != null) {
                        val before = allMatches.map { it.id }
                        val reordered = llmOrder.map { allMatches[it] }
                        if (reordered.map { it.id } != before) {
                            allMatches.clear(); allMatches.addAll(reordered); improved++
                        }
                    }
                }
            }
            1 -> {
                val before = allMatches.map { it.id }
                visualContinuityRepair()
                if (allMatches.map { it.id } != before) improved++
            }
            2 -> {
                val sorted = allMatches.sortedBy { it.coord }
                if (sorted.indices.any { sorted[it].id != allMatches[it].id }) {
                    allMatches.clear(); allMatches.addAll(sorted); improved++
                }
                val before = allMatches.map { it.id }
                visualContinuityRepair()
                if (allMatches.map { it.id } != before) improved++
            }
            3 -> {
                for (i in allMatches.indices) {
                    val m = allMatches[i]
                    if (m.locked) continue
                    val localMin = maxOf(0, m.coord - 200)
                    val localMax = minOf(scriptClean.length, m.coord + 200)
                    val fusion = crossValidationLocateOrdered(m.rawOcr, m.rawAsr, localMin, localMax, true, "", "")
                    if (fusion.score > m.score + IMPROVE_EPSILON) {
                        allMatches[i] = m.copy(scriptText = fusion.window, coord = fusion.pos, score = fusion.score)
                        improved++
                    }
                }
            }
            4 -> enforceOrderAndUniqueness()
        }

        // 最终强制顺序+唯一性(违反必降红)
        enforceOrderAndUniqueness()

        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
            allMatches[i] = allMatches[i].copy(locked = true); count++
        }
        return count
    }

    /**
     * 锁绿后强制视觉修复剩余红项
     */
    fun forceVisualRepairRedItems(): Int {
        var fixed = 0
        for (i in allMatches.indices) {
            if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
                allMatches[i] = allMatches[i].copy(locked = true)
            }
        }
        val redIndices = allMatches.indices.filter { !allMatches[it].locked }
        if (redIndices.size < 2) return 0
        var i = 0
        while (i < redIndices.size) {
            val start = redIndices[i]
            var end = i
            while (end + 1 < redIndices.size && redIndices[end + 1] == redIndices[end] + 1) end++
            val segStart = redIndices[i]
            val segEnd = redIndices[end]
            if (segEnd > segStart) {
                val block = (segStart..segEnd).map { allMatches[it] }.toMutableList()
                val reordered = mutableListOf<ClipMatch>()
                var prevLast = if (segStart > 0) allMatches[segStart - 1].lastFrameHash else ""
                while (block.isNotEmpty()) {
                    var bestIdx = 0; var bestAdj = -1f
                    for ((idx, m) in block.withIndex()) {
                        val adj = adjacencyScore(prevLast, m.firstFrameHash)
                        if (adj > bestAdj) { bestAdj = adj; bestIdx = idx }
                    }
                    val chosen = block.removeAt(bestIdx)
                    reordered.add(chosen)
                    prevLast = chosen.lastFrameHash
                }
                for ((k, newItem) in reordered.withIndex()) {
                    if (allMatches[segStart + k].id != newItem.id) fixed++
                    allMatches[segStart + k] = newItem
                }
            }
            i = end + 1
        }
        return fixed
    }

    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) if (allMatches[i].locked) {
            allMatches[i] = allMatches[i].copy(locked = false); count++
        }
        return count
    }

    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index] = allMatches[index].copy(locked = !allMatches[index].locked)
        return allMatches[index].locked
    }

    fun moveUp(index: Int) {
        if (index > 0 && index < allMatches.size) { val item = allMatches.removeAt(index); allMatches.add(index - 1, item) }
    }

    fun moveDown(index: Int) {
        if (index >= 0 && index < allMatches.size - 1) { val item = allMatches.removeAt(index); allMatches.add(index + 1, item) }
    }

    suspend fun recalculateMatchAt(index: Int) {
        if (index !in allMatches.indices) return
        val m = allMatches[index]
        if (m.locked) return
        if (m.rawOcr.isBlank() && m.rawAsr.isBlank()) return
        var lowerBound = 0; var prevCtx = ""
        for (j in index - 1 downTo 0) if (allMatches[j].locked) { lowerBound = allMatches[j].coord + allMatches[j].scriptText.length; prevCtx = allMatches[j].scriptText; break }
        var upperBound = scriptClean.length; var nextCtx = ""
        for (j in index + 1 until allMatches.size) if (allMatches[j].locked) { upperBound = allMatches[j].coord; nextCtx = allMatches[j].scriptText; break }
        if (upperBound <= lowerBound) upperBound = minOf(scriptClean.length, lowerBound + 2000)
        val fusion = crossValidationLocateOrdered(m.rawOcr, m.rawAsr, lowerBound, upperBound, true, prevCtx, nextCtx)
        val newScore = maxOf(m.score, fusion.score)
        val newCoord = if (fusion.score >= m.score) fusion.pos else m.coord
        val newWindow = if (fusion.score >= m.score) fusion.window else m.scriptText
        allMatches[index] = m.copy(scriptText = newWindow, coord = newCoord, score = newScore)
    }

    fun buildEpisodesJsonByUIOrder(): String {
        if (allMatches.isEmpty()) return "[]"
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "V150 顺序推进结果")
        val scenesArr = JsonArray(); val clipsArr = JsonArray()
        allMatches.forEachIndexed { idx, m ->
            scenesArr.add(JsonPrimitive("第 ${idx + 1} 段 · ${String.format("%.2f", m.score)}"))
            clipsArr.add(JsonPrimitive(m.clipName))
        }
        epObj.add("scenes", scenesArr); epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release()
            result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue
                withContext(Dispatchers.Main) { onProgress(10, "准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }
                withContext(Dispatchers.Main) { onProgress(40, "极速拼接尝试...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "重编码拼接...") }
                    session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${outFile.absolutePath}\"")
                    if (!ReturnCode.isSuccess(session.returnCode)) throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}