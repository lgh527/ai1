package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ClipMatch(
    val id: Int,
    val clipName: String,
    val heardText: String,
    val heardClean: String,
    var scriptText: String,
    var coord: Int,
    var score: Float,
    var locked: Boolean = false
)

data class CalibrateResult(
    val improvedCount: Int,
    val stillRed: Int,
    val stillGreen: Int
)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.50f
        const val YELLOW_THRESHOLD = 0.25f
        const val IMPROVE_EPSILON = 0.01f
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()

    private var scriptClean: String = ""
    private var scriptFull: String = ""

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var tfliteInterpreter: Interpreter? = null
    private var asrRecognizer: OfflineRecognizer? = null
    private val vocabMap = mutableMapOf<String, Int>()

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                loadVocab()
                withContext(Dispatchers.Main) { initTFLite(); initASR(); _modelsReadyFlow.value = true }
            } catch (e: Throwable) { _modelsReadyFlow.value = false }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() }
            } catch (e: Exception) { }
        }
    }

    fun resetMatches() {
        allMatches.clear()
        scriptClean = ""
        scriptFull = ""
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt", "minilm.tflite")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun loadVocab() {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            if (!tokensFile.exists()) return
            tokensFile.forEachLine { line ->
                val parts = line.trim().split(" ")
                if (parts.size >= 2) vocabMap[parts[0]] = parts[1].toIntOrNull() ?: 0
            }
        } catch (e: Throwable) { }
    }

    private fun initTFLite() {
        try {
            val modelFile = File(modelDir, "minilm.tflite")
            if (!modelFile.exists()) return
            val modelBuffer = loadModelFile(modelFile)
            tfliteInterpreter = Interpreter(modelBuffer, Interpreter.Options().apply { setNumThreads(4) })
        } catch (e: Throwable) { }
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val inputStream = FileInputStream(file)
        val channel = inputStream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
    }

    private fun cleanAndFilterText(text: String): String {
        val stopWords = setOf(
            '啊', '哎', '哦', '嗯', '呃', '的', '了', '是', '在', '有', '这', '那', '个', '就', '不', '和',
            '也', '你', '我', '他', '她', '它', '们', '说', '着', '去', '来', '把', '被', '让', '给', '上',
            '下', '里', '外'
        )
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "").filter { it !in stopWords }
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    data class PosScore(val pos: Int, val score: Float, val window: String)

    private fun findBestPositionInRange(heard: String, script: String, rangeStart: Int, rangeEnd: Int, windowSize: Int): PosScore {
        val heardLen = heard.length
        if (heardLen == 0) return PosScore(rangeStart, 0f, "")

        val safeStart = rangeStart.coerceIn(0, script.length)
        val safeEnd = rangeEnd.coerceIn(0, script.length)
        if (safeEnd <= safeStart) return PosScore(safeStart, 0f, "")

        val effUpper = maxOf(safeStart, safeEnd - windowSize)
        if (effUpper < safeStart) {
            val end = minOf(safeEnd, script.length)
            val start = maxOf(safeStart, end - heardLen)
            if (start >= end) return PosScore(safeStart, 0f, "")
            val win = script.substring(start, end)
            return PosScore(start, lcsLength(heard, win).toFloat() / heardLen, win)
        }

        var bestScore = -1f
        var bestPos = safeStart
        var pos = safeStart
        while (pos <= effUpper) {
            val actual = minOf(windowSize, script.length - pos)
            if (actual <= 0) break
            val window = script.substring(pos, pos + actual)
            val sc = lcsLength(heard, window).toFloat() / heardLen
            if (sc > bestScore) { bestScore = sc; bestPos = pos }
            pos += 4
        }

        val fineStart = maxOf(safeStart, bestPos - 4)
        val fineEnd = minOf(effUpper, bestPos + 4)
        pos = fineStart
        while (pos <= fineEnd) {
            val actual = minOf(windowSize, script.length - pos)
            if (actual <= 0) break
            val window = script.substring(pos, pos + actual)
            val sc = lcsLength(heard, window).toFloat() / heardLen
            if (sc > bestScore) { bestScore = sc; bestPos = pos }
            pos += 1
        }

        val finalWindow = script.substring(bestPos, minOf(bestPos + windowSize, script.length))
        return PosScore(bestPos, bestScore, finalWindow)
    }

    suspend fun initialMatch(script: String, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有找到视频文件")

            scriptFull = script
            scriptClean = cleanAndFilterText(script)
            if (scriptClean.isEmpty()) throw Exception("剧本内容为空")

            allMatches.clear()

            for ((index, clip) in clips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / clips.size * 100).toInt(), "AI 扫描 ${index + 1}/${clips.size}: ${clip.take(15)}")
                }
                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                // 【修复点 3】加入 -t 30 限制提取 30 秒音频，防止长视频导致内存爆炸
                val session = FFmpegKit.execute(
                    "-y -vn -i \"${videoFile.absolutePath}\" -t 30 -af \"volume=2.0\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                )
                var text = ""
                if (ReturnCode.isSuccess(session.returnCode)) {
                    text = recognizeAudio(wavFile)
                    wavFile.delete()
                }
                val cleanText = cleanAndFilterText(text)

                var coord = scriptClean.length
                var score = 0f
                var window = ""
                if (cleanText.length >= 3) {
                    val best = findBestPositionInRange(cleanText, scriptClean, 0, scriptClean.length, cleanText.length + 30)
                    coord = best.pos
                    score = best.score
                    window = best.window
                }

                allMatches.add(
                    ClipMatch(
                        id = index,
                        clipName = clip,
                        heardText = text,
                        heardClean = cleanText,
                        scriptText = window,
                        coord = coord,
                        score = score,
                        locked = false
                    )
                )
                delay(5)
            }

            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) {
            return@withContext CalibrateResult(0, 0, 0)
        }

        var improved = 0
        val n = allMatches.size

        for (i in 0 until n) {
            val m = allMatches[i]
            if (m.locked) continue
            if (m.heardClean.length < 3) continue

            var lower = 0
            var upper = scriptClean.length
            for (j in i - 1 downTo 0) {
                if (allMatches[j].locked) {
                    val anchorEnd = allMatches[j].coord + allMatches[j].scriptText.length
                    lower = maxOf(lower, anchorEnd)
                    break
                }
            }
            for (j in i + 1 until n) {
                if (allMatches[j].locked) {
                    upper = minOf(upper, allMatches[j].coord)
                    break
                }
            }
            if (upper - lower < m.heardClean.length) continue

            val windowSize = m.heardClean.length + 30
            val best = findBestPositionInRange(m.heardClean, scriptClean, lower, upper, windowSize)

            if (best.score > m.score + IMPROVE_EPSILON) {
                allMatches[i] = m.copy(
                    scriptText = best.window,
                    coord = best.pos,
                    score = best.score
                )
                improved++
            }
            delay(1)
        }

        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
                allMatches[i] = allMatches[i].copy(locked = true)
                count++
            }
        }
        return count
    }

    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (allMatches[i].locked) {
                allMatches[i] = allMatches[i].copy(locked = false)
                count++
            }
        }
        return count
    }

    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index] = allMatches[index].copy(locked = !allMatches[index].locked)
        return allMatches[index].locked
    }

    fun buildEpisodesJson(): String {
        if (allMatches.isEmpty()) return "[]"
        val sorted = allMatches.sortedBy { it.coord }
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "AI 校准后对齐结果")
        val scenesArr = JsonArray()
        val clipsArr = JsonArray()
        sorted.forEachIndexed { idx, m ->
            scenesArr.add("第 ${idx + 1} 段 · 匹配度${String.format("%.2f", m.score)}")
            clipsArr.add(m.clipName)
        }
        epObj.add("scenes", scenesArr)
        epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000)
            recognizer.decode(stream)
            val result = recognizer.getResult(stream)
            stream.release()
            result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")

                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(40, "正在尝试极速原画质拼接...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")

                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "格式差异，启动 H.264 重编码拼接(较慢)...") }
                    // 【修复点 4】将 mpeg4 替换为现代手机完美兼容的 libx264
                    session = FFmpegKit.execute(
                        "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 23 -preset ultrafast -c:a aac -f mp4 \"${outFile.absolutePath}\""
                    )
                    if (!ReturnCode.isSuccess(session.returnCode)) {
                        throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                    }
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) {
                onProgress(100, "渲染完成")
                onSuccess(lastOutputPath)
            }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}