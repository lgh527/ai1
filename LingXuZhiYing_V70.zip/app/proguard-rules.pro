# 保留模型推理的必要类
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class org.tensorflow.lite.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.google.gson.** { *; }
# 保留 JNI 接口和 Android 组件
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep public class * extends android.app.Activity
# 彻底混淆我们自己写的核心业务代码
-repackageclasses 'a'
-allowaccessmodification
-optimizationpasses 5
-dontpreverify