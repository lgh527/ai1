package com.lingxu.zhiying
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
data class ClipMatch(
    val id: Int,
    val clipName: String,
    val heardText: String,
    val heardClean: String,
    var scriptText: String,
    var coord: Int,
    var score: Float,
    var locked: Boolean = false,
    val rawOcr: String = "",
    val rawAsr: String = ""
)
data class CalibrateResult(
    val improvedCount: Int,
    val stillRed: Int,
    val stillGreen: Int
)
class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.65f
        const val YELLOW_THRESHOLD = 0.40f
        const val IMPROVE_EPSILON = 0.05f 
    }
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()
    private var scriptClean: String = ""
    private var scriptFull: String = ""
    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()
    private var asrRecognizer: OfflineRecognizer? = null
    private val vocabMap = mutableMapOf<String, Int>()
    private val textRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private var llmInference: LlmInference? = null
    private var isLlmReady = false
    init {
        scope.launch {
            try {
                copyLargeModelFromAssets()
                copyAssetsToFiles()
                loadVocab()
                initASR()
                initLLM() 
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            } catch (e: Throwable) { 
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            }
        }
    }
    private fun copyLargeModelFromAssets() {
        val modelName = "gemma-2b-it-gpu-int4.bin"
        val outFile = File(modelDir, modelName)
        if (outFile.exists() && outFile.length() > 0) return 
        try {
            val input = context.assets.open("models/$modelName")
            val output = FileOutputStream(outFile)
            input.copyTo(output)
            input.close()
            output.close()
        } catch (e: Throwable) { }
    }
    private fun initLLM() {
        try {
            val modelFile = File(modelDir, "gemma-2b-it-gpu-int4.bin")
            if (modelFile.exists()) {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath)
                    .setMaxTokens(512)
                    .build()
                llmInference = LlmInference.createFromOptions(context, options)
                isLlmReady = true
            } else {
                isLlmReady = false
            }
        } catch (e: Throwable) {
            isLlmReady = false
        }
    }
    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_") || it.name.startsWith("ocr_")) it.delete() }
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) { }
        }
    }
    fun resetMatches() {
        allMatches.clear()
        scriptClean = ""
        scriptFull = ""
    }
    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }
    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }
    private fun loadVocab() {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            if (!tokensFile.exists()) return
            tokensFile.forEachLine { line ->
                val parts = line.trim().split(" ")
                if (parts.size >= 2) vocabMap[parts[0]] = parts[1].toIntOrNull() ?: 0
            }
        } catch (e: Throwable) { }
    }
    private fun cleanAndFilterText(text: String): String {
        var cleaned = text.replace(Regex("[^\\u4e00-\\u9fa5a-zA-Z]"), "")
        val watermarks = listOf("抖音", "快手", "号", "aqwbQ", "安庆晚报", "字幕组", "关注", "点赞", "转发", "评论", "完整版", "致谢", "宣传部", "政府", "促进会", "作词", "作曲", "原唱", "音乐人", "安庆", "官方", "版权")
        for (wm in watermarks) {
            cleaned = cleaned.replace(wm, "")
        }
        return cleaned
    }
    private fun convertToPinyin(text: String): String {
        val sb = StringBuilder()
        for (char in text) {
            if (char.code in 0x4E00..0x9FFF) {
                val pinyins = android.icu.text.Transliterator.getInstance("Han-Latin/Names; Latin-ASCII; Lower").transliterate(char.toString())
                sb.append(pinyins.replace(" ", ""))
            } else {
                sb.append(char.lowercaseChar())
            }
        }
        return sb.toString()
    }
    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        if (abs(m - n) > maxOf(m, n) / 2) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }
    private fun lcsEndOffset(heard: String, window: String): Int {
        val m = heard.length; val n = window.length
        if (m == 0 || n == 0) return 0
        val dp = Array(m + 1) { IntArray(n + 1) }
        var endJ = 0
        var maxV = 0
        for (i in 1..m) for (j in 1..n) {
            dp[i][j] = if (heard[i - 1] == window[j - 1]) dp[i - 1][j - 1] + 1 else maxOf(dp[i - 1][j], dp[i][j - 1])
            if (dp[i][j] > maxV) { maxV = dp[i][j]; endJ = j }
        }
        return endJ
    }
    data class PosScore(val pos: Int, val score: Float, val window: String)
    private data class FusionResult(val pos: Int, val score: Float, val source: String, val window: String)
    private fun getTopCandidates(heard: String, script: String, searchStart: Int, searchEnd: Int, isCalibration: Boolean = false): List<PosScore> {
        val heardLen = heard.length
        if (heardLen == 0) return listOf(PosScore(searchStart, 0f, ""))
        val safeStart = searchStart.coerceIn(0, script.length)
        val safeEnd = searchEnd.coerceIn(safeStart, script.length)
        if (safeStart >= script.length) return listOf(PosScore(script.length, 0f, ""))
        val heardPinyin = convertToPinyin(heard)
        val windowSize = minOf(heardLen + 20, script.length - safeStart)
        var pos = safeStart
        val maxPos = minOf(safeEnd - windowSize, script.length - windowSize)
        val step = if (isCalibration) 1 else 2
        if (maxPos < safeStart) {
            val actualWindow = script.substring(safeStart, minOf(safeStart + windowSize, script.length))
            val actualWindowPinyin = convertToPinyin(actualWindow)
            val score = lcsLength(heardPinyin, actualWindowPinyin).toFloat() / heardPinyin.length
            return listOf(PosScore(safeStart, score, actualWindow))
        }
        val candidates = mutableListOf<PosScore>()
        while (pos <= maxPos) {
            val window = script.substring(pos, pos + windowSize)
            val windowPinyin = convertToPinyin(window)
            val lcs = lcsLength(heardPinyin, windowPinyin)
            val score = lcs.toFloat() / heardPinyin.length 
            candidates.add(PosScore(pos, score, window))
            pos += step
        }
        val sorted = candidates.sortedByDescending { it.score }
        val top3 = mutableListOf<PosScore>()
        for (c in sorted) {
            if (top3.none { abs(it.pos - c.pos) < 20 }) { 
                top3.add(c)
            }
            if (top3.size >= 3) break
        }
        return top3
    }
    private suspend fun llmArbitrate(ocr: String, asr: String, candidates: List<PosScore>, prevContext: String, nextContext: String): PosScore? = withContext(Dispatchers.Default) {
        if (!isLlmReady || llmInference == null || candidates.isEmpty()) return@withContext null
        try {
            val optionsText = candidates.mapIndexed { idx, it -> "候选${idx+1}：${it.window}" }.joinToString("\n")
            val prompt = """
                你是一个顶尖的影视台词逻辑大师。我们需要判断当前视频属于剧本的哪一段。
                
                【上下文环境】：
                已知前一句确定的剧本是：${if(prevContext.isBlank()) "未知" else prevContext}
                已知后一句确定的剧本是：${if(nextContext.isBlank()) "未知" else nextContext}
                
                【视频提取内容】(可能有错别字，请结合发音和剧情逻辑判断)：
                画面字幕：${if(ocr.isBlank()) "无" else ocr}
                语音识别：${if(asr.isBlank()) "无" else asr}
                
                【剧本候选段落】：
                $optionsText
                
                请结合上下文连贯性、发音相似度、字面重合度进行综合判断。
                请直接输出最匹配的编号数字（1、2 或 3）。若逻辑完全不符，输出0。绝对不要输出其他废话。
            """.trimIndent()
            val response = llmInference?.generateResponse(prompt) ?: ""
            val match = Regex("[1-3]").find(response)
            if (match != null) {
                val index = match.value.toInt() - 1
                if (index in candidates.indices) {
                    val best = candidates[index]
                    return@withContext best.copy(score = 1.0f) 
                }
            }
        } catch (e: Throwable) {
            return@withContext null
        }
        return@withContext null
    }
    private suspend fun crossValidationLocate(ocrText: String, asrText: String, hint: Int, expectedLen: Int, isCalibration: Boolean, prevCtx: String, nextCtx: String): FusionResult {
        val hasOcr = ocrText.length >= 2
        val hasAsr = asrText.length >= 2
        if (!hasOcr && !hasAsr) return FusionResult(hint, 0f, "无信号", "")
        val fullSearchStart = if (isCalibration) hint else 0
        val fullSearchEnd = scriptClean.length
        val ocrCandidates = if (hasOcr) getTopCandidates(ocrText, scriptClean, fullSearchStart, fullSearchEnd, isCalibration) else emptyList()
        val asrCandidates = if (hasAsr) getTopCandidates(asrText, scriptClean, fullSearchStart, fullSearchEnd, isCalibration) else emptyList()
        val bestOcr = ocrCandidates.firstOrNull()
        val bestAsr = asrCandidates.firstOrNull()
        var bestSingle = if ((bestOcr?.score ?: 0f) > (bestAsr?.score ?: 0f)) bestOcr else bestAsr
        if (bestSingle == null) return FusionResult(hint, 0f, "无效", "")
        val mergedCandidates = mutableListOf<PosScore>()
        mergedCandidates.addAll(ocrCandidates)
        if (bestAsr != null && mergedCandidates.none { abs(it.pos - bestAsr.pos) < 20 }) {
            mergedCandidates.add(bestAsr)
        }
        val finalCandidates = mergedCandidates.sortedByDescending { it.score }.take(3)
        if (isLlmReady && finalCandidates.isNotEmpty()) {
            val llmChoice = llmArbitrate(ocrText, asrText, finalCandidates, prevCtx, nextCtx)
            if (llmChoice != null) {
                return FusionResult(llmChoice.pos, llmChoice.score, "大模型逻辑确认", llmChoice.window)
            }
        }
        if (bestOcr != null && bestAsr != null) {
            if (abs(bestOcr.pos - bestAsr.pos) <= 50 && bestOcr.score > 0.8f && bestAsr.score > 0.8f) {
                val fusedScore = minOf(1.0f, (bestOcr.score + bestAsr.score) / 2f + 0.2f)
                val finalPos = if (bestOcr.score > bestAsr.score) bestOcr.pos else bestAsr.pos
                val finalWindow = if (bestOcr.score > bestAsr.score) bestOcr.window else bestAsr.window
                return FusionResult(finalPos, fusedScore, "视听高精准印证", finalWindow)
            }
        }
        return FusionResult(bestSingle.pos, minOf(bestSingle.score, 0.64f), "需大模型确认", bestSingle.window)
    }
    private fun naturalCompare(a: String, b: String): Int {
        val regex = Regex("(\\d+)|(\\D+)")
        val aParts = regex.findAll(a).map { it.value }.toList()
        val bParts = regex.findAll(b).map { it.value }.toList()
        val len = minOf(aParts.size, bParts.size)
        for (i in 0 until len) {
            val p1 = aParts[i]
            val p2 = bParts[i]
            val isNum1 = p1.all { it.isDigit() }
            val isNum2 = p2.all { it.isDigit() }
            if (isNum1 && isNum2) {
                val n1 = p1.toLongOrNull() ?: 0L
                val n2 = p2.toLongOrNull() ?: 0L
                val cmp = n1.compareTo(n2)
                if (cmp != 0) return cmp
            } else {
                val cmp = p1.compareTo(p2)
                if (cmp != 0) return cmp
            }
        }
        return aParts.size - bParts.size
    }
    private fun isFileNameSequential(files: List<String>): Boolean {
        var foundCount = 0
        val numbers = mutableListOf<Long>()
        for (f in files) {
            val nums = Regex("\\d+").findAll(f).map { it.value.toLongOrNull() ?: 0L }.toList()
            if (nums.isNotEmpty()) {
                foundCount++
                numbers.add(nums.last())
            }
        }
        if (foundCount >= files.size * 0.8) {
            var decreaseCount = 0
            for (i in 0 until numbers.size - 1) {
                if (numbers[i] >= numbers[i + 1]) decreaseCount++
            }
            if (decreaseCount > numbers.size * 0.2) return false
            return true
        }
        return false
    }
    private fun extractOcrText(videoFile: File): String {
        val tempDir = File(workDir, "ocr_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        val framesTextList = mutableListOf<List<String>>() 
        try {
            val session = FFmpegKit.execute("-y -i \"${videoFile.absolutePath}\" -vf fps=2 -q:v 2 \"${tempDir.absolutePath}/frame_%04d.jpg\"")
            if (ReturnCode.isSuccess(session.returnCode)) {
                val frames = tempDir.listFiles()?.sortedBy { it.name } ?: emptyList()
                var processed = 0
                for (frame in frames) {
                    val fullBitmap = BitmapFactory.decodeFile(frame.absolutePath) ?: continue
                    val sw = maxOf(1, fullBitmap.width / 2)
                    val sh = maxOf(1, fullBitmap.height / 2)
                    val scaledBitmap = Bitmap.createScaledBitmap(fullBitmap, sw, sh, true)
                    if (fullBitmap != scaledBitmap) fullBitmap.recycle()
                    val image = InputImage.fromBitmap(scaledBitmap, 0)
                    val visionText = Tasks.await(textRecognizer.process(image))
                    scaledBitmap.recycle()
                    val currentFrameTexts = mutableListOf<String>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val rawText = line.text
                            if (rawText.length < 2 || rawText.length > 25) continue
                            val badWords = listOf("原唱", "作词", "作曲", "音乐人", "安庆", "官方", "抖音", "快手", "字幕组", "号", "版权", "未经", "允许")
                            if (badWords.any { rawText.contains(it) }) continue
                            val cleanText = cleanAndFilterText(rawText)
                            if (cleanText.length >= 2) {
                                currentFrameTexts.add(cleanText)
                            }
                        }
                    }
                    framesTextList.add(currentFrameTexts)
                    if (++processed % 20 == 0) System.gc()
                }
                val textFreq = mutableMapOf<String, Int>()
                framesTextList.forEach { frameTexts ->
                    frameTexts.distinct().forEach { text -> textFreq[text] = (textFreq[text] ?: 0) + 1 }
                }
                val finalValidTexts = mutableListOf<String>()
                for ((text, freq) in textFreq) {
                    if (freq < frames.size * 0.3) { 
                        finalValidTexts.add(text)
                    }
                }
                return finalValidTexts.distinct().joinToString(" ").trim()
            }
        } catch (e: Throwable) {
        } finally {
            tempDir.listFiles()?.forEach { it.delete() }
            tempDir.delete()
        }
        return ""
    }
    suspend fun initialMatch(script: String, forceAI: Boolean, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sortedClips = uploadedClips.toList().sortedWith { o1, o2 ->
                naturalCompare(o1, o2)
            }
            if (sortedClips.isEmpty()) throw Exception("没有找到视频文件")
            scriptFull = script
            scriptClean = cleanAndFilterText(script)
            allMatches.clear()
            val totalClips = sortedClips.size
            if (scriptClean.isEmpty()) {
                for ((index, clip) in sortedClips.withIndex()) {
                    allMatches.add(
                        ClipMatch(
                            id = index,
                            clipName = clip,
                            heardText = "【极速直拼模式 (按文件名)】",
                            heardClean = "",
                            scriptText = "【直接拼接】",
                            coord = index,
                            score = 1.0f,
                            locked = true
                        )
                    )
                }
                withContext(Dispatchers.Main) { onSuccess() }
                return
            }
            val isDirectSequence = if (forceAI) false else isFileNameSequential(sortedClips)
            var currentScriptPos = 0 
            for ((index, clip) in sortedClips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / totalClips * 100).toInt(), "扫描 ${index + 1}/${totalClips}: ${clip.take(15)}")
                }
                val remainClips = totalClips - index
                val remainLen = scriptClean.length - currentScriptPos
                val expectedLen = maxOf(1, remainLen / remainClips)
                if (isDirectSequence) {
                    val finalCoord = currentScriptPos
                    val actualEnd = minOf(finalCoord + expectedLen, scriptClean.length)
                    val finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, actualEnd) else ""
                    allMatches.add(
                        ClipMatch(
                            id = index,
                            clipName = clip,
                            heardText = "【文件名序列直通】",
                            heardClean = "",
                            scriptText = finalWindow,
                            coord = finalCoord,
                            score = 0.8f,
                            locked = false
                        )
                    )
                    currentScriptPos = actualEnd
                    delay(5)
                    continue
                }
                val videoFile = File(uploadDir, clip)
                val asrText = withContext(Dispatchers.IO) {
                    var text = ""
                    val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                    val session = FFmpegKit.execute(
                        "-y -vn -i \"${videoFile.absolutePath}\" -t 30 -af \"highpass=f=200, lowpass=f=3400, volume=2.5\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                    )
                    if (ReturnCode.isSuccess(session.returnCode)) {
                        text = recognizeAudio(wavFile)
                        wavFile.delete()
                    }
                    text
                }
                val cleanAsr = cleanAndFilterText(asrText)
                val ocrText = withContext(Dispatchers.IO) { extractOcrText(videoFile) }
                val cleanOcr = cleanAndFilterText(ocrText)
                val fusion = crossValidationLocate(cleanOcr, cleanAsr, currentScriptPos, expectedLen, false, "", "")
                var finalCoord = currentScriptPos
                var finalScore = 0f
                var finalWindow = ""
                if (fusion.score >= GREEN_THRESHOLD) {
                    finalCoord = fusion.pos
                    finalScore = fusion.score
                    finalWindow = fusion.window
                    val heard = if (cleanOcr.isNotBlank() && cleanAsr.isNotBlank()) fusion.window else if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr
                    currentScriptPos = minOf(scriptClean.length, finalCoord + lcsEndOffset(heard, fusion.window))
                } else {
                    finalCoord = currentScriptPos
                    finalScore = 0f 
                    finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, minOf(finalCoord + 50, scriptClean.length)) else ""
                    currentScriptPos = minOf(scriptClean.length, currentScriptPos + expectedLen)
                }
                allMatches.add(
                    ClipMatch(
                        id = index,
                        clipName = clip,
                        heardText = if (cleanOcr.isNotBlank()) "【画面OCR】$cleanOcr\n【语音ASR】$cleanAsr" else "【语音ASR】$cleanAsr",
                        heardClean = if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr,
                        scriptText = finalWindow,
                        coord = finalCoord,
                        score = finalScore,
                        locked = false,
                        rawOcr = cleanOcr,
                        rawAsr = cleanAsr
                    )
                )
                delay(5)
            }
            val finalSorted = allMatches.sortedBy { it.coord }
            allMatches.clear()
            allMatches.addAll(finalSorted)
            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) {
            return@withContext CalibrateResult(0, 0, 0)
        }
        var improved = 0
        val n = allMatches.size
        var i = 0
        while (i < n) {
            if (allMatches[i].locked) {
                i++
                continue
            }
            val rangeStart = i
            while (i < n && !allMatches[i].locked) {
                i++
            }
            val rangeEnd = i - 1
            var lowerBound = 0
            var prevCtx = ""
            for (j in rangeStart - 1 downTo 0) {
                if (allMatches[j].locked) {
                    lowerBound = allMatches[j].coord + allMatches[j].scriptText.length
                    prevCtx = allMatches[j].scriptText
                    break
                }
            }
            var upperBound = scriptClean.length
            var nextCtx = ""
            for (j in rangeEnd + 1 until n) {
                if (allMatches[j].locked) {
                    upperBound = allMatches[j].coord
                    nextCtx = allMatches[j].scriptText
                    break
                }
            }
            if (upperBound <= lowerBound) upperBound = lowerBound + 50
            for (idx in rangeStart..rangeEnd) {
                val m = allMatches[idx]
                val fusion = crossValidationLocate(m.rawOcr, m.rawAsr, lowerBound, upperBound - lowerBound, true, prevCtx, nextCtx)
                if (fusion.score > m.score + IMPROVE_EPSILON && fusion.score >= YELLOW_THRESHOLD) {
                    allMatches[idx] = m.copy(
                        scriptText = fusion.window,
                        coord = fusion.pos,
                        score = fusion.score
                    )
                    improved++
                }
            }
        }
        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }
    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
                allMatches[i] = allMatches[i].copy(locked = true)
                count++
            }
        }
        return count
    }
    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (allMatches[i].locked) {
                allMatches[i] = allMatches[i].copy(locked = false)
                count++
            }
        }
        return count
    }
    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index] = allMatches[index].copy(locked = !allMatches[index].locked)
        return allMatches[index].locked
    }
    fun moveUp(index: Int) {
        if (index > 0 && index < allMatches.size) {
            val item = allMatches.removeAt(index)
            allMatches.add(index - 1, item)
        }
    }
    fun moveDown(index: Int) {
        if (index >= 0 && index < allMatches.size - 1) {
            val item = allMatches.removeAt(index)
            allMatches.add(index + 1, item)
        }
    }
    suspend fun recalculateMatchAt(index: Int) {
        if (index !in allMatches.indices) return
        val m = allMatches[index]
        if (m.locked) return
        var lowerBound = 0
        var prevCtx = ""
        for (j in index - 1 downTo 0) {
            if (allMatches[j].locked) {
                lowerBound = allMatches[j].coord + allMatches[j].scriptText.length
                prevCtx = allMatches[j].scriptText
                break
            }
        }
        var upperBound = scriptClean.length
        var nextCtx = ""
        for (j in index + 1 until allMatches.size) {
            if (allMatches[j].locked) {
                upperBound = allMatches[j].coord
                nextCtx = allMatches[j].scriptText
                break
            }
        }
        if (lowerBound == 0 && index > 0) lowerBound = maxOf(0, allMatches[index - 1].coord - 500)
        if (upperBound == scriptClean.length && index < allMatches.size - 1) upperBound = minOf(scriptClean.length, allMatches[index + 1].coord + 500)
        if (upperBound <= lowerBound) upperBound = lowerBound + 500
        val fusion = crossValidationLocate(m.rawOcr, m.rawAsr, lowerBound, upperBound - lowerBound, true, prevCtx, nextCtx)
        if (fusion.score < GREEN_THRESHOLD) {
            allMatches[index] = m.copy(
                scriptText = fusion.window,
                coord = fusion.pos,
                score = 0f 
            )
        } else {
            allMatches[index] = m.copy(
                scriptText = fusion.window,
                coord = fusion.pos,
                score = fusion.score
            )
        }
    }
    fun buildEpisodesJsonByUIOrder(): String {
        if (allMatches.isEmpty()) return "[]"
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "AI 校准后对齐结果")
        val scenesArr = JsonArray()
        val clipsArr = JsonArray()
        allMatches.forEachIndexed { idx, m ->
            scenesArr.add(JsonPrimitive("第 ${idx + 1} 段 · 匹配度${String.format("%.2f", m.score)}"))
            clipsArr.add(JsonPrimitive(m.clipName))
        }
        epObj.add("scenes", scenesArr)
        epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }
    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000)
            recognizer.decode(stream)
            val result = recognizer.getResult(stream)
            stream.release()
            result.text
        } catch (e: Throwable) { "" }
    }
    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue
                withContext(Dispatchers.Main) { onProgress(10, "正在准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }
                withContext(Dispatchers.Main) { onProgress(40, "正在尝试极速原画质拼接...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "格式差异，启动 H.264 重编码拼接(较慢)...") }
                    session = FFmpegKit.execute(
                        "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${outFile.absolutePath}\""
                    )
                    if (!ReturnCode.isSuccess(session.returnCode)) {
                        throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                    }
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) {
                onProgress(100, "渲染完成")
                onSuccess(lastOutputPath)
            }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}