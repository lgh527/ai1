package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip

/**
 * 同坐标片段的先后排序
 *
 * 解决这个具体场景：一支 MV 里，小女孩先唱了一句歌词，男主后来又唱了同一句。
 * 两个切片的字幕文本、听写文本**完全一样**，文本通道给出的得分也完全一样，
 * 单看文字根本无法判断谁先谁后——排错了就是把男主的画面放到小女孩前面。
 *
 * 判据按可靠性依次使用：
 *  1. **首尾帧连续性链**：若 A 的尾帧与 B 的首帧高度相似（同一镜头被切开），
 *     则 A 必在 B 前。这是最硬的证据，由 [ContinuityChain] 全链重建后给出位次。
 *  2. **重建位次（chainRank）**：不同场景（小女孩 / 男歌手）之间即使没有直接衔接，
 *     也会被全链重建串到同一条时间轴上，位次即先后。
 *  3. **场景首次出现顺序**：链证据完全缺失时的兜底。
 *
 * 已彻底移除「文件名自然序」判据：素材文件名可能毫无意义
 * （VID_xxxx、微信导出名、随机哈希），用它当时间轴会把顺序排反。
 */
object SameCoordOrderer {

    private const val CONTINUITY_THRESHOLD = 0.85f

    /**
     * 对共享同一剧本坐标的片段做稳定排序
     *
     * @param group    同一坐标下的片段（保持它们当前的相对顺序）
     * @param rankById 连续性全链重建位次表：clipId → 时间轴位次（不使用文件名）
     * @return 排好序的片段
     */
    fun order(group: List<AlignedClip>, rankById: Map<Int, Int>): List<AlignedClip> {
        if (group.size <= 1) return group

        // ---- 第 1 步：用首尾帧连续性建链 ----
        val remaining = group.toMutableList()
        val chained = ArrayList<AlignedClip>(group.size)
        // 链头：重建位次最靠前的那个片段
        var head = remaining.minByOrNull { rankOf(it, rankById) } ?: remaining.first()
        chained.add(head)
        remaining.remove(head)

        while (remaining.isNotEmpty()) {
            val last = chained.last()
            var bestIdx = -1
            var bestSim = CONTINUITY_THRESHOLD
            remaining.forEachIndexed { i, c ->
                // RGB 彩色 + 灰度结构的综合相似度，判断是否同一镜头被切开
                val sim = PerceptualHash.visualContinuity(
                    last.feature.tailHash, last.feature.colorTail,
                    c.feature.headHash, c.feature.colorHead
                )
                if (sim > bestSim) { bestSim = sim; bestIdx = i }
            }
            if (bestIdx >= 0) {
                chained.add(remaining[bestIdx])
                remaining.removeAt(bestIdx)
            } else {
                // 没有连续性证据：按场景首次出现顺序，再按自然序
                val next = remaining.minWithOrNull(
                    compareBy({ sceneFirstSeen(it, chained) }, { rankOf(it, rankById) })
                ) ?: remaining.first()
                chained.add(next)
                remaining.remove(next)
            }
        }
        return chained
    }

    /** 取重建位次；缺失时退回片段自带的 chainRank */
    private fun rankOf(c: AlignedClip, rankById: Map<Int, Int>): Int =
        rankById[c.feature.id] ?: c.chainRank

    /**
     * 该片段所属场景在已确定序列里最早出现的位置；
     * 找不到同场景就返回一个很大的值，让它排到后面等人工确认。
     */
    private fun sceneFirstSeen(c: AlignedClip, chained: List<AlignedClip>): Int {
        chained.forEachIndexed { i, other ->
            if (other.feature.sceneGroup >= 0 && other.feature.sceneGroup == c.feature.sceneGroup) return i
        }
        return Int.MAX_VALUE - 1
    }

    /**
     * 全局应用：把所有共享同一剧本坐标的片段按上面规则重排。
     * 只调整「同坐标内部」的相对顺序，不改变坐标之间的宏观顺序。
     *
     * @return 被调整过的坐标组数量
     */
    fun applyAll(clips: MutableList<AlignedClip>, rankById: Map<Int, Int>): Int {
        val byCoord = clips.filter { it.scriptIndex >= 0 }.groupBy { it.scriptIndex }
        var touched = 0
        byCoord.forEach { (coord, members) ->
            if (members.size <= 1) return@forEach
            val ordered = order(members, rankById)
            // 把排好的结果写回它们在原列表里占据的那些槽位
            val slots = ArrayList<Int>()
            clips.forEachIndexed { i, c -> if (c.scriptIndex == coord) slots.add(i) }
            if (slots.size != ordered.size) return@forEach
            val before = slots.map { clips[it].feature.id }
            slots.forEachIndexed { k, slot -> clips[slot] = ordered[k] }
            val after = slots.map { clips[it].feature.id }
            if (before != after) touched++
        }
        clips.forEachIndexed { i, c -> c.order = i + 1 }
        return touched
    }
}
