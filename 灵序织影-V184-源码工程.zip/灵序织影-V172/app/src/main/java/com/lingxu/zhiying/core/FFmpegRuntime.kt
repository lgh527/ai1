package com.lingxu.zhiying.core

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode

/**
 * FFmpeg 运行时自检
 *
 * 之前"读取成功 0 / 抽帧 0 / 音频提取 0，但 ASR 可用"这种全零现象，
 * 根因是 FFmpegKit 的原生库没能加载（UnsatisfiedLinkError），
 * 而各个调用点都把异常 catch 掉、静默返回默认值，于是整条管线看起来像"读不到文件"。
 *
 * 这个类在 App 启动时就把 FFmpeg 真实跑一次 `-version`：
 *   · 跑得通 → 记录版本号，后续流程正常
 *   · 跑不通 → 把异常类名和消息记下来，UI 直接弹窗告知，绝不再静默失败
 *
 * 同时统一在这里给 FFmpegKitConfig 注入 Context —— 这是 ffmpeg-kit
 * 访问 Android SAF（content://）的前置条件，缺了它 content URI 一律打不开。
 */
object FFmpegRuntime {

    @Volatile
    var ready: Boolean = false
        private set

    @Volatile
    var version: String = ""
        private set

    @Volatile
    var error: String = ""
        private set

    @Volatile
    var probeReady: Boolean = false
        private set

    /** APK 里 native 库目录的实际内容，运行时清点，用来确认 .so 到底有没有打进包 */
    @Volatile
    var nativeLibReport: String = "（未检测）"
        private set

    /** 逐个 System.loadLibrary 的结果，能精确定位是哪个 .so 加载失败 */
    @Volatile
    var preloadReport: String = "（未检测）"
        private set

    /** 缺失的必需类（ffmpeg-kit 的隐式依赖） */
    @Volatile
    var missingDeps: List<String> = emptyList()
        private set

    /** ffmpeg-kit 运行所必需、但不由它的 AAR 传递引入的类 */
    private val REQUIRED_CLASSES = listOf(
        "com.arthenica.smartexception.java.Exceptions",
        "com.arthenica.ffmpegkit.FFmpegKitConfig",
        "com.arthenica.ffmpegkit.FFmpegKit",
        "com.arthenica.ffmpegkit.FFprobeKit",
        "com.arthenica.ffmpegkit.ReturnCode"
    )

    private fun checkRequiredClasses(): List<String> {
        val missing = ArrayList<String>()
        REQUIRED_CLASSES.forEach { cn ->
            try {
                Class.forName(cn)
            } catch (t: Throwable) {
                missing.add(cn)
                LogX.e("FFmpeg", "缺少必需类 $cn → ${describe(t)}")
            }
        }
        return missing
    }

    private val nativeErrors = ArrayList<String>()

    /** 最近若干条被捕获的原生调用异常，诊断面板会展示 */
    val recentErrors: List<String>
        get() = synchronized(nativeErrors) { nativeErrors.toList().takeLast(8) }

    fun recordError(scope: String, t: Throwable) {
        val msg = "$scope: ${t.javaClass.simpleName} ${t.message}"
        synchronized(nativeErrors) {
            nativeErrors.add(msg)
            if (nativeErrors.size > 40) nativeErrors.removeAt(0)
        }
        LogX.e("FFmpeg", msg, t)
    }

    /**
     * 展开完整的异常 cause 链。
     *
     * NoClassDefFoundError 只是表象：FFmpegKitConfig 的 static 块里会
     * System.loadLibrary("ffmpegkit")，一旦 .so 缺失，第一次引用抛的是
     * ExceptionInInitializerError（cause = UnsatisfiedLinkError），
     * 之后再引用就变成 NoClassDefFoundError —— 真正的根因在 cause 里。
     * 之前只打印最外层异常，把根因吞掉了，所以看不到是哪个 .so 没加载上。
     */
    fun describe(t: Throwable): String {
        val sb = StringBuilder()
        var c: Throwable? = t
        var depth = 0
        while (c != null && depth < 6) {
            if (depth > 0) sb.append("\n    ← 根因: ")
            sb.append(c.javaClass.name)
            if (!c.message.isNullOrBlank()) sb.append(": ").append(c.message)
            c = c.cause
            depth++
        }
        return sb.toString()
    }

    /** 运行时清点 nativeLibraryDir：直接看 APK 装出来的 .so 有哪些 */
    private fun inspectNativeLibs(context: Context): String {
        return try {
            val dir = java.io.File(context.applicationInfo.nativeLibraryDir)
            val files = dir.listFiles()
            if (files == null) {
                "无法列出 ${dir.absolutePath}（目录不存在或无权限）"
            } else {
                val so = files.filter { it.name.endsWith(".so") }.sortedBy { it.name }
                buildString {
                    append("nativeLibraryDir=").append(dir.absolutePath).append("\n")
                    append("共 ").append(so.size).append(" 个 .so：")
                    if (so.isEmpty()) append("（空！说明 AAR 的原生库没打进 APK）")
                    so.forEach { append("\n  · ").append(it.name).append(" (").append(it.length() / 1024).append("KB)") }
                }
            }
        } catch (t: Throwable) {
            "读取 nativeLibraryDir 失败：${describe(t)}"
        }
    }

    /**
     * 按依赖顺序逐个预加载原生库。
     * 哪个失败就报哪个，不再让错误混成一团 NoClassDefFoundError。
     */
    private fun preloadNativeLibs(): String {
        val order = listOf(
            "c++_shared", "avutil", "swresample", "swscale",
            "avcodec", "avformat", "avfilter", "avdevice",
            "ffmpegkit_abidetect", "ffmpegkit"
        )
        val ok = ArrayList<String>()
        val bad = ArrayList<String>()
        order.forEach { name ->
            try {
                System.loadLibrary(name)
                ok.add(name)
            } catch (t: Throwable) {
                bad.add("$name → ${t.javaClass.simpleName}: ${t.message}")
            }
        }
        return buildString {
            append("成功 ").append(ok.size).append("/").append(order.size)
            if (ok.isNotEmpty()) append("：").append(ok.joinToString(", "))
            if (bad.isNotEmpty()) {
                append("\n失败：")
                bad.forEach { append("\n  ✗ ").append(it) }
            }
        }
    }

    @Synchronized
    fun init(context: Context) {
        // 0a) 先查 ffmpeg-kit 的必需 Java 依赖是否在包里。
        //     FFmpegKitConfig 直接引用 smartexception.Exceptions，缺了它整条链路都会崩，
        //     但报错会伪装成 NoClassDefFoundError / Bad JNI version，很难看出真因。
        missingDeps = checkRequiredClasses()
        if (missingDeps.isNotEmpty()) {
            ready = false
            error = "APK 缺少 ffmpeg-kit 的必需依赖类：${missingDeps.joinToString(", ")}\n" +
                    "→ 请在 app/build.gradle.kts 加上 implementation(\"com.arthenica:smart-exception-java:0.2.1\")"
            LogX.e("FFmpeg", error)
        }

        // 0b) 再把事实摆出来：APK 里到底有哪些 .so，能不能加载
        nativeLibReport = inspectNativeLibs(context)
        preloadReport = preloadNativeLibs()
        LogX.i("FFmpeg", "native 库清点:\n$nativeLibReport")
        LogX.i("FFmpeg", "预加载结果:\n$preloadReport")
        // 1) 注入 Context：ffmpeg-kit 访问 Android 存储依赖它。
        //    用反射调用而不是直接引用 FFmpegKitConfig —— 这个类的方法签名在不同
        //    ffmpeg-kit 版本/不同维护分支里并不一致，直接引用会造成编译期
        //    unresolved reference，整个构建挂掉。反射则最坏情况只是"没注入成功"，
        //    不影响编译，也不影响普通本地文件路径的正常使用。
        injectContext(context)

        // 2) 真跑一次 -version，验证原生库能否加载
        try {
            val session = FFmpegKit.execute("-version")
            val out = session.output ?: ""
            version = out.lineSequence().firstOrNull()?.trim() ?: ""
            ready = version.isNotBlank() || ReturnCode.isSuccess(session.returnCode)
            if (!ready) error = "FFmpeg -version 无输出：${out.take(200).ifBlank { "（空）" }}"
        } catch (e: Throwable) {
            ready = false
            error = "FFmpeg 调用失败 → ${describe(e)}"
            recordError("FFmpegKit.execute(-version)", e)
        }

        // 3) FFprobe 同样验一次
        try {
            val s = FFprobeKit.execute("-version")
            probeReady = (s.output ?: "").isNotBlank() || ReturnCode.isSuccess(s.returnCode)
        } catch (e: Throwable) {
            probeReady = false
            recordError("FFprobeKit.execute(-version)", e)
        }

        LogX.i("FFmpeg", "ready=$ready probe=$probeReady version=$version error=$error")
    }

    /** 反射注入 Context，兼容各种 ffmpeg-kit 版本的 API 形状 */
    private fun injectContext(context: Context) {
        val app = context.applicationContext
        val candidates = listOf(
            "com.arthenica.ffmpegkit.FFmpegKitConfig",
            "com.arthenica.smartexception.java.ExceptionsConfig"
        )
        for (cn in candidates) {
            try {
                val clazz = Class.forName(cn)
                val m = clazz.methods.firstOrNull { mm ->
                    mm.name == "setContext" && mm.parameterTypes.size == 1 &&
                            mm.parameterTypes[0].isAssignableFrom(app.javaClass)
                }
                if (m != null) {
                    m.invoke(null, app)
                    LogX.i("FFmpeg", "已通过反射注入 Context: $cn")
                    return
                }
            } catch (e: Throwable) {
                LogX.w("FFmpeg", "反射注入 $cn 失败: ${e.message}")
            }
        }
        LogX.w("FFmpeg", "未能注入 Context（不影响本地文件路径的 FFmpeg 调用）")
    }

    /** 给 UI 用的一句话结论 */
    fun statusLine(): String = when {
        ready && probeReady -> "✅ FFmpeg 正常：$version"
        ready -> "⚠️ FFmpeg 可用但 FFprobe 不可用，时长/分辨率探测会退化为 0"
        else -> "❌ FFmpeg 不可用：$error"
    }

    /** 完整诊断（弹窗用）：结论 + cause 链 + .so 清单 + 预加载结果 */
    fun fullReport(): String = buildString {
        append(statusLine()).append("\n\n")
        if (!ready) {
            append("【异常链】\n").append(error.ifBlank { "（无）" }).append("\n\n")
        }
        if (missingDeps.isNotEmpty()) {
            append("【缺失的必需类】\n")
            missingDeps.forEach { append("  ✗ ").append(it).append("\n") }
            append("\n")
        }
        append("【APK 内 .so 清点】\n").append(nativeLibReport).append("\n\n")
        append("【原生库预加载】\n").append(preloadReport).append("\n\n")
        val recent = recentErrors
        if (recent.isNotEmpty()) {
            append("【最近调用异常】\n")
            recent.forEach { append("· ").append(it).append("\n") }
        }
    }
}
