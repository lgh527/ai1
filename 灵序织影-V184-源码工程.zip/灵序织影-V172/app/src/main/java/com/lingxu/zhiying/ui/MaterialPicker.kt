package com.lingxu.zhiying.ui

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.app.AlertDialog
import androidx.documentfile.provider.DocumentFile
import com.lingxu.zhiying.core.LogX

/**
 * 文件夹式素材导入
 *
 * 系统相册选择器一次只能平铺所有视频，几十集素材根本分不清哪个属于哪一集。
 * 这里改成**先选文件夹、再看文件夹里的视频**的两级浏览：
 *
 *   第 1 级：列出所选目录下的所有子文件夹（每个文件夹 = 一集），显示各自视频数量
 *   第 2 级：进入某个文件夹，勾选要导入的视频，确认后带着「集名」一起回传
 *
 * 集名会显示在校对卡片上，多集素材不会混在一起。
 *
 * 基于 SAF（Storage Access Framework）实现，Android 11+ 的分区存储下也能正常浏览，
 * 不需要 MANAGE_EXTERNAL_STORAGE 这种高危权限。
 */
class MaterialPicker(private val context: Context) {

    /** 一个被选中的素材：Uri + 所属集名 */
    data class Pick(val uri: Uri, val episode: String)

    private val VIDEO_EXT = setOf("mp4", "mkv", "mov", "avi", "flv", "ts", "webm", "m4v", "3gp", "wmv")

    private var treeRoot: DocumentFile? = null
    private var onPicked: ((List<Pick>) -> Unit)? = null
    private var dialog: AlertDialog? = null

    /** 由 Activity 在拿到 tree uri 后调用 */
    fun openTree(treeUri: Uri, callback: (List<Pick>) -> Unit) {
        onPicked = callback
        treeRoot = try {
            DocumentFile.fromTreeUri(context, treeUri)
        } catch (e: Throwable) {
            LogX.e("Picker", "无法打开文件夹", e)
            null
        }
        val root = treeRoot
        if (root == null || !root.exists()) {
            callback(emptyList())
            return
        }
        showFolderLevel(root, root.name ?: "所选目录", ArrayList())
    }

    /** 第 1 级：文件夹列表 */
    private fun showFolderLevel(dir: DocumentFile, title: String, trail: ArrayList<DocumentFile>) {
        val files = runCatching { dir.listFiles() }.getOrNull() ?: emptyArray()
        val folders = files.filter { it.isDirectory }.sortedBy { it.name?.lowercase() }
        val videos = files.filter { isVideo(it) }.sortedWith { a, b ->
            com.lingxu.zhiying.core.NaturalOrder.compare(a.name ?: "", b.name ?: "")
        }

        val box = Ui.vbox(context).apply {
            setPadding(Ui.dp(context, 16f), Ui.dp(context, 14f), Ui.dp(context, 16f), Ui.dp(context, 6f))
        }
        box.addView(Ui.text(context, "📁 $title", 13f, Ui.TEXT_SUB))

        val scroll = ScrollView(context)
        val list = Ui.vbox(context)
        scroll.addView(list, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        // 返回上一级
        if (trail.isNotEmpty()) {
            list.addView(rowItem("⬅️", "返回上一级", "") {
                val parent = trail.removeAt(trail.size - 1)
                showFolderLevel(parent, com.lingxu.zhiying.core.MediaResolver.cleanName(parent.name), trail)
            })
        }

        // 子文件夹
        folders.forEach { f ->
            val sub = runCatching { f.listFiles() }.getOrNull() ?: emptyArray()
            val vCount = sub.count { isVideo(it) }
            val fCount = sub.count { it.isDirectory }
            val desc = buildString {
                append("$vCount 个视频")
                if (fCount > 0) append(" · $fCount 个子文件夹")
            }
            list.addView(rowItem("📂", com.lingxu.zhiying.core.MediaResolver.cleanName(f.name), desc) {
                trail.add(dir)
                showFolderLevel(f, com.lingxu.zhiying.core.MediaResolver.cleanName(f.name), trail)
            })
        }

        // 本目录的视频：一键全选导入
        if (videos.isNotEmpty()) {
            list.addView(rowItem("🎞", "本目录的 ${videos.size} 个视频", "点击逐个勾选后导入") {
                showVideoLevel(dir, videos, title)
            })
        }

        if (folders.isEmpty() && videos.isEmpty()) {
            list.addView(Ui.text(context, "这个目录里没有视频，也没有子文件夹", 13f, Ui.AMBER)
                .apply { setPadding(0, Ui.dp(context, 18f), 0, Ui.dp(context, 18f)) })
        }

        dialog?.dismiss()
        dialog = AlertDialog.Builder(context)
            .setView(box.apply { addView(scroll, Ui.matchWrap()) })
            .setNegativeButton("取消", null)
            .create()
        dialog?.show()
    }

    /** 第 2 级：勾选视频 */
    private fun showVideoLevel(dir: DocumentFile, videos: List<DocumentFile>, episodeName: String) {
        val box = Ui.vbox(context).apply {
            setPadding(Ui.dp(context, 16f), Ui.dp(context, 14f), Ui.dp(context, 16f), Ui.dp(context, 6f))
        }
        box.addView(Ui.text(context, "🎞 $episodeName · 共 ${videos.size} 个视频", 13f, Ui.TEXT_SUB))
        box.addView(Ui.text(context, "勾选要参与对齐的切片（默认全选）", 11f, Ui.TEXT_SUB))

        val scroll = ScrollView(context)
        val list = Ui.vbox(context)
        scroll.addView(list, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val checks = ArrayList<CheckBox>()
        videos.forEach { v ->
            val cb = CheckBox(context).apply {
                text = com.lingxu.zhiying.core.MediaResolver.cleanName(v.name)
                setTextColor(Color.parseColor(Ui.TEXT_MAIN))
                setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
                isChecked = true
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(Ui.CYAN))
                setPadding(Ui.dp(context, 4f), Ui.dp(context, 9f), Ui.dp(context, 4f), Ui.dp(context, 9f))
            }
            checks.add(cb)
            list.addView(cb, Ui.matchWrap())
        }
        box.addView(scroll, Ui.matchWrap())

        // 全选 / 全不选
        val tools = Ui.hbox(context)
        tools.addView(Ui.emojiButton(context, "✅", "全选") { checks.forEach { it.isChecked = true } },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(Ui.emojiButton(context, "⬜", "全不选") { checks.forEach { it.isChecked = false } },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, context, 8f, 0f, 0f, 0f) })
        box.addView(tools, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, context, 0f, 10f, 0f, 0f)
        })

        dialog?.dismiss()
        dialog = AlertDialog.Builder(context)
            .setView(box)
            .setNegativeButton("返回", { _, _ ->
                showFolderLevel(dir, dir.name ?: "目录", ArrayList())
            })
            .setPositiveButton("导入选中") { _, _ ->
                val picked = ArrayList<Pick>()
                checks.forEachIndexed { i, cb ->
                    if (cb.isChecked) picked.add(Pick(videos[i].uri, episodeName))
                }
                dialog?.dismiss()
                onPicked?.invoke(picked)
            }
            .create()
        dialog?.show()
    }

    private fun rowItem(emoji: String, title: String, desc: String, onClick: () -> Unit): LinearLayout {
        val row = Ui.hbox(context)
        row.background = Ui.ghostBg(context)
        row.setPadding(Ui.dp(context, 12f), Ui.dp(context, 11f), Ui.dp(context, 12f), Ui.dp(context, 11f))
        row.addView(Ui.text(context, emoji, 17f), Ui.lp(Ui.dp(context, 30f), ViewGroup.LayoutParams.WRAP_CONTENT))
        val col = Ui.vbox(context)
        col.addView(Ui.text(context, title, 14f, Ui.TEXT_MAIN, maxLines = 1))
        if (desc.isNotBlank()) col.addView(Ui.text(context, desc, 11f, Ui.TEXT_SUB))
        row.addView(col, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, context, 8f, 0f, 0f, 0f)
        })
        row.addView(Ui.text(context, "›", 18f, Ui.TEXT_SUB))
        row.isClickable = true
        row.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(context, 8f)
        row.layoutParams = lp
        return row
    }

    private fun isVideo(f: DocumentFile): Boolean {
        val mime = f.type ?: ""
        if (mime.startsWith("video/")) return true
        val name = f.name ?: return false
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in VIDEO_EXT
    }

    fun dismiss() {
        dialog?.dismiss()
        dialog = null
    }
}
