package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ClipFeature
import com.lingxu.zhiying.model.ScriptLine
import kotlin.math.max
import kotlin.math.min

/**
 * 全局动态规划时序对齐（DP Matrix）
 *
 * 不做单行贪心匹配，而是构建「视频数 × 剧本句数」的二维得分矩阵，
 * 在矩阵上寻找全局最高分的**单调**路径：
 *
 *   - 单向游标：第 i 个视频命中的剧本序号必须 ≥ 第 i-1 个视频，杜绝「时空倒流」；
 *   - 跳跃惩罚：视频若跨过大量剧本句，得分按 [JUMP_PENALTY] 线性衰减；
 *   - 重复惩罚：多个视频落在同一句上时按 [REPEAT_PENALTY] 轻微扣分（混剪中允许一镜多切）；
 *   - 空位容忍：得分低于 [DROP_THRESHOLD] 的视频判定为「未命中」，不强行占用剧本坐标。
 *
 * 复杂度 O(N×M)，借助前缀最大值把转移降到常数时间。
 */
object DpAligner {

    private const val JUMP_PENALTY = 0.06f     // 每跳过一句剧本的衰减
    private const val REPEAT_PENALTY = 0.10f   // 与前一片段落在同一句的衰减
    private const val NEG_INF = -1e9f
    private const val DROP_THRESHOLD = 0.12f

    data class Cell(val score: Float, val visual: Float, val audio: Float)

    /**
     * 先验权重。
     *
     * 已停用「文件名自然序」先验（置 0）：素材文件名可能毫无意义，
     * 把它当时间轴会间接影响坐标分配，进而把场景组的先后带偏。
     * 先后判据统一交给 ContinuityChain 的首尾帧连续性全链重建。
     * 如需在"文件名确实有序"的素材上加速收敛，可把该值调回 0.05~0.10。
     */
    const val PRIOR_WEIGHT = 0f

    /**
     * 构建原始得分矩阵
     *
     * 每个格子的分 = 文本融合分 × 时长一致性因子 + 自然序先验 × PRIOR_WEIGHT
     * @param naturalPos 每个片段在文件名自然序中的位置，可为 null（不给先验）
     */
    fun buildMatrix(
        clips: List<ClipFeature>,
        lines: List<ScriptLine>,
        naturalPos: IntArray? = null
    ): Array<Array<Cell>> {
        val n = clips.size
        val m = lines.size
        val matrix = Array(n) { Array(m) { Cell(0f, 0f, 0f) } }
        for (i in 0 until n) {
            val clip = clips[i]
            for (j in 0 until m) {
                val (v, a) = TextSimilarity.score(lines[j].text, clip.ocrText, clip.asrText)
                var fused = TextSimilarity.fuse(v, a)
                fused *= TextSimilarity.durationFactor(lines[j].text, clip.durationMs)
                val prior = if (naturalPos != null && i < naturalPos.size) {
                    NaturalOrder.priorBonus(naturalPos[i], n, j, m) * PRIOR_WEIGHT
                } else 0f
                matrix[i][j] = Cell((fused + prior).coerceIn(0f, 1f), v, a)
            }
        }
        return matrix
    }

    /**
     * 求解全局最优单调路径
     * @return 每个视频对应的剧本句序号，-1 表示未命中
     */
    fun solve(matrix: Array<Array<Cell>>): IntArray {
        val n = matrix.size
        if (n == 0) return IntArray(0)
        val m = matrix[0].size
        if (m == 0) return IntArray(n) { -1 }

        // dp[i][j]：前 i+1 个视频，且第 i 个视频落在第 j 句时的最高累计分
        val dp = Array(n) { FloatArray(m) { NEG_INF } }
        val from = Array(n) { IntArray(m) { -1 } }
        // bestUpTo[j] = max(dp[i-1][0..j])，同时记录取到该最大值的列
        var bestUpTo = FloatArray(m) { NEG_INF }
        var bestIdx = IntArray(m) { -1 }

        for (j in 0 until m) {
            val s = matrix[0][j].score
            // 第一个视频允许落在任意句，但离开头越远惩罚越重
            dp[0][j] = s - JUMP_PENALTY * j
            bestUpTo[j] = if (j == 0) dp[0][j] else max(bestUpTo[j - 1], dp[0][j])
            bestIdx[j] = if (j == 0) 0 else if (dp[0][j] >= bestUpTo[j - 1]) j else bestIdx[j - 1]
        }

        for (i in 1 until n) {
            val newBest = FloatArray(m) { NEG_INF }
            val newIdx = IntArray(m) { -1 }
            for (j in 0 until m) {
                var best = NEG_INF
                var arg = -1
                // 转移来源：上一片段落在 j' ≤ j
                // 同句重复 → REPEAT_PENALTY；跨句 → 每句 JUMP_PENALTY
                for (jp in 0..j) {
                    if (dp[i - 1][jp] <= NEG_INF / 2) continue
                    val pen = if (jp == j) REPEAT_PENALTY else JUMP_PENALTY * (j - jp)
                    val v = dp[i - 1][jp] - pen
                    if (v > best) {
                        best = v
                        arg = jp
                    }
                }
                if (arg >= 0) {
                    dp[i][j] = best + matrix[i][j].score
                    from[i][j] = arg
                }
                newBest[j] = if (j == 0) dp[i][j] else max(newBest[j - 1], dp[i][j])
                newIdx[j] = if (j == 0) j else if (dp[i][j] >= newBest[j - 1]) j else newIdx[j - 1]
            }
            bestUpTo = newBest
            bestIdx = newIdx
        }

        // 回溯
        val result = IntArray(n) { -1 }
        var endJ = 0
        var endVal = NEG_INF
        for (j in 0 until m) {
            if (dp[n - 1][j] > endVal) {
                endVal = dp[n - 1][j]
                endJ = j
            }
        }
        var curJ = endJ
        for (i in n - 1 downTo 0) {
            result[i] = if (matrix[i][curJ].score < DROP_THRESHOLD) -1 else curJ
            val prev = from[i][curJ]
            if (prev < 0) break
            curJ = prev
        }
        return result
    }

    /**
     * 局部重推演（涟漪重排的核心）：
     * 只在 [lo, hi] 区间内、且未锁定的片段上重跑一次微型 DP，
     * 已锁定片段与区间外片段的坐标视为硬边界。
     */
    fun resolveRange(
        clips: List<AlignedClip>,
        matrix: Array<Array<Cell>>,
        lo: Int,
        hi: Int,
        minScript: Int,
        maxScript: Int
    ): IntArray {
        val from = max(0, lo)
        val to = min(clips.size - 1, hi)
        if (to < from) return IntArray(0)
        val rows = (from..to).filter { !clips[it].locked }
        if (rows.isEmpty()) return IntArray(0)

        val subMatrix = Array(rows.size) { r ->
            val i = rows[r]
            val js = (minScript..maxScript).toList()
            Array(js.size) { c -> matrix[i][js[c].coerceIn(0, matrix[i].size - 1)] }
        }
        val sub = solve(subMatrix)
        val out = IntArray(clips.size) { -2 } // -2 表示本次未参与
        rows.forEachIndexed { r, i ->
            val js = (minScript..maxScript).toList()
            out[i] = if (sub[r] in js.indices) js[sub[r]] else -1
        }
        return out
    }

    /** 把求解结果写回卡片列表 */
    fun apply(clips: List<AlignedClip>, matrix: Array<Array<Cell>>, assignment: IntArray) {
        clips.forEachIndexed { i, clip ->
            if (i >= assignment.size) return@forEachIndexed
            val j = assignment[i]
            clip.scriptIndex = j
            if (j in 0 until matrix[i].size) {
                val cell = matrix[i][j]
                clip.visualScore = cell.visual
                clip.audioScore = cell.audio
                clip.finalScore = cell.score
            } else {
                // 未命中：给出该片段的最高潜在分，便于用户判断
                var bv = 0f; var ba = 0f; var bs = 0f
                for (c in matrix[i]) {
                    if (c.score > bs) { bs = c.score; bv = c.visual; ba = c.audio }
                }
                clip.visualScore = bv
                clip.audioScore = ba
                clip.finalScore = bs
            }
        }
    }
}
