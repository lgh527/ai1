package com.lingxu.zhiying.core

import android.graphics.Bitmap
import android.graphics.Color

/**
 * 场景指纹（视觉指纹的增强版）
 *
 * 只靠 aHash 无法回答「同一句歌词，先出现的是小女孩还是男主」——
 * 因为两次演唱的字幕文字完全一样，文本通道彻底失效。
 * 但**画面不一样**：不同的人、不同的机位、不同的光线，色彩分布差别很大。
 *
 * 所以这里给每个片段额外算一份 32 位的 HSV 颜色直方图指纹：
 *   · 色相 H 分 16 桶（人物肤色、服装、背景主色都落在这里）
 *   · 饱和度 S 分 8 桶
 *   · 明度 V 分 8 桶
 * 再用 aHash 补充结构信息。两者合成一个「场景签名」，
 * 相同签名 = 大概率同一机位同一人，不同签名 = 不同场景。
 *
 * 有了场景分组，同词片段就能按「场景在整片里首次出现的先后」排序，
 * 小女孩的场景先出现，就一定排在男主前面，不会颠倒。
 */
object SceneFingerprint {

    private const val H_BINS = 16
    private const val S_BINS = 8
    private const val V_BINS = 8

    data class Scene(
        val histogram: FloatArray,   // H_BINS + S_BINS + V_BINS 归一化直方图
        val headHash: Long,
        val tailHash: Long,
        /** RGB 彩色指纹（192 位） */
        val colorHash: LongArray = LongArray(3)
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Scene) return false
            return headHash == other.headHash && histogram.contentEquals(other.histogram)
        }

        override fun hashCode(): Int = 31 * headHash.hashCode() + histogram.contentHashCode()
    }

    fun of(
        head: Bitmap?,
        tail: Bitmap?,
        headHash: Long,
        tailHash: Long,
        colorHash: LongArray = LongArray(3)
    ): Scene {
        val ref = head ?: tail
        return Scene(histogram(ref), headHash, tailHash, colorHash)
    }

    private fun histogram(bmp: Bitmap?): FloatArray {
        val bins = FloatArray(H_BINS + S_BINS + V_BINS)
        if (bmp == null) return bins
        val w = bmp.width
        val h = bmp.height
        val xStep = ((w / 64).coerceAtLeast(1))
        val yStep = ((h / 64).coerceAtLeast(1))
        var count = 0
        val hsv = FloatArray(3)
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p = bmp.getPixel(x, y)
                Color.RGBToHSV(Color.red(p), Color.green(p), Color.blue(p), hsv)
                val hIdx = ((hsv[0] / 360f) * H_BINS).toInt().coerceIn(0, H_BINS - 1)
                val sIdx = (hsv[1] * S_BINS).toInt().coerceIn(0, S_BINS - 1)
                val vIdx = (hsv[2] * V_BINS).toInt().coerceIn(0, V_BINS - 1)
                bins[hIdx] += 1f
                bins[H_BINS + sIdx] += 1f
                bins[H_BINS + S_BINS + vIdx] += 1f
                count++
                x += xStep
            }
            y += yStep
        }
        if (count > 0) {
            for (i in bins.indices) bins[i] = bins[i] / count
        }
        return bins
    }

    /** 直方图相似度（余弦），0..1 */
    fun histogramSimilarity(a: Scene, b: Scene): Float {
        var dot = 0f; var na = 0f; var nb = 0f
        val n = minOf(a.histogram.size, b.histogram.size)
        for (i in 0 until n) {
            dot += a.histogram[i] * b.histogram[i]
            na += a.histogram[i] * a.histogram[i]
            nb += b.histogram[i] * b.histogram[i]
        }
        if (na <= 0f || nb <= 0f) return 0f
        return (dot / (kotlin.math.sqrt(na) * kotlin.math.sqrt(nb))).coerceIn(0f, 1f)
    }

    /**
     * 综合场景相似度：色彩 0.6 + 画面结构 0.4
     */
    /**
     * 综合场景相似度：色彩直方图 0.40 + RGB 彩色指纹 0.35 + 灰度结构 0.25
     *
     * 加入 RGB 彩色指纹后，「同构图不同人」的镜头能被明确区分：
     * 小女孩的暖色调与男歌手的冷色调，即使画面结构接近，色彩指纹差异也很大。
     */
    fun similarity(a: Scene, b: Scene): Float {
        val hist = histogramSimilarity(a, b)
        val color = PerceptualHash.colorSimilarity(a.colorHash, b.colorHash)
        val struct = PerceptualHash.similarity(a.headHash, b.headHash)
        return if (color <= 0f) hist * 0.6f + struct * 0.4f
        else hist * 0.40f + color * 0.35f + struct * 0.25f
    }

    /**
     * 场景聚类：把相似度 ≥ [threshold] 的片段归为同一场景组。
     * 采用简单的贪心代表点聚类，O(n·k)，几十个片段完全够用。
     *
     * @return 每个片段的组号（0 起）
     */
    fun cluster(scenes: List<Scene>, threshold: Float = 0.86f): IntArray {
        val groups = ArrayList<Scene>()
        val label = IntArray(scenes.size) { -1 }
        scenes.forEachIndexed { i, s ->
            var best = -1
            var bestSim = threshold
            groups.forEachIndexed { gi, rep ->
                val sim = similarity(s, rep)
                if (sim >= bestSim) { bestSim = sim; best = gi }
            }
            if (best < 0) {
                groups.add(s)
                label[i] = groups.size - 1
            } else {
                label[i] = best
            }
        }
        return label
    }

    /** 组号 → 人类可读标签：场景A / 场景B … */
    fun label(group: Int): String {
        if (group < 0) return "场景?"
        val letter = ('A' + (group % 26))
        return if (group < 26) "场景$letter" else "场景$letter${group / 26}"
    }
}
