package com.lingxu.zhiying.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.lingxu.zhiying.core.OrderVerifier
import com.lingxu.zhiying.core.SceneFingerprint
import com.lingxu.zhiying.model.AlignedClip

/**
 * 智能校对与手动微调工作台
 *
 * 卡片上**只显示两样东西**：视频里提取出来的台词、剧本对应的台词。
 * 其余无关信息（时长、分辨率、抽帧数、哈希串）一律不显示，避免干扰判断。
 *
 * 红绿灯的语义是**顺序**，不是文字相似度：
 *   🟢 绿灯 = 这段在剧本时间线上的位置是对的
 *   🔴 红灯 = 顺序错了（倒流）或还没归位
 *
 * 因为 ASR / OCR 都可能出错别字，而**错别字不代表位置错**——
 * 只要片段落在剧本的正确坐标上，提取出的字即使有误，也判绿灯。
 */
class ClipCardAdapter(
    private val items: MutableList<AlignedClip>,
    private val lights: MutableList<OrderVerifier.Item>,
    private val onMoveUp: (Int) -> Unit,
    private val onMoveDown: (Int) -> Unit,
    private val onToggleLock: (Int, Boolean) -> Unit,
    private val onTrim: (Int, Long, Long) -> Unit = { _, _, _ -> },
    private val onToggleDuplicate: (Int) -> Unit = { _ -> }
) : RecyclerView.Adapter<ClipCardAdapter.CardHolder>() {

    private val expandedTrim = HashSet<Int>()

    class CardHolder(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val dot: View = root.findViewById(TAG_DOT)
        val headLine: TextView = root.findViewById(TAG_HEAD)
        val videoLine: TextView = root.findViewById(TAG_VIDEO)
        val scriptLine: TextView = root.findViewById(TAG_SCRIPT)
        val reasonLine: TextView = root.findViewById(TAG_REASON)
        val trimLine: TextView = root.findViewById(TAG_TRIM)
        val trimRow: LinearLayout = root.findViewById(TAG_TRIM_ROW)
        val btnUp: TextView = root.findViewById(TAG_UP)
        val btnDown: TextView = root.findViewById(TAG_DOWN)
        val btnLock: TextView = root.findViewById(TAG_LOCK)
        val btnTrim: TextView = root.findViewById(TAG_TRIM_BTN)
        val btnDup: TextView = root.findViewById(TAG_DUP)
    }

    companion object {
        private const val TAG_DOT = 0x7f0a0101
        private const val TAG_HEAD = 0x7f0a0102
        private const val TAG_VIDEO = 0x7f0a0103
        private const val TAG_SCRIPT = 0x7f0a0104
        private const val TAG_REASON = 0x7f0a0105
        private const val TAG_TRIM = 0x7f0a0106
        private const val TAG_TRIM_ROW = 0x7f0a0107
        private const val TAG_UP = 0x7f0a0108
        private const val TAG_DOWN = 0x7f0a0109
        private const val TAG_LOCK = 0x7f0a010A
        private const val TAG_TRIM_BTN = 0x7f0a010B
        private const val TAG_DUP = 0x7f0a010C
        private const val TRIM_STEP = 500L
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
        val ctx = parent.context
        val root = Ui.vbox(ctx)
        root.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = Ui.dp(ctx, 10f) }
        root.background = Ui.cardBg(ctx)
        root.setPadding(Ui.dp(ctx, 14f), Ui.dp(ctx, 12f), Ui.dp(ctx, 14f), Ui.dp(ctx, 12f))

        // ---- 第一行：红绿灯 + 序号 + 集/场景标签 ----
        val head = Ui.hbox(ctx)
        val dot = View(ctx).apply {
            id = TAG_DOT
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(Ui.GREEN))
            }
        }
        head.addView(dot, Ui.lp(Ui.dp(ctx, 12f), Ui.dp(ctx, 12f)))
        val headLine = Ui.text(ctx, "01", 14f, Ui.TEXT_MAIN, bold = true, maxLines = 1).apply { id = TAG_HEAD }
        head.addView(headLine, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, ctx, 9f, 0f, 0f, 0f)
        })
        root.addView(head, Ui.matchWrap())

        // ---- 第二行：视频里提取的台词 ----
        val video = twoLine(ctx, "视频台词", "（无）", TAG_VIDEO)
        root.addView(video, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 10f, 0f, 0f) })

        // ---- 第三行：剧本对应台词 ----
        val script = twoLine(ctx, "剧本台词", "（未匹配）", TAG_SCRIPT)
        root.addView(script, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 6f, 0f, 0f) })

        // ---- 第四行：红灯原因 ----
        val reason = Ui.text(ctx, "", 11f, Ui.RED).apply { id = TAG_REASON; visibility = View.GONE }
        root.addView(reason, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 8f, 0f, 0f) })

        // ---- 裁剪信息 + 裁剪按钮行（默认折叠）----
        val trimLine = Ui.text(ctx, "", 11f, Ui.AMBER).apply { id = TAG_TRIM; visibility = View.GONE }
        root.addView(trimLine, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 6f, 0f, 0f) })

        val trimRow = Ui.hbox(ctx).apply { id = TAG_TRIM_ROW; visibility = View.GONE }
        val inMinus = Ui.emojiButton(ctx, "◀", "入点-") {}
        val inPlus = Ui.emojiButton(ctx, "▶", "入点+") {}
        val outMinus = Ui.emojiButton(ctx, "◀", "出点-") {}
        val outPlus = Ui.emojiButton(ctx, "▶", "出点+") {}
        val reset = Ui.emojiButton(ctx, "♻️", "复原") {}
        inMinus.id = 0x7f0a0111; inPlus.id = 0x7f0a0112
        outMinus.id = 0x7f0a0113; outPlus.id = 0x7f0a0114; reset.id = 0x7f0a0115
        listOf(inMinus, inPlus, outMinus, outPlus, reset).forEachIndexed { i, v ->
            trimRow.addView(v, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) Ui.margin(this, ctx, 5f, 0f, 0f, 0f)
            })
        }
        root.addView(trimRow, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, ctx, 0f, 8f, 0f, 0f)
        })

        // ---- 操作行 ----
        val row = Ui.hbox(ctx)
        val up = Ui.emojiButton(ctx, "⬆️", "上移") {}.apply { id = TAG_UP }
        val down = Ui.emojiButton(ctx, "⬇️", "下移") {}.apply { id = TAG_DOWN }
        val lock = Ui.emojiButton(ctx, "🔒", "锁定") {}.apply { id = TAG_LOCK }
        val trim = Ui.emojiButton(ctx, "✂️", "裁剪") {}.apply { id = TAG_TRIM_BTN }
        val dup = Ui.emojiButton(ctx, "🚫", "重复") {}.apply { id = TAG_DUP }
        listOf(up, down, lock, trim, dup).forEachIndexed { i, v ->
            row.addView(v, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) Ui.margin(this, ctx, 5f, 0f, 0f, 0f)
            })
        }
        root.addView(row, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, ctx, 0f, 10f, 0f, 0f)
        })

        return CardHolder(root)
    }

    private fun twoLine(ctx: android.content.Context, label: String, value: String, id: Int): LinearLayout {
        val box = Ui.vbox(ctx)
        box.background = Ui.ghostBg(ctx)
        box.setPadding(Ui.dp(ctx, 10f), Ui.dp(ctx, 8f), Ui.dp(ctx, 10f), Ui.dp(ctx, 8f))
        val l = Ui.text(ctx, label, 10f, Ui.TEXT_SUB)
        val v = Ui.text(ctx, value, 14f, Ui.TEXT_MAIN).apply { this.id = id }
        box.addView(l, Ui.matchWrap())
        box.addView(v, Ui.matchWrap())
        box.tag = v
        return box
    }

    override fun onBindViewHolder(holder: CardHolder, position: Int) {
        val ctx = holder.root.context
        val item = items[position]
        val light = lights.getOrNull(position) ?: OrderVerifier.Item(OrderVerifier.Light.GRAY, "")
        val f = item.feature

        // 红绿灯
        val colorHex = when (light.light) {
            OrderVerifier.Light.GREEN -> Ui.GREEN
            OrderVerifier.Light.RED -> Ui.RED
            OrderVerifier.Light.GRAY -> Ui.TEXT_SUB
        }
        (holder.dot.background as? GradientDrawable)?.setColor(Color.parseColor(colorHex))

        // 头部：序号 + 集名 + 场景 + 文件名（只留识别必需的信息）
        val tags = StringBuilder()
        if (item.scriptIndex >= 0 && extractedTag(item)) tags.append("无文本证据 · ")
        if (f.episode.isNotBlank()) tags.append(f.episode).append(" · ")
        if (f.sceneGroup >= 0) tags.append(SceneFingerprint.label(f.sceneGroup)).append(" · ")
        if (item.isDuplicate) tags.append("重复段 · ")
        holder.headLine.text = String.format("%02d", position + 1) + "  " + tags.toString().trimEnd(' ', '·') +
                "  " + f.displayName.take(16)
        holder.headLine.setTextColor(Color.parseColor(if (item.isDuplicate) Ui.AMBER else Ui.TEXT_MAIN))

        // 只展示台词对比，不展示任何其他内容
        // 只显示与剧本句对应的那一段台词，其余内容一律不显示
        val extracted = item.matchedExtract
        val hasAnySignal = f.ocrText.isNotBlank() || f.asrText.isNotBlank()
        setLineValue(
            holder.videoLine,
            when {
                extracted.isNotBlank() -> extracted
                hasAnySignal -> "（有文字但与本句剧本未精确对应）"
                else -> "（本段无字幕、无人声，仅按画面归位）"
            },
            if (extracted.isBlank()) Ui.TEXT_SUB else Ui.TEXT_MAIN
        )
        setLineValue(holder.scriptLine, item.matchedScriptText.ifBlank { "（未匹配到剧本句）" },
            if (item.matchedScriptText.isBlank()) Ui.TEXT_SUB else Ui.CYAN)

        if (light.light == OrderVerifier.Light.RED) {
            holder.reasonLine.visibility = View.VISIBLE
            holder.reasonLine.text = "🔴 " + light.reason
        } else {
            holder.reasonLine.visibility = View.GONE
        }

        // 裁剪状态
        val hasTrim = item.trimInMs > 0 || item.trimOutMs > 0
        holder.trimLine.visibility = if (hasTrim) View.VISIBLE else View.GONE
        if (hasTrim) {
            val inTxt = if (item.trimInMs > 0) String.format("%.1fs", item.trimInMs / 1000f) else "片头"
            val outTxt = if (item.trimOutMs > 0) String.format("%.1fs", item.trimOutMs / 1000f) else "片尾"
            holder.trimLine.text = "✂️ 保留 $inTxt → $outTxt"
        }
        holder.trimRow.visibility = if (expandedTrim.contains(position)) View.VISIBLE else View.GONE

        holder.btnLock.text = if (item.locked) "🔓 解锁" else "🔒 锁定"
        holder.btnDup.text = if (item.isDuplicate) "✅ 恢复" else "🚫 重复"

        if (item.locked) {
            holder.root.background = Ui.cardBg(ctx, "#121A28", Ui.AMBER, 16f)
        } else if (light.light == OrderVerifier.Light.RED) {
            holder.root.background = Ui.cardBg(ctx, "#1A0E14", Ui.RED, 16f)
        } else {
            holder.root.background = Ui.cardBg(ctx, "#0E1420", "#1B3A2E", 16f)
        }

        holder.btnUp.alpha = if (position == 0) 0.35f else 1f
        holder.btnDown.alpha = if (position == items.size - 1) 0.35f else 1f

        holder.btnUp.setOnClickListener { pos(holder).let { if (it > 0) onMoveUp(it) } }
        holder.btnDown.setOnClickListener {
            pos(holder).let { if (it in 0 until items.size - 1) onMoveDown(it) }
        }
        holder.btnLock.setOnClickListener {
            pos(holder).let { if (it in items.indices) onToggleLock(it, !items[it].locked) }
        }
        holder.btnDup.setOnClickListener { pos(holder).let { if (it in items.indices) onToggleDuplicate(it) } }
        holder.btnTrim.setOnClickListener {
            val p = pos(holder)
            if (p >= 0) {
                if (expandedTrim.contains(p)) expandedTrim.remove(p) else expandedTrim.add(p)
                notifyItemChanged(p)
            }
        }
        bindTrimButtons(holder) { deltaIn, deltaOut, reset ->
            val p = pos(holder)
            if (p !in items.indices) return@bindTrimButtons
            if (reset) {
                items[p].trimInMs = -1L
                items[p].trimOutMs = -1L
                notifyItemChanged(p)
            } else {
                onTrim(p, deltaIn, deltaOut)
            }
        }
    }

    private fun pos(holder: CardHolder): Int = holder.bindingAdapterPosition

    /** 绿灯但完全没有任何文本/画面归位证据时给出提示，保证红绿灯可被核查 */
    private fun extractedTag(item: AlignedClip): Boolean =
        item.feature.ocrText.isBlank() && item.feature.asrText.isBlank() && !item.byHash

    private fun setLineValue(tv: TextView, value: String, colorHex: String) {
        tv.text = value
        tv.setTextColor(Color.parseColor(colorHex))
    }

    private fun bindTrimButtons(holder: CardHolder, act: (Long, Long, Boolean) -> Unit) {
        val row = holder.trimRow
        row.findViewById<TextView>(0x7f0a0111)?.setOnClickListener { act(-TRIM_STEP, 0L, false) }
        row.findViewById<TextView>(0x7f0a0112)?.setOnClickListener { act(TRIM_STEP, 0L, false) }
        row.findViewById<TextView>(0x7f0a0113)?.setOnClickListener { act(0L, -TRIM_STEP, false) }
        row.findViewById<TextView>(0x7f0a0114)?.setOnClickListener { act(0L, TRIM_STEP, false) }
        row.findViewById<TextView>(0x7f0a0115)?.setOnClickListener { act(0L, 0L, true) }
    }

    override fun getItemCount(): Int = items.size

    fun submitLights(newLights: List<OrderVerifier.Item>) {
        lights.clear()
        lights.addAll(newLights)
    }
}
