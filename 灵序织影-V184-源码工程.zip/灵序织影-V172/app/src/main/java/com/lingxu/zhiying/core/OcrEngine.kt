package com.lingxu.zhiying.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions

/**
 * 视觉大模型：Google ML Kit 中文离线文字识别
 *
 * 与 [SubtitleBand] 配合：先定位字幕带、动态放大，再送 OCR。
 * 全流程离线，断网可用。
 */
object OcrEngine {

    @Volatile
    private var recognizer: com.google.mlkit.vision.text.TextRecognizer? = null

    private val NOISE = Regex("[\\s\\-_=*#|\\\\/{}\\[\\]<>~`]+")
    private val WATERMARK_HINT = Regex("(高清|无水印|字幕组|www\\.|http|\\.com|\\.cn|抖音|快手|B站| bilibili )", RegexOption.IGNORE_CASE)

    fun init(context: Context) {
        if (recognizer == null) {
            synchronized(this) {
                if (recognizer == null) {
                    recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                    LogX.i("OcrEngine", "ML Kit 中文 OCR 已就绪")
                }
            }
        }
    }

    /** 同步识别单帧，返回清洗后的文本 */
    fun recognize(bitmap: Bitmap?): String {
        if (bitmap == null) return ""
        val client = recognizer ?: return ""
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = Tasks.await(client.process(image))
            clean(result.text)
        } catch (e: Throwable) {
            LogX.w("OcrEngine", "识别失败: ${e.message}")
            ""
        }
    }

    /**
     * OCR 预处理增强：灰度化 + 直方图对比度拉伸 + gamma 校正 + 轻度锐化。
     *
     * 影视字幕常见三种难识别形态：半透明底、描边字、渐变彩色字。
     * 直接送 ML Kit 命中率低，先做这几步能明显改善。
     */
    fun enhanceForOcr(src: Bitmap?): Bitmap {
        if (src == null) return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val gray = IntArray(px.size)
        val hist = IntArray(256)
        for (i in px.indices) {
            val p = px[i]
            val g = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p))
                .toInt().coerceIn(0, 255)
            gray[i] = g
            hist[g]++
        }
        val total = gray.size
        var acc = 0
        var lo = 0
        var hi = 255
        for (v in 0..255) {
            acc += hist[v]
            if (lo == 0 && acc >= total * 0.02) lo = v
            if (acc >= total * 0.98) { hi = v; break }
        }
        if (hi - lo < 20) { lo = 0; hi = 255 }
        val span = (hi - lo).toFloat()

        val lut = IntArray(256)
        for (v in 0..255) {
            val t = ((v - lo) / span).coerceIn(0f, 1f)
            lut[v] = (255 * Math.pow(t.toDouble(), 0.85)).toInt().coerceIn(0, 255)
        }

        val out = IntArray(px.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val c = lut[gray[i]]
                var v = c
                if (x in 1 until w - 1 && y in 1 until h - 1) {
                    val lap = 4 * lut[gray[i]] -
                            lut[gray[i - 1]] - lut[gray[i + 1]] -
                            lut[gray[i - w]] - lut[gray[i + w]]
                    v = (c + 0.35f * (lap - c)).toInt().coerceIn(0, 255)
                }
                out[i] = Color.rgb(v, v, v)
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    /** 裁出画面底部指定比例的区域（字幕带漏检时的兜底扫描区） */
    fun cropBottom(src: Bitmap, ratio: Float): Bitmap {
        val h = (src.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createBitmap(src, 0, src.height - h, src.width, h)
    }

    /**
     * 多帧合并：同一句字幕会在连续多帧重复出现，
     * 这里按「行」去重并保留出现次数最多的表达，抑制单帧误识别。
     */
    fun mergeFrames(texts: List<String>): String {
        val counter = LinkedHashMap<String, Int>()
        texts.filter { it.isNotBlank() }.forEach { t ->
            t.split('\n').map { it.trim() }.filter { it.length >= 2 }.forEach { line ->
                counter[line] = (counter[line] ?: 0) + 1
            }
        }
        if (counter.isEmpty()) return ""
        // 出现 2 次以上的行更可信，优先保留；孤行按原顺序补足
        val reliable = counter.filter { it.value >= 2 }.keys
        val singles = counter.keys.filter { it !in reliable }
        val picked = if (reliable.isNotEmpty()) reliable + singles else counter.keys
        return picked.joinToString("") { it }
    }

    private fun clean(raw: String): String {
        var s = raw
        // 去掉 OCR 常见的换行断句，中文台词不需要
        s = s.replace("\n", "")
        // 去水印/域名等干扰串
        s = WATERMARK_HINT.replace(s, "")
        s = NOISE.replace(s, "")
        // 只保留中文、字母、数字与基本标点
        s = s.filter { it.code in 0x4E00..0x9FA5 || it.isLetterOrDigit() || it in "，。！？、；：“”‘’" }
        return s.trim()
    }

    fun release() {
        try {
            recognizer?.close()
        } catch (_: Throwable) {
        }
        recognizer = null
    }
}
