package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip

/**
 * 首尾帧连续性全链重建（Continuity Chain Reconstruction）
 *
 * 目的：彻底摆脱「文件名自然序」这个不可靠的时序代理。
 * 素材文件名可能毫无意义（VID_xxxx、微信导出名、随机哈希），
 * 用它当时间轴会把顺序排反——MV 里小女孩在前、男歌手在后被排反就是这么来的。
 *
 * 真正客观的时序证据只有画面本身：
 *   如果 A 的**尾帧**和 B 的**首帧**几乎是同一画面，那么 A 必然紧接在 B 前面。
 *
 * 算法分三步：
 *
 *  1. **建边**：对所有片段两两计算衔接度
 *     `visualContinuity(A.tailHash/A.colorTail → B.headHash/B.colorHead)`
 *     （RGB 彩色指纹 0.6 + 灰度结构 0.4），超过 [LINK_THRESHOLD] 记为一条有向边 A→B。
 *
 *  2. **建链**：每个节点只保留得分最高的出边与入边（互选优先），
 *     沿出边游走出若干条不重叠的链；孤立片段自成单节点链。
 *     带环检测，避免死循环。
 *
 *  3. **串链**：链与链之间用「上一条链的尾帧 → 下一条链的首帧」的衔接度贪心拼接。
 *     起点锚定在**剧本坐标最小**的那条链上（用剧情顺序当锚，不用文件名），
 *     若坐标全部缺失则退化为「没有入边的链」优先。
 *     衔接度都很低时，按剧本坐标兜底排序。
 *
 * 输出每个片段在重建时间轴上的位次（rank），
 * 供 [SameCoordOrderer] 与 [OrderVerifier] 替代文件名自然序使用。
 */
object ContinuityChain {

    /** 建链阈值：高于它才认为是"同一镜头被切开"的硬衔接 */
    const val LINK_THRESHOLD = 0.80f

    /** 串链阈值：链间衔接度低于它就认为证据不足，转用剧本坐标兜底 */
    const val CHAIN_LINK_THRESHOLD = 0.62f

    data class Result(
        /** 每个片段在重建时间轴上的位次（0 起） */
        val ranks: IntArray,
        /** 重建后的片段顺序（下标引用原列表） */
        val order: List<Int>,
        val chainCount: Int,
        val linkedPairs: Int,
        /** 有多少片段拿到了硬衔接证据 */
        val anchoredCount: Int,
        val confidence: Float
    ) {
        fun summary(total: Int): String =
            "连续性全链重建：$chainCount 条链 / 硬衔接 $linkedPairs 对 / " +
                    "有证据片段 $anchoredCount/$total / 置信度 ${(confidence * 100).toInt()}%"
    }

    /**
     * @param clips 待排序的片段（顺序无关，本方法不依赖传入顺序）
     */
    fun build(clips: List<AlignedClip>): Result {
        val n = clips.size
        if (n == 0) return Result(IntArray(0), emptyList(), 0, 0, 0, 0f)
        if (n == 1) return Result(intArrayOf(0), listOf(0), 1, 0, 0, 0f)

        // ---------- 1. 衔接度矩阵 ----------
        val score = Array(n) { FloatArray(n) }
        for (i in 0 until n) {
            val a = clips[i].feature
            for (j in 0 until n) {
                if (i == j) continue
                val b = clips[j].feature
                score[i][j] = PerceptualHash.visualContinuity(
                    a.tailHash, a.colorTail, b.headHash, b.colorHead
                )
            }
        }

        // ---------- 2. 选出每条硬衔接边（互选优先，其次单向最强）----------
        val succ = IntArray(n) { -1 }
        val pred = IntArray(n) { -1 }
        for (i in 0 until n) {
            var bestJ = -1
            var bestV = LINK_THRESHOLD
            for (j in 0 until n) {
                if (i == j) continue
                if (score[i][j] > bestV) { bestV = score[i][j]; bestJ = j }
            }
            succ[i] = bestJ
            if (bestJ >= 0) pred[bestJ] = i
        }
        // 互选校验：若 j 的最优前驱不是 i，说明存在竞争，保留更强的一方
        for (i in 0 until n) {
            val j = succ[i]
            if (j >= 0 && pred[j] != i) {
                if (score[pred[j]][j] > score[i][j]) succ[i] = -1
                else pred[j] = i
            }
        }

        var linkedPairs = 0
        for (i in 0 until n) if (succ[i] >= 0) linkedPairs++

        // ---------- 3. 沿出边游走出链 ----------
        val chains = ArrayList<ArrayList<Int>>()
        val used = BooleanArray(n)
        // 链头 = 没有入边的节点；先处理它们，剩下的按环外任意节点起链
        val heads = (0 until n).filter { pred[it] < 0 }
        val starters = heads + (0 until n).filter { it !in heads }
        for (start in starters) {
            if (used[start]) continue
            val chain = ArrayList<Int>()
            var cur = start
            var guard = 0
            while (cur >= 0 && !used[cur] && guard++ <= n) {
                used[cur] = true
                chain.add(cur)
                cur = succ[cur]
            }
            if (chain.isNotEmpty()) chains.add(chain)
        }

        // ---------- 4. 串链：起点锚定剧本坐标最小的链 ----------
        fun minCoord(chain: List<Int>): Int {
            var m = Int.MAX_VALUE
            chain.forEach { i ->
                val c = clips[i].scriptIndex
                if (c in 0 until Int.MAX_VALUE && c < m) m = c
            }
            return if (m == Int.MAX_VALUE) Int.MAX_VALUE - 1 else m
        }

        val placed = BooleanArray(chains.size)
        val sequence = ArrayList<Int>(n)

        var startChain = -1
        var bestCoord = Int.MAX_VALUE
        chains.forEachIndexed { ci, chain ->
            val mc = minCoord(chain)
            // 坐标相同则优先选"没有外部入边"的链，它更像整片的开头
            val externalIn = chain.any { idx -> pred[idx] >= 0 && !chain.contains(pred[idx]) }
            val key = mc * 2 + (if (externalIn) 1 else 0)
            if (key < bestCoord) { bestCoord = key; startChain = ci }
        }
        if (startChain < 0) startChain = 0

        var current = startChain
        while (true) {
            placed[current] = true
            sequence.addAll(chains[current])
            val tailIdx = chains[current].last()

            // 找与当前尾帧衔接最强的未放置链
            var nextChain = -1
            var bestScore = CHAIN_LINK_THRESHOLD
            chains.forEachIndexed { ci, chain ->
                if (placed[ci]) return@forEachIndexed
                val headIdx = chain.first()
                val v = score[tailIdx][headIdx]
                if (v > bestScore) { bestScore = v; nextChain = ci }
            }
            if (nextChain >= 0) {
                current = nextChain
                continue
            }
            // 衔接证据不足：用剧本坐标兜底挑下一条
            var fallback = -1
            var fbCoord = Int.MAX_VALUE
            chains.forEachIndexed { ci, chain ->
                if (placed[ci]) return@forEachIndexed
                val mc = minCoord(chain)
                if (mc < fbCoord) { fbCoord = mc; fallback = ci }
            }
            if (fallback < 0) break
            current = fallback
        }

        // 补齐（理论上不会发生，防御性处理）
        for (i in 0 until n) if (!sequence.contains(i)) sequence.add(i)

        // ---------- 5. 输出位次 ----------
        val ranks = IntArray(n)
        sequence.forEachIndexed { pos, idx -> ranks[idx] = pos }

        val anchored = (0 until n).count { succ[it] >= 0 || pred[it] >= 0 }
        val confidence = if (n <= 1) 0f else anchored.toFloat() / n

        LogX.i(
            "Chain",
            "链数=${chains.size} 硬衔接=$linkedPairs 有证据=$anchored/$n 置信度=$confidence"
        )
        return Result(ranks, sequence, chains.size, linkedPairs, anchored, confidence)
    }

    /**
     * 同坐标片段的先后：完全按重建位次决定，不看文件名。
     */
    fun compareByRank(ranks: IntArray, a: Int, b: Int): Int {
        val ra = if (a in ranks.indices) ranks[a] else Int.MAX_VALUE
        val rb = if (b in ranks.indices) ranks[b] else Int.MAX_VALUE
        return ra.compareTo(rb)
    }
}
