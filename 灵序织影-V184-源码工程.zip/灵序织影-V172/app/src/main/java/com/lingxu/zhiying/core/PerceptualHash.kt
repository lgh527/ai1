package com.lingxu.zhiying.core

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/**
 * 感知哈希指纹（aHash）
 *
 * 把画面缩放为 8x8 灰度图，与 64 个像素的平均亮度逐一对比，
 * 大于均值记 1、否则记 0，得到 64 位二进制指纹。
 * 用于「静音 / 无字幕片段」的视觉归位与相邻镜头连续性判定。
 */
object PerceptualHash {

    private const val SIZE = 8

    fun aHash(bitmap: Bitmap?): Long {
        if (bitmap == null) return 0L
        val small = try {
            Bitmap.createScaledBitmap(bitmap, SIZE, SIZE, true)
        } catch (e: Throwable) {
            return 0L
        }
        val gray = IntArray(SIZE * SIZE)
        var sum = 0
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val p = small.getPixel(x, y)
                // ITU-R BT.601 亮度
                val g = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
                gray[y * SIZE + x] = g
                sum += g
            }
        }
        if (small !== bitmap) small.recycle()
        val avg = sum / (SIZE * SIZE)
        var hash = 0L
        for (i in gray.indices) {
            hash = hash shl 1
            if (gray[i] > avg) hash = hash or 1L
        }
        return hash
    }

    // ==================================================================
    //  RGB 彩色指纹（192 位 = R/G/B 各 64 位）
    //
    //  灰度 aHash 只记亮度结构，无法区分「同样构图、不同色调」的画面，
    //  例如 MV 里小女孩的暖色镜头与男歌手的冷色镜头。
    //  彩色指纹对 R、G、B 三个通道分别与各自的通道均值比较，
    //  得到 3 × 64 = 192 位，既保留结构又保留色彩倾向。
    // ==================================================================

    /** 返回 LongArray(3)，依次为 R / G / B 通道的 64 位指纹 */
    fun colorHash(bitmap: Bitmap?): LongArray {
        val empty = LongArray(3)
        if (bitmap == null) return empty
        val small = try {
            Bitmap.createScaledBitmap(bitmap, SIZE, SIZE, true)
        } catch (e: Throwable) {
            return empty
        }
        val px = IntArray(SIZE * SIZE)
        small.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
        if (small !== bitmap) small.recycle()

        var sumR = 0L; var sumG = 0L; var sumB = 0L
        for (p in px) {
            sumR += Color.red(p); sumG += Color.green(p); sumB += Color.blue(p)
        }
        val n = px.size
        val avgR = (sumR / n).toInt()
        val avgG = (sumG / n).toInt()
        val avgB = (sumB / n).toInt()

        var hr = 0L; var hg = 0L; var hb = 0L
        for (i in px.indices) {
            val p = px[i]
            hr = hr shl 1; if (Color.red(p) > avgR) hr = hr or 1L
            hg = hg shl 1; if (Color.green(p) > avgG) hg = hg or 1L
            hb = hb shl 1; if (Color.blue(p) > avgB) hb = hb or 1L
        }
        return longArrayOf(hr, hg, hb)
    }

    /** 彩色指纹汉明距离（0..192） */
    fun colorHamming(a: LongArray, b: LongArray): Int {
        if (a.size < 3 || b.size < 3) return 192
        return hamming(a[0], b[0]) + hamming(a[1], b[1]) + hamming(a[2], b[2])
    }

    /** 彩色指纹相似度 0f..1f */
    fun colorSimilarity(a: LongArray, b: LongArray): Float {
        if (a.size < 3 || b.size < 3) return 0f
        if (a[0] == 0L && a[1] == 0L && a[2] == 0L) return 0f
        if (b[0] == 0L && b[1] == 0L && b[2] == 0L) return 0f
        return 1f - colorHamming(a, b) / 192f
    }

    /** 综合视觉相似度：彩色 0.6 + 灰度结构 0.4 */
    fun visualSimilarity(aHash1: Long, color1: LongArray, aHash2: Long, color2: LongArray): Float {
        val c = colorSimilarity(color1, color2)
        val g = similarity(aHash1, aHash2)
        return if (c <= 0f) g else c * 0.6f + g * 0.4f
    }

    /** 综合衔接度：前一段尾帧 vs 后一段首帧 */
    fun visualContinuity(
        prevTailHash: Long, prevTailColor: LongArray,
        nextHeadHash: Long, nextHeadColor: LongArray
    ): Float = visualSimilarity(prevTailHash, prevTailColor, nextHeadHash, nextHeadColor)

    fun colorToHex(c: LongArray): String =
        if (c.size < 3) "0000000000000000" else String.format("%016X", c[0]).take(6) +
                String.format("%016X", c[1]).take(5) + String.format("%016X", c[2]).take(5)

    /** 汉明距离：两个指纹有多少位不同 */
    fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    /** 相似度 0f..1f，汉明距离越小越像 */
    fun similarity(a: Long, b: Long): Float {
        if (a == 0L || b == 0L) return 0f
        return 1f - hamming(a, b) / 64f
    }

    fun toHex(hash: Long): String = String.format("%016X", hash)

    /** 生成 4x4 的可视化色块，用于卡片上的「视觉指纹」展示 */
    fun toBlocks(hash: Long): List<Boolean> {
        val out = ArrayList<Boolean>(64)
        for (i in 0 until 64) {
            out.add((hash ushr (63 - i)) and 1L == 1L)
        }
        return out
    }

    /** 两个片段的「首尾衔接度」：前一段尾帧 vs 后一段首帧 */
    fun continuity(prevTail: Long, nextHead: Long): Float = similarity(prevTail, nextHead)

    /** 判断是否为近乎相同的画面（阈值 0.85 由调用方掌握，这里给出差值） */
    fun diffBits(prevTail: Long, nextHead: Long): Int = abs(hamming(prevTail, nextHead))
}
