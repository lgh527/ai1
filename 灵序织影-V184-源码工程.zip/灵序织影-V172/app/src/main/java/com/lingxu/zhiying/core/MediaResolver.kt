package com.lingxu.zhiying.core

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File

/**
 * Uri → FFmpeg 可用路径
 *
 * 之前"读取成功 0 / 27"的根因就在这里：
 * 文件夹（SAF）导入拿到的是 tree 派生的 document URI，
 * 它**没有 DATA 列**，而旧实现拿不到 DATA 就去复制流，
 * 复制一旦失败就把原始 content:// 字符串直接丢给 FFmpeg，
 * FFmpeg 打不开 → 抽帧 0 → OCR/ASR 全空 → 得分矩阵全 0 → 顺序全乱。
 *
 * 现在改成四级策略，并且**每一级都做真实可读性验证**，失败原因会记录进诊断报告：
 *   1. DATA 列真实路径（MediaStore 素材）
 *   2. FFmpegKit 的 SAF 通道：直接把 content:// 交给 FFmpeg（ffmpeg-kit 原生支持）
 *   3. 复制流到 cacheDir 后用本地路径
 *   4. 全部失败 → 返回 null，并把异常原因写进 lastError
 */
object MediaResolver {

    data class Resolved(
        val path: String,
        val displayName: String,
        val size: Long,
        /** true = 本地文件路径；false = 尚未落地（相册查询结果，使用前会先复制） */
        val isLocalFile: Boolean
    )

    /** 最近一次解析失败的原因，供诊断面板展示 */
    @Volatile
    var lastError: String = ""
        private set

    /** 累计统计，诊断面板直接用 */
    var okCount = 0
        private set
    var failCount = 0
        private set
    var contentModeCount = 0
        private set

    fun resetStats() {
        okCount = 0; failCount = 0; contentModeCount = 0; lastError = ""
    }

    fun resolve(context: Context, uri: Uri): Resolved? {
        val name = cleanName(queryName(context, uri))

        // ---- 策略 1：DATA 真实路径 ----
        val data = queryDataPath(context, uri)
        if (data != null) {
            val f = File(data)
            if (f.exists() && f.length() > 0 && f.canRead()) {
                okCount++
                return Resolved(f.absolutePath, name, f.length(), true)
            }
        }

        // ---- 策略 2：复制到私有缓存，得到 FFmpeg 一定能读的本地路径 ----
        // 说明：不能把 content:// 直接交给 FFmpeg。ffmpeg-kit 的 SAF 通道依赖
        // Context 注入且在各厂商 ROM 上表现不稳，一旦打不开就是"抽帧 0 张"的静默失败。
        // 复制成真实文件虽然多花一点时间和空间，但确定性最高。
        val copied = copyToCache(context, uri, name)
        if (copied != null) {
            okCount++
            return copied
        }

        failCount++
        lastError = "「$name」无法读取：DATA 列不可用，且复制失败（$lastError）"
        LogX.e("MediaResolver", lastError)
        return null
    }

    private fun canOpenStream(context: Context, uri: Uri): Boolean {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buf = ByteArray(8)
                val n = input.read(buf)
                n > 0
            } ?: false
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.message}"
            false
        }
    }

    private fun copyToCache(context: Context, uri: Uri, name: String): Resolved? {
        return try {
            val dir = File(context.cacheDir, "inputs").apply { if (!exists()) mkdirs() }
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val out = File(dir, "${System.currentTimeMillis()}_$safe")
            context.contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { output -> input.copyTo(output, 1024 * 256) }
            } ?: run {
                lastError = "openInputStream 返回 null（权限未持久化？）"
                return null
            }
            if (out.length() <= 0) {
                out.delete()
                lastError = "复制后文件为 0 字节"
                return null
            }
            Resolved(out.absolutePath, name, out.length(), true)
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * 清洗显示名：SAF 的 document URI 末段是 URL 编码的
     * 「primary:DCIM/Camera/xxx.mp4」，直接显示会变成 primary%3ADCIM%2 这种乱码。
     * 解码后取真正的文件名。
     */
    fun cleanName(raw: String?): String {
        if (raw.isNullOrBlank()) return "video"
        return try {
            var n = java.net.URLDecoder.decode(raw, "UTF-8")
            n = n.substringAfterLast('/').substringAfterLast(':')
            if (n.isBlank()) "video" else n
        } catch (e: Throwable) {
            raw.substringAfterLast('/').takeIf { it.isNotBlank() } ?: "video"
        }
    }

    private fun queryName(context: Context, uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        } catch (e: Throwable) {
            null
        } finally {
            cursor?.close()
        }
    }

    @Suppress("DEPRECATION")
    private fun queryDataPath(context: Context, uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(
                uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null
            )
            if (cursor != null && cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        } catch (e: Throwable) {
            // SAF document URI 没有 DATA 列，这里抛异常是正常的
            null
        } finally {
            cursor?.close()
        }
    }

    /** 批量列出相册视频（不走 SAF 时使用） */
    fun queryAllVideos(context: Context, limit: Int = 300): List<Resolved> {
        val out = ArrayList<Resolved>()
        var cursor: Cursor? = null
        try {
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE
            )
            cursor = context.contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Video.Media.DATE_TAKEN} DESC"
            )
            if (cursor != null) {
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                while (cursor.moveToNext() && out.size < limit) {
                    val id = cursor.getLong(idCol)
                    val u = Uri.withAppendedPath(collection, id.toString())
                    out.add(
                        Resolved(
                            path = u.toString(),
                            displayName = cursor.getString(nameCol) ?: "video_$id",
                            size = 0L,
                            isLocalFile = false
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            LogX.e("MediaResolver", "查询相册失败", e)
        } finally {
            cursor?.close()
        }
        return out
    }
}
