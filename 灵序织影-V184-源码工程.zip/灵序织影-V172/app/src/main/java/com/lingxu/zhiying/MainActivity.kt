package com.lingxu.zhiying

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.lingxu.zhiying.core.AlignOrchestrator
import com.lingxu.zhiying.core.ConcatEngine
import com.lingxu.zhiying.core.FFmpegRuntime
import com.lingxu.zhiying.core.CoverageChecker
import com.lingxu.zhiying.core.DuplicateDetector
import com.lingxu.zhiying.core.LogX
import com.lingxu.zhiying.core.MediaResolver
import com.lingxu.zhiying.core.OcrEngine
import com.lingxu.zhiying.core.OrderVerifier
import com.lingxu.zhiying.core.RippleAdjust
import com.lingxu.zhiying.core.ScriptParser
import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ScriptLine
import com.lingxu.zhiying.security.ActivationManager
import com.lingxu.zhiying.security.SignatureGuard
import com.lingxu.zhiying.ui.ClipCardAdapter
import com.lingxu.zhiying.ui.MaterialPicker
import com.lingxu.zhiying.ui.Ui
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 灵序织影 · 主界面
 *
 * 两页结构：
 *   第 1 页「剧本与素材」：粘贴剧本、按文件夹导入切片、增强开关、启动智能对齐
 *   第 2 页「智能校对与手动微调」：红绿灯卡片流、一键捋直、重复段处理、渲染导出
 *
 * UI 全部由纯原生代码构建，深色系 #05080E。
 */
class MainActivity : ComponentActivity() {

    companion object {
        /** CI 构建时由 sed 注入真实 SHA-256 签名指纹 */
        const val SIGNATURE_PLACEHOLDER = "YOUR_APP_SIGNATURE_PLACEHOLDER"
        private const val REQ_PERMISSIONS = 0x1772
    }

    // ---- 状态 ----
    private var scriptLines: List<ScriptLine> = emptyList()
    private val selectedUris = ArrayList<String>()
    private val episodeNames = ArrayList<String>()
    private val clipCards = ArrayList<AlignedClip>()
    private val lightItems = ArrayList<OrderVerifier.Item>()
    private var alignResult: AlignOrchestrator.AlignResult? = null
    private var isBusy = false
    private var currentPage = 0

    private lateinit var orchestrator: AlignOrchestrator
    private val picker by lazy { MaterialPicker(this) }

    // ---- 视图（全部可空，避免 onCreate 中途异常导致二次崩溃）----
    private var rootLayout: LinearLayout? = null
    private var authLayout: LinearLayout? = null
    private var pageHost: FrameLayout? = null
    private var page1: LinearLayout? = null
    private var page2: LinearLayout? = null
    private var tab1: TextView? = null
    private var tab2: TextView? = null
    private var etScript: EditText? = null
    private var tvScriptInfo: TextView? = null
    private var tvMaterialInfo: TextView? = null
    private var swSubtitleZoom: LinearLayout? = null
    private var swAudioGain: LinearLayout? = null
    private var swLlm: LinearLayout? = null
    private var swAutoTrim: LinearLayout? = null
    private var progressBar: ProgressBar? = null
    private var tvStatus: TextView? = null
    private var tvSummary: TextView? = null
    private var btnAlign: TextView? = null
    private var btnRender: TextView? = null
    private var recycler: RecyclerView? = null
    private var adapter: ClipCardAdapter? = null

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri == null) return@registerForActivityResult
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            picker.openTree(uri) { picks ->
                if (picks.isEmpty()) {
                    toast("没有选中任何视频")
                    return@openTree
                }
                picks.forEach { p ->
                    val s = p.uri.toString()
                    if (!selectedUris.contains(s)) {
                        selectedUris.add(s)
                        episodeNames.add(p.episode)
                    }
                }
                refreshMaterialInfo()
                toast("已导入 ${picks.size} 个视频（${picks.first().episode}）")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val verdict = runCatching { SignatureGuard.verify(this) }
            .getOrElse { SignatureGuard.Verdict(false, "校验异常:${it.message}", "") }
        if (!verdict.pass) {
            SignatureGuard.execute(this, verdict)
            return
        }

        orchestrator = AlignOrchestrator(this)

        // FFmpeg 是整条管线的地基，启动就先验一次；不可用要立刻告诉用户，
        // 不能等跑完对齐才发现所有计数都是 0
        FFmpegRuntime.init(this)

        buildRootUi()
        requestPermissionsCompat()
        if (!FFmpegRuntime.ready) {
            val report = FFmpegRuntime.fullReport()
            android.widget.ScrollView(this).let { sv ->
                val tv = Ui.text(this, report, 11f, Ui.TEXT_MAIN)
                tv.setTextIsSelectable(true)
                sv.addView(tv, android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                ))
                sv.setPadding(Ui.dp(this, 18f), Ui.dp(this, 14f), Ui.dp(this, 18f), Ui.dp(this, 6f))
                AlertDialog.Builder(this)
                    .setTitle("❌ FFmpeg 引擎不可用")
                    .setView(sv)
                    .setNeutralButton("复制报告") { _, _ ->
                        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("ffmpeg", report))
                        toast("诊断报告已复制，可直接粘贴发给开发者")
                    }
                    .setPositiveButton("知道了", null)
                    .show()
            }
        }
        if (!ActivationManager.isActivated(this)) showAuthScreen()
    }

    // ==================================================================
    //  UI
    // ==================================================================

    private fun buildRootUi() {
        rootLayout = Ui.vbox(this).apply {
            setBackgroundColor(Color.parseColor(Ui.BG_DEEP))
        }

        // 顶栏
        val header = Ui.hbox(this).apply {
            setPadding(Ui.dp(context, 18f), Ui.dp(context, 24f), Ui.dp(context, 18f), Ui.dp(context, 10f))
        }
        header.addView(Ui.text(this, "🎬", 24f))
        val titleCol = Ui.vbox(this)
        titleCol.addView(Ui.text(this, "灵序织影", 20f, Ui.TEXT_MAIN, bold = true))
        titleCol.addView(Ui.text(this, "端侧全离线 · 多模态视频对齐与混剪", 11f, Ui.TEXT_SUB))
        header.addView(titleCol, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, this@MainActivity, 10f, 0f, 0f, 0f)
        })
        header.addView(Ui.text(this, "V184", 11f, Ui.CYAN).apply {
            background = Ui.chipBg(this@MainActivity, Ui.CYAN)
            gravity = Gravity.CENTER
            setPadding(Ui.dp(context, 10f), Ui.dp(context, 4f), Ui.dp(context, 10f), Ui.dp(context, 4f))
        })
        rootLayout?.addView(header, Ui.matchWrap())

        // 页面容器
        pageHost = FrameLayout(this)
        page1 = buildPage1()
        page2 = buildPage2()
        pageHost?.addView(page1, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        pageHost?.addView(page2, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        page2?.visibility = View.GONE
        rootLayout?.addView(pageHost, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // 底部两页导航
        val nav = Ui.hbox(this).apply {
            setBackgroundColor(Color.parseColor("#0A0F18"))
            setPadding(Ui.dp(context, 10f), Ui.dp(context, 8f), Ui.dp(context, 10f), Ui.dp(context, 14f))
        }
        tab1 = navTab("📝", "剧本与素材", true) { switchPage(0) }
        tab2 = navTab("🛠", "智能校对与手动微调", false) { switchPage(1) }
        nav.addView(tab1, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(tab2, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, this@MainActivity, 8f, 0f, 0f, 0f)
        })
        rootLayout?.addView(nav, Ui.matchWrap())

        setContentView(rootLayout)
    }

    private fun navTab(emoji: String, label: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = "$emoji\n$label"
            gravity = Gravity.CENTER
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.parseColor(if (active) Ui.CYAN else Ui.TEXT_SUB))
            background = if (active) Ui.chipBg(this@MainActivity, Ui.CYAN) else Ui.ghostBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 10f), 0, Ui.dp(context, 10f))
            setOnClickListener { onClick() }
        }
    }

    private fun switchPage(index: Int) {
        currentPage = index
        page1?.visibility = if (index == 0) View.VISIBLE else View.GONE
        page2?.visibility = if (index == 1) View.VISIBLE else View.GONE
        tab1?.setTextColor(Color.parseColor(if (index == 0) Ui.CYAN else Ui.TEXT_SUB))
        tab2?.setTextColor(Color.parseColor(if (index == 1) Ui.CYAN else Ui.TEXT_SUB))
        tab1?.background = if (index == 0) Ui.chipBg(this, Ui.CYAN) else Ui.ghostBg(this)
        tab2?.background = if (index == 1) Ui.chipBg(this, Ui.CYAN) else Ui.ghostBg(this)
        if (index == 1) refreshLights()
    }

    private fun scrollable(content: LinearLayout): ScrollView {
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        sv.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        return sv
    }

    // ---------------- 第 1 页 ----------------

    private fun buildPage1(): LinearLayout {
        val col = Ui.vbox(this).apply {
            setPadding(Ui.dp(context, 16f), Ui.dp(context, 6f), Ui.dp(context, 16f), Ui.dp(context, 16f))
        }

        // 剧本
        val c1 = card("📝", "第一步 · 剧本文本", "一切以剧本为准；自动剥离「男主:」「【旁白】」等前缀")
        etScript = EditText(this).apply {
            background = Ui.ghostBg(this@MainActivity)
            setTextColor(Color.parseColor(Ui.TEXT_MAIN))
            setHintTextColor(Color.parseColor("#4C5A6E"))
            hint = "把剧本粘贴到这里，一行一句台词…"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
            minLines = 5; maxLines = 10
            gravity = Gravity.TOP or Gravity.START
            setPadding(Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        c1.addView(etScript, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })
        tvScriptInfo = Ui.text(this, "尚未解析", 12f, Ui.TEXT_SUB)
        c1.addView(tvScriptInfo, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })
        val r1 = Ui.hbox(this)
        r1.addView(Ui.emojiButton(this, "🧩", "解析剧本") { parseScript() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r1.addView(Ui.emojiButton(this, "✨", "示例") { fillDemo() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 8f, 0f, 0f, 0f) })
        c1.addView(r1, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f)
        })
        col.addView(c1, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        // 素材：文件夹浏览
        val c2 = card("📁", "第二步 · 按文件夹导入素材", "先进文件夹，再看文件夹里的视频；一个文件夹就是一集")
        val btnFolder = TextView(this).apply {
            text = "📁 打开视频文件夹"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#031018"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            background = Ui.primaryBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 13f), 0, Ui.dp(context, 13f))
            setOnClickListener {
                ensurePermission { folderPicker.launch(null) }
            }
        }
        c2.addView(btnFolder, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })
        tvMaterialInfo = Ui.text(this, "已导入 0 个切片", 12f, Ui.TEXT_SUB)
        c2.addView(tvMaterialInfo, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })

        val r2 = Ui.hbox(this)
        r2.addView(Ui.emojiButton(this, "🗑", "清空素材") {
            selectedUris.clear(); episodeNames.clear(); refreshMaterialInfo()
        }, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r2.addView(Ui.emojiButton(this, "🩺", "为什么没排对") { showDiagnostics() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 8f, 0f, 0f, 0f) })
        r2.addView(Ui.emojiButton(this, "🔬", "单片段试跑") { selfTestOne() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 8f, 0f, 0f, 0f) })
        c2.addView(r2, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f)
        })

        swSubtitleZoom = makeSwitch("🔍 智能字幕感知放大", "检测字幕带并对小字等比放大 2~4 倍再 OCR", true)
        swAudioGain = makeSwitch("🎙️ 语音智能增益", "高通/低通/频谱降噪/压缩/响度归一化滤镜链", true)
        swAutoTrim = makeSwitch("✂️ 自动去首尾静音", "silencedetect 探测并给出裁剪入出点", false)
        swLlm = makeSwitch("🧠 大模型深水区仲裁", "模糊片段交给 Gemma-2B-IT（很慢，首次建议关闭）", false)
        listOf(swSubtitleZoom, swAudioGain, swAutoTrim, swLlm).forEach { sw ->
            c2.addView(sw, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 6f, 0f, 0f) })
        }
        col.addView(c2, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        // 对齐
        val c3 = card("🧠", "第三步 · 智能对齐", "DP 全局时序对齐 + 场景指纹区分同词不同人 + 重复检测")
        btnAlign = TextView(this).apply {
            text = "🧠 开始智能对齐"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#031018"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            background = Ui.primaryBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 14f), 0, Ui.dp(context, 14f))
            setOnClickListener { startAlign() }
        }
        c3.addView(btnAlign, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(Ui.CYAN))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#16202E"))
        }
        c3.addView(progressBar, Ui.matchWrap())
        tvStatus = Ui.text(this, "待命中。请先解析剧本并导入素材。", 12f, Ui.TEXT_SUB)
        c3.addView(tvStatus, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })
        val goPage2 = Ui.emojiButton(this, "🛠", "去校对工作台") { switchPage(1) }
        c3.addView(goPage2, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })
        col.addView(c3, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        return scrollable(col).let { sv ->
            val wrap = Ui.vbox(this)
            wrap.addView(sv, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            wrap
        }
    }

    // ---------------- 第 2 页 ----------------

    private fun buildPage2(): LinearLayout {
        val col = Ui.vbox(this).apply {
            setPadding(Ui.dp(context, 16f), Ui.dp(context, 6f), Ui.dp(context, 16f), Ui.dp(context, 10f))
        }

        // 工具条
        val tools = Ui.hbox(this)
        tools.addView(Ui.emojiButton(this, "🪄", "一键捋直") { straighten() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(Ui.emojiButton(this, "✅", "锁定绿灯") { lockGreens() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        tools.addView(Ui.emojiButton(this, "🔓", "全部解锁") { unlockAll() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        tools.addView(Ui.emojiButton(this, "🚫", "查重") { scanDuplicates() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        col.addView(tools, Ui.matchWrap())

        val tools2 = Ui.hbox(this)
        tools2.addView(Ui.emojiButton(this, "📊", "对齐体检") { showCoverage() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools2.addView(Ui.emojiButton(this, "🩺", "管线自检") { showDiagnostics() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        tools2.addView(Ui.emojiButton(this, "📐", "按剧本重排") { sortToScript() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        col.addView(tools2, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 6f, 0f, 0f) })

        tvSummary = Ui.text(this, "🟢 顺序正确 0 · 🔴 顺序错误 0", 12f, Ui.TEXT_SUB)
        col.addView(tvSummary, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 6f) })

        adapter = ClipCardAdapter(
            clipCards,
            lightItems,
            onMoveUp = { pos -> moveClip(pos, true) },
            onMoveDown = { pos -> moveClip(pos, false) },
            onToggleLock = { pos, locked -> toggleLock(pos, locked) },
            onTrim = { pos, di, dout -> adjustTrim(pos, di, dout) },
            onToggleDuplicate = { pos -> toggleDuplicate(pos) }
        )
        recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            setBackgroundColor(Color.TRANSPARENT)
        }
        col.addView(recycler, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // 渲染导出
        btnRender = TextView(this).apply {
            text = "⬆️ 渲染并导出到相册"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor(Ui.TEXT_MAIN))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
            background = Ui.ghostBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 14f), 0, Ui.dp(context, 14f))
            isEnabled = false; alpha = 0.4f
            setOnClickListener { confirmAndRender() }
        }
        col.addView(btnRender, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })

        return col
    }

    private fun card(emoji: String, title: String, subtitle: String): LinearLayout {
        val c = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity)
            setPadding(Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f))
        }
        c.addView(Ui.text(this, "$emoji  $title", 15f, Ui.TEXT_MAIN, bold = true))
        c.addView(Ui.text(this, subtitle, 11f, Ui.TEXT_SUB))
        return c
    }

    private fun makeSwitch(title: String, desc: String, checked: Boolean): LinearLayout {
        val box = Ui.vbox(this).apply {
            background = Ui.ghostBg(this@MainActivity)
            setPadding(Ui.dp(context, 12f), Ui.dp(context, 9f), Ui.dp(context, 12f), Ui.dp(context, 9f))
        }
        val row = Ui.hbox(this)
        val col = Ui.vbox(this)
        col.addView(Ui.text(this, title, 13f, Ui.TEXT_MAIN, bold = true))
        col.addView(Ui.text(this, desc, 10f, Ui.TEXT_SUB))
        row.addView(col, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = checked
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(Ui.CYAN))
            trackTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#243144"))
        }
        row.addView(sw)
        box.addView(row, Ui.matchWrap())
        box.tag = sw
        return box
    }

    private fun switchOf(box: LinearLayout?): Boolean = (box?.tag as? Switch)?.isChecked ?: false

    // ==================================================================
    //  逻辑
    // ==================================================================

    private fun parseScript() {
        val raw = etScript?.text?.toString() ?: ""
        if (raw.isBlank()) { toast("剧本内容为空"); return }
        scriptLines = ScriptParser.parse(raw)
        if (scriptLines.isEmpty()) {
            tvScriptInfo?.text = "⚠️ 没有解析出有效台词，请检查剧本格式"
            tvScriptInfo?.setTextColor(Color.parseColor(Ui.RED))
            return
        }
        tvScriptInfo?.text = "✅ 解析出 ${scriptLines.size} 句台词"
        tvScriptInfo?.setTextColor(Color.parseColor(Ui.GREEN))
        updateButtons()
    }

    private fun fillDemo() {
        etScript?.setText(
            """
            【旁白】三年后，他回到了这座熟悉的城市
            男主: 你到底想干什么
            女主: 我只是想问你一句话
            男主: 那就问吧
            【旁白】雨下了整整一夜，谁也没有先开口
            女主: 那年夏天，你为什么不告而别
            男主: 因为我不想让你看到我狼狈的样子
            """.trimIndent()
        )
        parseScript()
    }

    private fun refreshMaterialInfo() {
        val eps = episodeNames.filter { it.isNotBlank() }.distinct()
        tvMaterialInfo?.text = buildString {
            append("已导入 ${selectedUris.size} 个切片")
            if (eps.isNotEmpty()) append(" · ${eps.size} 集：").append(eps.take(3).joinToString("、"))
            if (eps.size > 3) append(" …")
        }
        updateButtons()
    }

    private fun updateButtons() {
        val ready = scriptLines.isNotEmpty() && selectedUris.isNotEmpty() && !isBusy
        btnAlign?.isEnabled = ready
        btnAlign?.alpha = if (ready) 1f else 0.4f
    }

    private fun startAlign() {
        if (isBusy) return
        if (scriptLines.isEmpty()) { toast("请先解析剧本"); return }
        if (selectedUris.isEmpty()) { toast("请先导入视频素材"); return }
        isBusy = true
        updateButtons()
        progressBar?.visibility = View.VISIBLE
        clipCards.clear(); lightItems.clear(); adapter?.notifyDataSetChanged()

        val zoom = switchOf(swSubtitleZoom)
        val gain = switchOf(swAudioGain)
        val llm = switchOf(swLlm)
        val trim = switchOf(swAutoTrim)

        lifecycleScope.launch {
            try {
                orchestrator.run(selectedUris.toList(), scriptLines, zoom, gain, llm, trim, episodeNames.toList())
                    .collectLatest { p ->
                        tvStatus?.text = "${p.stage}（${p.current}/${p.total}）· ${p.message}"
                        progressBar?.progress = (p.ratio * 100).toInt()
                    }
                val r = orchestrator.lastResult
                alignResult = r
                if (r != null) {
                    clipCards.clear(); clipCards.addAll(r.clips)
                    r.clips.forEach { c ->
                        if (c.scriptIndex in scriptLines.indices) c.matchedScriptText = scriptLines[c.scriptIndex].text
                    }
                    refreshLights()
                    btnRender?.isEnabled = true
                    btnRender?.alpha = 1f
                    btnRender?.background = Ui.primaryBg(this@MainActivity)
                    btnRender?.setTextColor(Color.parseColor("#031018"))
                    val red = OrderVerifier.countRed(lightItems)
                    tvStatus?.text = "对齐完成：${clipCards.size} 段，其中 $red 段顺序待修。\n" +
                            "点「🛠 去校对工作台」，先按「🪄 一键捋直」，再逐个处理红灯。"
                    tvStatus?.setTextColor(Color.parseColor(if (red == 0) Ui.GREEN else Ui.AMBER))
                    switchPage(1)
                } else {
                    tvStatus?.text = "⚠️ 没有产出结果，点「🩺 为什么没排对」看诊断"
                    tvStatus?.setTextColor(Color.parseColor(Ui.RED))
                }
            } catch (e: Throwable) {
                LogX.e("Main", "对齐异常", e)
                tvStatus?.text = "❌ 对齐失败：${e.javaClass.simpleName} ${e.message}"
                tvStatus?.setTextColor(Color.parseColor(Ui.RED))
            } finally {
                isBusy = false
                progressBar?.visibility = View.GONE
                updateButtons()
            }
        }
    }

    /** 重新计算红绿灯（判定标准是顺序，不是文字相似度） */
    private fun refreshLights() {
        val items = OrderVerifier.verify(clipCards, scriptLines)
        lightItems.clear(); lightItems.addAll(items)
        adapter?.notifyDataSetChanged()
        val red = OrderVerifier.countRed(items)
        val green = items.size - red
        tvSummary?.text = "🟢 顺序正确 $green · 🔴 顺序错误 $red · 共 ${items.size} 段"
        tvSummary?.setTextColor(Color.parseColor(if (red == 0) Ui.GREEN else Ui.AMBER))
    }

    private fun moveClip(position: Int, upward: Boolean) {
        val r = alignResult ?: run { toast("请先完成智能对齐"); return }
        val touched = RippleAdjust.move(clipCards, r.matrix, position, upward)
        if (touched <= 0) { toast(if (upward) "已经在最顶端" else "已经在最底端"); return }
        clipCards.forEach { c ->
            if (c.scriptIndex in scriptLines.indices) {
                c.matchedScriptText = scriptLines[c.scriptIndex].text
                val extracted = if (c.feature.asrText.isNotBlank()) c.feature.asrText else c.feature.ocrText
                c.matchedExtract = com.lingxu.zhiying.core.TextSimilarity.bestSpan(c.matchedScriptText, extracted)
            } else {
                c.matchedScriptText = ""
                c.matchedExtract = ""
            }
        }
        refreshLights()
    }

    private fun toggleLock(position: Int, locked: Boolean) {
        if (position !in clipCards.indices) return
        clipCards[position].locked = locked
        adapter?.notifyItemChanged(position)
    }

    private fun toggleDuplicate(position: Int) {
        if (position !in clipCards.indices) return
        val c = clipCards[position]
        if (c.isDuplicate) DuplicateDetector.restore(c) else { c.isDuplicate = true; c.duplicateOf = -1 }
        adapter?.notifyItemChanged(position)
        toast(if (c.isDuplicate) "已标记为重复，拼接时跳过" else "已恢复参与拼接")
    }

    private fun adjustTrim(position: Int, deltaIn: Long, deltaOut: Long) {
        if (position !in clipCards.indices) return
        val c = clipCards[position]
        val dur = c.feature.durationMs
        if (deltaIn != 0L) {
            var v = (if (c.trimInMs < 0) 0L else c.trimInMs) + deltaIn
            v = v.coerceIn(0L, if (dur > 0) dur - 300 else Long.MAX_VALUE)
            c.trimInMs = if (v <= 0L) -1L else v
        }
        if (deltaOut != 0L) {
            var v = (if (c.trimOutMs < 0) (if (dur > 0) dur else 0L) else c.trimOutMs) + deltaOut
            val floor = (if (c.trimInMs > 0) c.trimInMs else 0L) + 300
            v = v.coerceAtLeast(floor)
            if (dur > 0) v = v.coerceAtMost(dur)
            c.trimOutMs = if (dur > 0 && v >= dur) -1L else v
        }
        adapter?.notifyItemChanged(position)
    }

    /**
     * 🪄 一键捋直
     *
     * 顺序是两步定的：
     *  1. 先把「同一句剧本、不同人先后说」的片段按场景指纹 + 首尾帧连续性排好
     *     （小女孩的场景在前就排在前，男主在后就排在后）
     *  2. 再对整体做 LIS 锚点捋直，把少数倒流的片段插回正确位置
     */
    /**
     * 🪄 智能校对（一键捋直）
     *
     * 严格单调收敛：每点一次只接受「红灯变少」的结果，
     * 若这次调整没有改善甚至更差，立即回退到调整前的顺序。
     * 所以多点几次一定是越来越对，绝不会越点越乱。
     */
    private fun straighten() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val snapshot = ArrayList(clipCards)
        val beforeRed = OrderVerifier.countRed(OrderVerifier.verify(clipCards, scriptLines))

        // 先后判据 = 首尾帧连续性全链重建的位次，不再使用文件名自然序
        val rankById = HashMap<Int, Int>()
        clipCards.forEach { c -> rankById[c.feature.id] = c.chainRank }
        val groups = com.lingxu.zhiying.core.SameCoordOrderer.applyAll(clipCards, rankById)
        val moved = OrderVerifier.straighten(clipCards)
        val afterRed = OrderVerifier.countRed(OrderVerifier.verify(clipCards, scriptLines))

        if (afterRed > beforeRed) {
            // 变差了 → 回退，保证「点一次只会更好或不变」
            clipCards.clear()
            clipCards.addAll(snapshot)
            syncMatrixRows()
            refreshLights()
            toast("本次调整未改善（红灯 $beforeRed → $afterRed），已自动回退。请改用手动微调 ⬆️⬇️")
            return
        }
        syncMatrixRows()
        refreshLights()
        straightenRounds++
        if (afterRed == 0) {
            toast("✅ 已全部捋直：$moved 张卡片归位，0 红灯，可以导出了")
        } else {
            toast("第 $straightenRounds 次校对：红灯 $beforeRed → $afterRed（同词重排 $groups 组）。再点一次可继续收敛")
        }
    }

    private var straightenRounds = 0

    private fun sortToScript() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val moved = CoverageChecker.sortToScriptOrder(clipCards)
        syncMatrixRows()
        refreshLights()
        toast("已按剧本顺序重排，移动 $moved 张卡片")
    }

    /** 卡片顺序变化后，DP 矩阵的行必须跟着搬，否则涟漪重排会拿错分 */
    private fun syncMatrixRows() {
        val r = alignResult ?: return
        val idToRow = HashMap<Int, Int>()
        r.clips.forEachIndexed { i, c -> idToRow[c.feature.id] = i }
        val snapshot = r.matrix.map { it.clone() }.toTypedArray()
        clipCards.forEachIndexed { newRow, c ->
            val old = idToRow[c.feature.id]
            if (old != null && old < snapshot.size) r.matrix[newRow] = snapshot[old]
        }
    }

    private fun lockGreens() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        var n = 0
        lightItems.forEachIndexed { i, item ->
            if (item.light == OrderVerifier.Light.GREEN && !clipCards[i].locked) {
                clipCards[i].locked = true; n++
            }
        }
        adapter?.notifyDataSetChanged()
        toast(if (n > 0) "已锁定 $n 个绿灯片段" else "没有可锁定的绿灯片段")
    }

    private fun unlockAll() {
        val n = clipCards.count { it.locked }
        clipCards.forEach { it.locked = false }
        adapter?.notifyDataSetChanged()
        toast("已解锁 $n 个片段")
    }

    private fun scanDuplicates() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val dups = DuplicateDetector.scan(clipCards)
        adapter?.notifyDataSetChanged()
        val audit = DuplicateDetector.audit(clipCards)
        AlertDialog.Builder(this)
            .setTitle("🚫 重复片段检查")
            .setMessage(
                (if (dups.isEmpty()) "✅ 没有发现重复片段\n\n" else "发现 ${dups.size} 段重复：\n" +
                        dups.take(10).joinToString("\n") { "· 第${it.index + 1}段 ${it.reason}" } + "\n\n") +
                        audit.summary()
            )
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun showCoverage() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val report = CoverageChecker.check(clipCards, scriptLines)
        val audit = DuplicateDetector.audit(clipCards)
        val chainInfo = orchestrator.chainResult?.summary(clipCards.size) ?: "（无连续性重建数据）"
        AlertDialog.Builder(this)
            .setTitle("📊 对齐体检报告")
            .setMessage(
                report.summary(scriptLines) +
                        "\n\n【时序证据 · 首尾帧连续性全链重建】\n" + chainInfo +
                        "\n\n【拼接审计】\n" + audit.summary()
            )
            .setNeutralButton("一键捋直") { _, _ -> straighten() }
            .setPositiveButton("知道了", null)
            .show()
    }

    /** 🔬 只跑第一个片段，把每一环的中间结果摊开，定位到底哪一环断了 */
    private fun selfTestOne() {
        if (selectedUris.isEmpty()) { toast("请先导入素材"); return }
        tvStatus?.text = "🔬 正在对第 1 个片段做全链路试跑，约需十几秒…"
        tvStatus?.setTextColor(Color.parseColor(Ui.CYAN))
        lifecycleScope.launch {
            val report = try {
                orchestrator.selfTest(selectedUris[0])
            } catch (e: Throwable) {
                "试跑异常：${e.javaClass.simpleName} ${e.message}"
            }
            tvStatus?.text = "🔬 试跑完成，请查看报告"
            AlertDialog.Builder(this@MainActivity)
                .setTitle("🔬 单片段全链路试跑")
                .setMessage(report)
                .setPositiveButton("知道了", null)
                .show()
        }
    }

    private fun showDiagnostics() {
        val d = orchestrator.diagReport
        val head = FFmpegRuntime.statusLine() + "\n\n"
        val msg = head + (d?.render() ?: "还没有跑过对齐。\n\n先解析剧本、导入素材，点「开始智能对齐」，" +
                "跑完再回来看这份自检报告——它会告诉你 FFmpeg、抽帧、字幕带、OCR、ASR 每一环的成败计数。")
        AlertDialog.Builder(this)
            .setTitle("🩺 管线自检（为什么没排对）")
            .setMessage(msg)
            .setPositiveButton("知道了", null)
            .show()
    }

    // ---------------- 渲染 ----------------

    private fun confirmAndRender() {
        if (clipCards.isEmpty()) return
        val red = OrderVerifier.countRed(lightItems)
        val dups = clipCards.count { it.isDuplicate }
        val audit = DuplicateDetector.audit(clipCards)
        val msg = buildString {
            if (red > 0) append("⚠️ 还有 $red 段顺序不对，确定要继续导出吗？\n\n")
            if (dups > 0) append("已自动跳过 $dups 段重复片段，不会拼进成片。\n\n")
            append(audit.summary())
        }
        AlertDialog.Builder(this)
            .setTitle("🎬 导出前确认")
            .setMessage(msg)
            .setNegativeButton("再看看", null)
            .setPositiveButton("确认导出") { _, _ -> startRender() }
            .show()
    }

    private var lastOutputPath: String = ""

    private fun startRender() {
        if (isBusy) return
        isBusy = true
        lifecycleScope.launch {
            try {
                val renderClips = DuplicateDetector.renderList(clipCards)
                if (renderClips.isEmpty()) { toast("没有可拼接的片段"); return@launch }
                val items = withContext(Dispatchers.IO) {
                    renderClips.mapNotNull { c ->
                        val raw = c.feature.uri
                        val real = if (raw.startsWith("content://")) {
                            MediaResolver.resolve(this@MainActivity, Uri.parse(raw))?.path
                        } else raw
                        if (real.isNullOrBlank()) null
                        else ConcatEngine.TrimItem(real, c.trimInMs, c.trimOutMs)
                    }
                }
                if (items.isEmpty()) { toast("素材路径全部失效，请重新导入"); return@launch }
                val (uri, file) = orchestrator.renderAndExport(items, ConcatEngine.Mode.AUTO)
                if (uri != null) {
                    lastOutputPath = file?.absolutePath ?: uri.toString()
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("🎉 出片成功")
                        .setMessage("已存入相册 Movies/灵序织影/\n\n共拼接 ${items.size} 段（已排除重复）\n$lastOutputPath")
                        .setPositiveButton("知道了", null)
                        .show()
                } else {
                    toast("拼接失败，请查看 logcat -s LingXu")
                }
            } catch (e: Throwable) {
                LogX.e("Main", "渲染异常", e)
                toast("渲染失败：${e.message}")
            } finally {
                isBusy = false
            }
        }
    }

    // ==================================================================
    //  授权
    // ==================================================================

    private fun showAuthScreen() {
        authLayout = Ui.vbox(this).apply {
            setBackgroundColor(Color.parseColor(Ui.BG_DEEP))
            gravity = Gravity.CENTER
            setPadding(Ui.dp(context, 28f), Ui.dp(context, 28f), Ui.dp(context, 28f), Ui.dp(context, 28f))
        }
        val panel = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity, "#0E1420", Ui.PURPLE, 20f)
            setPadding(Ui.dp(context, 22f), Ui.dp(context, 22f), Ui.dp(context, 22f), Ui.dp(context, 22f))
        }
        panel.addView(Ui.text(this, "🔐 灵序织影 · 设备授权", 18f, Ui.TEXT_MAIN, bold = true))
        panel.addView(Ui.text(this, "一机一码，不可跨设备使用。长按设备码可复制。", 12f, Ui.TEXT_SUB).apply {
            setPadding(0, Ui.dp(context, 6f), 0, Ui.dp(context, 16f))
        })
        val deviceCode = ActivationManager.deviceCode(this)
        panel.addView(Ui.text(this, "设备码", 11f, Ui.TEXT_SUB))
        panel.addView(Ui.text(this, deviceCode, 20f, Ui.CYAN, bold = true).apply {
            background = Ui.ghostBg(this@MainActivity)
            gravity = Gravity.CENTER
            setPadding(0, Ui.dp(context, 12f), 0, Ui.dp(context, 12f))
            setOnLongClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("device", deviceCode))
                toast("设备码已复制"); true
            }
        }, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 16f) })

        panel.addView(Ui.text(this, "激活码（32 位）", 11f, Ui.TEXT_SUB))
        val etCode = EditText(this).apply {
            background = Ui.ghostBg(this@MainActivity)
            setTextColor(Color.parseColor(Ui.TEXT_MAIN))
            setHintTextColor(Color.parseColor("#4C5A6E"))
            hint = "粘贴激活码"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setPadding(Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f))
        }
        panel.addView(etCode, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 16f) })
        panel.addView(TextView(this).apply {
            text = "✅ 立即激活"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#031018"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            background = Ui.primaryBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 14f), 0, Ui.dp(context, 14f))
            setOnClickListener {
                val input = etCode.text.toString()
                if (input.isBlank()) { toast("请输入激活码"); return@setOnClickListener }
                if (ActivationManager.activate(this@MainActivity, input)) {
                    toast("激活成功"); setContentView(rootLayout)
                } else toast("激活码与本机设备码不匹配")
            }
        }, Ui.matchWrap())
        authLayout?.addView(panel, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(authLayout)
    }

    // ==================================================================
    //  权限
    // ==================================================================

    private fun requiredPermissions(): Array<String> {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.READ_MEDIA_VIDEO)
            list.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return list.toTypedArray()
    }

    private var pendingAction: (() -> Unit)? = null

    private fun requestPermissionsCompat() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_PERMISSIONS)
    }

    private fun ensurePermission(action: () -> Unit) {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) { action(); return }
        pendingAction = action
        requestPermissions(missing.toTypedArray(), REQ_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMISSIONS) return
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAction?.invoke()
        } else {
            toast("未授予媒体读取权限。文件夹导入不受影响")
        }
        pendingAction = null
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { picker.dismiss() }
        runCatching { OcrEngine.release() }
        runCatching { orchestrator.cleanup() }
    }
}
