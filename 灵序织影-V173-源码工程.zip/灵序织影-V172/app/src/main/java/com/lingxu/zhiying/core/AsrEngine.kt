package com.lingxu.zhiying.core

import android.content.Context
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineSenseVoiceModelConfig

/**
 * 听觉大模型：Sherpa-ONNX + SenseVoice 中英日韩粤多语种离线识别
 *
 * 模型来自 assets/models/model.int8.onnx 与 assets/models/tokens.txt，
 * 直接通过 AssetManager 交给 JNI 层读取，无需先落地到磁盘。
 *
 * 若 AAR 或 .so 缺失（例如模型未下载成功），本类会安全降级为「无听写结果」，
 * 不会让整个对齐流程崩溃——视觉通道仍可独立完成对齐。
 */
object AsrEngine {

    private const val MODEL_DIR = "models"
    private const val MODEL_FILE = "$MODEL_DIR/model.int8.onnx"
    private const val TOKENS_FILE = "$MODEL_DIR/tokens.txt"

    @Volatile
    private var recognizer: OfflineRecognizer? = null

    @Volatile
    var available: Boolean = false
        private set

    var unavailableReason: String = ""
        private set

    /** SenseVoice 会吐出 <|zh|><|NEUTRAL|><|Speech|> 之类标记，必须清掉 */
    private val TAG_TOKEN = Regex("<\\|[^|]*\\|>")
    private val KEEP = Regex("[\\u4e00-\\u9fa5A-Za-z0-9，。！？、；：]|\n")

    @Synchronized
    fun init(context: Context, numThreads: Int = 2): Boolean {
        if (recognizer != null) return true
        return try {
            val exists = modelExists(context)
            if (!exists) {
                unavailableReason = "assets/models 下未找到 SenseVoice 模型（model.int8.onnx / tokens.txt）"
                LogX.w("AsrEngine", unavailableReason)
                return false
            }
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = AudioPipeline.SAMPLE_RATE, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = MODEL_FILE,
                        language = "auto",
                        useInverseTextNormalization = true
                    ),
                    tokens = TOKENS_FILE,
                    numThreads = numThreads,
                    debug = false,
                    provider = "cpu"
                ),
                decodingMethod = "greedy_search"
            )
            recognizer = OfflineRecognizer(context.assets, config)
            available = true
            unavailableReason = ""
            LogX.i("AsrEngine", "SenseVoice 离线识别引擎已就绪")
            true
        } catch (e: Throwable) {
            // 常见为 UnsatisfiedLinkError（.so 未打进包）
            recognizer = null
            available = false
            unavailableReason = "ASR 初始化失败：${e.javaClass.simpleName} ${e.message}"
            LogX.e("AsrEngine", unavailableReason, e)
            false
        }
    }

    private fun modelExists(context: Context): Boolean = try {
        val list = context.assets.list(MODEL_DIR) ?: emptyArray()
        list.any { it == "model.int8.onnx" } && list.any { it == "tokens.txt" }
    } catch (e: Throwable) {
        false
    }

    /**
     * 识别一段 PCM。超长音频由 [AudioPipeline.windows] 切好的滑动窗口逐段送入，
     * 识别结果按窗口顺序拼接。
     */
    fun transcribe(pcm: FloatArray): String {
        val rec = recognizer ?: return ""
        if (pcm.isEmpty()) return ""
        val sb = StringBuilder()
        try {
            val stream = rec.createStream()
            stream.acceptWaveform(pcm, AudioPipeline.SAMPLE_RATE)
            rec.decode(stream)
            sb.append(clean(rec.getResult(stream).text))
            stream.release()
        } catch (e: Throwable) {
            LogX.w("AsrEngine", "识别窗口失败: ${e.message}")
        }
        return sb.toString().trim()
    }

    /** 直接吃完整 PCM，内部自动滑窗 */
    fun transcribeWithWindows(windows: List<FloatArray>): String {
        if (windows.isEmpty()) return ""
        val parts = ArrayList<String>(windows.size)
        windows.forEachIndexed { i, w ->
            val t = transcribe(w)
            if (t.isNotBlank()) parts.add(t)
            LogX.i("AsrEngine", "窗口 ${i + 1}/${windows.size} → ${t.length} 字")
        }
        return dedupOverlap(parts)
    }

    /** 滑窗有 1 秒重叠，去掉相邻窗口首尾重复的片段 */
    private fun dedupOverlap(parts: List<String>): String {
        if (parts.size <= 1) return parts.firstOrNull() ?: ""
        val out = StringBuilder(parts[0])
        for (i in 1 until parts.size) {
            val cur = parts[i]
            val prevTail = out.toString().takeLast(24)
            var cut = 0
            val maxOverlap = minOf(prevTail.length, cur.length)
            for (len in maxOverlap downTo 4) {
                if (prevTail.endsWith(cur.substring(0, len))) {
                    cut = len
                    break
                }
            }
            out.append(cur.substring(cut))
        }
        return out.toString()
    }

    private fun clean(raw: String): String {
        var s = TAG_TOKEN.replace(raw, "")
        s = s.replace("[blank]", "").replace("[noise]", "")
        s = s.filter { KEEP.matches(it.toString()) }
        return s.trim()
    }

    @Synchronized
    fun release() {
        try {
            recognizer?.release()
        } catch (_: Throwable) {
        }
        recognizer = null
        available = false
    }
}
