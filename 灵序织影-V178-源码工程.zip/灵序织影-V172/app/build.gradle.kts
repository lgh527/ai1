plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// CI（GitHub Actions）会用 keytool 在仓库根目录生成 release.jks，alias=release，口令 123456
val releaseStore = rootProject.file("release.jks")

android {
    namespace = "com.lingxu.zhiying"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lingxu.zhiying"
        minSdk = 26
        targetSdk = 34
        versionCode = 178
        versionName = "V178-原生库修复版"

        ndk {
            // 必须与依赖 AAR 实际提供的架构严格一致：
            //   ffmpeg-kit-full:8.1.7 只有 arm64-v8a 与 x86_64 两套 .so（没有 armeabi-v7a）
            // 多写一个 AAR 里不存在的 ABI，会让打包/安装时的架构选择出现歧义。
            abiFilters.add("arm64-v8a")
            abiFilters.add("x86_64")
        }
    }

    signingConfigs {
        create("release") {
            storeFile = releaseStore
            storePassword = "123456"
            keyAlias = "release"
            keyPassword = "123456"
            isV1SigningEnabled = true
            isV2SigningEnabled = true
        }
    }

    buildTypes {
        release {
            // 关闭代码混淆/压缩。
            // 原因：ffmpeg-kit 依赖 JNI + FFmpegKitConfig 的 static 块加载原生库，
            // R8 在 full mode 下的类合并与静态初始化重排会造成
            // NoClassDefFoundError / ExceptionInInitializerError（真机上已复现过）。
            // 体积换稳定性：等 FFmpeg 链路实测跑通后再考虑打开。
            isMinifyEnabled = false
            isShrinkResources = false
            if (releaseStore.exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // 模型文件禁止压缩，否则 assets 里的 .onnx / .bin 无法直接映射读取
    androidResources {
        noCompress += listOf("onnx", "bin", "tflite", "task", "txt")
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            // ffmpeg-kit-full 与其它库的 META-INF 重名文件会导致打包失败，这里统一排除
            excludes += listOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/LICENSE-2.0.txt",
                "META-INF/LICENSE-3.0.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt",
                "META-INF/NOTICE-2.0.txt",
                "META-INF/NOTICE-3.0.txt",
                "META-INF/INDEX.LIST",
                "META-INF/AL2.0",
                "META-INF/LGPL2.1",
                "META-INF/*.kotlin_module",
                "META-INF/protobuf/kotlin/**"
            )
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // sherpa-onnx v1.13.5 官方预编译 AAR（由 CI 下载到 app/libs/）
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar", "*.jar"))))

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.material:material:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // 多媒体引擎：全功能版 FFmpeg（社区维护版）
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")

    // 视觉大模型：谷歌中文离线 OCR
    implementation("com.google.mlkit:text-recognition-chinese:16.0.0")

    // 逻辑大模型：MediaPipe GenAI（Gemma-2B-IT int4）
    implementation("com.google.mediapipe:tasks-genai:0.10.14")
}
