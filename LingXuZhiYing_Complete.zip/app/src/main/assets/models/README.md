# 模型文件说明
将以下文件放入本目录，ASR 和 LLM 功能才会启用：

1. SenseVoice ASR
   - model.int8.onnx
   - tokens.txt
   下载：https://hf-mirror.com/csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17

2. Gemma 2B LLM
   - gemma-2b-it-gpu-int4.bin (约 1.35 GB)
   下载：https://www.kaggle.com/models/google/gemma/tfLite/gemma-2b-it-gpu-int4

不放模型也能编译运行，只是 ASR/LLM 走降级路径，不会崩溃。