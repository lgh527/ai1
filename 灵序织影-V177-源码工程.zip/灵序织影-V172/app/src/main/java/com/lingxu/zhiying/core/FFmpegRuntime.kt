package com.lingxu.zhiying.core

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode

/**
 * FFmpeg 运行时自检
 *
 * 之前"读取成功 0 / 抽帧 0 / 音频提取 0，但 ASR 可用"这种全零现象，
 * 根因是 FFmpegKit 的原生库没能加载（UnsatisfiedLinkError），
 * 而各个调用点都把异常 catch 掉、静默返回默认值，于是整条管线看起来像"读不到文件"。
 *
 * 这个类在 App 启动时就把 FFmpeg 真实跑一次 `-version`：
 *   · 跑得通 → 记录版本号，后续流程正常
 *   · 跑不通 → 把异常类名和消息记下来，UI 直接弹窗告知，绝不再静默失败
 *
 * 同时统一在这里给 FFmpegKitConfig 注入 Context —— 这是 ffmpeg-kit
 * 访问 Android SAF（content://）的前置条件，缺了它 content URI 一律打不开。
 */
object FFmpegRuntime {

    @Volatile
    var ready: Boolean = false
        private set

    @Volatile
    var version: String = ""
        private set

    @Volatile
    var error: String = ""
        private set

    @Volatile
    var probeReady: Boolean = false
        private set

    private val nativeErrors = ArrayList<String>()

    /** 最近若干条被捕获的原生调用异常，诊断面板会展示 */
    val recentErrors: List<String>
        get() = synchronized(nativeErrors) { nativeErrors.toList().takeLast(8) }

    fun recordError(scope: String, t: Throwable) {
        val msg = "$scope: ${t.javaClass.simpleName} ${t.message}"
        synchronized(nativeErrors) {
            nativeErrors.add(msg)
            if (nativeErrors.size > 40) nativeErrors.removeAt(0)
        }
        LogX.e("FFmpeg", msg, t)
    }

    @Synchronized
    fun init(context: Context) {
        // 1) 注入 Context：ffmpeg-kit 访问 Android 存储依赖它。
        //    用反射调用而不是直接引用 FFmpegKitConfig —— 这个类的方法签名在不同
        //    ffmpeg-kit 版本/不同维护分支里并不一致，直接引用会造成编译期
        //    unresolved reference，整个构建挂掉。反射则最坏情况只是"没注入成功"，
        //    不影响编译，也不影响普通本地文件路径的正常使用。
        injectContext(context)

        // 2) 真跑一次 -version，验证原生库能否加载
        try {
            val session = FFmpegKit.execute("-version")
            val out = session.output ?: ""
            version = out.lineSequence().firstOrNull()?.trim() ?: ""
            ready = version.isNotBlank() || ReturnCode.isSuccess(session.returnCode)
            if (!ready) error = "FFmpeg -version 无输出：${out.take(200).ifBlank { "（空）" }}"
        } catch (e: Throwable) {
            ready = false
            error = "FFmpeg 原生库加载失败：${e.javaClass.simpleName} ${e.message}"
            recordError("FFmpegKit.execute(-version)", e)
        }

        // 3) FFprobe 同样验一次
        try {
            val s = FFprobeKit.execute("-version")
            probeReady = (s.output ?: "").isNotBlank() || ReturnCode.isSuccess(s.returnCode)
        } catch (e: Throwable) {
            probeReady = false
            recordError("FFprobeKit.execute(-version)", e)
        }

        LogX.i("FFmpeg", "ready=$ready probe=$probeReady version=$version error=$error")
    }

    /** 反射注入 Context，兼容各种 ffmpeg-kit 版本的 API 形状 */
    private fun injectContext(context: Context) {
        val app = context.applicationContext
        val candidates = listOf(
            "com.arthenica.ffmpegkit.FFmpegKitConfig",
            "com.arthenica.smartexception.java.ExceptionsConfig"
        )
        for (cn in candidates) {
            try {
                val clazz = Class.forName(cn)
                val m = clazz.methods.firstOrNull { mm ->
                    mm.name == "setContext" && mm.parameterTypes.size == 1 &&
                            mm.parameterTypes[0].isAssignableFrom(app.javaClass)
                }
                if (m != null) {
                    m.invoke(null, app)
                    LogX.i("FFmpeg", "已通过反射注入 Context: $cn")
                    return
                }
            } catch (e: Throwable) {
                LogX.w("FFmpeg", "反射注入 $cn 失败: ${e.message}")
            }
        }
        LogX.w("FFmpeg", "未能注入 Context（不影响本地文件路径的 FFmpeg 调用）")
    }

    /** 给 UI 用的一句话结论 */
    fun statusLine(): String = when {
        ready && probeReady -> "✅ FFmpeg 正常：$version"
        ready -> "⚠️ FFmpeg 可用但 FFprobe 不可用，时长/分辨率探测会退化为 0"
        else -> "❌ FFmpeg 不可用：$error"
    }
}
