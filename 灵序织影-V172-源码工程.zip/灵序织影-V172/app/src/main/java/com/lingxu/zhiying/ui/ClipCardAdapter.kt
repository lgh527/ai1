package com.lingxu.zhiying.ui

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.lingxu.zhiying.core.PerceptualHash
import com.lingxu.zhiying.model.AlignedClip

/**
 * 卡片式校对工作台
 *
 * 每张卡片实时显示：
 *   · 匹配度（红 / 黄 / 绿三档色标）
 *   · 视觉指纹（8x8 aHash 色块）
 *   · AI 听写内容与 OCR 字幕内容
 *   · 命中的剧本原句
 *   · ⬆️ 上移 / ⬇️ 下移 / 🔒 锁定 手动微调入口
 */
class ClipCardAdapter(
    private val items: MutableList<AlignedClip>,
    private val onMoveUp: (Int) -> Unit,
    private val onMoveDown: (Int) -> Unit,
    private val onToggleLock: (Int, Boolean) -> Unit
) : RecyclerView.Adapter<ClipCardAdapter.CardHolder>() {

    class CardHolder(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val orderBadge: TextView = root.findViewById(TAG_ORDER)
        val fileName: TextView = root.findViewById(TAG_NAME)
        val scoreChip: TextView = root.findViewById(TAG_SCORE)
        val sourceChip: TextView = root.findViewById(TAG_SOURCE)
        val scriptText: TextView = root.findViewById(TAG_SCRIPT)
        val ocrText: TextView = root.findViewById(TAG_OCR)
        val asrText: TextView = root.findViewById(TAG_ASR)
        val metaText: TextView = root.findViewById(TAG_META)
        val hashView: HashView = root.findViewById(TAG_HASH)
        val btnUp: TextView = root.findViewById(TAG_UP)
        val btnDown: TextView = root.findViewById(TAG_DOWN)
        val btnLock: TextView = root.findViewById(TAG_LOCK)
    }

    companion object {
        private const val TAG_ORDER = 0x7f0a0001
        private const val TAG_NAME = 0x7f0a0002
        private const val TAG_SCORE = 0x7f0a0003
        private const val TAG_SOURCE = 0x7f0a0004
        private const val TAG_SCRIPT = 0x7f0a0005
        private const val TAG_OCR = 0x7f0a0006
        private const val TAG_ASR = 0x7f0a0007
        private const val TAG_META = 0x7f0a0008
        private const val TAG_HASH = 0x7f0a0009
        private const val TAG_UP = 0x7f0a000A
        private const val TAG_DOWN = 0x7f0a000B
        private const val TAG_LOCK = 0x7f0a000C
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
        val ctx = parent.context
        val root = Ui.vbox(ctx)
        root.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = Ui.dp(ctx, 10f)
        }
        root.background = Ui.cardBg(ctx)
        root.setPadding(Ui.dp(ctx, 14f), Ui.dp(ctx, 13f), Ui.dp(ctx, 14f), Ui.dp(ctx, 13f))

        // ---- 第一行：序号 + 文件名 + 匹配度 + 来源 ----
        val row1 = Ui.hbox(ctx)
        val order = Ui.text(ctx, "01", 15f, Ui.CYAN, bold = true).apply { id = TAG_ORDER }
        row1.addView(order, Ui.lp(Ui.dp(ctx, 30f), ViewGroup.LayoutParams.WRAP_CONTENT))

        val name = Ui.text(ctx, "clip.mp4", 13f, Ui.TEXT_MAIN, maxLines = 1).apply { id = TAG_NAME }
        row1.addView(name, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, ctx, 4f, 0f, 8f, 0f)
        })

        val score = Ui.text(ctx, "0%", 12f, Ui.GREEN).apply {
            id = TAG_SCORE
            background = Ui.chipBg(ctx, Ui.GREEN)
            gravity = Gravity.CENTER
            setPadding(Ui.dp(ctx, 9f), Ui.dp(ctx, 3f), Ui.dp(ctx, 9f), Ui.dp(ctx, 3f))
        }
        row1.addView(score)

        val source = Ui.text(ctx, "文本", 11f, Ui.TEXT_SUB).apply {
            id = TAG_SOURCE
            setPadding(Ui.dp(ctx, 8f), 0, 0, 0)
        }
        row1.addView(source)
        root.addView(row1, Ui.matchWrap())

        // ---- 第二行：剧本命中句 ----
        val script = Ui.text(ctx, "未命中剧本", 13f, Ui.TEXT_SUB).apply {
            id = TAG_SCRIPT
            background = Ui.ghostBg(ctx)
            setPadding(Ui.dp(ctx, 10f), Ui.dp(ctx, 8f), Ui.dp(ctx, 10f), Ui.dp(ctx, 8f))
        }
        root.addView(script, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 10f, 0f, 0f) })

        // ---- 第三行：视觉指纹 + OCR/ASR 文本 ----
        val row3 = Ui.hbox(ctx, Gravity.TOP)
        val hash = HashView(ctx).apply { id = TAG_HASH }
        row3.addView(hash, Ui.lp(Ui.dp(ctx, 34f), Ui.dp(ctx, 34f)))

        val textCol = Ui.vbox(ctx)
        val ocr = Ui.text(ctx, "字幕：-", 12f, Ui.TEXT_SUB).apply { id = TAG_OCR; maxLines = 2 }
        val asr = Ui.text(ctx, "听写：-", 12f, Ui.TEXT_SUB).apply { id = TAG_ASR; maxLines = 2 }
        val meta = Ui.text(ctx, "", 11f, "#5A6A80").apply { id = TAG_META; maxLines = 1 }
        textCol.addView(ocr, Ui.matchWrap())
        textCol.addView(asr, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 4f, 0f, 0f) })
        textCol.addView(meta, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 4f, 0f, 0f) })
        row3.addView(textCol, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, ctx, 10f, 0f, 0f, 0f)
        })
        root.addView(row3, Ui.matchWrap().apply { Ui.margin(this, ctx, 0f, 10f, 0f, 0f) })

        // ---- 第四行：操作按钮 ----
        val row4 = Ui.hbox(ctx)
        val up = Ui.emojiButton(ctx, "⬆️", "上移") {}.apply { id = TAG_UP }
        val down = Ui.emojiButton(ctx, "⬇️", "下移") {}.apply { id = TAG_DOWN }
        val lock = Ui.emojiButton(ctx, "🔒", "锁定") {}.apply { id = TAG_LOCK }
        row4.addView(up, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row4.addView(down, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, ctx, 8f, 0f, 8f, 0f)
        })
        row4.addView(lock, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row4, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, ctx, 0f, 12f, 0f, 0f)
        })

        return CardHolder(root)
    }

    override fun onBindViewHolder(holder: CardHolder, position: Int) {
        val ctx = holder.root.context
        val item = items[position]
        val f = item.feature

        holder.orderBadge.text = String.format("%02d", position + 1)
        holder.fileName.text = f.displayName
        holder.hashView.setHash(if (f.headHash != 0L) f.headHash else f.tailHash)

        // 匹配度色标：绿 ≥65%，黄 35%~65%，红 <35%
        val percent = (item.finalScore * 100).toInt()
        val colorHex = when (item.confidenceLevel) {
            AlignedClip.Level.HIGH -> Ui.GREEN
            AlignedClip.Level.MID -> Ui.AMBER
            AlignedClip.Level.LOW -> Ui.RED
        }
        holder.scoreChip.text = if (item.scriptIndex < 0) "未命中" else "$percent%"
        holder.scoreChip.setTextColor(Color.parseColor(colorHex))
        holder.scoreChip.background = Ui.chipBg(ctx, colorHex)

        // 判定来源
        holder.sourceChip.text = when {
            item.byLlm -> "🧠 大模型仲裁"
            item.byHash -> "🖼 帧哈希归位"
            item.visualScore > 0f && item.audioScore > 0f -> "👁🎙 双通道印证"
            item.visualScore > 0f -> "👁 视觉"
            item.audioScore > 0f -> "🎙 听觉"
            else -> "❔ 无信号"
        }
        holder.sourceChip.setTextColor(
            Color.parseColor(if (item.byLlm) Ui.PURPLE else Ui.TEXT_SUB)
        )

        holder.scriptText.text = if (item.scriptIndex >= 0 && item.matchedScriptText.isNotBlank()) {
            "剧本 #${item.scriptIndex + 1}：${item.matchedScriptText}"
        } else {
            "剧本 #—：未匹配到台词（可手动上移/下移微调）"
        }
        holder.scriptText.setTextColor(Color.parseColor(if (item.scriptIndex >= 0) Ui.TEXT_MAIN else Ui.TEXT_SUB))

        holder.ocrText.text = "字幕：${f.ocrText.ifBlank { "（未检测到）" }}"
        holder.asrText.text = "听写：${f.asrText.ifBlank { "（无语音信号）" }}"
        val bandFlag = if (f.hasSubtitleBand) "字幕带✓" else "字幕带✗"
        holder.metaText.text = "时长 ${f.durationMs / 1000}.${(f.durationMs % 1000) / 100}s · " +
                "${f.width}x${f.height} · 抽帧 ${f.frameCount} · " +
                "aHash ${PerceptualHash.toHex(f.headHash).take(8)}… · $bandFlag"

        holder.btnUp.alpha = if (position == 0) 0.35f else 1f
        holder.btnDown.alpha = if (position == items.size - 1) 0.35f else 1f
        holder.btnLock.text = if (item.locked) "🔓 解锁" else "🔒 锁定"
        holder.btnLock.setTextColor(Color.parseColor(if (item.locked) Ui.AMBER else Ui.TEXT_MAIN))
        if (item.locked) {
            holder.root.background = Ui.cardBg(ctx, "#121A28", Ui.AMBER, 16f)
        } else {
            holder.root.background = Ui.cardBg(ctx)
        }

        holder.btnUp.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p > 0) onMoveUp(p)
        }
        holder.btnDown.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p in 0 until items.size - 1) onMoveDown(p)
        }
        holder.btnLock.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p in items.indices) onToggleLock(p, !items[p].locked)
        }
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<AlignedClip>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
