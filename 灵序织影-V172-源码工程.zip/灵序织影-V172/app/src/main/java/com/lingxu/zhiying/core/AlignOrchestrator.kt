package com.lingxu.zhiying.core

import android.content.Context
import com.lingxu.zhiying.model.AlignProgress
import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ClipFeature
import com.lingxu.zhiying.model.ScriptLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 对齐流水线总调度
 *
 * 视觉通道（抽帧 → 字幕带检测 → 动态放大 → ML Kit OCR）
 * 听觉通道（FFmpeg 提纯滤镜链 → PCM → 滑窗 → Sherpa-ONNX SenseVoice）
 * 逻辑通道（DP 全局时序对齐 → Gemma 深水区仲裁 → 帧哈希视觉归位）
 *
 * 全流程端侧离线，断网可用。
 */
class AlignOrchestrator(private val context: Context) {

    /** 一次完整对齐的产物，matrix 需保留给涟漪重排复用 */
    class AlignResult(
        val clips: MutableList<AlignedClip>,
        val matrix: Array<Array<DpAligner.Cell>>,
        val lines: List<ScriptLine>,
        val stats: Stats
    )

    data class Stats(
        val totalClips: Int,
        val matched: Int,
        val byLlm: Int,
        val byHash: Int,
        val asrAvailable: Boolean,
        val llmAvailable: Boolean
    )

    companion object {
        /** 单个片段最多分析的帧数，控制耗时与内存 */
        private const val MAX_FRAMES_PER_CLIP = 24
    }

    private val frameExtractor = FrameExtractor(context)
    private val audioPipeline = AudioPipeline(context)
    private val concatEngine = ConcatEngine(context)

    fun run(
        selectedUris: List<String>,
        lines: List<ScriptLine>,
        subtitleZoomEnabled: Boolean,
        audioGainEnabled: Boolean,
        enableLlm: Boolean
    ): Flow<AlignProgress> = flow {
        val total = selectedUris.size
        if (total == 0) {
            emit(AlignProgress("结束", 0, 0, "没有选中任何素材"))
            return@flow
        }

        // ---------- 阶段 0：初始化模型 ----------
        emit(AlignProgress("初始化", 0, total, "加载端侧 OCR 引擎…"))
        OcrEngine.init(context)

        emit(AlignProgress("初始化", 0, total, "加载 SenseVoice 语音模型…"))
        val asrOk = withContext(Dispatchers.IO) { AsrEngine.init(context) }

        var llmOk = false
        if (enableLlm) {
            emit(AlignProgress("初始化", 0, total, "加载 Gemma-2B-IT 端侧大模型…"))
            llmOk = withContext(Dispatchers.IO) {
                LlmArbiter.init(context) { msg -> LogX.i("LlmArbiter", msg) }
            }
        }

        // ---------- 阶段 1：逐片段提取多模态特征 ----------
        val features = ArrayList<ClipFeature>(total)
        selectedUris.forEachIndexed { idx, uriStr ->
            val name = uriStr.substringAfterLast('/')
            emit(AlignProgress("特征提取", idx + 1, total, "正在分析 ${idx + 1}/$total：$name"))

            val feature = withContext(Dispatchers.IO) {
                extractOne(uriStr, idx, subtitleZoomEnabled, audioGainEnabled, asrOk)
            }
            features.add(feature)
            // 及时释放帧缓存，避免手机存储被打满
            frameExtractor.clean(idx)
        }

        // ---------- 阶段 2：DP 全局时序对齐 ----------
        emit(AlignProgress("时序对齐", total, total, "构建二维得分矩阵并求解全局最优路径…"))
        val matrix = DpAligner.buildMatrix(features, lines)
        val assignment = DpAligner.solve(matrix)

        val clips = features.mapIndexed { i, f ->
            AlignedClip(order = i + 1, feature = f)
        }.toMutableList()
        DpAligner.apply(clips, matrix, assignment)

        // ---------- 阶段 3：大模型深水区仲裁 ----------
        var byLlm = 0
        if (llmOk) {
            val ambiguous = clips.indices.filter { i ->
                val s = clips[i].finalScore
                LlmArbiter.needArbitration(s) && clips[i].extractedText().isNotBlank() && lines.isNotEmpty()
            }
            ambiguous.forEachIndexed { k, i ->
                emit(AlignProgress("大模型仲裁", k + 1, ambiguous.size, "第 ${i + 1} 个片段得分模糊，交由 Gemma 判断…"))
                val clip = clips[i]
                val current = clip.scriptIndex
                val window = candidateWindow(current, lines.size)
                val candidates = window.map { j -> LlmArbiter.Candidate(j, lines[j].text, lines[j].role) }
                val verdict = withContext(Dispatchers.IO) {
                    LlmArbiter.arbitrate(clip.extractedText(), candidates)
                }
                if (verdict != null && verdict in lines.indices) {
                    clip.scriptIndex = verdict
                    clip.byLlm = true
                    clip.finalScore = (clip.finalScore + 0.25f).coerceAtMost(1f)
                    if (verdict < matrix[i].size) {
                        val cell = matrix[i][verdict]
                        clip.visualScore = cell.visual
                        clip.audioScore = cell.audio
                    }
                    byLlm++
                }
            }
        }

        // ---------- 阶段 4：静音/无字幕片段的视觉归位 ----------
        var byHash = 0
        val sortedForAnchor = clips.sortedBy { if (it.scriptIndex < 0) Int.MAX_VALUE else it.scriptIndex }
        val empties = clips.filter { it.scriptIndex < 0 && it.feature.ocrText.isBlank() && it.feature.asrText.isBlank() }
        empties.forEachIndexed { k, target ->
            emit(AlignProgress("视觉归位", k + 1, maxOf(1, empties.size), "第 ${target.order} 个片段无文本信号，比对帧哈希…"))
            val anchors = sortedForAnchor.filter { it !== target && it.scriptIndex >= 0 && it.feature.headHash != 0L }
            val placement = HashAnchor.place(target, anchors)
            if (placement != null) {
                val near = anchors.getOrElse(placement.position - 1) { anchors.firstOrNull() }
                if (near != null) {
                    target.scriptIndex = near.scriptIndex
                    target.byHash = true
                    target.finalScore = placement.similarity
                    byHash++
                }
            }
        }

        // ---------- 阶段 5：按剧本坐标排序输出 ----------
        emit(AlignProgress("整理顺序", total, total, "按剧情时间线重排卡片…"))
        clips.forEachIndexed { i, c -> c.order = i + 1 }
        clips.sortWith(compareBy({ if (it.scriptIndex < 0) 1 else 0 }, { it.scriptIndex }, { it.order }))
        clips.forEachIndexed { i, c -> c.order = i + 1 }
        // 矩阵行必须跟随卡片一起移动，涟漪重排才能拿到正确得分
        reorderMatrix(matrix, clips, features)
        clips.forEach { c ->
            if (c.scriptIndex in lines.indices) c.matchedScriptText = lines[c.scriptIndex].text
        }

        val matched = clips.count { it.scriptIndex >= 0 }
        emit(
            AlignProgress(
                "完成", total, total,
                "对齐完成：$matched/$total 命中剧本，大模型仲裁 $byLlm 处，帧哈希归位 $byHash 处"
            )
        )
        lastResult = AlignResult(
            clips, matrix, lines,
            Stats(total, matched, byLlm, byHash, asrOk, llmOk)
        )
    }.flowOn(Dispatchers.Default)

    /** 供 UI 层取回最近一次对齐结果 */
    var lastResult: AlignResult? = null
        private set

    private fun extractOne(
        uriStr: String,
        clipId: Int,
        subtitleZoom: Boolean,
        audioGain: Boolean,
        asrOk: Boolean
    ): ClipFeature {
        val path = if (uriStr.startsWith("content://")) {
            MediaResolver.resolve(context, android.net.Uri.parse(uriStr))?.path ?: uriStr
        } else uriStr

        val info = VideoProbe.probe(path)
        val feature = ClipFeature(
            id = clipId,
            uri = uriStr,
            displayName = uriStr.substringAfterLast('/'),
            durationMs = info.durationMs,
            width = info.width,
            height = info.height
        )

        // 首尾帧 aHash
        try {
            val (head, tail) = frameExtractor.extractHeadTail(path, clipId)
            feature.headHash = PerceptualHash.aHash(head)
            feature.tailHash = if (tail != null) PerceptualHash.aHash(tail) else feature.headHash
            head?.recycle(); tail?.recycle()
        } catch (e: Throwable) {
            LogX.w("Align", "aHash 提取失败: ${e.message}")
        }

        // 抽帧 + 字幕带检测 + OCR
        try {
            val frames = frameExtractor.extract(path, clipId)
            feature.frameCount = frames.size
            val texts = ArrayList<String>()
            frames.take(MAX_FRAMES_PER_CLIP).forEachIndexed { i, file ->
                val bmp = frameExtractor.decodeSampled(file.absolutePath, 720) ?: return@forEachIndexed
                val band = SubtitleBand.detect(bmp)
                if (band != null) {
                    feature.hasSubtitleBand = true
                    val enhanced = SubtitleBand.cropAndEnhance(bmp, band, subtitleZoom)
                    val t = OcrEngine.recognize(enhanced)
                    if (t.isNotBlank()) texts.add(t)
                    if (enhanced !== bmp) enhanced.recycle()
                } else if (i % 4 == 0) {
                    // 没检测到字幕带时，每隔几帧做一次全屏 OCR 兜底
                    val t = OcrEngine.recognize(bmp)
                    if (t.isNotBlank()) texts.add(t)
                }
                bmp.recycle()
            }
            feature.ocrText = OcrEngine.mergeFrames(texts)
        } catch (e: Throwable) {
            LogX.e("Align", "视觉管线失败", e)
        }

        // 音频提纯 + ASR
        if (asrOk) {
            try {
                val wav = audioPipeline.extract(path, clipId, audioGain)
                if (wav != null) {
                    val pcm = audioPipeline.readPcm(wav)
                    val windows = audioPipeline.windows(pcm)
                    feature.asrText = AsrEngine.transcribeWithWindows(windows)
                }
            } catch (e: Throwable) {
                LogX.e("Align", "听觉管线失败", e)
            } finally {
                audioPipeline.clean(clipId)
            }
        }

        LogX.i(
            "Align",
            "片段#$clipId 时长${info.durationMs}ms OCR=${feature.ocrText.length}字 ASR=${feature.asrText.length}字 " +
                    "aHash=${PerceptualHash.toHex(feature.headHash)}"
        )
        return feature
    }

    /** 取仲裁候选窗口：当前句前后各 2 句 */
    private fun candidateWindow(current: Int, lineCount: Int): List<Int> {
        val center = current.coerceIn(0, maxOf(0, lineCount - 1))
        val lo = (center - 2).coerceAtLeast(0)
        val hi = (center + 2).coerceAtMost(lineCount - 1)
        return (lo..hi).toList()
    }

    /** 按 clips 的新顺序重排 matrix 行 */
    private fun reorderMatrix(
        matrix: Array<Array<DpAligner.Cell>>,
        clips: List<AlignedClip>,
        features: List<ClipFeature>
    ) {
        val idToRow = HashMap<Int, Int>()
        features.forEachIndexed { row, f -> idToRow[f.id] = row }
        val order = clips.mapNotNull { idToRow[it.feature.id] }
        if (order.size != matrix.size) return
        val snapshot = matrix.map { it.clone() }.toTypedArray()
        order.forEachIndexed { newRow, oldRow ->
            if (oldRow in snapshot.indices && newRow in matrix.indices) {
                matrix[newRow] = snapshot[oldRow]
            }
        }
    }

    private fun AlignedClip.extractedText(): String =
        if (feature.asrText.isNotBlank()) feature.asrText else feature.ocrText

    /** 第四步：渲染导出 */
    suspend fun renderAndExport(
        paths: List<String>,
        mode: ConcatEngine.Mode = ConcatEngine.Mode.AUTO
    ): Pair<android.net.Uri?, File?> = withContext(Dispatchers.IO) {
        val out = concatEngine.concat(paths) { msg -> LogX.i("Render", msg) }
        if (out == null) return@withContext null to null
        val uri = GalleryExporter.export(context, out)
        uri to out
    }

    fun cleanup() {
        frameExtractor.cleanAll()
        audioPipeline.cleanAll()
        concatEngine.cleanAll()
    }
}
