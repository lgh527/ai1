package com.lingxu.zhiying.core

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * 字幕带检测（Subtitle Band Detection）
 *
 * 将画面纵向分为上、中、下三区，每 10 像素为一行切片，
 * 统计该行的「像素亮度平均值」与「高亮像素占比」，
 * 满足阈值即判定为字幕所在行带。
 *
 * 检测到字幕带后，若带高小于 80 像素，交给 [ScaleEnhancer] 做 2~4 倍等比放大，
 * 再送入 OCR，可显著提升小字号识别率。
 */
object SubtitleBand {

    private const val ROW_STEP = 10          // 每 10 像素一行切片
    private const val LUMA_THRESHOLD = 150   // 行平均亮度阈值（字幕多为亮字暗底）
    private const val BRIGHT_RATIO = 0.18f   // 高亮像素占比阈值
    private const val BRIGHT_PIXEL = 200     // 单像素判定为「高亮」的亮度
    const val MIN_BAND_HEIGHT = 80           // 小于该高度触发放大增强

    data class Band(
        val top: Int,
        val bottom: Int,
        val zone: Zone,
        val score: Float
    ) {
        val height: Int get() = bottom - top
    }

    enum class Zone { TOP, MIDDLE, BOTTOM }

    /**
     * 分析一帧，返回最可能的字幕带（可能为 null）
     */
    fun detect(src: Bitmap?): Band? {
        if (src == null) return null
        val w = src.width
        val h = src.height
        if (w < 32 || h < 32) return null

        // 为省内存，横向按步长采样
        val xStep = max(1, w / 240)
        val rows = ArrayList<IntArray>()
        var y = 0
        while (y < h) {
            val end = min(h, y + ROW_STEP)
            var lumaSum = 0L
            var bright = 0
            var count = 0
            var yy = y
            while (yy < end) {
                var xx = 0
                while (xx < w) {
                    val p = src.getPixel(xx, yy)
                    val l = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
                    lumaSum += l
                    if (l >= BRIGHT_PIXEL) bright++
                    count++
                    xx += xStep
                }
                yy += max(1, (end - y) / 2)
            }
            if (count == 0) {
                rows.add(intArrayOf(y, end, 0, 0))
            } else {
                rows.add(intArrayOf(y, end, (lumaSum / count).toInt(), bright * 1000 / count))
            }
            y = end
        }

        // 逐区寻找连续命中行
        var best: Band? = null
        for (zone in Zone.values()) {
            val band = scanZone(rows, zone, h) ?: continue
            if (best == null || band.score > best.score) best = band
        }
        return best
    }

    private fun scanZone(rows: List<IntArray>, zone: Zone, h: Int): Band? {
        val lo: Int
        val hi: Int
        when (zone) {
            Zone.TOP -> { lo = 0; hi = h * 30 / 100 }
            Zone.MIDDLE -> { lo = h * 35 / 100; hi = h * 65 / 100 }
            Zone.BOTTOM -> { lo = h * 62 / 100; hi = h }
        }
        var start = -1
        var end = -1
        var scoreSum = 0f
        var hit = 0
        var bestBand: Band? = null

        for (r in rows) {
            val ry = r[0]
            if (ry < lo || ry >= hi) continue
            val isSubtitleRow = r[2] >= LUMA_THRESHOLD && r[3] >= BRIGHT_RATIO * 1000
            if (isSubtitleRow) {
                if (start < 0) start = ry
                end = r[1]
                scoreSum += (r[2] / 255f) * 0.5f + (r[3] / 1000f) * 0.5f
                hit++
            } else if (start >= 0) {
                bestBand = finish(bestBand, zone, start, end, scoreSum, hit)
                start = -1; end = -1; scoreSum = 0f; hit = 0
            }
        }
        if (start >= 0) bestBand = finish(bestBand, zone, start, end, scoreSum, hit)
        return bestBand
    }

    private fun finish(best: Band?, zone: Zone, start: Int, end: Int, scoreSum: Float, hit: Int): Band? {
        if (hit <= 0) return best
        val height = max(1, end - start)
        // 字幕带高度在 20~180 像素之间最合理，过高说明是整屏亮画面
        if (height < 12 || height > 220) return best
        val band = Band(start, end, zone, scoreSum / hit)
        return if (best == null || band.score > best.score) band else best
    }

    /**
     * 动态缩放增强：字幕高度小于 80 像素时等比放大 2~4 倍再送 OCR。
     * 放大倍数按「目标高度 160 像素」反推，并夹在 [2,4]。
     */
    fun cropAndEnhance(src: Bitmap, band: Band, enabled: Boolean): Bitmap {
        val pad = (band.height * 0.35f).toInt()
        val top = max(0, band.top - pad)
        val bottom = min(src.height, band.bottom + pad)
        val cropH = max(1, bottom - top)
        val crop = Bitmap.createBitmap(src, 0, top, src.width, cropH)
        if (!enabled) return crop
        if (cropH >= MIN_BAND_HEIGHT) return crop

        val scale = ((160f / cropH).coerceIn(2f, 4f))
        val nw = max(1, (crop.width * scale).toInt())
        val nh = max(1, (cropH * scale).toInt())
        val scaled = Bitmap.createScaledBitmap(crop, nw, nh, true)
        if (scaled !== crop) crop.recycle()
        return scaled
    }
}
