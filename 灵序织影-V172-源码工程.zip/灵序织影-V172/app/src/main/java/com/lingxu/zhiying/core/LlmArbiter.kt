package com.lingxu.zhiying.core

import android.content.Context
import com.google.mediapipe.tasks.core.OutputHandler
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * 逻辑大模型：MediaPipe GenAI + Gemma-2B-IT（int4 量化）
 *
 * 深水区仲裁触发条件：视觉与听觉的交叉匹配得分落在 [LOW_BOUND, HIGH_BOUND] 模糊地带。
 * 此时把「当前听写/字幕台词 + 前后各两句剧本」拼成 Prompt 交给大模型判断，
 * 再用正则 Regex("\\d+") 从回复里精准提取编号数字。
 *
 * 模型必须落地为真实文件路径（MediaPipe 不接受 AssetManager），
 * 因此首次使用时从 assets/models 复制到 filesDir/models，之后直接复用。
 */
object LlmArbiter {

    const val LOW_BOUND = 0.20f
    const val HIGH_BOUND = 0.65f

    private const val MODEL_DIR = "models"
    private const val SYSTEM_PROMPT =
        "你是首席影视对轴导演。下面给你一段从视频里提取的台词，以及编号后的候选剧本句子。" +
                "请结合上下文语义，判断这段台词最可能对应哪一句剧本。" +
                "只输出匹配的编号数字，不要输出任何解释、标点或其他文字。"

    @Volatile
    private var inference: LlmInference? = null

    /** tasks-genai 0.10.14 的结果通过 ProgressListener 分片回调，这里做累积 */
    private val buffer = StringBuilder()

    @Volatile
    private var latch: CountDownLatch? = null

    private val resultListener = OutputHandler.ProgressListener<String> { partial, done ->
        synchronized(buffer) {
            if (partial != null) buffer.append(partial)
        }
        if (done) latch?.countDown()
    }

    @Volatile
    var available: Boolean = false
        private set

    var unavailableReason: String = ""
        private set

    var modelPath: String = ""
        private set

    /** 处于模糊地带的候选 */
    data class Candidate(val index: Int, val text: String, val role: String = "")

    /**
     * 初始化。失败不抛异常，只把 [available] 置 false，
     * 让对齐流程退化为「纯视觉 + 纯听觉」，保证一定能出结果。
     */
    @Synchronized
    fun init(context: Context, progress: (String) -> Unit = {}): Boolean {
        if (inference != null) return true
        return try {
            progress("正在准备端侧大模型…")
            val local = ensureModelFile(context, progress)
            if (local == null) {
                unavailableReason = "assets/models 下未找到 Gemma 量化模型（*.bin）"
                LogX.w("LlmArbiter", unavailableReason)
                return false
            }
            modelPath = local.absolutePath
            // 0.10.14 的 Builder 没有 setPreferredBackend（0.10.15+ 才引入），后端由模型文件本身决定
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setRandomSeed(101)
                .setMaxTokens(16) // 只需要一个编号，限制生成长度可大幅提速
                .setResultListener(resultListener)
                .setErrorListener { e -> LogX.w("LlmArbiter", "推理错误: ${e.message}") }
                .build()
            inference = LlmInference.createFromOptions(context, options)
            available = true
            unavailableReason = ""
            LogX.i("LlmArbiter", "Gemma-2B-IT 端侧推理引擎已就绪: $modelPath")
            true
        } catch (e: Throwable) {
            inference = null
            available = false
            unavailableReason = "LLM 初始化失败：${e.javaClass.simpleName} ${e.message}"
            LogX.e("LlmArbiter", unavailableReason, e)
            false
        }
    }

    /** 从 assets 找出 *.bin 并复制到 filesDir，已存在则跳过 */
    private fun ensureModelFile(context: Context, progress: (String) -> Unit): File? {
        val outDir = File(context.filesDir, MODEL_DIR).apply { if (!exists()) mkdirs() }
        val assetName = try {
            context.assets.list(MODEL_DIR)?.firstOrNull { it.endsWith(".bin") }
        } catch (e: Throwable) {
            null
        } ?: return outDir.listFiles()?.firstOrNull { it.endsWith(".bin") }

        val target = File(outDir, assetName)
        if (target.exists() && target.length() > 1024 * 1024) return target

        progress("正在释放 Gemma 模型到本地存储（仅首次，约 1GB）…")
        return try {
            context.assets.open("$MODEL_DIR/$assetName").use { input ->
                target.outputStream().use { output ->
                    val buf = ByteArray(1024 * 512)
                    var total = 0L
                    var lastReport = 0L
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        output.write(buf, 0, read)
                        total += read
                        if (total - lastReport > 64L * 1024 * 1024) {
                            lastReport = total
                            progress("已释放 ${total / 1024 / 1024} MB…")
                        }
                    }
                    output.flush()
                }
            }
            target
        } catch (e: Throwable) {
            LogX.e("LlmArbiter", "模型释放失败", e)
            target.delete()
            null
        }
    }

    /**
     * 仲裁一次：返回大模型给出的剧本编号，解析失败返回 null
     *
     * @param extractedText 该片段当前提取到的台词（OCR 或 ASR）
     * @param candidates    候选剧本句（建议控制在 8 句以内，2B 模型上下文有限）
     */
    fun arbitrate(extractedText: String, candidates: List<Candidate>): Int? {
        val engine = inference ?: return null
        if (candidates.isEmpty() || extractedText.isBlank()) return null
        val prompt = buildPrompt(extractedText, candidates)
        return try {
            val wait = CountDownLatch(1)
            latch = wait
            synchronized(buffer) { buffer.setLength(0) }
            engine.generateResponse(prompt)
            // 同步接口在 0.10.14 上可能立即返回，结果仍走回调，这里等回调收尾
            wait.await(120, TimeUnit.SECONDS)
            latch = null
            val raw = synchronized(buffer) { buffer.toString() }
            LogX.i("LlmArbiter", "大模型回复: $raw")
            parseNumber(raw, candidates)
        } catch (e: Throwable) {
            LogX.w("LlmArbiter", "仲裁失败: ${e.message}")
            null
        }
    }

    private fun buildPrompt(extractedText: String, candidates: List<Candidate>): String {
        val sb = StringBuilder()
        sb.append(SYSTEM_PROMPT).append("\n\n")
        sb.append("【视频台词】").append(extractedText).append("\n\n")
        sb.append("【候选剧本】\n")
        candidates.forEach { c ->
            sb.append(c.index).append(". ")
            if (c.role.isNotBlank()) sb.append("(").append(c.role).append(") ")
            sb.append(c.text).append("\n")
        }
        sb.append("\n只输出编号数字：")
        return sb.toString()
    }

    /** 正则提取数字，并校验必须落在候选编号集合内 */
    private fun parseNumber(raw: String, candidates: List<Candidate>): Int? {
        val ids = candidates.map { it.index }.toSet()
        Regex("\\d+").findAll(raw).forEach { m ->
            val v = m.value.toIntOrNull()
            if (v != null && v in ids) return v
        }
        // 退一步：回复里的第一个数字，按候选列表位置解释
        Regex("\\d+").find(raw)?.value?.toIntOrNull()?.let { ordinal ->
            if (ordinal in 1..candidates.size) return candidates[ordinal - 1].index
        }
        return null
    }

    /** 判断某个得分是否落在需要仲裁的模糊地带 */
    fun needArbitration(score: Float): Boolean = score in LOW_BOUND..HIGH_BOUND

    @Synchronized
    fun release() {
        try {
            inference?.close()
        } catch (_: Throwable) {
        }
        inference = null
        available = false
    }
}
