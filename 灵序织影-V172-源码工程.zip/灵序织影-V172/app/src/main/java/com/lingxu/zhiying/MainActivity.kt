package com.lingxu.zhiying

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.lingxu.zhiying.core.AlignOrchestrator
import com.lingxu.zhiying.core.ConcatEngine
import com.lingxu.zhiying.core.LogX
import com.lingxu.zhiying.core.MediaResolver
import com.lingxu.zhiying.core.OcrEngine
import com.lingxu.zhiying.core.RippleAdjust
import com.lingxu.zhiying.core.ScriptParser
import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ScriptLine
import com.lingxu.zhiying.security.ActivationManager
import com.lingxu.zhiying.security.SignatureGuard
import com.lingxu.zhiying.ui.ClipCardAdapter
import com.lingxu.zhiying.ui.Ui
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 灵序织影 V172 终极融合版 —— 主界面
 *
 * UI 全部由纯原生 Android 代码构建（无 XML 布局），深色系 #05080E 科技风。
 * 四大操作流：剧本解析 → 素材与增强开关 → 对齐与卡片式校对 → 渲染导出。
 */
class MainActivity : ComponentActivity() {

    companion object {
        /** CI 构建时由 sed 注入真实 SHA-256 签名指纹（与 SignatureGuard 保持一致） */
        const val SIGNATURE_PLACEHOLDER = "YOUR_APP_SIGNATURE_PLACEHOLDER"

        private const val REQ_PERMISSIONS = 0x1772
    }

    // ---- 状态 ----
    private var scriptLines: List<ScriptLine> = emptyList()
    private val selectedUris = ArrayList<String>()
    private val clipCards = ArrayList<AlignedClip>()
    private var alignResult: AlignOrchestrator.AlignResult? = null
    private var isBusy = false

    private lateinit var orchestrator: AlignOrchestrator

    // ---- 视图（用可空引用，避免 onCreate 中途异常导致 UninitializedPropertyAccessException）----
    private var rootLayout: LinearLayout? = null
    private var authLayout: LinearLayout? = null
    private var etScript: EditText? = null
    private var tvScriptInfo: TextView? = null
    private var tvMaterialInfo: TextView? = null
    private var swSubtitleZoom: LinearLayout? = null
    private var swAudioGain: LinearLayout? = null
    private var swLlm: LinearLayout? = null
    private var swAutoTrim: LinearLayout? = null
    private var progressBar: ProgressBar? = null
    private var tvStatus: TextView? = null
    private var btnAlign: TextView? = null
    private var btnRender: TextView? = null
    private var recycler: RecyclerView? = null
    private var adapter: ClipCardAdapter? = null
    private var step3Card: LinearLayout? = null
    private var step4Card: LinearLayout? = null

    private val videoPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            uris.forEach { u ->
                runCatching {
                    contentResolver.takePersistableUriPermission(u, flags)
                }
                if (!selectedUris.contains(u.toString())) selectedUris.add(u.toString())
            }
            refreshMaterialInfo()
            toast("已导入 ${uris.size} 个视频切片")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ===== 安全校验：签名 + 反调试 + 反 Hook =====
        val verdict = runCatching { SignatureGuard.verify(this) }
            .getOrElse { SignatureGuard.Verdict(false, "校验异常:${it.message}", "") }
        if (!verdict.pass) {
            SignatureGuard.execute(this, verdict)
            return
        }

        orchestrator = AlignOrchestrator(this)
        buildRootUi()
        requestPermissionsCompat()

        if (!ActivationManager.isActivated(this)) {
            showAuthScreen()
        }
    }

    // ==================================================================
    //  UI 构建
    // ==================================================================

    private fun buildRootUi() {
        rootLayout = Ui.vbox(this).apply {
            setBackgroundColor(Color.parseColor(Ui.BG_DEEP))
            setPadding(Ui.dp(context, 18f), Ui.dp(context, 26f), Ui.dp(context, 18f), Ui.dp(context, 18f))
        }

        // ---- 顶栏 ----
        val header = Ui.hbox(this)
        val logo = Ui.text(this, "🎬", 26f)
        header.addView(logo)
        val titleCol = Ui.vbox(this)
        titleCol.addView(Ui.text(this, "灵序织影", 21f, Ui.TEXT_MAIN, bold = true))
        titleCol.addView(Ui.text(this, "端侧全离线 AI 多模态视频对齐与混剪系统", 11f, Ui.TEXT_SUB))
        header.addView(titleCol, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, this@MainActivity, 10f, 0f, 0f, 0f)
        })
        val badge = Ui.text(this, "V172", 11f, Ui.CYAN).apply {
            background = Ui.chipBg(this@MainActivity, Ui.CYAN)
            gravity = Gravity.CENTER
            setPadding(Ui.dp(context, 10f), Ui.dp(context, 4f), Ui.dp(context, 10f), Ui.dp(context, 4f))
        }
        header.addView(badge)
        rootLayout?.addView(header, Ui.matchWrap())

        // ---- 滚动区 ----
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Color.TRANSPARENT)
        }
        val column = Ui.vbox(this)
        scroll.addView(column, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        column.addView(buildStep1(), Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 18f, 0f, 0f) })
        column.addView(buildStep2(), Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 14f, 0f, 0f) })
        step3Card = buildStep3()
        column.addView(step3Card, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 14f, 0f, 0f) })
        step4Card = buildStep4()
        column.addView(step4Card, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 14f, 0f, 0f) })

        rootLayout?.addView(scroll, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(rootLayout)
    }

    private fun sectionTitle(emoji: String, title: String, subtitle: String): LinearLayout {
        val box = Ui.vbox(this)
        box.addView(Ui.text(this, "$emoji  $title", 15f, Ui.TEXT_MAIN, bold = true))
        box.addView(Ui.text(this, subtitle, 11f, Ui.TEXT_SUB))
        return box
    }

    private fun buildStep1(): LinearLayout {
        val card = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity)
            setPadding(Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f))
        }
        card.addView(sectionTitle("📝", "第一步 · 剧本解析", "粘贴纯文本剧本，自动剥离「男主:」「【旁白】」等前缀"))

        etScript = EditText(this).apply {
            background = Ui.ghostBg(this@MainActivity)
            setTextColor(Color.parseColor(Ui.TEXT_MAIN))
            setHintTextColor(Color.parseColor("#4C5A6E"))
            hint = "把剧本粘贴到这里，一行一句台词…\n例：\n男主: 你到底想干什么\n【旁白】三年后，他回来了"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
            minLines = 5
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
            setPadding(Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        card.addView(etScript, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        tvScriptInfo = Ui.text(this, "尚未解析", 12f, Ui.TEXT_SUB)
        card.addView(tvScriptInfo, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })

        val row = Ui.hbox(this)
        val btnParse = Ui.emojiButton(this, "🧩", "解析剧本") { parseScript() }
        val btnDemo = Ui.emojiButton(this, "✨", "填入示例") { fillDemoScript() }
        row.addView(btnParse, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btnDemo, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, this@MainActivity, 10f, 0f, 0f, 0f)
        })
        card.addView(row, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f)
        })
        return card
    }

    private fun buildStep2(): LinearLayout {
        val card = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity)
            setPadding(Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f))
        }
        card.addView(sectionTitle("📥", "第二步 · 素材导入与增强开关", "批量勾选相册中的乱序视频切片"))

        val btnImport = TextView(this).apply {
            text = "📥 批量导入视频素材"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#031018"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            background = Ui.primaryBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 13f), 0, Ui.dp(context, 13f))
            setOnClickListener {
                ensureStoragePermissionThen {
                    videoPicker.launch(arrayOf("video/*"))
                }
            }
        }
        card.addView(btnImport, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        tvMaterialInfo = Ui.text(this, "已选 0 个切片", 12f, Ui.TEXT_SUB)
        card.addView(tvMaterialInfo, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f) })

        val btnScan = Ui.emojiButton(this, "🔎", "扫描相册全部视频") {
            ensureStoragePermissionThen {
                lifecycleScope.launch {
                    val all = withContext(Dispatchers.IO) { MediaResolver.queryAllVideos(this@MainActivity) }
                    if (all.isEmpty()) {
                        toast("相册里没有可用视频，或权限未授予")
                    } else {
                        selectedUris.clear()
                        all.forEach { selectedUris.add(it.path) }
                        refreshMaterialInfo()
                        toast("已扫描到 ${all.size} 个视频")
                    }
                }
            }
        }
        val btnClear = Ui.emojiButton(this, "🗑", "清空素材") {
            selectedUris.clear(); refreshMaterialInfo()
        }
        val row = Ui.hbox(this)
        row.addView(btnScan, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btnClear, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, this@MainActivity, 10f, 0f, 0f, 0f)
        })
        card.addView(row, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f)
        })

        // ---- 两个增强开关 ----
        swSubtitleZoom = makeSwitch("🔍 智能字幕感知放大", "检测字幕带并对小字等比放大 2~4 倍再 OCR", true)
        swAudioGain = makeSwitch("🎙️ 语音智能增益", "挂载高通/低通/频谱降噪/压缩/响度归一化滤镜链", true)
        swLlm = makeSwitch("🧠 大模型深水区仲裁", "得分落在 0.2~0.65 模糊地带时，调用 Gemma-2B-IT 判断（慢，首次建议关闭）", false)
        swAutoTrim = makeSwitch("✂️ 自动去首尾静音", "用 silencedetect 探测并给出裁剪入出点，拼接时精确切掉", false)
        card.addView(swSubtitleZoom, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })
        card.addView(swAudioGain, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 0f) })
        card.addView(swLlm, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 0f) })
        card.addView(swAutoTrim, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 0f) })
        return card
    }

    private fun makeSwitch(title: String, desc: String, checked: Boolean): LinearLayout {
        val box = Ui.vbox(this).apply {
            background = Ui.ghostBg(this@MainActivity)
            setPadding(Ui.dp(context, 12f), Ui.dp(context, 10f), Ui.dp(context, 12f), Ui.dp(context, 10f))
        }
        val row = Ui.hbox(this)
        val col = Ui.vbox(this)
        col.addView(Ui.text(this, title, 13f, Ui.TEXT_MAIN, bold = true))
        col.addView(Ui.text(this, desc, 11f, Ui.TEXT_SUB))
        row.addView(col, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = checked
            tag = title
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(Ui.CYAN))
            trackTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#243144"))
        }
        row.addView(sw)
        box.addView(row, Ui.matchWrap())
        // 把真正的 Switch 挂到容器 tag 上，便于统一读取状态
        box.tag = sw
        return box
    }

    /** 从 makeSwitch 生成的容器里取出真正的 Switch 控件并读取状态 */
    private fun switchOf(box: LinearLayout?): Boolean = (box?.tag as? Switch)?.isChecked ?: true

    private fun buildStep3(): LinearLayout {
        val card = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity)
            setPadding(Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f))
        }
        card.addView(sectionTitle("🧠", "第三步 · 智能对齐与校对工作台", "DP 全局时序对齐 + 卡片式手动微调（涟漪重排）"))

        btnAlign = TextView(this).apply {
            text = "🧠 智能对齐"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#031018"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            background = Ui.primaryBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 14f), 0, Ui.dp(context, 14f))
            setOnClickListener { startAlign() }
        }
        card.addView(btnAlign, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(Ui.CYAN))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#16202E"))
            visibility = View.GONE
        }
        card.addView(progressBar, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        tvStatus = Ui.text(this, "待命中。请先解析剧本并导入素材。", 12f, Ui.TEXT_SUB)
        card.addView(tvStatus, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 8f, 0f, 0f) })

        // ---- 校对工作台工具条：把「拨乱反正」做成一键操作 ----
        val tools = Ui.hbox(this)
        tools.addView(Ui.emojiButton(this, "✅", "锁定高置信") { lockGreens() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(Ui.emojiButton(this, "🔓", "全部解锁") { unlockAll() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        tools.addView(Ui.emojiButton(this, "📐", "按剧本重排") { sortToScript() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        tools.addView(Ui.emojiButton(this, "📊", "对齐体检") { showCoverageReport() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { Ui.margin(this, this@MainActivity, 6f, 0f, 0f, 0f) })
        card.addView(tools, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f)
        })

        adapter = ClipCardAdapter(
            clipCards,
            onMoveUp = { pos -> moveClip(pos, true) },
            onMoveDown = { pos -> moveClip(pos, false) },
            onToggleLock = { pos, locked -> toggleLock(pos, locked) },
            onTrim = { pos, deltaIn, deltaOut -> adjustTrim(pos, deltaIn, deltaOut) }
        )
        recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            this.adapter = this@MainActivity.adapter
            isNestedScrollingEnabled = false
            visibility = View.GONE
            setBackgroundColor(Color.TRANSPARENT)
        }
        card.addView(recycler, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })
        return card
    }

    private fun buildStep4(): LinearLayout {
        val card = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity)
            setPadding(Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f), Ui.dp(context, 14f))
        }
        card.addView(sectionTitle("🎬", "第四步 · 渲染导出", "-f concat -c copy 无损极速拼接，冲突时自动降级 libx264 -crf 18"))

        btnRender = TextView(this).apply {
            text = "⬆️ 渲染并导出到相册"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor(Ui.TEXT_MAIN))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
            background = Ui.ghostBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 13f), 0, Ui.dp(context, 13f))
            isEnabled = false
            alpha = 0.4f
            setOnClickListener { startRender() }
        }
        card.addView(btnRender, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 12f, 0f, 0f) })

        val row = Ui.hbox(this)
        row.addView(Ui.emojiButton(this, "📋", "复制导出路径") { copyLastOutput() },
            Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.emojiButton(this, "🧹", "清理缓存") {
            orchestrator.cleanup(); toast("临时帧与音频缓存已清理")
        }, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            Ui.margin(this, this@MainActivity, 10f, 0f, 0f, 0f)
        })
        card.addView(row, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            Ui.margin(this, this@MainActivity, 0f, 10f, 0f, 0f)
        })
        return card
    }

    // ==================================================================
    //  交互逻辑
    // ==================================================================

    private fun parseScript() {
        val raw = etScript?.text?.toString() ?: ""
        if (raw.isBlank()) {
            toast("剧本内容为空")
            return
        }
        scriptLines = ScriptParser.parse(raw)
        if (scriptLines.isEmpty()) {
            tvScriptInfo?.text = "⚠️ 没有解析出有效台词，请检查剧本格式"
            tvScriptInfo?.setTextColor(Color.parseColor(Ui.RED))
            return
        }
        val roles = scriptLines.map { it.role }.filter { it.isNotBlank() }.distinct()
        tvScriptInfo?.text = "✅ 解析出 ${scriptLines.size} 句有效台词" +
                if (roles.isNotEmpty()) "，识别到角色：${roles.take(6).joinToString("、")}" else ""
        tvScriptInfo?.setTextColor(Color.parseColor(Ui.GREEN))
        updatePrimaryButtons()
    }

    private fun fillDemoScript() {
        etScript?.setText(
            """
            【旁白】三年后，他回到了这座熟悉的城市
            男主: 你到底想干什么
            女主: 我只是想问你一句话
            男主: 那就问吧
            【旁白】雨下了整整一夜，谁也没有先开口
            女主: 那年夏天，你为什么不告而别
            男主: 因为我不想让你看到我狼狈的样子
            """.trimIndent()
        )
        parseScript()
    }

    private fun refreshMaterialInfo() {
        tvMaterialInfo?.text = if (selectedUris.isEmpty()) {
            "已选 0 个切片"
        } else {
            "已选 ${selectedUris.size} 个切片 · " + selectedUris.take(2)
                .joinToString("、") { it.substringAfterLast('/').take(18) } +
                    if (selectedUris.size > 2) " 等" else ""
        }
        updatePrimaryButtons()
    }

    private fun updatePrimaryButtons() {
        val ready = scriptLines.isNotEmpty() && selectedUris.isNotEmpty() && !isBusy
        btnAlign?.isEnabled = ready
        btnAlign?.alpha = if (ready) 1f else 0.4f
    }

    private fun startAlign() {
        if (isBusy) return
        if (scriptLines.isEmpty()) {
            toast("请先解析剧本"); return
        }
        if (selectedUris.isEmpty()) {
            toast("请先导入视频素材"); return
        }
        isBusy = true
        updatePrimaryButtons()
        progressBar?.visibility = View.VISIBLE
        recycler?.visibility = View.GONE
        clipCards.clear()
        adapter?.notifyDataSetChanged()

        val zoom = switchOf(swSubtitleZoom)
        val gain = switchOf(swAudioGain)
        val llm = switchOf(swLlm)
        val autoTrim = switchOf(swAutoTrim)

        lifecycleScope.launch {
            try {
                orchestrator.run(selectedUris.toList(), scriptLines, zoom, gain, llm, autoTrim)
                    .collectLatest { p ->
                        tvStatus?.text = "${p.stage}（${p.current}/${p.total}）· ${p.message}"
                        progressBar?.progress = (p.ratio * 100).toInt()
                    }
                val result = orchestrator.lastResult
                alignResult = result
                if (result != null) {
                    clipCards.clear()
                    clipCards.addAll(result.clips)
                    adapter?.notifyDataSetChanged()
                    recycler?.visibility = View.VISIBLE
                    val s = result.stats
                    tvStatus?.text = "✅ 对齐完成：${s.matched}/${s.totalClips} 命中 · " +
                            "大模型仲裁 ${s.byLlm} 处 · 帧哈希归位 ${s.byHash} 处 · " +
                            "ASR ${if (s.asrAvailable) "在线" else "不可用"} · LLM ${if (s.llmAvailable) "在线" else "不可用"}"
                    tvStatus?.setTextColor(Color.parseColor(Ui.GREEN))
                    btnRender?.isEnabled = true
                    btnRender?.alpha = 1f
                    btnRender?.background = Ui.primaryBg(this@MainActivity)
                    btnRender?.setTextColor(Color.parseColor("#031018"))
                } else {
                    tvStatus?.text = "⚠️ 对齐未产出结果，请检查素材是否可读"
                    tvStatus?.setTextColor(Color.parseColor(Ui.AMBER))
                }
            } catch (e: Throwable) {
                LogX.e("Main", "对齐流程异常", e)
                tvStatus?.text = "❌ 对齐失败：${e.javaClass.simpleName} ${e.message}"
                tvStatus?.setTextColor(Color.parseColor(Ui.RED))
            } finally {
                isBusy = false
                progressBar?.visibility = View.GONE
                updatePrimaryButtons()
            }
        }
    }

    /** ⬆️/⬇️ 手动微调 + 涟漪重排 */
    private fun moveClip(position: Int, upward: Boolean) {
        val result = alignResult ?: run { toast("请先完成智能对齐"); return }
        val touched = RippleAdjust.move(clipCards, result.matrix, position, upward)
        if (touched <= 0) {
            toast(if (upward) "已经在最顶端了" else "已经在最底端了")
            return
        }
        adapter?.notifyDataSetChanged()
        if (touched > 1) {
            toast("已重排，涟漪区间内 $touched 张卡片重新平衡")
        }
    }

    private fun toggleLock(position: Int, locked: Boolean) {
        if (position !in clipCards.indices) return
        clipCards[position].locked = locked
        adapter?.notifyItemChanged(position)
        toast(if (locked) "已锁定，涟漪重排将跳过该片段" else "已解锁")
    }

    /** 一键锁定所有高置信片段：之后的涟漪重排都不会动它们 */
    private fun lockGreens() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val n = clipCards.count { !it.locked && it.finalScore >= 0.65f && it.scriptIndex >= 0 }
        clipCards.forEach { if (!it.locked && it.finalScore >= 0.65f && it.scriptIndex >= 0) it.locked = true }
        adapter?.notifyDataSetChanged()
        toast(if (n > 0) "已锁定 $n 个高置信片段" else "没有可锁定的高置信片段")
    }

    private fun unlockAll() {
        val n = clipCards.count { it.locked }
        clipCards.forEach { it.locked = false }
        adapter?.notifyDataSetChanged()
        toast("已解锁 $n 个片段")
    }

    /** 一键按剧本坐标重排：手动调乱了也能回到剧本序 */
    private fun sortToScript() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val moved = com.lingxu.zhiying.core.CoverageChecker.sortToScriptOrder(clipCards)
        alignResult?.let { r ->
            // 卡片顺序变了，矩阵行必须跟着走，涟漪重排才不会拿错分
            val idToRow = HashMap<Int, Int>()
            r.clips.forEachIndexed { i, c -> idToRow[c.feature.id] = i }
            val snapshot = r.matrix.map { it.clone() }.toTypedArray()
            clipCards.forEachIndexed { newRow, c ->
                val old = idToRow[c.feature.id]
                if (old != null && old < snapshot.size) r.matrix[newRow] = snapshot[old]
            }
        }
        adapter?.notifyDataSetChanged()
        toast("已按剧本顺序重排，移动 $moved 张卡片")
    }

    /** 对齐体检：剧本覆盖率 + 缺素材的句子 + 时序倒流，照着补就能到 100% */
    private fun showCoverageReport() {
        if (clipCards.isEmpty()) { toast("请先完成智能对齐"); return }
        val report = alignResult?.let {
            com.lingxu.zhiying.core.CoverageChecker.check(clipCards, it.lines)
        } ?: return
        AlertDialog.Builder(this)
            .setTitle("📊 对齐体检报告")
            .setMessage(report.summary(scriptLines))
            .setNeutralButton("一键按剧本重排") { _, _ -> sortToScript() }
            .setPositiveButton("知道了") { d, _ -> d.dismiss() }
            .show()
    }

    /** ✂️ 帧级微调：入点/出点各加减 deltaMs */
    private fun adjustTrim(position: Int, deltaIn: Long, deltaOut: Long) {
        if (position !in clipCards.indices) return
        val c = clipCards[position]
        val dur = c.feature.durationMs
        if (deltaIn != 0L) {
            var v = (if (c.trimInMs < 0) 0L else c.trimInMs) + deltaIn
            v = v.coerceIn(0L, if (dur > 0) dur - 300 else Long.MAX_VALUE)
            c.trimInMs = if (v <= 0L) -1L else v
        }
        if (deltaOut != 0L) {
            var v = (if (c.trimOutMs < 0) (if (dur > 0) dur else 0L) else c.trimOutMs) + deltaOut
            val floor = (if (c.trimInMs > 0) c.trimInMs else 0L) + 300
            v = v.coerceAtLeast(floor)
            if (dur > 0) v = v.coerceAtMost(dur)
            c.trimOutMs = if (dur > 0 && v >= dur) -1L else v
        }
        adapter?.notifyItemChanged(position)
    }

    private var lastOutputPath: String = ""

    private fun startRender() {
        if (clipCards.isEmpty()) {
            toast("没有可渲染的片段"); return
        }
        if (isBusy) return
        isBusy = true
        progressBar?.visibility = View.VISIBLE
        tvStatus?.text = "🎬 正在拼接成片…"
        tvStatus?.setTextColor(Color.parseColor(Ui.CYAN))

        lifecycleScope.launch {
            try {
                val paths = withContext(Dispatchers.IO) {
                    clipCards.mapNotNull { c ->
                        val raw = c.feature.uri
                        val real = if (raw.startsWith("content://")) {
                            MediaResolver.resolve(this@MainActivity, Uri.parse(raw))?.path
                        } else raw
                        if (real == null) null
                        else ConcatEngine.TrimItem(real, c.trimInMs, c.trimOutMs)
                    }
                }
                if (paths.isEmpty()) {
                    tvStatus?.text = "❌ 素材路径全部失效，请重新导入"
                    tvStatus?.setTextColor(Color.parseColor(Ui.RED))
                    return@launch
                }
                val (uri, file) = orchestrator.renderAndExport(paths, ConcatEngine.Mode.AUTO)
                if (uri != null) {
                    lastOutputPath = file?.absolutePath ?: uri.toString()
                    tvStatus?.text = "✅ 已导出到相册：Movies/灵序织影/${com.lingxu.zhiying.core.GalleryExporter.defaultName()}"
                    tvStatus?.setTextColor(Color.parseColor(Ui.GREEN))
                    showExportDialog(uri.toString())
                } else {
                    tvStatus?.text = "❌ 拼接失败，请查看日志（ConcatEngine）"
                    tvStatus?.setTextColor(Color.parseColor(Ui.RED))
                }
            } catch (e: Throwable) {
                LogX.e("Main", "渲染异常", e)
                tvStatus?.text = "❌ 渲染失败：${e.message}"
                tvStatus?.setTextColor(Color.parseColor(Ui.RED))
            } finally {
                isBusy = false
                progressBar?.visibility = View.GONE
            }
        }
    }

    private fun showExportDialog(uriString: String) {
        AlertDialog.Builder(this)
            .setTitle("🎉 出片成功")
            .setMessage("成片已安全写入系统相册：\nMovies/灵序织影/\n\nMediaStore URI:\n$uriString")
            .setPositiveButton("知道了") { d, _ -> d.dismiss() }
            .show()
    }

    private fun copyLastOutput() {
        if (lastOutputPath.isBlank()) {
            toast("还没有导出过成片"); return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", lastOutputPath))
        toast("已复制：$lastOutputPath")
    }

    // ==================================================================
    //  授权验证界面
    // ==================================================================

    private fun showAuthScreen() {
        authLayout = Ui.vbox(this).apply {
            setBackgroundColor(Color.parseColor(Ui.BG_DEEP))
            gravity = Gravity.CENTER
            setPadding(Ui.dp(context, 28f), Ui.dp(context, 28f), Ui.dp(context, 28f), Ui.dp(context, 28f))
        }
        val panel = Ui.vbox(this).apply {
            background = Ui.cardBg(this@MainActivity, "#0E1420", Ui.PURPLE, 20f)
            setPadding(Ui.dp(context, 22f), Ui.dp(context, 22f), Ui.dp(context, 22f), Ui.dp(context, 22f))
        }
        panel.addView(Ui.text(this, "🔐 灵序织影 · 设备授权", 18f, Ui.TEXT_MAIN, bold = true))
        panel.addView(Ui.text(this, "本授权与设备绑定，一机一码，不可跨设备使用。", 12f, Ui.TEXT_SUB)
            .apply { setPadding(0, Ui.dp(context, 6f), 0, Ui.dp(context, 16f)) })

        val deviceCode = ActivationManager.deviceCode(this)
        panel.addView(Ui.text(this, "设备码", 11f, Ui.TEXT_SUB))
        val tvDeviceCode = Ui.text(this, deviceCode, 20f, Ui.CYAN, bold = true).apply {
            background = Ui.ghostBg(this@MainActivity)
            gravity = Gravity.CENTER
            setPadding(0, Ui.dp(context, 12f), 0, Ui.dp(context, 12f))
            setOnLongClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("device", deviceCode))
                toast("设备码已复制，请发送给授权方"); true
            }
        }
        panel.addView(tvDeviceCode, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 16f) })

        panel.addView(Ui.text(this, "激活码（32 位）", 11f, Ui.TEXT_SUB))
        val etCode = EditText(this).apply {
            background = Ui.ghostBg(this@MainActivity)
            setTextColor(Color.parseColor(Ui.TEXT_MAIN))
            setHintTextColor(Color.parseColor("#4C5A6E"))
            hint = "粘贴激活码"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setPadding(Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f), Ui.dp(context, 12f))
        }
        panel.addView(etCode, Ui.matchWrap().apply { Ui.margin(this, this@MainActivity, 0f, 4f, 0f, 16f) })

        val btnActivate = TextView(this).apply {
            text = "✅ 立即激活"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#031018"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            background = Ui.primaryBg(this@MainActivity)
            setPadding(0, Ui.dp(context, 14f), 0, Ui.dp(context, 14f))
            setOnClickListener {
                val input = etCode.text.toString()
                if (input.isBlank()) {
                    toast("请输入激活码"); return@setOnClickListener
                }
                if (ActivationManager.activate(this@MainActivity, input)) {
                    toast("激活成功，正在进入工作台")
                    setContentView(rootLayout)
                } else {
                    toast("激活码与本机设备码不匹配")
                }
            }
        }
        panel.addView(btnActivate, Ui.matchWrap())

        panel.addView(Ui.text(this, "提示：授权码由 HmacSHA256(设备码, 内置密钥) 生成，密钥在包内以 XOR 混淆存储。", 10f, "#5A6A80")
            .apply { setPadding(0, Ui.dp(context, 14f), 0, 0) })

        authLayout?.addView(panel, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(authLayout)
    }

    // ==================================================================
    //  权限
    // ==================================================================

    private fun requiredPermissions(): Array<String> {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.READ_MEDIA_VIDEO)
            list.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        return list.toTypedArray()
    }

    private fun requestPermissionsCompat() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    private fun ensureStoragePermissionThen(action: () -> Unit) {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
            return
        }
        pendingAction = action
        requestPermissions(missing.toTypedArray(), REQ_PERMISSIONS)
    }

    private var pendingAction: (() -> Unit)? = null

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMISSIONS) return
        val granted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (granted) {
            pendingAction?.invoke()
        } else {
            toast("未授予媒体读取权限，无法导入素材")
        }
        pendingAction = null
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { OcrEngine.release() }
        runCatching { orchestrator.cleanup() }
    }
}
