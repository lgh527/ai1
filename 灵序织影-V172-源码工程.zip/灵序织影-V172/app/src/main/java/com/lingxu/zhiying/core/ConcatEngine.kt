package com.lingxu.zhiying.core

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/**
 * 极速视频拼接引擎（FFmpeg Concat）
 *
 * 策略：
 *  1. 先探明所有片段的分辨率 / 编码是否一致；
 *  2. 一致 → `-f concat -c copy` 无损流拷贝，秒级出片，不消耗 CPU 重编码；
 *  3. 不一致或流拷贝失败 → 自动降级 `libx264 -crf 18` 快速重编码，保证必定出片。
 */
class ConcatEngine(private val context: Context) {

    private val workDir: File
        get() = File(context.cacheDir, "concat").apply { if (!exists()) mkdirs() }

    enum class Mode { COPY, REENCODE, AUTO }

    /**
     * @param paths 已按最终顺序排好的视频绝对路径
     * @return 成片文件，失败返回 null
     */
    fun concat(paths: List<String>, mode: Mode = Mode.AUTO, progress: (String) -> Unit = {}): File? {
        if (paths.isEmpty()) return null
        val valid = paths.filter { File(it).exists() && File(it).length() > 0 }
        if (valid.isEmpty()) {
            LogX.e("ConcatEngine", "没有任何可用素材")
            return null
        }

        val out = File(workDir, "lingxu_final_${System.currentTimeMillis()}.mp4")
        if (out.exists()) out.delete()
        val list = writeListFile(valid)

        val canCopy = mode == Mode.COPY || (mode == Mode.AUTO && isHomogeneous(valid))
        if (canCopy) {
            progress("检测到编码一致，启用无损极速拼接（-c copy）…")
            val cmd = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"${list.absolutePath}\" " +
                    "-c copy -movflags +faststart \"${out.absolutePath}\""
            val session = FFmpegKit.execute(cmd)
            if (ReturnCode.isSuccess(session.returnCode) && out.exists() && out.length() > 1024) {
                LogX.i("ConcatEngine", "无损拼接成功：${out.length() / 1024} KB")
                return out
            }
            LogX.w("ConcatEngine", "流拷贝失败，降级重编码：${session.output}")
            out.delete()
        }

        progress("素材编码不一致，降级为 libx264 -crf 18 重编码…")
        // 统一到 1080 宽、偶数高，避免分辨率冲突导致花屏（嵌套引号在 FFmpegKit 解析器里不稳，这里不用）
        val vf = "scale=1080:-2:force_original_aspect_ratio=decrease,fps=30,setsar=1"
        val cmd2 = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"${list.absolutePath}\" " +
                "-vf \"$vf\" -c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p " +
                "-c:a aac -b:a 192k -ar 44100 -ac 2 -movflags +faststart \"${out.absolutePath}\""
        val s2 = FFmpegKit.execute(cmd2)
        if (ReturnCode.isSuccess(s2.returnCode) && out.exists() && out.length() > 1024) {
            LogX.i("ConcatEngine", "重编码拼接成功：${out.length() / 1024 / 1024} MB")
            return out
        }

        // 最后兜底：逐个转成统一中间格式再拷贝
        progress("二次兜底：统一转码中间片段…")
        val intermediates = valid.mapIndexed { i, p -> transcodeOne(p, i) }.filterNotNull()
        if (intermediates.isEmpty()) {
            LogX.e("ConcatEngine", "拼接彻底失败：${s2.output}")
            return null
        }
        val list2 = writeListFile(intermediates.map { it.absolutePath })
        val cmd3 = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"${list2.absolutePath}\" " +
                "-c copy -movflags +faststart \"${out.absolutePath}\""
        val s3 = FFmpegKit.execute(cmd3)
        return if (ReturnCode.isSuccess(s3.returnCode) && out.exists()) out else null
    }

    private fun transcodeOne(src: String, index: Int): File? {
        val tmp = File(workDir, "seg_$index.mp4")
        if (tmp.exists()) tmp.delete()
        val cmd = "-hide_banner -loglevel error -y -i \"$src\" " +
                "-vf \"scale=1080:-2:force_original_aspect_ratio=decrease,fps=30,setsar=1\" " +
                "-c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p " +
                "-c:a aac -b:a 192k -ar 44100 -ac 2 \"${tmp.absolutePath}\""
        val session = FFmpegKit.execute(cmd)
        return if (ReturnCode.isSuccess(session.returnCode) && tmp.exists()) tmp else null
    }

    /** 判断素材是否「同质」：分辨率与视频编码全一致，才能安全 -c copy */
    private fun isHomogeneous(paths: List<String>): Boolean {
        var w = -1; var h = -1; var codec = ""
        for (p in paths) {
            val info = VideoProbe.probe(p)
            if (info.width <= 0) return false
            if (w == -1) { w = info.width; h = info.height; codec = info.vCodec }
            else if (w != info.width || h != info.height || codec != info.vCodec) return false
        }
        return true
    }

    private fun writeListFile(paths: List<String>): File {
        val f = File(workDir, "list_${System.currentTimeMillis()}.txt")
        f.bufferedWriter().use { bw ->
            paths.forEach { p ->
                // concat demuxer 要求单引号内的 ' 转义为 '\''
                val escaped = p.replace("'", "'\\''")
                bw.write("file '$escaped'")
                bw.newLine()
            }
        }
        return f
    }

    fun cleanAll() {
        workDir.deleteRecursively()
    }
}
