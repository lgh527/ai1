# 灵序织影 V172 终极融合版

端侧全离线 AI 多模态视频自动对齐与混剪系统（Android / Kotlin / 纯代码 UI）

---

## 一、这是什么

导入一堆**乱序**的视频切片，粘贴一段**纯文本剧本**，App 在**完全断网**的情况下：

1. 用 **ML Kit 中文 OCR** 把画面里的字幕读出来（先做字幕带检测 + 小字动态放大）
2. 用 **Sherpa-ONNX + SenseVoice** 把声音听写出来（先过一遍 FFmpeg 提纯滤镜链）
3. 用 **DP 二维得分矩阵**求全局最优单调路径，把每个视频钉到剧本的正确坐标上
4. 得分落在 0.2~0.65 模糊地带的，交给 **MediaPipe + Gemma-2B-IT** 做深水区仲裁
5. OCR / ASR 双双失效的空镜，用 **aHash 帧哈希 + 汉明距离**做视觉归位
6. 卡片式校对工作台支持 ⬆️⬇️ 手动微调，微调会触发**涟漪重排**（局部 ±3 个片段重跑微型 DP）
7. **FFmpeg** `-f concat -c copy` 无损拼接，编码冲突自动降级 `libx264 -crf 18`，MediaStore 写入相册

---

## 二、目录结构

```
├── .github/workflows/build.yml      一键云端打包脚本（GitHub Actions）
├── build.gradle.kts                 根构建脚本（AGP 8.2.2 / Kotlin 1.9.22）
├── settings.gradle.kts
├── gradle.properties                低内存单线程编译配置（-Xmx3g / max-workers=1）
└── app/
    ├── build.gradle.kts             release 已配签名（读取仓库根 release.jks）
    ├── proguard-rules.pro           R8 规则（含 JNI / MLKit / MediaPipe / ONNX 白名单）
    ├── libs/                        ← CI 会把 sherpa-onnx-1.13.5.aar 下载到这里
    └── src/main/
        ├── AndroidManifest.xml      READ_MEDIA_VIDEO + IS_PENDING 分区存储适配
        ├── res/values/themes.xml    自建 AppTheme（不依赖厂商 DeviceDefault 主题名）
        ├── assets/models/           ← CI 会把 SenseVoice / Gemma 模型下载到这里
        └── java/com/lingxu/zhiying/
            ├── MainActivity.kt              纯代码深色 UI + 四大操作流
            ├── model/Models.kt              数据模型
            ├── core/
            │   ├── ScriptParser.kt          剧本解析（剥离「男主:」「【旁白】」前缀）
            │   ├── FrameExtractor.kt        fps=2 抽帧 + 首尾帧
            │   ├── SubtitleBand.kt          字幕带检测 + 动态缩放增强
            │   ├── PerceptualHash.kt        aHash 64 位感知指纹 + 汉明距离
            │   ├── AudioPipeline.kt         FFmpeg 五级提纯滤镜链 + PCM + 滑窗
            │   ├── OcrEngine.kt             ML Kit 中文 OCR + 多帧去重
            │   ├── AsrEngine.kt             Sherpa-ONNX SenseVoice
            │   ├── LlmArbiter.kt            MediaPipe Gemma-2B-IT 仲裁
            │   ├── PinyinTable.kt           内置高频汉字拼音映射表
            │   ├── TextSimilarity.kt        Bigram + 拼音双通道相似度
            │   ├── DpAligner.kt             全局 DP 时序对齐（单向游标 + 跳跃惩罚）
            │   ├── HashAnchor.kt            静音/无字幕片段视觉归位
            │   ├── RippleAdjust.kt          涟漪重排算法
            │   ├── ConcatEngine.kt          FFmpeg 极速拼接 + 降级重编码
            │   ├── GalleryExporter.kt       MediaStore 安全写入相册
            │   ├── MediaResolver.kt         content:// → 真实路径
            │   └── AlignOrchestrator.kt     流水线总调度（Flow 进度）
            ├── security/
            │   ├── SignatureGuard.kt        SHA-256 动态签名校验 + 反调试 + 反 Hook
            │   └── ActivationManager.kt     XOR 混淆密钥 + HmacSHA256 一机一码
            └── ui/
                ├── Ui.kt                    代码构建控件的工具箱 + HashView 指纹可视化
                └── ClipCardAdapter.kt       卡片式校对工作台
```

---

## 三、怎么打包

### 方式 A：GitHub Actions 一键云端打包（推荐）

1. 新建仓库，把**这个 zip 直接上传**（`.github/workflows/build.yml` 里已含解压步骤），或解压后把内容 push 到 `main`
2. Actions → `灵序织影 - V172完美融合版打包` → Run workflow
3. 等构建结束，在 Artifacts 下载 `LingXu-App-Final-V172Core`

脚本会自动完成：生成临时签名证书 → `sed` 把真实 SHA-256 指纹注入源码 → 下载 Sherpa-ONNX AAR → 下载 SenseVoice 与 Gemma 模型到 `assets/models` → `assembleRelease` → 校验签名 → 上传 APK。

> 已针对 7GB 内存云主机做了防 OOM 处理：`--no-daemon --max-workers=1 -Dorg.gradle.jvmargs=-Xmx3g`，且 `gradle.properties` 里也写死了同样的低内存参数。

### 方式 B：Android Studio 本地打包

1. 用 Android Studio 打开工程根目录，等待 Gradle Sync
2. 手动下载 `sherpa-onnx-1.13.5.aar` 放进 `app/libs/`
   <https://github.com/k2-fsa/sherpa-onnx/releases/tag/v1.13.5>
3. 手动下载模型放进 `app/src/main/assets/models/`：
   - `model.int8.onnx` + `tokens.txt`（SenseVoice）
   - `gemma-2b-it-gpu-int4.bin`（Gemma-2B-IT，文件名以 `.bin` 结尾即可被自动识别）
4. 根目录生成签名（本地调试可跳过，代码会自动降级为开发构建）：
   ```bash
   keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 \
     -validity 10000 -alias release -storepass 123456 -keypass 123456 \
     -dname "CN=Android, OU=Android, O=Android, L=Android, ST=Android, C=US" -noprompt
   ```
   再把 `keytool -list -v` 输出的 SHA-256 指纹（去掉冒号、转大写）替换源码里的 `YOUR_APP_SIGNATURE_PLACEHOLDER`
5. `./gradlew assembleRelease`

> **模型不放进去也能编译、能安装、能跑**：OCR 与视觉通道正常工作，ASR / LLM 会安全降级为「不可用」并在状态栏提示，不会崩。

---

## 四、V69 → V172 已修掉的历史坑

| 坑 | 现在的处理 |
| --- | --- |
| AAPT `resource style/Theme.DeviceDefault... not found` | 自建 `res/values/themes.xml` → `AppTheme`，parent 用 `@android:style/Theme.Material.NoActionBar`，不碰厂商主题名 |
| `com.github.k2-fsa:sherpa-onnx` 是 JVM 聚合模块，不产出 Android so | 改用官方 Release 的 **sherpa-onnx-1.13.5.aar**，CI 自动下载到 `app/libs/` |
| release 未签名 → `INSTALL_PARSE_FAILED_NO_CERTIFICATES` | `app/build.gradle.kts` 配了 `signingConfigs.release`，指向仓库根 `release.jks`；CI 额外加了一步 `apksigner verify` 兜底 |
| R8 `Missing class detected` | `proguard-rules.pro` 加 `-ignorewarnings` + 成套 `-dontwarn`，并**删掉** `-repackageclasses` / `-optimizationpasses` / `-allowaccessmodification`（JNI 靠类名反查，重打包必崩） |
| `2 files found with path 'META-INF/...'` | `packaging.resources.excludes` 已排除 ffmpeg-kit 与 onnxruntime 的重名 META-INF |
| AGP 8 弃用 API | `aaptOptions` → `androidResources.noCompress`，`packagingOptions` → `packaging` |
| 缺 `RECORD_AUDIO` | Manifest 已补全（含 Android 13+ 的 `READ_MEDIA_VIDEO` / `READ_MEDIA_VISUAL_USER_SELECTED`） |
| `lateinit` 未初始化导致二次崩溃 | 全部视图字段改为可空引用 `var xxx: View? = null` |
| 模型文件被 aapt 压缩导致读取失败 | `noCompress += ["onnx","bin","tflite","task","txt"]` |

---

## 五、关键参数速查（都在源码里可调）

| 参数 | 位置 | 默认值 |
| --- | --- | --- |
| 抽帧频率 | `FrameExtractor.extract(fps=)` | 2 fps |
| 字幕带行切片步长 | `SubtitleBand.ROW_STEP` | 10 px |
| 字幕带亮度阈值 | `SubtitleBand.LUMA_THRESHOLD` | 150 |
| 触发放大增强的字幕高度 | `SubtitleBand.MIN_BAND_HEIGHT` | 80 px |
| 音频提纯滤镜链 | `AudioPipeline.PURE_FILTER_CHAIN` | highpass 180 / lowpass 3600 / afftdn -25 / acompressor / loudnorm |
| ASR 滑窗 | `AudioPipeline.WINDOW_SECONDS` | 25 s（重叠 1 s） |
| Bigram : 拼音 权重 | `TextSimilarity.combined` | 0.55 : 0.45 |
| 跳跃惩罚 | `DpAligner.JUMP_PENALTY` | 0.06 / 句 |
| 同句重复惩罚 | `DpAligner.REPEAT_PENALTY` | 0.10 |
| 未命中丢弃阈值 | `DpAligner.DROP_THRESHOLD` | 0.12 |
| 大模型仲裁区间 | `LlmArbiter.LOW_BOUND / HIGH_BOUND` | 0.20 ~ 0.65 |
| 帧哈希归位阈值 | `HashAnchor.THRESHOLD` | 0.85 |
| 涟漪重排半径 | `RippleAdjust.RADIUS` | 上下各 3 个片段 |
| 降级重编码质量 | `ConcatEngine` | libx264 -preset ultrafast -crf 18 |

---

## 六、安全机制说明

- **动态签名校验**：启动时读取当前 APK 的 SHA-256 签名与硬编码值比对，不匹配 → `finishAffinity()` + `killProcess()` + `exitProcess(0)`
- **反调试**：`Debug.isDebuggerConnected()` 与 `/proc/self/status` 的 `TracerPid` 双重探测
- **反 Hook**：扫描 Xposed / Frida 特征文件与类名
- **一机一码**：设备码 = SHA256(ANDROID_ID + 硬件指纹) 前 12 位；激活码 = HmacSHA256(设备码, 内置密钥) 前 32 位十六进制。密钥在包内以 `intArrayOf` + XOR 掩码混淆存储，还原后立即 `fill(0)` 擦除内存

> 开发期构建（占位符未被 sed 替换）不会闪退，只在日志里标注「开发构建」，方便本地调试。
