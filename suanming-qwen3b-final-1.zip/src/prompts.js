function slimBazi(b) {
  return {
    year: b.yearGan + b.yearZhi, month: b.monthGan + b.monthZhi,
    day: b.dayGan + b.dayZhi, hour: b.hourGan + b.hourZhi,
    dayMaster: b.dayMaster, strength: b.dayMasterStrength,
    favorable: b.favorableElements, tenGods: b.tenGods,
    daYun: b.daYun?.slice(0, 3), liuNian: b.liuNian?.slice(0, 2),
  };
}

export function buildFortunePrompts(results, user) {
  const bazi = slimBazi(results.bazi || {});
  const baseRule = '你是资深命理师。只根据下面提供的排盘数据做白话解读。不要自行推算、修正或补充任何干支、星曜、卦象。如果数据中没有的信息，就说"盘面未提供"。用通俗口语的中文，分段说人话，不要输出 JSON。';
  return [
    { label: '性格底色', prompt: baseRule + '\n\n【八字】' + JSON.stringify(bazi) + '\n\n请用 300 字左右，说明这个人的性格底色、优势、容易踩的坑。基于日主强弱和十神，不要泛泛而谈。' },
    { label: '当前大运', prompt: baseRule + '\n\n【八字】' + JSON.stringify(bazi) + '\n\n请用 250 字左右，说明当前大运的十年基调：是顺风期还是冬蛰期，适合主动出击还是向内积累。基于大运干支与原局的交互，不要编造数据。' },
    { label: '今年流年', prompt: baseRule + '\n\n【八字】' + JSON.stringify(bazi) + '\n\n请用 200 字左右，说明今年的年度重点：哪些方面容易有变动，哪些方面适合稳步推进。最后给一条具体、可操作的生活建议。' },
  ];
}

export function fallbackBaihua(results) {
  const L = [];
  const b = results.bazi || {};
  const strengthMap = { strong: '日主偏强，做事有主见，但也容易固执。', weak: '日主偏弱，心思细，适合借力打力。' };
  if (b.dayMasterStrength && strengthMap[b.dayMasterStrength]) L.push(strengthMap[b.dayMasterStrength]);
  const yong = b.favorableElements?.[0];
  if (yong) L.push('喜用五行：' + yong + '。日常可多接触与' + yong + '相关的环境或颜色。');
  if (b.daYun?.[0]) L.push('当前大运：' + (b.daYun[0].ganZhi || '') + '，建议稳扎稳打。');
  if (!L.length) L.push('排盘已完成，但规则解读未提取到足够字段。');
  return L.join('\n');
}
