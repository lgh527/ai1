import { getCurrentEightCharJSON } from 'mystilight-8char';
import { astro } from 'iztro';
import { dayan, decodePan } from 'iching-shifa';
import { initLlama } from 'llama-cpp-capacitor';
import { Clipboard } from '@capacitor/clipboard';
import { buildFortunePrompts, fallbackBaihua } from './prompts.js';

const TABS = ['八字', '紫微', '六爻', 'AI 解读'];
let llamaContext = null;
let lastResults = null;
let lastUser = null;
let currentTab = 0;

async function getModel() {
  if (llamaContext) return llamaContext;
  llamaContext = await initLlama({ model: 'libmodel-qwen25-3b-q4km.so', n_ctx: 4096, n_threads: 4 });
  return llamaContext;
}

async function copyText(text) {
  try { await Clipboard.write({ string: text }); return true; }
  catch (e) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (e2) { return false; }
  }
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 1800);
}

document.getElementById('calculate').addEventListener('click', async () => {
  const name = document.getElementById('name').value.trim();
  const gender = document.getElementById('gender').value;
  const dateStr = document.getElementById('birthDate').value;
  const hourIndex = Number(document.getElementById('birthHour').value);
  if (!dateStr) { alert('请选择出生日期'); return; }
  const [year, month, day] = dateStr.split('-').map(Number);
  const hour = hourIndex === 0 ? 23 : hourIndex * 2 - 1;
  const output = document.getElementById('output');
  const resultEl = document.getElementById('result');
  const tabsEl = document.getElementById('tabs');
  output.hidden = false; tabsEl.innerHTML = '';
  TABS.forEach((label, i) => {
    const btn = document.createElement('button');
    btn.textContent = label;
    btn.addEventListener('click', () => render(i));
    tabsEl.appendChild(btn);
  });
  const results = {};
  const user = { name, gender, year, month, day, hour };
  try { results.bazi = getCurrentEightCharJSON({ year, month, day, hour, gender: gender === 'male' ? 1 : 0 }); }
  catch (e) { results.bazi = { error: e.message }; }
  try {
    const astrolabe = astro.bySolar(year + '-' + month + '-' + day, hourIndex, gender === 'male' ? '男' : '女', true, 'zh-CN');
    results.ziwei = astrolabe.palaces();
  } catch (e) { results.ziwei = { error: e.message }; }
  try {
    const yaoString = dayan();
    results.liuyao = decodePan(yaoString, { year, month, day, hour });
  } catch (e) { results.liuyao = { error: e.message }; }
  try {
    resultEl.textContent = '正在加载本地模型…首次加载可能需要 10-20 秒。';
    const ctx = await getModel();
    const prompts = buildFortunePrompts(results, user);
    const sections = [];
    for (const p of prompts) {
      resultEl.textContent = '正在生成：' + p.label + '…';
      const reply = await ctx.completion({ prompt: p.prompt, temperature: 0.7, n_predict: 400 });
      sections.push('【' + p.label + '】\n' + reply.text.trim());
    }
    results.ai = sections.join('\n\n');
  } catch (e) {
    results.ai = 'AI 解读暂不可用，已降级为规则模板。\n\n' + fallbackBaihua(results) + '\n\n错误：' + e.message;
  }
  lastResults = results; lastUser = user; currentTab = 3; render(currentTab);
});

function render(i) {
  currentTab = i;
  const tabsEl = document.getElementById('tabs');
  const resultEl = document.getElementById('result');
  tabsEl.querySelectorAll('button').forEach((b, idx) => b.classList.toggle('active', idx === i));
  const keys = ['bazi', 'ziwei', 'liuyao', 'ai'];
  const val = lastResults[keys[i]];
  if (typeof val === 'string') resultEl.textContent = val;
  else { try { resultEl.textContent = JSON.stringify(val, null, 2); } catch (e) { resultEl.textContent = '数据展示失败：' + e.message; } }
}

document.getElementById('copyCurrent').addEventListener('click', async (e) => {
  if (!lastResults) { showToast('还没有结果可复制'); return; }
  const keys = ['bazi', 'ziwei', 'liuyao', 'ai'];
  const val = lastResults[keys[currentTab]];
  const text = typeof val === 'string' ? val : JSON.stringify(val, null, 2);
  const ok = await copyText('【' + TABS[currentTab] + '】\n' + text);
  flashButton(e.target, ok ? '已复制' : '复制失败');
  showToast(ok ? '已复制本页' : '复制失败，请手动选择');
});

document.getElementById('copyAll').addEventListener('click', async (e) => {
  if (!lastResults) { showToast('还没有结果可复制'); return; }
  const ok = await copyText(buildFullReport());
  flashButton(e.target, ok ? '已复制' : '复制失败');
  showToast(ok ? '已复制完整报告' : '复制失败，请手动选择');
});

function buildFullReport() {
  const u = lastUser;
  const head = ['====== 命理推算报告 ======', '姓名：' + (u.name || '未提供'), '性别：' + (u.gender === 'male' ? '男' : '女'), '出生（公历）：' + u.year + '年' + u.month + '月' + u.day + '日 ' + u.hour + '时', '生成时间：' + new Date().toLocaleString('zh-CN'), ''].join('\n');
  const keys = ['bazi', 'ziwei', 'liuyao', 'ai'];
  const body = keys.map((k, i) => {
    const val = lastResults[k];
    const text = typeof val === 'string' ? val : JSON.stringify(val, null, 2);
    return '【' + TABS[i] + '】\n' + text;
  }).join('\n\n');
  const foot = '\n\n—— 本报告由本地离线模型生成，仅供传统文化研究与娱乐参考 ——';
  return head + body + foot;
}

function flashButton(btn, text) {
  const original = btn.textContent;
  btn.textContent = text; btn.classList.add('copied');
  setTimeout(() => { btn.textContent = original; btn.classList.remove('copied'); }, 1500);
}
