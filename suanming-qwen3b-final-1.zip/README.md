# 命理推算 · Qwen2.5 3B 离线完整版

## 功能
- 本地排盘：八字、紫微、六爻，纯 JS 离线
- 本地 AI：Qwen2.5 3B（约 2.1 GB）在 GitHub Actions 构建时自动下载并打入 APK，安装后无需首次下载
- 结果一键复制：当前页 / 完整报告
- 黑金太极 LOGO + 白底黑字界面

## 使用流程
1. 解压本 ZIP。
2. 把全部文件（含隐藏的 .github 文件夹）推送到 GitHub 仓库 main 分支。
3. Actions → Build Qwen3B Offline APK → Run workflow。
4. 等待构建完成（约 15–25 分钟）。
5. Artifacts 下载 suanming-qwen3b-apk，安装到手机即可离线使用。

## 设备要求
- arm64-v8a 架构
- 运行内存 6 GB 以上
- 安装时约 2 GB 额外可用存储

## 边界说明
排盘数据由开源库本地计算，AI 解读由本地 Qwen2.5 3B 模型生成。
结果仅供传统文化研究与娱乐参考，不构成任何决策依据。
