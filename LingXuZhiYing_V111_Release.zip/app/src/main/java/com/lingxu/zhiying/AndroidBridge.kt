package com.lingxu.zhiying

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.abs
import kotlin.math.sqrt

data class Sentence(val text: String, val firstChar: Char, val lastChar: Char, val length: Int)

data class ClipMatch(
    val id: Int, val clipName: String,
    val heardText: String, val heardClean: String,
    var scriptText: String, var coord: Int, var score: Float,
    var locked: Boolean = false,
    val rawOcr: String = "", val rawAsr: String = "",
    val ocrSentences: List<Sentence> = emptyList(),
    val asrSentences: List<Sentence> = emptyList(),
    val sourceTag: String = "",
    var forceConfirmed: Boolean = false
) { fun isConfirmed(): Boolean = locked || forceConfirmed || score >= AndroidBridge.GREEN_THRESHOLD }

data class CalibrateResult(val improvedCount: Int, val stillRed: Int, val stillGreen: Int)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        private const val TAG = "LingXu"
        const val GREEN_THRESHOLD = 0.50f
        const val YELLOW_THRESHOLD = 0.25f
        const val L1_OCR_DIRECT = 0.60f
        const val L1_OCR_WEAK = 0.40f
        const val L2_ASR_DIRECT = 0.50f
        const val L3_FUZZY_LOW = 0.25f
        const val L3_FUZZY_HIGH = 0.60f
        const val L4_ALIGN_TRIGGER = 0.60f
        const val ANCHOR_THRESHOLD = 0.45f
        const val MIN_ANCHOR_LEN = 4
        const val CALIB_MIN_NEW_SCORE = 0.35f
        const val CALIB_MIN_GAIN = 0.15f
        const val BOTTOM_ROI_RATIO = 0.25f
        const val LEN_TOLERANCE = 0.30f
        const val ALIGN_FRAME_RATE = 50
        const val ALIGN_VOCAB = 10288
        const val ALIGN_FRAMES = 500
        const val BLANK_IDX = 1
        const val BGE_MAX_LEN = 64
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()

    private var scriptClean = ""
    private var scriptSentences: List<Sentence> = emptyList()
    private var scriptSentencePositions: List<Int> = emptyList()

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()
    private val _asrReadyFlow = MutableStateFlow(false)
    val asrReadyFlow = _asrReadyFlow.asStateFlow()
    private val _embedReadyFlow = MutableStateFlow(false)
    val embedReadyFlow = _embedReadyFlow.asStateFlow()
    private val _alignReadyFlow = MutableStateFlow(false)
    val alignReadyFlow = _alignReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null
    private val textRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private var ortEnv: OrtEnvironment? = null
    private var bgeSession: OrtSession? = null
    private val bgeVocab = HashMap<String, Int>()
    private var bgeClsId = 101
    private var bgeSepId = 102
    private var bgePadId = 0
    private var bgeUnkId = 100
    private var alignInterpreter: Interpreter? = null
    private val spPieces = HashMap<String, Int>()
    private var spUnkId = 0

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                withContext(Dispatchers.Default) { initEmbed(); initASR(); initAlign() }
                _modelsReadyFlow.value = true
            } catch (e: Throwable) { Log.e(TAG, "init fail", e); _modelsReadyFlow.value = false }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_") || it.name.startsWith("ocr_")) it.delete() }
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (_: Exception) { }
        }
    }

    fun resetMatches() { allMatches.clear(); scriptClean = ""; scriptSentences = emptyList(); scriptSentencePositions = emptyList() }

    fun confirmedCount(): Int = allMatches.count { it.isConfirmed() }
    fun isAllConfirmed(): Boolean = allMatches.isNotEmpty() && allMatches.all { it.isConfirmed() }

    fun isOrderConsistent(): Boolean {
        if (allMatches.size < 2) return true
        for (i in 1 until allMatches.size) if (allMatches[i].coord < allMatches[i - 1].coord) return false
        return true
    }

    fun forceConfirmAt(index: Int) {
        if (index !in allMatches.indices) return
        val m = allMatches[index]
        var lowerBound = if (index > 0) allMatches[index - 1].coord + allMatches[index - 1].scriptText.length else 0
        val upperBound = if (index < allMatches.size - 1) allMatches[index + 1].coord else scriptClean.length
        if (upperBound <= lowerBound) lowerBound = if (index > 0) allMatches[index - 1].coord + 1 else 0
        val newCoord = lowerBound.coerceIn(0, scriptClean.length)
        val newWindow = if (m.scriptText.isNotBlank()) m.scriptText
                        else if (newCoord < scriptClean.length) scriptClean.substring(newCoord, minOf(newCoord + 50, scriptClean.length)) else ""
        allMatches[index] = m.copy(forceConfirmed = true, locked = true, coord = newCoord, scriptText = newWindow, score = maxOf(m.score, 0.60f), sourceTag = "用户强制确认")
    }

    fun forceConfirmAllRemaining(): Int {
        var count = 0
        for (i in allMatches.indices) if (!allMatches[i].isConfirmed()) { forceConfirmAt(i); count++ }
        return count
    }

    fun fixOrderByCoord(): Int {
        if (allMatches.isEmpty()) return 0
        var changes = 0
        val sorted = allMatches.sortedWith(compareBy({ it.coord }, { it.id }))
        for (i in allMatches.indices) if (allMatches[i] !== sorted[i]) changes++
        allMatches.clear(); allMatches.addAll(sorted)
        var cursor = 0
        for (i in allMatches.indices) {
            val m = allMatches[i]
            if (m.locked || m.forceConfirmed) cursor = maxOf(cursor, m.coord + m.scriptText.length)
            else {
                val newCoord = maxOf(cursor, m.coord)
                if (newCoord != m.coord) { allMatches[i] = m.copy(coord = newCoord); changes++ }
                cursor = newCoord + m.scriptText.length
            }
        }
        return changes
    }

    private fun copyAssetsToFiles() {
        val required = listOf("sherpa-onnx-paraformer-zh-small/model.int8.onnx","sherpa-onnx-paraformer-zh-small/tokens.txt","omnilingual-ctc-300m.tflite","tokenizer.model","bge-small-zh-v1.5.onnx","tokenizer.json")
        for (f in required) {
            val o = File(modelDir, File(f).name)
            if (!o.exists()) try { context.assets.open("models/$f").use { i -> FileOutputStream(o).use { out -> i.copyTo(out) } } } catch (_: Throwable) { Log.w(TAG, "asset missing: $f") }
        }
    }

    private fun initASR() {
        try {
            val mf = File(modelDir, "model.int8.onnx"); val tf = File(modelDir, "tokens.txt")
            if (!mf.exists() || !tf.exists() || mf.length() < 1000) { _asrReadyFlow.value = false; return }
            asrRecognizer = OfflineRecognizer(config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    paraformer = OfflineParaformerModelConfig(model = mf.absolutePath),
                    tokens = tf.absolutePath, numThreads = 4, debug = false
                )
            ))
            _asrReadyFlow.value = true
        } catch (e: Throwable) { asrRecognizer = null; _asrReadyFlow.value = false }
    }

    private fun recognizeAudio(w: File): String {
        val r = asrRecognizer ?: return ""
        return try {
            val b = w.readBytes(); if (b.size <= 44) return ""
            val sb = ByteBuffer.wrap(b, 44, b.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val a = FloatArray(sb.remaining()) { sb.get() / 32768.0f }
            val s = r.createStream(); s.acceptWaveform(a, 16000); r.decode(s); val res = r.getResult(s); s.release(); res.text
        } catch (_: Throwable) { "" }
    }

    private fun initEmbed() {
        try {
            val mf = File(modelDir, "bge-small-zh-v1.5.onnx"); val tf = File(modelDir, "tokenizer.json")
            if (!mf.exists() || mf.length() < 1000 || !tf.exists()) { _embedReadyFlow.value = false; return }
            parseBgeTokenizer(tf)
            ortEnv = OrtEnvironment.getEnvironment()
            bgeSession = ortEnv!!.createSession(mf.absolutePath, OrtSession.SessionOptions().apply { setIntraOpNumThreads(4); setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT) })
            _embedReadyFlow.value = true
        } catch (e: Throwable) { bgeSession = null; _embedReadyFlow.value = false }
    }

    private fun parseBgeTokenizer(file: File) {
        val root = JsonParser.parseString(file.readText()).asJsonObject
        val vocab = root.getAsJsonObject("model").getAsJsonObject("vocab")
        for ((token, idEl) in vocab.entrySet()) bgeVocab[token] = idEl.asInt
        val added = root.getAsJsonArray("added_tokens")
        if (added != null) for (el in added) {
            val obj = el.asJsonObject
            val content = obj.get("content")?.asString ?: continue
            val id = obj.get("id")?.asInt ?: continue
            when (content) { "[CLS]" -> bgeClsId = id; "[SEP]" -> bgeSepId = id; "[PAD]" -> bgePadId = id; "[UNK]" -> bgeUnkId = id }
            bgeVocab[content] = id
        }
    }

    private fun bgeEncode(text: String): Pair<LongArray, LongArray> {
        val cleaned = text.replace(Regex("[^\\u4e00-\\u9fa5a-zA-Z0-9]"), "").lowercase()
        val tokens = mutableListOf<String>(); var i = 0
        while (i < cleaned.length) {
            val c = cleaned[i]
            if (c.code in 0x4E00..0x9FFF) { tokens.add(c.toString()); i++ }
            else {
                val start = i; while (i < cleaned.length && cleaned[i].code !in 0x4E00..0x9FFF && !cleaned[i].isWhitespace()) i++
                val word = cleaned.substring(start, i).lowercase()
                if (word.isNotEmpty()) {
                    var s = 0
                    while (s < word.length) {
                        var end = word.length; var found: String? = null
                        while (end > s) { val sub = if (s == 0) word.substring(s, end) else "##" + word.substring(s, end); if (bgeVocab.containsKey(sub)) { found = sub; break }; end-- }
                        if (found != null) { tokens.add(found); s = end } else { tokens.add("[UNK]"); s++ }
                    }
                }
            }
        }
        val ids = ArrayList<Long>(BGE_MAX_LEN); ids.add(bgeClsId.toLong())
        for (t in tokens) { if (ids.size >= BGE_MAX_LEN - 1) break; ids.add((bgeVocab[t] ?: bgeUnkId).toLong()) }
        ids.add(bgeSepId.toLong())
        val mask = LongArray(BGE_MAX_LEN) { if (it < ids.size) 1L else 0L }
        while (ids.size < BGE_MAX_LEN) ids.add(bgePadId.toLong())
        return ids.toLongArray() to mask
    }

    private fun embed(text: String): FloatArray? {
        val session = bgeSession ?: return null; val env = ortEnv ?: return null
        return try {
            val (ids, mask) = bgeEncode(text)
            val shape = longArrayOf(1, BGE_MAX_LEN.toLong())
            val inputIds = OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(ids), shape)
            val attnMask = OnnxTensor.createTensor(env, java.nio.LongBuffer.wrap(mask), shape)
            session.run(mapOf("input_ids" to inputIds, "attention_mask" to attnMask)).use { result ->
                val out = result.get(0).value
                val arr = when (out) { is Array<*> -> (out as Array<Array<FloatArray>>)[0][0]; is FloatArray -> out; else -> return null }
                var norm = 0f; for (x in arr) norm += x * x; norm = sqrt(norm)
                if (norm > 0) for (j in arr.indices) arr[j] /= norm
                arr
            }.also { inputIds.close(); attnMask.close() }
        } catch (_: Throwable) { null }
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float { var d = 0f; for (i in a.indices) d += a[i] * b[i]; return d.coerceIn(0f, 1f) }

    private fun initAlign() {
        try {
            val mf = File(modelDir, "omnilingual-ctc-300m.tflite"); val sf = File(modelDir, "tokenizer.model")
            if (!mf.exists() || mf.length() < 10_000_000 || !sf.exists()) { _alignReadyFlow.value = false; return }
            parseSentencePiece(sf)
            alignInterpreter = Interpreter(loadModelFile(mf), Interpreter.Options().apply { setNumThreads(4) })
            _alignReadyFlow.value = true
        } catch (e: Throwable) { alignInterpreter = null; _alignReadyFlow.value = false }
    }

    private fun parseSentencePiece(file: File) {
        val bytes = file.readBytes(); var idx = 0
        fun readVarint(): Long { var r = 0L; var s = 0; while (true) { val b = bytes[idx++].toInt() and 0xFF; r = r or ((b and 0x7F).toLong() shl s); if (b and 0x80 == 0) break; s += 7 }; return r }
        fun skip(w: Int) { when (w) { 0 -> readVarint(); 1 -> idx += 8; 2 -> { val l = readVarint().toInt(); idx += l }; 5 -> idx += 4 } }
        while (idx < bytes.size) {
            val tag = readVarint().toInt(); val fn = tag ushr 3; val wt = tag and 0x7
            if (fn == 1 && wt == 2) {
                val len = readVarint().toInt(); val end = idx + len
                var piece: String? = null
                while (idx < end) {
                    val t = readVarint().toInt(); val f = t ushr 3; val w = t and 0x7
                    when (f) { 1 -> { val sl = readVarint().toInt(); piece = String(bytes, idx, sl, Charsets.UTF_8); idx += sl }; 2 -> idx += 4; 3 -> readVarint(); else -> skip(w) }
                }
                if (piece != null) { val id = spPieces.size; spPieces[piece] = id; if (piece == "<unk>") spUnkId = id }
                idx = end
            } else skip(wt)
        }
    }

    private fun spEncode(text: String): IntArray {
        val clean = cleanFilter(text); val ids = mutableListOf<Int>(); var i = 0
        while (i < clean.length) {
            val c = clean[i]
            if (c.code in 0x4E00..0x9FFF) { ids.add(spPieces[c.toString()] ?: spUnkId); i++ }
            else {
                val start = i; while (i < clean.length && clean[i].code !in 0x4E00..0x9FFF) i++
                val word = clean.substring(start, i).lowercase(); var s = 0
                while (s < word.length) {
                    var end = word.length; var found: String? = null
                    while (end > s) { val sub = (if (s == 0) "▁" else "") + word.substring(s, end); if (spPieces.containsKey(sub)) { found = sub; break }; end-- }
                    if (found != null) { ids.add(spPieces[found]!!); s = end } else { ids.add(spUnkId); s++ }
                }
            }
        }
        return ids.toIntArray()
    }

    private fun loadModelFile(f: File): MappedByteBuffer = FileInputStream(f).channel.map(FileChannel.MapMode.READ_ONLY, 0, f.length())

    private fun ctcForcedAlign(logits: Array<FloatArray>, targetIds: IntArray): List<IntRange>? {
        val T = logits.size; val L = targetIds.size; if (L == 0 || T == 0) return null
        val S = 2 * L + 1; val NEG = -1e30f
        val dp = Array(T) { FloatArray(S) { NEG } }; val back = Array(T) { IntArray(S) { -1 } }
        dp[0][0] = logits[0][BLANK_IDX]; if (L > 0) dp[0][1] = logits[0][targetIds[0]]
        for (t in 1 until T) for (s in 0 until S) {
            val tokenIdx = if (s % 2 == 0) BLANK_IDX else targetIds[s / 2]; val score = logits[t][tokenIdx]
            var bestPrev = dp[t - 1][s]; var bestS = s
            if (s - 1 >= 0 && dp[t - 1][s - 1] > bestPrev) { bestPrev = dp[t - 1][s - 1]; bestS = s - 1 }
            if (s - 2 >= 0) { val cur = if (s % 2 == 1) targetIds[s / 2] else -1; val prev = if ((s - 2) % 2 == 1) targetIds[(s - 2) / 2] else -2; if (cur != prev && dp[t - 1][s - 2] > bestPrev) { bestPrev = dp[t - 1][s - 2]; bestS = s - 2 } }
            dp[t][s] = bestPrev + score; back[t][s] = bestS
        }
        var endState = S - 1; if (S - 2 >= 0 && dp[T - 1][S - 2] > dp[T - 1][endState]) endState = S - 2
        if (dp[T - 1][endState] <= NEG / 2) return null
        val path = IntArray(T); var curS = endState
        for (t in T - 1 downTo 0) { path[t] = curS; curS = back[t][curS]; if (curS < 0) curS = 0 }
        val result = mutableListOf<IntRange>(); var tokenIdx = 0; var start = -1
        for (t in 0 until T) {
            val s = path[t]
            if (s % 2 == 1) { val tt = s / 2; if (tt == tokenIdx) { if (start == -1) start = t } else if (tt > tokenIdx) { while (tokenIdx < tt) { result.add(if (start == -1) t..t else start..(t - 1)); tokenIdx++; start = t } } }
            else if (start != -1 && tokenIdx < L) { result.add(start..t); tokenIdx++; start = -1 }
        }
        while (result.size < L) result.add(T - 1..T - 1)
        return result.take(L)
    }

    private fun alignAndVerify(audio: FloatArray, candidateText: String): Pair<Float, Float>? {
        if (audio.size < 8000) return null
        val window = FloatArray(160_000); System.arraycopy(audio, 0, window, 0, minOf(audio.size, 160_000))
        val logits = runAlignForward(window) ?: return null
        val ids = spEncode(candidateText); if (ids.isEmpty()) return null
        val ranges = ctcForcedAlign(logits, ids) ?: return null
        val covered = ranges.count { it.last > it.first }; val coverage = covered.toFloat() / ids.size
        val firstStartSec = ranges.firstOrNull()?.first?.let { it / ALIGN_FRAME_RATE.toFloat() } ?: 0f
        return coverage to firstStartSec
    }

    private fun runAlignForward(audio10s: FloatArray): Array<FloatArray>? {
        val interp = alignInterpreter ?: return null
        return try { val i = Array(1) { audio10s }; val o = Array(1) { Array(ALIGN_FRAMES) { FloatArray(ALIGN_VOCAB) } }; interp.run(i, o); o[0] } catch (_: Throwable) { null }
    }

    private fun cleanFilter(t: String): String = t.replace(Regex("[^\\u4e00-\\u9fa5a-zA-Z]"), "")

    private fun lcs(a: String, b: String): Int {
        val m = a.length; val n = b.length; if (m == 0 || n == 0) return 0
        if (abs(m - n) > maxOf(m, n) / 2) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) { val c = i % 2; val p = (i - 1) % 2; for (j in 1..n) dp[c][j] = if (a[i - 1] == b[j - 1]) dp[p][j - 1] + 1 else maxOf(dp[p][j], dp[c][j - 1]) }
        return dp[m % 2][n]
    }

    private fun splitScript(script: String): Pair<List<Sentence>, List<Int>> {
        val res = mutableListOf<Sentence>(); val pos = mutableListOf<Int>(); var cp = 0
        for (part in script.split(Regex("[。！？!?；;\\n\\r]+"))) {
            val c = cleanFilter(part); if (c.length < 2) { cp += c.length; continue }
            res.add(Sentence(c, c[0], c.last(), c.length)); pos.add(cp); cp += c.length
        }
        if (res.isEmpty() && scriptClean.isNotEmpty()) { res.add(Sentence(scriptClean, scriptClean[0], scriptClean.last(), scriptClean.length)); pos.add(0) }
        return res to pos
    }

    private fun splitAsr(asr: String): List<Sentence> {
        val c = cleanFilter(asr); if (c.length < 2) return emptyList()
        val out = mutableListOf<Sentence>(); val chunk = 15; var i = 0
        while (i < c.length) { val e = minOf(i + chunk, c.length); val ch = c.substring(i, e); if (ch.length >= 2) out.add(Sentence(ch, ch[0], ch.last(), ch.length)); i = e }
        return out
    }

    private fun coarseFilter(s: Sentence, hint: Int): List<Int> {
        if (scriptSentences.isEmpty()) return emptyList()
        val minL = (s.length * (1 - LEN_TOLERANCE)).toInt().coerceAtLeast(2); val maxL = (s.length * (1 + LEN_TOLERANCE)).toInt() + 1
        val cands = mutableListOf<Int>()
        for (i in scriptSentences.indices) {
            val ss = scriptSentences[i]
            if (ss.firstChar != s.firstChar || ss.lastChar != s.lastChar) continue
            if (ss.length < minL || ss.length > maxL) continue
            cands.add(i)
        }
        return cands.sortedBy { abs(scriptSentencePositions[it] - hint) }.take(8)
    }

    private data class SingleResult(val pos: Int, val score: Float, val window: String, val matchedLen: Int, val sentence: Sentence)

    private fun lcsSearchOne(text: String, hint: Int, expected: Int, isCalib: Boolean = false): SingleResult? {
        if (text.length < 2) return null
        val probe = Sentence(text, text[0], text.last(), text.length)
        val cands = coarseFilter(probe, hint)
        val windows: List<IntRange> = if (cands.isNotEmpty()) cands.map { ci -> val st = scriptSentencePositions[ci]; st..minOf(scriptClean.length, st + scriptSentences[ci].length + 20) } else listOf(hint..minOf(scriptClean.length, hint + expected * 3))
        var best: SingleResult? = null; val step = if (isCalib) 1 else 2
        for (range in windows) {
            val ws = minOf(text.length + 20, scriptClean.length - range.first); if (ws <= 0) continue
            var pos = range.first
            while (pos <= minOf(range.last - ws, scriptClean.length - ws)) {
                val w = scriptClean.substring(pos, pos + ws); val l = lcs(text, w); val s = l.toFloat() / text.length
                if (best == null || s > best!!.score) best = SingleResult(pos, s, w, l, probe)
                pos += step
            }
        }
        return best
    }

    private fun semanticRescore(text: String, hint: Int): SingleResult? {
        if (bgeSession == null) return null
        val probe = Sentence(text, text[0], text.last(), text.length); val cands = coarseFilter(probe, hint); if (cands.isEmpty()) return null
        val probeEmb = embed(text) ?: return null; var best: SingleResult? = null
        for (ci in cands) {
            val ss = scriptSentences[ci]; val ssEmb = embed(ss.text) ?: continue
            val sim = cosine(probeEmb, ssEmb); val st = scriptSentencePositions[ci]
            val w = scriptClean.substring(st, minOf(scriptClean.length, st + ss.length))
            if (best == null || sim > best!!.score) best = SingleResult(st, sim, w, 0, probe)
        }
        return best
    }

    private data class LocateResult(val pos: Int, val score: Float, val source: String)

    private fun layeredLocate(ocr: String, asr: String, hint: Int, expected: Int, audio: FloatArray?): LocateResult {
        val hasOcr = ocr.length >= 2; val hasAsr = asr.length >= 2
        var l1: SingleResult? = null
        if (hasOcr) { l1 = lcsSearchOne(ocr, hint, expected, false); if (l1 != null && l1.score >= L1_OCR_DIRECT) return LocateResult(l1.pos, l1.score, "L1-OCR首选") }
        var l2: SingleResult? = null
        if (hasAsr && (!hasOcr || l1 == null || l1.score < L1_OCR_WEAK)) { l2 = lcsSearchOne(asr, hint, expected, false); if (l2 != null && l2.score >= L2_ASR_DIRECT) return LocateResult(l2.pos, l2.score, "L2-Paraformer备选") }
        var l3: SingleResult? = null
        val l1F = l1 != null && l1.score in L3_FUZZY_LOW..L3_FUZZY_HIGH; val l2F = l2 != null && l2.score in L3_FUZZY_LOW..L3_FUZZY_HIGH
        if (l1F || l2F) { val pt = if (hasOcr) ocr else asr; l3 = semanticRescore(pt, hint); if (l3 != null && l3.score >= 0.50f) return LocateResult(l3.pos, l3.score, "L3-bge语义") }
        val candidates = listOfNotNull(l1, l2, l3); val best = candidates.maxByOrNull { it.score } ?: return LocateResult(hint, 0f, "L5-无信号")
        val bestSource = when (best) { l1 -> "L1-OCR弱"; l2 -> "L2-Paraformer弱"; l3 -> "L3-bge弱"; else -> "未知" }
        if (best.score < L4_ALIGN_TRIGGER && audio != null && alignInterpreter != null && best.pos < scriptClean.length) {
            val candText = scriptClean.substring(best.pos, minOf(best.pos + 80, scriptClean.length))
            if (candText.length >= 4) {
                val verify = alignAndVerify(audio, candText)
                if (verify != null) {
                    val (coverage, firstStartSec) = verify
                    if (coverage >= 0.70f) return LocateResult(best.pos, maxOf(best.score, 0.75f), "$bestSource+L4Omni确认")
                    else if (coverage < 0.35f) {
                        val approxCharsPerSec = candText.length / 10.0f; val offset = (firstStartSec * approxCharsPerSec).toInt()
                        val newPos = (best.pos + offset).coerceIn(0, maxOf(0, scriptClean.length - 10))
                        val newWindow = scriptClean.substring(newPos, minOf(newPos + candText.length, scriptClean.length))
                        val newLcs = lcs(if (hasOcr) ocr else asr, newWindow).toFloat() / (if (hasOcr) ocr.length else asr.length)
                        if (newLcs > best.score) return LocateResult(newPos, minOf(0.70f, newLcs + 0.15f), "L4-Omni重定位")
                    }
                }
            }
        }
        return LocateResult(best.pos, best.score, bestSource)
    }

    private fun extractOcrSentences(vf: File): List<Sentence> {
        val td = File(workDir, "ocr_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        val sents = mutableListOf<Sentence>(); val seen = mutableSetOf<String>()
        try {
            val s = FFmpegKit.execute("-y -i \"${vf.absolutePath}\" -vf fps=1 -q:v 3 \"${td.absolutePath}/f_%04d.jpg\"")
            if (ReturnCode.isSuccess(s.returnCode)) {
                val frames = td.listFiles()?.sortedBy { it.name } ?: emptyList(); var proc = 0
                for (f in frames) {
                    val full = BitmapFactory.decodeFile(f.absolutePath) ?: continue
                    val top = (full.height * (1f - BOTTOM_ROI_RATIO)).toInt(); val h = full.height - top
                    if (h <= 0 || full.width <= 0) { full.recycle(); continue }
                    val region = Bitmap.createBitmap(full, 0, top, full.width, h); full.recycle()
                    val sw = maxOf(1, region.width / 2); val sh = maxOf(1, region.height / 2)
                    val scaled = Bitmap.createScaledBitmap(region, sw, sh, true); if (region != scaled) region.recycle()
                    val vt = Tasks.await(textRecognizer.process(InputImage.fromBitmap(scaled, 0))); scaled.recycle()
                    for (blk in vt.textBlocks) for (line in blk.lines) {
                        val c = cleanFilter(line.text)
                        if (c.length >= 2 && c !in seen) { sents.add(Sentence(c, c[0], c.last(), c.length)); seen.add(c) }
                    }
                    if (++proc % 20 == 0) System.gc()
                }
            }
        } catch (e: Throwable) { Log.w(TAG, "ocr: ${e.message}") }
        finally { td.listFiles()?.forEach { it.delete() }; td.delete() }
        return sents
    }

    suspend fun initialMatch(script: String, forceAI: Boolean, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sorted = uploadedClips.toList().sortedWith { a, b -> natural(a, b) }
            if (sorted.isEmpty()) throw Exception("无视频")
            scriptClean = cleanFilter(script); if (scriptClean.isEmpty()) throw Exception("剧本为空")
            val (ss, sp) = splitScript(script); scriptSentences = ss; scriptSentencePositions = sp
            allMatches.clear(); var cur = 0
            for ((idx, clip) in sorted.withIndex()) {
                withContext(Dispatchers.Main) { onProgress(((idx + 1).toFloat() / sorted.size * 100).toInt(), "扫描 ${idx + 1}/${sorted.size}: ${clip.take(15)}") }
                val remain = sorted.size - idx; val exp = maxOf(1, (scriptClean.length - cur) / remain); val vf = File(uploadDir, clip)
                val (asrText, audio10s) = withContext(Dispatchers.IO) {
                    var t = ""; var a: FloatArray? = null
                    try {
                        var dur = 60.0; try { dur = FFprobeKit.getMediaInformation(vf.absolutePath)?.mediaInformation?.duration?.toDoubleOrNull() ?: 60.0 } catch (_: Throwable) {}
                        val sec = minOf(dur, 60.0).toInt().coerceAtLeast(1)
                        val wav = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                        val s = FFmpegKit.execute("-y -vn -i \"${vf.absolutePath}\" -t $sec -af \"highpass=f=200, lowpass=f=3400, volume=2.5\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wav.absolutePath}\"")
                        if (ReturnCode.isSuccess(s.returnCode)) { t = recognizeAudio(wav); a = readWavAsFloat(wav); wav.delete() }
                    } catch (_: Throwable) {}
                    t to a
                }
                val cleanAsr = cleanFilter(asrText); val ocrSents = withContext(Dispatchers.IO) { extractOcrSentences(vf) }
                val cleanOcr = ocrSents.joinToString("") { it.text }; val asrSents = splitAsr(asrText)
                val r = layeredLocate(cleanOcr, cleanAsr, cur, exp, audio10s)
                val anchor = r.score >= ANCHOR_THRESHOLD && (cleanOcr.length >= MIN_ANCHOR_LEN || cleanAsr.length >= MIN_ANCHOR_LEN)
                val fc = if (anchor) r.pos else cur; val fs = if (anchor) r.score else 0f
                val fw = if (fc < scriptClean.length) scriptClean.substring(fc, minOf(fc + 50, scriptClean.length)) else ""
                if (anchor) cur = minOf(scriptClean.length, r.pos + 10) else cur = minOf(scriptClean.length, cur + maxOf(exp, 10))
                allMatches.add(ClipMatch(idx, clip, buildString { if (cleanOcr.isNotBlank()) append("【底部字幕】$cleanOcr\n"); if (cleanAsr.isNotBlank()) append("【Paraformer】$cleanAsr") },
                    if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr, fw, fc, fs, false, cleanOcr, cleanAsr, ocrSents, asrSents, if (anchor) r.source else "L5-未锚定", false))
                delay(3)
            }
            val sortedM = allMatches.sortedBy { it.coord }; allMatches.clear(); allMatches.addAll(sortedM)
            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) { Log.e(TAG, "initial fail", e); withContext(Dispatchers.Main) { onError(e.message ?: "未知") } }
    }

    private fun natural(a: String, b: String): Int {
        val rx = Regex("(\\d+)|(\\D+)"); val ap = rx.findAll(a).map { it.value }.toList(); val bp = rx.findAll(b).map { it.value }.toList()
        for (i in 0 until minOf(ap.size, bp.size)) {
            val n1 = ap[i].all { it.isDigit() }; val n2 = bp[i].all { it.isDigit() }
            if (n1 && n2) { val c = (ap[i].toLongOrNull() ?: 0L).compareTo(bp[i].toLongOrNull() ?: 0L); if (c != 0) return c }
            else { val c = ap[i].compareTo(bp[i]); if (c != 0) return c }
        }
        return ap.size - bp.size
    }

    private fun readWavAsFloat(w: File): FloatArray {
        return try {
            val b = w.readBytes(); if (b.size <= 44) return FloatArray(0)
            val sb = ByteBuffer.wrap(b, 44, b.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            FloatArray(sb.remaining()) { sb.get() / 32768.0f }
        } catch (_: Throwable) { FloatArray(0) }
    }

    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) return@withContext CalibrateResult(0, 0, 0)
        var improved = 0; val n = allMatches.size; var i = 0
        while (i < n) {
            if (allMatches[i].locked || allMatches[i].forceConfirmed) { i++; continue }
            val rs = i; while (i < n && !(allMatches[i].locked || allMatches[i].forceConfirmed)) i++; val re = i - 1
            var lo = if (rs > 0) maxOf(0, allMatches[rs - 1].coord - 30) else 0
            var hi = if (re < n - 1) minOf(scriptClean.length, allMatches[re + 1].coord + allMatches[re + 1].scriptText.length + 30) else scriptClean.length
            for (j in rs - 1 downTo 0) if (allMatches[j].locked || allMatches[j].forceConfirmed) { lo = allMatches[j].coord + allMatches[j].scriptText.length; break }
            for (j in re + 1 until n) if (allMatches[j].locked || allMatches[j].forceConfirmed) { hi = allMatches[j].coord; break }
            if (hi <= lo) { lo = 0; hi = scriptClean.length }
            for (idx in rs..re) {
                val m = allMatches[idx]; val audio = loadClipAudio10s(m.clipName)
                val r = layeredLocate(m.rawOcr, m.rawAsr, lo, hi - lo, audio)
                if (r.score >= CALIB_MIN_NEW_SCORE && r.score - m.score > CALIB_MIN_GAIN) {
                    allMatches[idx] = m.copy(scriptText = if (r.pos < scriptClean.length) scriptClean.substring(r.pos, minOf(r.pos + 50, scriptClean.length)) else m.scriptText, coord = r.pos, score = r.score, sourceTag = "校对-${r.source}")
                    improved++
                }
            }
        }
        val g = allMatches.count { it.score >= GREEN_THRESHOLD }; CalibrateResult(improved, allMatches.size - g, g)
    }

    suspend fun smartCalibrateMultiRound(maxRounds: Int = 5): CalibrateResult = withContext(Dispatchers.Default) {
        var total = 0; var last = CalibrateResult(0, 0, 0)
        for (round in 1..maxRounds) { val r = smartCalibrateOnce(); total += r.improvedCount; last = r; if (r.improvedCount == 0) break }
        CalibrateResult(total, last.stillRed, last.stillGreen)
    }

    suspend fun forceAlignBatch(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) return@withContext CalibrateResult(0, 0, 0)
        var improved = 0
        for (idx in allMatches.indices) {
            if (allMatches[idx].locked || allMatches[idx].forceConfirmed) continue
            val m = allMatches[idx]; if (alignInterpreter == null) continue
            val audio = loadClipAudio10s(m.clipName) ?: continue
            val candText = if (m.coord < scriptClean.length) scriptClean.substring(m.coord, minOf(m.coord + 80, scriptClean.length)) else ""
            if (candText.length < 4) continue
            val verify = alignAndVerify(audio, candText) ?: continue
            val (coverage, firstStartSec) = verify
            when {
                coverage >= 0.75f -> if (m.score < 0.70f) { allMatches[idx] = m.copy(score = maxOf(m.score, 0.72f), sourceTag = "L4-Omni确认"); improved++ }
                coverage < 0.30f -> {
                    val approxCharsPerSec = candText.length / 10.0f; val offset = (firstStartSec * approxCharsPerSec).toInt()
                    val newPos = (m.coord + offset).coerceIn(0, maxOf(0, scriptClean.length - 10))
                    allMatches[idx] = m.copy(scriptText = scriptClean.substring(newPos, minOf(newPos + 50, scriptClean.length)), coord = newPos, score = maxOf(m.score, 0.55f), sourceTag = "L4-Omni重定位")
                    improved++
                }
            }
        }
        val g = allMatches.count { it.score >= GREEN_THRESHOLD }; CalibrateResult(improved, allMatches.size - g, g)
    }

    private fun loadClipAudio10s(clipName: String): FloatArray? {
        val vf = File(uploadDir, clipName); if (!vf.exists()) return null
        return try {
            val wav = File(workDir, "temp_align_${System.currentTimeMillis()}.wav")
            val s = FFmpegKit.execute("-y -vn -i \"${vf.absolutePath}\" -t 10 -ar 16000 -ac 1 -c:a pcm_s16le \"${wav.absolutePath}\"")
            if (!ReturnCode.isSuccess(s.returnCode)) return null
            val a = readWavAsFloat(wav); wav.delete(); a
        } catch (_: Throwable) { null }
    }

    fun recalculateMatchAt(i: Int) {
        if (i !in allMatches.indices) return; val m = allMatches[i]
        if (m.locked || m.forceConfirmed) return
        var ll = 0; for (j in i - 1 downTo 0) if (allMatches[j].locked || allMatches[j].forceConfirmed) { ll = allMatches[j].coord + allMatches[j].scriptText.length; break }
        var ul = scriptClean.length; for (j in i + 1 until allMatches.size) if (allMatches[j].locked || allMatches[j].forceConfirmed) { ul = allMatches[j].coord; break }
        val lo = maxOf(0, minOf(ll, if (i > 0) allMatches[i - 1].coord - 50 else 0))
        val hi = minOf(scriptClean.length, maxOf(ul, if (i < allMatches.size - 1) allMatches[i + 1].coord + 50 else scriptClean.length))
        if (hi <= lo) return
        val audio = loadClipAudio10s(m.clipName)
        val r = layeredLocate(m.rawOcr, m.rawAsr, lo, hi - lo, audio)
        allMatches[i] = m.copy(scriptText = if (r.pos < scriptClean.length) scriptClean.substring(r.pos, minOf(r.pos + 50, scriptClean.length)) else m.scriptText, coord = r.pos, score = r.score, sourceTag = "微调-${r.source}")
    }

    fun lockGreenItems() = allMatches.indices.count { if (!allMatches[it].locked && allMatches[it].score >= GREEN_THRESHOLD) { allMatches[it] = allMatches[it].copy(locked = true); true } else false }
    fun unlockAll() = allMatches.indices.count { if (allMatches[it].locked) { allMatches[it] = allMatches[it].copy(locked = false, forceConfirmed = false); true } else false }
    fun toggleLock(i: Int): Boolean { if (i !in allMatches.indices) return false; allMatches[i] = allMatches[i].copy(locked = !allMatches[i].locked); return allMatches[i].locked }
    fun moveUp(i: Int) { if (i > 0 && i < allMatches.size) allMatches.add(i - 1, allMatches.removeAt(i)) }
    fun moveDown(i: Int) { if (i >= 0 && i < allMatches.size - 1) allMatches.add(i + 1, allMatches.removeAt(i)) }

    fun buildEpisodesJsonByUIOrder(): String {
        if (allMatches.isEmpty()) return "[]"
        val ep = JsonObject(); ep.addProperty("episode_id", 1); ep.addProperty("title", "V111")
        val sc = JsonArray(); val cl = JsonArray()
        allMatches.forEachIndexed { i, m -> sc.add("段${i+1} · ${String.format("%.2f", m.score)}"); cl.add(m.clipName) }
        ep.add("scenes", sc); ep.add("clips", cl); val r = JsonArray(); r.add(ep); return r.toString()
    }

    suspend fun stitchVideo(json: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val arr = JsonParser.parseString(json).asJsonArray; var last = ""
            for (ei in 0 until arr.size()) {
                val eo = arr.get(ei).asJsonObject; val eid = eo.get("episode_id").asInt; val cl = eo.getAsJsonArray("clips")
                if (cl.size() == 0) continue
                val lf = File(workDir, "concat_${eid}_${System.currentTimeMillis()}.txt")
                val of = File(workDir, "lingxu_ep_${eid}_${System.currentTimeMillis()}.mp4")
                lf.bufferedWriter().use { out -> for (i in 0 until cl.size()) { val f = File(uploadDir, cl.get(i).asString); if (f.exists()) out.write("file '${f.absolutePath}'\n") } }
                var s = FFmpegKit.execute("-y -f concat -safe 0 -i \"${lf.absolutePath}\" -c copy \"${of.absolutePath}\"")
                if (!ReturnCode.isSuccess(s.returnCode)) {
                    s = FFmpegKit.execute("-y -f concat -safe 0 -i \"${lf.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${of.absolutePath}\"")
                    if (!ReturnCode.isSuccess(s.returnCode)) throw Exception("拼接失败")
                }
                lf.delete(); last = of.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "完成"); onSuccess(last) }
        } catch (e: Throwable) { withContext(Dispatchers.Main) { onError(e.message ?: "未知") } }
    }
}