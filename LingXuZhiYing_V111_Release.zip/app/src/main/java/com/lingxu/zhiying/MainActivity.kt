package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class FolderInfo(val name: String, val videos: MutableList<Map<String, Any>>)

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainScrollView: ScrollView
    private lateinit var calibrateLayout: LinearLayout
    private val REQ_CODE_PERM = 100
    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private lateinit var btnActivate: Button
    private var deviceId: String = ""
    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnStitch: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvReadyGate: TextView
    private lateinit var btnGoCalibrate: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var cardAdapter: ClipAdapter
    private lateinit var calibProgressBar: ProgressBar
    private lateinit var calibStatus: TextView
    private lateinit var btnCalibrateMulti: Button
    private lateinit var btnForceAlign: Button
    private lateinit var btnFixOrder: Button
    private lateinit var btnForceConfirmAll: Button
    private lateinit var btnLockGreen: Button
    private lateinit var btnUnlockAll: Button
    private var calibrateRound = 0
    private var isCalibrating = false
    private var isModelsReady = false
    private var isAsrReady = false
    private var isAlignReady = false
    private var currentJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            checkPermissions(); setupBaseUI()
            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val n = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", n).apply(); n
            }
            if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString()).setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.READ_MEDIA_VIDEO)
        else { p.add(Manifest.permission.READ_EXTERNAL_STORAGE); p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
        val m = p.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (m.isNotEmpty()) ActivityCompat.requestPermissions(this, m.toTypedArray(), REQ_CODE_PERM)
    }

    private fun setupBaseUI() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(80, 200, 80, 80); gravity = Gravity.CENTER_HORIZONTAL }
        authLayout.addView(TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        authLayout.addView(TextView(this).apply { text = "复制设备码获取激活码"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) })
        tvDeviceCode = TextView(this).apply {
            text = deviceId; setTextColor(Color.parseColor("#10B981")); textSize = 28f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER; setPadding(0, 0, 0, 40)
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("code", deviceId))
                Toast.makeText(this@MainActivity, "已复制", Toast.LENGTH_SHORT).show()
            }
        }
        authLayout.addView(tvDeviceCode)
        etActivationCode = EditText(this).apply { hint = "32 位激活码"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(30,30,30,30); gravity = Gravity.CENTER }
        authLayout.addView(etActivationCode)
        btnActivate = Button(this).apply { text = "立即激活"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setPadding(0,30,0,30); setOnClickListener { verifyActivation() } }
        authLayout.addView(btnActivate)
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "格式错误", Toast.LENGTH_SHORT).show(); return }
        val ob = byteArrayOf(0x16,0x3B,0x38,0x31,0x06,0x2E,0x1A,0x3A,0x39,0x03,0x16,0x3D,0x39,0x52,0x1B,0x35,0x30,0x16,0x12,0x0B,0x02,0x5A,0x13,0x3B,0x39,0x30,0x3B,0x17,0x39,0x3B,0x13,0x1E)
        val dec = ByteArray(ob.size) { i -> (ob[i].toInt() xor 0x5A).toByte() }
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(String(dec).toByteArray(), "HmacSHA256"))
            val exp = mac.doFinal(deviceId.toByteArray()).joinToString("") { "%02x".format(it) }.uppercase().substring(0,32)
            if (input == exp) {
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE; showMainApp()
                Toast.makeText(this, "激活成功", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this, "激活码错误", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun showMainApp() {
        if (::mainScrollView.isInitialized) { mainScrollView.visibility = View.VISIBLE; return }
        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        val ml = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(40,60,40,60) }
        ml.addView(TextView(this).apply { text = "灵序织影 · V111 闭环"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0,0,0,20) })
        ml.addView(TextView(this).apply { text = "剧本"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0,0,0,8) })
        etScript = EditText(this).apply { hint = "粘贴完整剧本"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(24,20,24,20); minLines = 3; maxLines = 6; gravity = Gravity.TOP }
        ml.addView(etScript)
        ml.addView(TextView(this).apply { text = "素材"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0,16,0,8) })
        btnImport = Button(this).apply { text = "📥 导入视频"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        ml.addView(btnImport)
        tvClipCount = TextView(this).apply { text = "已导入：0"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 12f; setPadding(0,8,0,8) }
        ml.addView(tvClipCount)
        ml.addView(TextView(this).apply { text = "对齐"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0,16,0,8) })
        val mr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,0,0,8) }
        btnMatch = Button(this).apply { text = "🧠 一键自动对齐"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 8 }; setOnClickListener { showMatchingDialog() } }
        btnGoCalibrate = Button(this).apply { text = "📝 校对台"; setBackgroundColor(Color.parseColor("#7C3AED")); setTextColor(Color.WHITE); isEnabled = false; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); setOnClickListener { mainScrollView.visibility = View.GONE; calibrateLayout.visibility = View.VISIBLE } }
        mr.addView(btnMatch); mr.addView(btnGoCalibrate); ml.addView(mr)
        tvStats = TextView(this).apply { text = "等待对齐..."; setTextColor(Color.parseColor("#F59E0B")); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0,8,0,8) }
        ml.addView(tvStats)
        tvReadyGate = TextView(this).apply { text = "🔒 渲染锁定：请先完成对齐"; setTextColor(Color.parseColor("#EF4444")); textSize = 12f; gravity = Gravity.CENTER; setPadding(0,4,0,8) }
        ml.addView(tvReadyGate)
        btnStitch = Button(this).apply { text = "🎬 渲染完整视频"; setBackgroundColor(Color.parseColor("#64748B")); setTextColor(Color.WHITE); setPadding(0,24,0,24); isEnabled = false; setOnClickListener { tryStartStitching() } }
        ml.addView(btnStitch)
        btnSave = Button(this).apply { text = "💾 保存至相册"; setBackgroundColor(Color.parseColor("#D97706")); setTextColor(Color.WHITE); setPadding(0,24,0,24); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        ml.addView(btnSave)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0,16,0,16) }
        ml.addView(progressBar)
        tvStatus = TextView(this).apply { text = "就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 13f; gravity = Gravity.CENTER }
        ml.addView(tvStatus)

        mainScrollView = ScrollView(this).apply { isFillViewport = true; addView(ml); layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }
        rootLayout.addView(mainScrollView)

        calibrateLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(40,60,40,60); visibility = View.GONE; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0,0,0,12) }
        tr.addView(Button(this).apply { text = "🔙"; setBackgroundColor(Color.parseColor("#64748B")); setTextColor(Color.WHITE); setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f); setOnClickListener { calibrateLayout.visibility = View.GONE; mainScrollView.visibility = View.VISIBLE; refreshReadyGate() } })
        tr.addView(TextView(this).apply { text = " 校对台"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 20f; typeface = Typeface.DEFAULT_BOLD })
        calibrateLayout.addView(tr)
        val br1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,6,0,3) }
        btnCalibrateMulti = Button(this).apply { text = "🔄 多轮智能校对"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#7C3AED")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }; setOnClickListener { runCalibrationMulti() } }
        btnForceAlign = Button(this).apply { text = "🔍 强对齐修正"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#0EA5E9")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); setOnClickListener { runForceAlignBatch() } }
        br1.addView(btnCalibrateMulti); br1.addView(btnForceAlign); calibrateLayout.addView(br1)
        val br2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,3,0,3) }
        btnFixOrder = Button(this).apply { text = "🔧 修复顺序"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#F59E0B")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }; setOnClickListener { runFixOrder() } }
        btnForceConfirmAll = Button(this).apply { text = "⚡ 全部确认"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#EF4444")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }; setOnClickListener { runForceConfirmAll() } }
        btnLockGreen = Button(this).apply { text = "🔒 锁绿"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }; setOnClickListener { lockGreens() } }
        btnUnlockAll = Button(this).apply { text = "🔓 解锁"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#64748B")); setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); setOnClickListener { unlockAll() } }
        br2.addView(btnFixOrder); br2.addView(btnForceConfirmAll); br2.addView(btnLockGreen); br2.addView(btnUnlockAll); calibrateLayout.addView(br2)
        calibProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0,6,0,6) }
        calibrateLayout.addView(calibProgressBar)
        calibStatus = TextView(this).apply { text = "等待操作..."; setTextColor(Color.parseColor("#F59E0B")); textSize = 12f; gravity = Gravity.CENTER; setPadding(0,0,0,6) }
        calibrateLayout.addView(calibStatus)
        recyclerView = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity); layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); cardAdapter = ClipAdapter(); adapter = cardAdapter }
        calibrateLayout.addView(recyclerView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        rootLayout.addView(calibrateLayout)

        CoroutineScope(Dispatchers.Main).launch { bridge.modelsReadyFlow.collect { r -> isModelsReady = r; if (r) refreshEngineStatus() } }
        CoroutineScope(Dispatchers.Main).launch { bridge.asrReadyFlow.collect { r -> isAsrReady = r; if (isModelsReady) refreshEngineStatus() } }
        CoroutineScope(Dispatchers.Main).launch { bridge.alignReadyFlow.collect { r -> isAlignReady = r; if (isModelsReady) refreshEngineStatus() } }
    }

    private fun refreshEngineStatus() {
        val parts = mutableListOf<String>()
        parts.add("OCR")
        if (isAsrReady) parts.add("ASR") else parts.add("ASR❌")
        if (isAlignReady) parts.add("强对齐") else parts.add("强对齐❌")
        tvStatus.text = "引擎：${parts.joinToString(" + ")}"
        tvStatus.setTextColor(if (isAsrReady) Color.parseColor("#10B981") else Color.parseColor("#F59E0B"))
    }

    private fun refreshReadyGate() {
        if (bridge.allMatches.isEmpty()) {
            tvReadyGate.text = "🔒 渲染锁定：请先完成对齐"
            tvReadyGate.setTextColor(Color.parseColor("#EF4444"))
            btnStitch.isEnabled = false; btnStitch.setBackgroundColor(Color.parseColor("#64748B"))
            return
        }
        val confirmed = bridge.confirmedCount(); val total = bridge.allMatches.size
        val allConfirmed = bridge.isAllConfirmed(); val orderOk = bridge.isOrderConsistent()
        when {
            !allConfirmed -> {
                tvReadyGate.text = "🔒 渲染锁定：已确认 $confirmed / $total ，仍有 ${total - confirmed} 项待确认"
                tvReadyGate.setTextColor(Color.parseColor("#EF4444"))
                btnStitch.isEnabled = false; btnStitch.setBackgroundColor(Color.parseColor("#64748B"))
            }
            !orderOk -> {
                tvReadyGate.text = "🔒 已确认全部，但顺序与剧本不一致，请点 🔧 修复顺序"
                tvReadyGate.setTextColor(Color.parseColor("#F59E0B"))
                btnStitch.isEnabled = false; btnStitch.setBackgroundColor(Color.parseColor("#64748B"))
            }
            else -> {
                tvReadyGate.text = "✅ 渲染就绪：全部 $total 段已确认，顺序与剧本一致"
                tvReadyGate.setTextColor(Color.parseColor("#10B981"))
                btnStitch.isEnabled = true; btnStitch.setBackgroundColor(Color.parseColor("#059669"))
            }
        }
    }

    inner class ClipAdapter : RecyclerView.Adapter<ClipAdapter.VH>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(16,10,16,10); layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 } }
            val h = TextView(this@MainActivity).apply { textSize = 12f; setTypeface(null, Typeface.BOLD) }
            val heard = TextView(this@MainActivity).apply { textSize = 12f; setPadding(0,4,0,4) }
            val script = TextView(this@MainActivity).apply { textSize = 12f }
            val bu = Button(this@MainActivity).apply { text = "⬆️"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#3B82F6")); setTextColor(Color.WHITE) }
            val bd = Button(this@MainActivity).apply { text = "⬇️"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#3B82F6")); setTextColor(Color.WHITE) }
            val fc = Button(this@MainActivity).apply { text = "✅ 强制确认"; setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setBackgroundColor(Color.parseColor("#EF4444")); setTextColor(Color.WHITE) }
            val lb = Button(this@MainActivity).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setTextColor(Color.WHITE) }
            val r1 = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0,6,0,0) }
            bu.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            bd.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            fc.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 4 }
            lb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            r1.addView(bu); r1.addView(bd); r1.addView(fc); r1.addView(lb)
            c.addView(h); c.addView(heard); c.addView(script); c.addView(r1)
            return VH(c, h, heard, script, lb, bu, bd, fc)
        }
        override fun onBindViewHolder(h: VH, p: Int) {
            val m = bridge.allMatches[p]
            val confirmed = m.locked || m.forceConfirmed || m.score >= AndroidBridge.GREEN_THRESHOLD
            val col = when { m.locked -> "#38BDF8"; m.forceConfirmed -> "#10B981"; m.score >= AndroidBridge.GREEN_THRESHOLD -> "#10B981"; m.score >= AndroidBridge.YELLOW_THRESHOLD -> "#F59E0B"; else -> "#EF4444" }
            h.card.setBackgroundColor(Color.parseColor(if (m.locked || m.forceConfirmed) "#1E293B" else "#0F172A"))
            val icon = when { m.locked -> "🔒"; m.forceConfirmed -> "✅"; m.score >= AndroidBridge.GREEN_THRESHOLD -> "🟢"; m.score >= AndroidBridge.YELLOW_THRESHOLD -> "🟡"; else -> "❌" }
            h.header.text = "$icon 段${p+1} · ${String.format("%.2f", m.score)} · [${m.sourceTag}]"
            h.header.setTextColor(Color.parseColor(col))
            h.heard.text = "🎤 ${if (m.heardText.length > 280) m.heardText.take(280) + "..." else m.heardText}"
            h.heard.setTextColor(Color.parseColor("#94A3B8"))
            h.script.text = "📖 ${if (m.scriptText.length > 200) m.scriptText.take(200) + "..." else m.scriptText}"
            h.script.setTextColor(Color.parseColor("#7DD3FC"))
            h.forceBtn.visibility = if (!confirmed) View.VISIBLE else View.GONE
            h.lock.text = if (m.locked) "🔓" else "🔒"
            h.lock.setBackgroundColor(Color.parseColor(col))
            h.up.isEnabled = p > 0; h.up.alpha = if (p > 0) 1f else 0.5f
            h.up.setOnClickListener { bridge.moveUp(p); bridge.recalculateMatchAt(p); if (p-1 >= 0) bridge.recalculateMatchAt(p-1); notifyItemMoved(p, p-1); notifyItemChanged(p-1); notifyItemChanged(p); updateStats(); refreshReadyGate() }
            h.down.isEnabled = p < bridge.allMatches.size-1; h.down.alpha = if (p < bridge.allMatches.size-1) 1f else 0.5f
            h.down.setOnClickListener { bridge.moveDown(p); bridge.recalculateMatchAt(p); if (p+1 < bridge.allMatches.size) bridge.recalculateMatchAt(p+1); notifyItemMoved(p, p+1); notifyItemChanged(p); notifyItemChanged(p+1); updateStats(); refreshReadyGate() }
            h.forceBtn.setOnClickListener { bridge.forceConfirmAt(p); notifyItemChanged(p); updateStats(); refreshReadyGate(); Toast.makeText(this@MainActivity, "已强制确认第${p+1}段", Toast.LENGTH_SHORT).show() }
            h.lock.setOnClickListener { bridge.toggleLock(p); notifyItemChanged(p); updateStats(); refreshReadyGate() }
        }
        override fun getItemCount() = bridge.allMatches.size
        inner class VH(val card: LinearLayout, val header: TextView, val heard: TextView, val script: TextView, val lock: Button, val up: Button, val down: Button, val forceBtn: Button) : RecyclerView.ViewHolder(card)
    }

    private fun resetButtons() {
        btnImport.isEnabled = true; btnMatch.isEnabled = true; btnMatch.text = "🧠 一键自动对齐"
        btnCalibrateMulti.isEnabled = true; btnCalibrateMulti.text = "🔄 多轮智能校对"
        btnForceAlign.isEnabled = true; btnForceAlign.text = "🔍 强对齐修正"
        btnFixOrder.isEnabled = true; btnForceConfirmAll.isEnabled = true
        btnGoCalibrate.isEnabled = bridge.allMatches.isNotEmpty(); progressBar.visibility = View.GONE; isCalibrating = false
        refreshReadyGate()
    }

    private fun showMatchingDialog() {
        val s = etScript.text.toString().trim()
        if (s.isEmpty()) { Toast.makeText(this, "请先输入剧本", Toast.LENGTH_SHORT).show(); return }
        if (bridge.uploadedClips.isEmpty()) { Toast.makeText(this, "请先导入素材", Toast.LENGTH_SHORT).show(); return }
        if (!isModelsReady) { Toast.makeText(this, "引擎未就绪", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("对齐模式")
            .setItems(arrayOf("🚀 文件名直通", "🧠 分层降级对齐（OCR→ASR→强对齐）")) { _, w -> executeMatching(s, w == 1) }.show()
    }

    private fun executeMatching(script: String, ai: Boolean) {
        btnMatch.isEnabled = false; btnMatch.text = "🧠 处理中..."
        btnImport.isEnabled = false; btnGoCalibrate.isEnabled = false
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = if (ai) "L1 OCR → L2 ASR → L4 强对齐..." else "文件名排位..."
        calibrateRound = 0
        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                bridge.initialMatch(script, ai, { p, msg -> progressBar.progress = (p * 0.7).toInt(); tvStatus.text = msg }, {
                    tvStatus.text = "对齐完毕，请进入校对台"; progressBar.progress = 100
                    cardAdapter.notifyDataSetChanged(); updateStats()
                    Toast.makeText(this@MainActivity, "✅ 完成，请进入校对台确认", Toast.LENGTH_LONG).show()
                }, { err -> tvStatus.text = "失败：$err"; tvStatus.setTextColor(Color.parseColor("#EF4444")) })
            } finally { launch { delay(500); resetButtons() } }
        }
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false; tvStatus.text = "扫描中..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val fm = mutableMapOf<String, FolderInfo>()
                val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                        val n = c.getString(c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        val f = c.getString(c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)) ?: "默认"
                        fm.getOrPut(f) { FolderInfo(f, mutableListOf()) }.videos.add(mapOf("id" to id, "name" to n))
                    }
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (fm.isEmpty()) { tvStatus.text = "未找到视频"; return@withContext }
                    AlertDialog.Builder(this@MainActivity).setTitle("选择文件夹")
                        .setItems(fm.values.map { "${it.name} (${it.videos.size})" }.toTypedArray()) { _, w -> showVideoSelection(fm.values.toList()[w]) }
                        .setNegativeButton("取消", null).show()
                }
            } catch (_: Throwable) { withContext(Dispatchers.Main) { btnImport.isEnabled = true; tvStatus.text = "读取失败" } }
        }
    }

    private fun showVideoSelection(fi: FolderInfo) {
        val names = fi.videos.map { it["name"] as String }.toTypedArray()
        val checked = BooleanArray(fi.videos.size); val cbs = mutableListOf<CheckBox>()
        val sv = ScrollView(this); val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,10,30,10); setBackgroundColor(Color.WHITE) }
        for (i in names.indices) {
            val cb = CheckBox(this).apply { text = names[i]; setTextColor(Color.BLACK); textSize = 14f; setOnCheckedChangeListener { _, c -> checked[i] = c } }
            cbs.add(cb); ll.addView(cb)
        }
        sv.addView(ll)
        val cn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        cn.addView(CheckBox(this).apply { text = "全选"; setTextColor(Color.BLACK); textSize = 16f; setTypeface(null, Typeface.BOLD); setPadding(40,20,40,10); setOnCheckedChangeListener { _, c -> for (i in cbs.indices) { cbs[i].isChecked = c; checked[i] = c } } })
        cn.addView(sv)
        AlertDialog.Builder(this).setTitle("【${fi.name}】").setView(cn)
            .setPositiveButton("导入") { _, _ -> val sel = mutableListOf<Map<String,Any>>(); for (i in checked.indices) if (checked[i]) sel.add(fi.videos[i]); if (sel.isNotEmpty()) downloadSelected(sel) }
            .setNegativeButton("取消", null).show()
    }

    private fun downloadSelected(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0; btnImport.isEnabled = false
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val ok = mutableListOf<String>()
            for (i in videos.indices) {
                val id = videos[i]["id"] as Long; val n = videos[i]["name"] as String
                withContext(Dispatchers.Main) { tvStatus.text = "(${i+1}/${videos.size}): ${n.take(20)}"; progressBar.progress = ((i.toFloat()/videos.size)*100).toInt() }
                try {
                    contentResolver.openInputStream(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id))?.use { inp ->
                        FileOutputStream(File(bridge.uploadDir, n)).use { out -> inp.copyTo(out) }
                    }
                    ok.add(n)
                } catch (_: Throwable) { }
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE; btnImport.isEnabled = true
                if (ok.isNotEmpty()) {
                    bridge.uploadedClips.clear(); bridge.uploadedClips.addAll(ok); bridge.resetMatches()
                    btnSave.visibility = View.GONE; btnSave.tag = null; btnGoCalibrate.isEnabled = false
                    tvClipCount.text = "已导入：${ok.size}"; tvStatus.text = "导入成功，请对齐"; tvStatus.setTextColor(Color.parseColor("#10B981"))
                    calibrateRound = 0; cardAdapter.notifyDataSetChanged(); updateStats(); resetButtons()
                }
            }
        }
    }

    private fun runCalibrationMulti() {
        if (isCalibrating || bridge.allMatches.isEmpty()) return
        isCalibrating = true; btnCalibrateMulti.isEnabled = false; btnForceAlign.isEnabled = false; btnFixOrder.isEnabled = false; btnForceConfirmAll.isEnabled = false
        btnCalibrateMulti.text = "🔄 计算中..."
        calibProgressBar.visibility = View.VISIBLE; calibProgressBar.progress = 0
        calibStatus.text = "多轮智能校对（最多5轮，只修大错）..."
        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                val anim = launch { for (i in 1..90) { delay(15); calibProgressBar.progress = i } }
                val r = withContext(Dispatchers.Default) { bridge.smartCalibrateMultiRound(5) }
                anim.cancel(); calibProgressBar.progress = 100; calibrateRound++
                cardAdapter.notifyDataSetChanged(); updateStats(); refreshReadyGate()
                calibStatus.text = "完成：共校准 ${r.improvedCount} 项 | 🟢${r.stillGreen} 🔴${r.stillRed}"
                calibStatus.setTextColor(if (r.improvedCount > 0) Color.parseColor("#10B981") else Color.parseColor("#F59E0B"))
            } catch (e: Throwable) { calibStatus.text = "失败：${e.message}"; calibStatus.setTextColor(Color.parseColor("#EF4444")) }
            finally { delay(500); isCalibrating = false; btnCalibrateMulti.isEnabled = true; btnForceAlign.isEnabled = true; btnFixOrder.isEnabled = true; btnForceConfirmAll.isEnabled = true; btnCalibrateMulti.text = "🔄 多轮智能校对"; calibProgressBar.visibility = View.GONE }
        }
    }

    private fun runForceAlignBatch() {
        if (isCalibrating || bridge.allMatches.isEmpty()) return
        isCalibrating = true; btnCalibrateMulti.isEnabled = false; btnForceAlign.isEnabled = false; btnFixOrder.isEnabled = false; btnForceConfirmAll.isEnabled = false
        btnForceAlign.text = "🔍 仲裁中..."
        calibProgressBar.visibility = View.VISIBLE; calibProgressBar.progress = 0
        calibStatus.text = "Omnilingual CTC 强制对齐复核..."
        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                val anim = launch { for (i in 1..90) { delay(15); calibProgressBar.progress = i } }
                val r = withContext(Dispatchers.Default) { bridge.forceAlignBatch() }
                anim.cancel(); calibProgressBar.progress = 100
                cardAdapter.notifyDataSetChanged(); updateStats(); refreshReadyGate()
                calibStatus.text = "复核：修正 ${r.improvedCount} 项 | 🟢${r.stillGreen} 🔴${r.stillRed}"
                calibStatus.setTextColor(if (r.improvedCount > 0) Color.parseColor("#10B981") else Color.parseColor("#F59E0B"))
            } catch (e: Throwable) { calibStatus.text = "失败：${e.message}"; calibStatus.setTextColor(Color.parseColor("#EF4444")) }
            finally { delay(500); isCalibrating = false; btnCalibrateMulti.isEnabled = true; btnForceAlign.isEnabled = true; btnFixOrder.isEnabled = true; btnForceConfirmAll.isEnabled = true; btnForceAlign.text = "🔍 强对齐修正"; calibProgressBar.visibility = View.GONE }
        }
    }

    private fun runFixOrder() {
        if (bridge.allMatches.isEmpty()) return
        val changed = bridge.fixOrderByCoord()
        cardAdapter.notifyDataSetChanged(); updateStats(); refreshReadyGate()
        Toast.makeText(this, if (changed > 0) "已按剧本坐标重排 ${changed} 处" else "顺序已经一致", Toast.LENGTH_SHORT).show()
    }

    private fun runForceConfirmAll() {
        if (bridge.allMatches.isEmpty()) return
        val remaining = bridge.allMatches.count { !it.isConfirmed() }
        if (remaining == 0) { Toast.makeText(this, "已无待确认项", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this)
            .setTitle("确认全部 $remaining 项？")
            .setMessage("这会一次性标记剩余所有未确认片段为已确认并锁定。\n请确保你已人工核对过这些片段。")
            .setPositiveButton("确认") { _, _ ->
                val n = bridge.forceConfirmAllRemaining()
                cardAdapter.notifyDataSetChanged(); updateStats(); refreshReadyGate()
                Toast.makeText(this, "已确认 $n 项", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("取消", null).show()
    }

    private fun lockGreens() { val c = bridge.lockGreenItems(); Toast.makeText(this, "锁定 $c", Toast.LENGTH_SHORT).show(); cardAdapter.notifyDataSetChanged(); updateStats(); refreshReadyGate() }
    private fun unlockAll() { val c = bridge.unlockAll(); Toast.makeText(this, "解锁 $c", Toast.LENGTH_SHORT).show(); cardAdapter.notifyDataSetChanged(); updateStats(); refreshReadyGate() }

    private fun updateStats() {
        if (bridge.allMatches.isEmpty()) { tvStats.text = "等待对齐..."; return }
        val confirmed = bridge.confirmedCount(); val total = bridge.allMatches.size
        val green = bridge.allMatches.count { it.score >= AndroidBridge.GREEN_THRESHOLD }
        val forced = bridge.allMatches.count { it.forceConfirmed }
        val locked = bridge.allMatches.count { it.locked }
        val pending = total - confirmed
        tvStats.text = "已确认 $confirmed/$total | 待确认 $pending\n🟢$green · ✅强制$forced · 🔒锁定$locked"
        tvStats.setTextColor(if (pending == 0) Color.parseColor("#10B981") else Color.parseColor("#F59E0B"))
    }

    private fun tryStartStitching() {
        if (bridge.allMatches.isEmpty()) { Toast.makeText(this, "请先对齐", Toast.LENGTH_SHORT).show(); return }
        if (!bridge.isAllConfirmed()) {
            val remaining = bridge.allMatches.size - bridge.confirmedCount()
            Toast.makeText(this, "还有 $remaining 项未确认，请进入校对台处理", Toast.LENGTH_LONG).show()
            mainScrollView.visibility = View.GONE; calibrateLayout.visibility = View.VISIBLE
            return
        }
        if (!bridge.isOrderConsistent()) {
            Toast.makeText(this, "顺序与剧本不一致，请在校对台点击 🔧 修复顺序", Toast.LENGTH_LONG).show()
            mainScrollView.visibility = View.GONE; calibrateLayout.visibility = View.VISIBLE
            return
        }
        startStitching()
    }

    private fun startStitching() {
        btnStitch.isEnabled = false; btnMatch.isEnabled = false; btnImport.isEnabled = false; btnGoCalibrate.isEnabled = false
        btnSave.visibility = View.GONE; progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "渲染原画质..."
        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                bridge.stitchVideo(bridge.buildEpisodesJsonByUIOrder(), { p, msg -> progressBar.progress = p; tvStatus.text = msg }, { fp ->
                    btnSave.visibility = View.VISIBLE; btnSave.tag = fp; btnSave.isEnabled = true; tvStatus.text = "渲染完成"
                }, { err -> tvStatus.text = "失败：$err"; tvStatus.setTextColor(Color.parseColor("#EF4444")) })
            } finally { resetButtons() }
        }
    }

    private fun saveToGallery() {
        val fp = btnSave.tag as? String ?: return
        val sf = File(fp); if (!sf.exists() || sf.length() == 0L) { Toast.makeText(this, "文件丢失", Toast.LENGTH_SHORT).show(); return }
        btnSave.isEnabled = false
        CoroutineScope(Dispatchers.Main).launch {
            try {
                withContext(Dispatchers.IO) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影"); put(MediaStore.Video.Media.IS_PENDING, 1) }
                    }
                    val col = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    contentResolver.insert(col, cv)?.let { uri ->
                        contentResolver.openOutputStream(uri)?.use { o -> FileInputStream(sf).use { i -> i.copyTo(o) } }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { cv.clear(); cv.put(MediaStore.Video.Media.IS_PENDING, 0); contentResolver.update(uri, cv, null, null) }
                    }
                }
                Toast.makeText(this@MainActivity, "已保存", Toast.LENGTH_LONG).show(); btnSave.visibility = View.GONE
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "失败：${e.message}", Toast.LENGTH_LONG).show() }
            finally { btnSave.isEnabled = true }
        }
    }
}