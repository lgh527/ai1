# 灵序织影 V111 (最终稳定版)
ONNX Runtime 版本对齐 1.24.3，配合 pickFirsts 解决冲突。