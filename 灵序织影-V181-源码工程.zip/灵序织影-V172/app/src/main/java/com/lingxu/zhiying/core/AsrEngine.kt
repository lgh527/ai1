package com.lingxu.zhiying.core

import android.content.Context
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineSenseVoiceModelConfig

/**
 * 听觉大模型：Sherpa-ONNX + SenseVoice 中英日韩粤多语种离线识别
 *
 * 模型来自 assets/models/model.int8.onnx 与 assets/models/tokens.txt，
 * 直接通过 AssetManager 交给 JNI 层读取，无需先落地到磁盘。
 *
 * 若 AAR 或 .so 缺失（例如模型未下载成功），本类会安全降级为「无听写结果」，
 * 不会让整个对齐流程崩溃——视觉通道仍可独立完成对齐。
 */
object AsrEngine {

    private const val MODEL_DIR = "models"
    private const val MODEL_FILE = "$MODEL_DIR/model.int8.onnx"
    private const val TOKENS_FILE = "$MODEL_DIR/tokens.txt"

    @Volatile
    private var recognizer: OfflineRecognizer? = null

    @Volatile
    var available: Boolean = false
        private set

    var unavailableReason: String = ""
        private set

    /** SenseVoice 会吐出 <|zh|><|NEUTRAL|><|Speech|> 之类标记，必须清掉 */
    private val TAG_TOKEN = Regex("<\\|[^|]*\\|>")
    private val KEEP = Regex("[\\u4e00-\\u9fa5A-Za-z0-9，。！？、；：]|\n")

    @Synchronized
    fun init(context: Context, numThreads: Int = 4): Boolean {
        if (recognizer != null) return true
        return try {
            if (!modelExists(context)) {
                LogX.e("AsrEngine", unavailableReason)
                return false
            }
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = AudioPipeline.SAMPLE_RATE, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = MODEL_FILE,
                        // 素材以中文为主，给 zh 提示可减少语种误判；夹杂英文仍能识别
                        language = "zh",
                        useInverseTextNormalization = true
                    ),
                    tokens = TOKENS_FILE,
                    numThreads = numThreads,
                    debug = false,
                    provider = "cpu"
                ),
                decodingMethod = "greedy_search"
            )
            recognizer = OfflineRecognizer(context.assets, config)
            available = true
            unavailableReason = ""
            LogX.i("AsrEngine", "SenseVoice 离线识别引擎已就绪")
            true
        } catch (e: Throwable) {
            // 常见为 UnsatisfiedLinkError（.so 未打进包）
            recognizer = null
            available = false
            unavailableReason = "ASR 初始化失败：${e.javaClass.simpleName} ${e.message}"
            LogX.e("AsrEngine", unavailableReason, e)
            false
        }
    }

    /**
     * 模型完整性校验。
     *
     * 只看文件名存在是不够的：CI 里 `wget -q -O model.int8.onnx` 一旦下载失败，
     * 会留下一个 0 字节的同名文件，名字检查照样通过，然后 ASR 静默全空——
     * 表现就是"什么都没识别出来、顺序全乱"。所以这里必须校验体积。
     */
    private fun modelExists(context: Context): Boolean {
        return try {
            val list = context.assets.list(MODEL_DIR) ?: emptyArray()
            if (!list.any { it == "model.int8.onnx" } || !list.any { it == "tokens.txt" }) {
                unavailableReason = "assets/models 缺少 model.int8.onnx 或 tokens.txt（现有：${list.joinToString()}）"
                return false
            }
            val modelSize = assetSize(context, "$MODEL_DIR/model.int8.onnx")
            val tokenSize = assetSize(context, TOKENS_FILE)
            // SenseVoice int8 模型正常在 200MB 量级，低于 10MB 必然是残缺文件
            if (modelSize < 10L * 1024 * 1024) {
                unavailableReason = "SenseVoice 模型只有 ${modelSize / 1024}KB，是下载残缺的空文件，请重新打包"
                return false
            }
            if (tokenSize < 1024) {
                unavailableReason = "tokens.txt 只有 ${tokenSize}B，文件残缺"
                return false
            }
            true
        } catch (e: Throwable) {
            unavailableReason = "模型校验异常：${e.message}"
            false
        }
    }

    private fun assetSize(context: Context, path: String): Long = try {
        context.assets.openFd(path).use { it.length }
    } catch (e: Throwable) {
        // 压缩存放的 asset 拿不到 fd，退化为流式统计
        try {
            context.assets.open(path).use { it.available().toLong() }
        } catch (e2: Throwable) {
            -1L
        }
    }

    /**
     * 识别一段 PCM。超长音频由 [AudioPipeline.windows] 切好的滑动窗口逐段送入，
     * 识别结果按窗口顺序拼接。
     */
    fun transcribe(pcm: FloatArray): String {
        val rec = recognizer ?: return ""
        if (pcm.isEmpty()) return ""
        val sb = StringBuilder()
        try {
            val stream = rec.createStream()
            stream.acceptWaveform(pcm, AudioPipeline.SAMPLE_RATE)
            rec.decode(stream)
            sb.append(clean(rec.getResult(stream).text))
            stream.release()
        } catch (e: Throwable) {
            LogX.w("AsrEngine", "识别窗口失败: ${e.message}")
        }
        return sb.toString().trim()
    }

    /** 直接吃完整 PCM，内部自动滑窗 */
    fun transcribeWithWindows(windows: List<FloatArray>): String {
        if (windows.isEmpty()) return ""
        val parts = ArrayList<String>(windows.size)
        windows.forEachIndexed { i, w ->
            val t = transcribe(w)
            if (t.isNotBlank()) parts.add(t)
            LogX.i("AsrEngine", "窗口 ${i + 1}/${windows.size} → ${t.length} 字")
        }
        return dedupOverlap(parts)
    }

    /** 滑窗有 1 秒重叠，去掉相邻窗口首尾重复的片段 */
    private fun dedupOverlap(parts: List<String>): String {
        if (parts.size <= 1) return parts.firstOrNull() ?: ""
        val out = StringBuilder(parts[0])
        for (i in 1 until parts.size) {
            val cur = parts[i]
            val prevTail = out.toString().takeLast(24)
            var cut = 0
            val maxOverlap = minOf(prevTail.length, cur.length)
            for (len in maxOverlap downTo 4) {
                if (prevTail.endsWith(cur.substring(0, len))) {
                    cut = len
                    break
                }
            }
            out.append(cur.substring(cut))
        }
        return out.toString()
    }

    private fun clean(raw: String): String {
        var s = TAG_TOKEN.replace(raw, "")
        s = s.replace("[blank]", "").replace("[noise]", "")
        s = s.filter { KEEP.matches(it.toString()) }
        return s.trim()
    }

    @Synchronized
    fun release() {
        try {
            recognizer?.release()
        } catch (_: Throwable) {
        }
        recognizer = null
        available = false
    }
}
