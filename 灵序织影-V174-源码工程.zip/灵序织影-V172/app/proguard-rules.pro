# ===== 基础 =====
-dontpreverify
-ignorewarnings
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,Exceptions

# ===== 自家代码 =====
-keep public class * extends android.app.Activity
-keep class com.lingxu.zhiying.** { *; }
-keepclassmembers class com.lingxu.zhiying.** { *; }

# ===== sherpa-onnx（JNI 靠类名反查，禁止重打包/混淆）=====
-keep class com.k2fsa.sherpa.onnx.** { *; }
-dontwarn com.k2fsa.sherpa.onnx.**

# ===== FFmpegKit =====
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.arthenica.smartexception.** { *; }
-dontwarn com.arthenica.ffmpegkit.**
-dontwarn com.arthenica.smartexception.**

# ===== MLKit OCR =====
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_text.** { *; }
-dontwarn com.google.mlkit.**

# ===== MediaPipe GenAI（Gemma-2B-IT）=====
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**

# ===== ONNXRuntime / 桌面端类在 Android 上不存在 =====
-dontwarn java.awt.**
-dontwarn javax.swing.**
-dontwarn org.slf4j.**
-dontwarn ai.onnxruntime.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
