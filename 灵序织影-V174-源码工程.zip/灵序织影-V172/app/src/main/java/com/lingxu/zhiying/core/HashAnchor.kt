package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip

/**
 * 静音 / 无字幕片段的视觉归位
 *
 * 当 OCR 与 ASR 双双为空（纯空镜、纯环境音）时，文本通道彻底失效。
 * 此时改用画面本身说话：计算该片段首尾帧与「相邻已确认片段（锚点）」的
 * aHash 汉明距离，相似度 > [THRESHOLD] 即判定为连续画面，自动插入到锚点旁。
 */
object HashAnchor {

    const val THRESHOLD = 0.85f

    data class Placement(val position: Int, val similarity: Float, val anchorOrder: Int)

    /**
     * @param target  待归位的片段
     * @param ordered 当前已排好序的卡片列表（含已确认锚点）
     * @return 建议插入的位置（在 ordered 中的下标），null 表示无法归位
     */
    fun place(target: AlignedClip, ordered: List<AlignedClip>): Placement? {
        if (ordered.isEmpty()) return null
        var best: Placement? = null

        ordered.forEachIndexed { i, anchor ->
            if (anchor === target) return@forEachIndexed
            if (anchor.scriptIndex < 0 || anchor.headHash0() == 0L) return@forEachIndexed

            // 情况 A：目标是锚点的后续画面（锚点尾帧 ≈ 目标首帧）
            val tailToHead = PerceptualHash.continuity(anchor.tailHash0(), target.headHash0())
            if (tailToHead > THRESHOLD && (best?.similarity ?: -1f) < tailToHead) {
                best = Placement(i + 1, tailToHead, anchor.order)
            }
            // 情况 B：目标是锚点的前置画面（目标尾帧 ≈ 锚点首帧）
            val headToTail = PerceptualHash.continuity(target.tailHash0(), anchor.headHash0())
            if (headToTail > THRESHOLD && (best?.similarity ?: -1f) < headToTail) {
                best = Placement(i, headToTail, anchor.order)
            }
            // 情况 C：同机位同场景（首首相似 / 尾尾相似），作为兜底弱判据
            val sceneSim = maxOf(
                PerceptualHash.similarity(anchor.headHash0(), target.headHash0()),
                PerceptualHash.similarity(anchor.tailHash0(), target.tailHash0())
            )
            if (sceneSim > 0.94f && (best?.similarity ?: -1f) < sceneSim) {
                best = Placement(i + 1, sceneSim, anchor.order)
            }
        }
        return best
    }

    private fun AlignedClip.headHash0(): Long = feature.headHash
    private fun AlignedClip.tailHash0(): Long = feature.tailHash
}
