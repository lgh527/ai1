package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ScriptLine

/**
 * 顺序校验与自动捋直
 *
 * 红绿灯的判定标准是**顺序**，不是文字相似度：
 *   · 🟢 绿灯 = 该片段在剧本时间线上的位置正确（与前后邻居不倒流、且已归位）
 *   · 🔴 红灯 = 顺序错误（时序倒流）或尚未归位
 *
 * 这样设计的原因：ASR 与 OCR 都可能出错别字，但**错别字不代表位置错**。
 * 以剧本文本为准，只要片段落在剧本的正确坐标上，即使提取出的字有误也算对。
 */
object OrderVerifier {

    enum class Light { GREEN, RED, GRAY }

    data class Item(val light: Light, val reason: String, val suggestBefore: Int = -1)

    /**
     * 逐张卡片判定红绿灯
     *
     * 规则：
     *  1. 未命中剧本（scriptIndex < 0）→ 红灯「未归位」
     *  2. 与前一个已归位片段相比坐标变小 → 红灯「时序倒流」
     *  3. 其余 → 绿灯
     */
    fun verify(clips: List<AlignedClip>, lines: List<ScriptLine>): List<Item> {
        val out = ArrayList<Item>(clips.size)
        var lastCoord = -1
        var lastPos = -1
        clips.forEachIndexed { i, c ->
            if (c.scriptIndex < 0) {
                out.add(Item(Light.RED, "未归位：没有匹配到剧本句", suggestPosition(clips, i)))
                return@forEachIndexed
            }
            if (lines.isNotEmpty() && c.scriptIndex >= lines.size) {
                out.add(Item(Light.RED, "坐标越界", i))
                return@forEachIndexed
            }
            if (lastCoord >= 0 && c.scriptIndex < lastCoord) {
                out.add(
                    Item(
                        Light.RED,
                        "时序倒流：剧本 #${c.scriptIndex + 1} 出现在 #${lastCoord + 1} 之后",
                        lastPos
                    )
                )
            } else {
                out.add(Item(Light.GREEN, "顺序正确：剧本 #${c.scriptIndex + 1}"))
            }
            lastCoord = c.scriptIndex
            lastPos = i
        }
        return out
    }

    private fun suggestPosition(clips: List<AlignedClip>, index: Int): Int {
        // 建议插到「坐标不大于自己的最后一个已归位片段」之后
        val me = clips[index].scriptIndex
        if (me < 0) return index
        var pos = 0
        clips.forEachIndexed { i, c ->
            if (i != index && c.scriptIndex in 0..me) pos = i + 1
        }
        return pos.coerceIn(0, clips.size - 1)
    }

    fun countRed(items: List<Item>): Int = items.count { it.light == Light.RED }

    /**
     * 一键捋直（智能校对的核心动作）
     *
     * 做法不是简单按坐标排序，而是：
     *  1. 对「已归位」片段的坐标序列求**最长不减子序列（LIS）**，
     *     这批片段本身顺序就是对的，作为锚点原地不动；
     *  2. 不在 LIS 里的片段（即造成倒流的少数）按坐标插到最近的锚点之间；
     *  3. 未归位片段用帧哈希找最连续的邻居插入，找不到就留在原位等人工处理。
     *
     * 这样能把「大部分对、少数错位」的序列一次性捋直，
     * 而不会像全局排序那样把用户已经手动调好的部分冲掉。
     *
     * @return 被移动的卡片数量
     */
    fun straighten(clips: MutableList<AlignedClip>): Int {
        if (clips.size < 2) return 0
        val before = clips.map { it.feature.id }

        val matchedIdx = clips.indices.filter { clips[it].scriptIndex >= 0 }
        val keep = lisPositions(matchedIdx.map { clips[it].scriptIndex })
        val anchors = LinkedHashSet<Int>()
        keep.forEach { k -> anchors.add(matchedIdx[k]) }

        val result = ArrayList<AlignedClip>(clips.size)
        // 1. 先按锚点搭骨架
        val loose = ArrayList<AlignedClip>()
        clips.forEachIndexed { i, c ->
            if (anchors.contains(i)) result.add(c) else loose.add(c)
        }

        // 2. 已归位但造成倒流的片段：插到坐标最接近的位置
        val placed = ArrayList<AlignedClip>()
        val leftovers = ArrayList<AlignedClip>()
        loose.forEach { c ->
            if (c.scriptIndex >= 0) placed.add(c) else leftovers.add(c)
        }
        placed.sortedBy { it.scriptIndex }.forEach { c ->
            var insertAt = result.size
            for (i in result.indices) {
                if (result[i].scriptIndex > c.scriptIndex) { insertAt = i; break }
            }
            result.add(insertAt.coerceIn(0, result.size), c)
        }

        // 3. 未归位片段：用帧哈希找最连续的邻居
        leftovers.forEach { c ->
            var bestPos = -1
            var bestSim = 0.85f
            for (i in result.indices) {
                val sim = PerceptualHash.continuity(result[i].feature.tailHash, c.feature.headHash)
                if (sim > bestSim) { bestSim = sim; bestPos = i + 1 }
            }
            if (bestPos < 0) {
                // 退一步：按文件名自然序位置估算
                bestPos = (c.naturalPos.toFloat() / clips.size.coerceAtLeast(1) * result.size)
                    .toInt().coerceIn(0, result.size)
            }
            result.add(bestPos.coerceIn(0, result.size), c)
        }

        clips.clear()
        clips.addAll(result)
        clips.forEachIndexed { i, c -> c.order = i + 1 }

        val after = clips.map { it.feature.id }
        var moved = 0
        before.forEachIndexed { i, id -> if (i < after.size && after[i] != id) moved++ }
        return moved
    }

    /**
     * 最长不减子序列，返回原数组中的下标集合。
     * 用「坐标 + 原始位置」双关键字保证稳定，相同坐标允许并列（一镜多切）。
     */
    private fun lisPositions(values: List<Int>): List<Int> {
        if (values.isEmpty()) return emptyList()
        val n = values.size
        val prev = IntArray(n) { -1 }
        // tails[k] = 长度为 k+1 的不减子序列的最小结尾对应的下标
        val tails = ArrayList<Int>()
        for (i in 0 until n) {
            val v = values[i]
            // 找第一个 > v 的位置（不减 → 允许相等，故用 upperBound）
            var lo = 0
            var hi = tails.size
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (values[tails[mid]] <= v) lo = mid + 1 else hi = mid
            }
            if (lo > 0) prev[i] = tails[lo - 1]
            if (lo == tails.size) tails.add(i) else tails[lo] = i
        }
        val out = ArrayList<Int>(tails.size)
        var cur = if (tails.isEmpty()) -1 else tails[tails.size - 1]
        while (cur >= 0) {
            out.add(cur)
            cur = prev[cur]
        }
        out.reverse()
        return out
    }
}
