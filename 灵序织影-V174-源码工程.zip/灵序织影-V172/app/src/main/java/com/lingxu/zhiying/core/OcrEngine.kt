package com.lingxu.zhiying.core

import android.content.Context
import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions

/**
 * 视觉大模型：Google ML Kit 中文离线文字识别
 *
 * 与 [SubtitleBand] 配合：先定位字幕带、动态放大，再送 OCR。
 * 全流程离线，断网可用。
 */
object OcrEngine {

    @Volatile
    private var recognizer: com.google.mlkit.vision.text.TextRecognizer? = null

    private val NOISE = Regex("[\\s\\-_=*#|\\\\/{}\\[\\]<>~`]+")
    private val WATERMARK_HINT = Regex("(高清|无水印|字幕组|www\\.|http|\\.com|\\.cn|抖音|快手|B站| bilibili )", RegexOption.IGNORE_CASE)

    fun init(context: Context) {
        if (recognizer == null) {
            synchronized(this) {
                if (recognizer == null) {
                    recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                    LogX.i("OcrEngine", "ML Kit 中文 OCR 已就绪")
                }
            }
        }
    }

    /** 同步识别单帧，返回清洗后的文本 */
    fun recognize(bitmap: Bitmap?): String {
        if (bitmap == null) return ""
        val client = recognizer ?: return ""
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = Tasks.await(client.process(image))
            clean(result.text)
        } catch (e: Throwable) {
            LogX.w("OcrEngine", "识别失败: ${e.message}")
            ""
        }
    }

    /**
     * 多帧合并：同一句字幕会在连续多帧重复出现，
     * 这里按「行」去重并保留出现次数最多的表达，抑制单帧误识别。
     */
    fun mergeFrames(texts: List<String>): String {
        val counter = LinkedHashMap<String, Int>()
        texts.filter { it.isNotBlank() }.forEach { t ->
            t.split('\n').map { it.trim() }.filter { it.length >= 2 }.forEach { line ->
                counter[line] = (counter[line] ?: 0) + 1
            }
        }
        if (counter.isEmpty()) return ""
        // 出现 2 次以上的行更可信，优先保留；孤行按原顺序补足
        val reliable = counter.filter { it.value >= 2 }.keys
        val singles = counter.keys.filter { it !in reliable }
        val picked = if (reliable.isNotEmpty()) reliable + singles else counter.keys
        return picked.joinToString("") { it }
    }

    private fun clean(raw: String): String {
        var s = raw
        // 去掉 OCR 常见的换行断句，中文台词不需要
        s = s.replace("\n", "")
        // 去水印/域名等干扰串
        s = WATERMARK_HINT.replace(s, "")
        s = NOISE.replace(s, "")
        // 只保留中文、字母、数字与基本标点
        s = s.filter { it.code in 0x4E00..0x9FA5 || it.isLetterOrDigit() || it in "，。！？、；：“”‘’" }
        return s.trim()
    }

    fun release() {
        try {
            recognizer?.close()
        } catch (_: Throwable) {
        }
        recognizer = null
    }
}
