package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip
import com.lingxu.zhiying.model.ScriptLine

/**
 * 剧本覆盖率校验
 *
 * 「100% 对齐」不能靠自动算法打包票，但可以做到**可验证**：
 * 每一句剧本是否都有素材覆盖、每个素材是否都落到了剧本坐标上、
 * 最终顺序是否严格不倒流——三件事全部量化成报告，
 * 用户照着报告补漏，就能把结果收敛到 100%。
 */
object CoverageChecker {

    data class Report(
        val totalLines: Int,
        val coveredLines: Int,
        val missingLines: List<Int>,          // 没有素材覆盖的剧本句序号
        val unmatchedClips: List<Int>,        // 没落到任何剧本句的片段序号
        val backwardPairs: List<Pair<Int, Int>>, // 时序倒流的相邻片段对（前, 后）
        val duplicateLines: List<Int>         // 被多个片段占用的剧本句
    ) {
        val coverage: Float
            get() = if (totalLines == 0) 1f else coveredLines.toFloat() / totalLines

        val isPerfect: Boolean
            get() = missingLines.isEmpty() && unmatchedClips.isEmpty() && backwardPairs.isEmpty()

        fun summary(lines: List<ScriptLine>): String {
            val sb = StringBuilder()
            sb.append("剧本覆盖率 ${(coverage * 100).toInt()}%（$coveredLines/$totalLines 句）\n")
            if (missingLines.isNotEmpty()) {
                sb.append("⚠️ 缺素材的剧本句 ${missingLines.size} 处：")
                sb.append(missingLines.take(6).joinToString("、") {
                    "#${it + 1}「${lines.getOrNull(it)?.text?.take(12) ?: ""}」"
                })
                if (missingLines.size > 6) sb.append(" …")
                sb.append("\n")
            }
            if (unmatchedClips.isNotEmpty()) {
                sb.append("⚠️ 未归位片段 ${unmatchedClips.size} 个：")
                sb.append(unmatchedClips.take(8).joinToString("、") { "第${it + 1}张卡" })
                sb.append("\n")
            }
            if (backwardPairs.isNotEmpty()) {
                sb.append("⚠️ 时序倒流 ${backwardPairs.size} 处：")
                sb.append(backwardPairs.take(5).joinToString("、") {
                    "卡${it.first + 1}(#${scriptOf(it.first)})→卡${it.second + 1}"
                })
                sb.append("\n")
            }
            if (duplicateLines.isNotEmpty()) {
                sb.append("ℹ️ 一句对应多片段 ${duplicateLines.size} 处（混剪中正常）\n")
            }
            if (isPerfect) sb.append("✅ 已完全对齐：每句剧本都有素材，且顺序严格不倒流")
            return sb.toString().trim()
        }

        private fun scriptOf(cardIndex: Int) = cardIndex
    }

    fun check(clips: List<AlignedClip>, lines: List<ScriptLine>): Report {
        val covered = HashSet<Int>()
        val unmatched = ArrayList<Int>()
        clips.forEachIndexed { i, c ->
            if (c.scriptIndex in lines.indices) covered.add(c.scriptIndex) else unmatched.add(i)
        }
        val missing = lines.indices.filter { it !in covered }

        // 时序倒流：按当前卡片顺序，后一张的剧本坐标严格小于前一张（忽略未命中的）
        val backward = ArrayList<Pair<Int, Int>>()
        var lastIdx = -1
        var lastPos = -1
        clips.forEachIndexed { i, c ->
            if (c.scriptIndex < 0) return@forEachIndexed
            if (lastIdx >= 0 && c.scriptIndex < lastIdx) backward.add(lastPos to i)
            lastIdx = c.scriptIndex
            lastPos = i
        }

        // 一句多片段
        val counter = HashMap<Int, Int>()
        clips.forEach { c -> if (c.scriptIndex >= 0) counter[c.scriptIndex] = (counter[c.scriptIndex] ?: 0) + 1 }
        val duplicates = counter.filter { it.value > 1 }.keys.sorted()

        return Report(
            totalLines = lines.size,
            coveredLines = covered.size,
            missingLines = missing,
            unmatchedClips = unmatched,
            backwardPairs = backward,
            duplicateLines = duplicates
        )
    }

    /**
     * 一键按剧本坐标重排：把所有已命中片段按 scriptIndex 升序稳定排序，
     * 未命中的片段保持相对位置塞在原处附近，供用户继续手工处理。
     * 这是「拨乱反正」的最后一道保险——即使手动微调把顺序弄乱了，也能一键回到剧本序。
     */
    fun sortToScriptOrder(clips: MutableList<AlignedClip>): Int {
        var moved = 0
        val before = clips.map { it.feature.id }
        // 稳定排序：命中优先，其次按剧本坐标，再按当前顺序
        val indexed = clips.mapIndexed { i, c -> Triple(i, c.scriptIndex, c) }
        val sorted = indexed.sortedWith(
            compareBy({ if (it.second < 0) 1 else 0 }, { it.second }, { it.first })
        ).map { it.third }
        clips.clear()
        clips.addAll(sorted)
        clips.forEachIndexed { i, c -> c.order = i + 1 }
        val after = clips.map { it.feature.id }
        before.forEachIndexed { i, id -> if (i < after.size && after[i] != id) moved++ }
        return moved
    }
}
