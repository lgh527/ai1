package com.lingxu.zhiying.core

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * 字幕带检测（Subtitle Band Detection）
 *
 * 将画面纵向分为上、中、下三区，每 [ROW_STEP] 像素为一行切片，
 * 统计该行的「像素亮度平均值」与「高亮像素占比」，满足阈值即判定为字幕所在行带。
 *
 * 判定条件按真实影视素材校准（白字暗底为主）：
 *   · 行平均亮度不能太高（整屏亮画面不是字幕）
 *   · 但必须存在一定比例的高亮像素（字幕笔画）
 *   · 高亮占比不能过高（大面积白墙 / 过曝天空会被排除）
 *
 * 单帧判定容易受画面内容干扰，因此提供**跨帧投票**接口：
 * 字幕在一段视频里位置固定，累计命中次数最多的行带才是真正的字幕带。
 */
object SubtitleBand {

    const val ROW_STEP = 10            // 每 10 像素一行切片
    private const val BRIGHT_PIXEL = 200   // 单像素判定为「高亮」的亮度
    private const val MAX_ROW_AVG = 215    // 行平均亮度上限，超过说明是亮背景而非字幕行
    private const val MIN_ROW_AVG = 12     // 全黑行不含信息
    private const val MIN_BRIGHT_RATIO = 0.012f  // 高亮占比下限
    private const val MAX_BRIGHT_RATIO = 0.78f   // 高亮占比上限
    private const val LOOSE_BRIGHT_RATIO = 0.05f // 无亮度约束时的强判据
    const val MIN_BAND_HEIGHT = 80     // 小于该高度触发放大增强

    data class Band(
        val top: Int,
        val bottom: Int,
        val zone: Zone,
        val score: Float,
        val votes: Int = 0
    ) {
        val height: Int get() = bottom - top
    }

    enum class Zone { TOP, MIDDLE, BOTTOM }

    // ==================================================================
    //  跨帧投票（推荐用法）
    // ==================================================================

    /** 行票数累加器，rows = ceil(height / ROW_STEP) */
    class VoteSheet(val height: Int) {
        val rows: Int = max(1, (height + ROW_STEP - 1) / ROW_STEP)
        val hits = IntArray(rows)
        val lumaSum = LongArray(rows)
        var frames = 0

        fun accumulate(bmp: Bitmap) {
            frames++
            val w = bmp.width
            val h = min(bmp.height, height)
            val xStep = max(1, w / 200)
            val samplesPerRow = max(1, w / xStep)
            var y = 0
            var rowIdx = 0
            while (y < h) {
                var rowLuma = 0L
                var bright = 0
                var count = 0
                var yy = y
                while (yy < min(h, y + ROW_STEP)) {
                    var xx = 0
                    while (xx < w) {
                        val px = bmp.getPixel(xx, yy)
                        val l = (0.299 * Color.red(px) + 0.587 * Color.green(px) + 0.114 * Color.blue(px)).toInt()
                        rowLuma += l
                        if (l >= BRIGHT_PIXEL) bright++
                        count++
                        xx += xStep
                    }
                    yy += 2
                }
                if (count > 0 && rowIdx < rows) {
                    val avg = (rowLuma / count).toInt()
                    val ratio = bright.toFloat() / samplesPerRow
                    lumaSum[rowIdx] = lumaSum[rowIdx] + avg
                    if (isSubtitleRow(avg, ratio)) hits[rowIdx]++
                }
                rowIdx++
                y += ROW_STEP
            }
        }

        /** 取得票最高的连续行带；票数为 0 返回 null */
        fun bestBand(): Band? {
            if (frames == 0) return null
            // 至少 30% 的帧命中才算稳定字幕带
            val minVotes = max(1, frames * 3 / 10)
            var bestStart = -1
            var bestScore = -1f
            var bestVotes = 0
            var i = 0
            while (i < rows) {
                if (hits[i] >= minVotes) {
                    var j = i
                    var votes = 0
                    while (j < rows && hits[j] >= minVotes) {
                        votes += hits[j]; j++
                    }
                    val top = i * ROW_STEP
                    val bottom = min(height, j * ROW_STEP)
                    val heightPx = bottom - top
                    if (heightPx in 12..260) {
                        val score = votes.toFloat() / frames
                        if (score > bestScore) {
                            bestScore = score; bestStart = i; bestVotes = votes
                        }
                    }
                    i = j
                } else i++
            }
            if (bestStart < 0) return null
            var end = bestStart
            while (end < rows && hits[end] >= minVotes) end++
            val top = bestStart * ROW_STEP
            val bottom = min(height, end * ROW_STEP)
            return Band(top, bottom, zoneOf(top, bottom, height), bestScore, bestVotes)
        }
    }

    private fun isSubtitleRow(avg: Int, brightRatio: Float): Boolean {
        if (brightRatio > LOOSE_BRIGHT_RATIO && brightRatio <= MAX_BRIGHT_RATIO) return true
        return avg in MIN_ROW_AVG..MAX_ROW_AVG &&
                brightRatio in MIN_BRIGHT_RATIO..MAX_BRIGHT_RATIO
    }

    private fun zoneOf(top: Int, bottom: Int, h: Int): Zone {
        val center = (top + bottom) / 2
        return when {
            center < h * 30 / 100 -> Zone.TOP
            center < h * 65 / 100 -> Zone.MIDDLE
            else -> Zone.BOTTOM
        }
    }

    // ==================================================================
    //  单帧检测（兜底用法）
    // ==================================================================

    fun detect(src: Bitmap?): Band? {
        if (src == null) return null
        if (src.width < 32 || src.height < 32) return null
        val sheet = VoteSheet(src.height)
        sheet.accumulate(src)
        // 单帧时放宽票数要求
        var best: Band? = null
        val w = src.width
        val h = src.height
        val xStep = max(1, w / 200)
        val samples = max(1, w / xStep)
        var y = 0
        var start = -1
        while (y < h) {
            var lumaSum = 0L; var bright = 0; var count = 0
            var yy = y
            while (yy < min(h, y + ROW_STEP)) {
                var xx = 0
                while (xx < w) {
                    val p = src.getPixel(xx, yy)
                    val l = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
                    lumaSum += l
                    if (l >= BRIGHT_PIXEL) bright++
                    count++
                    xx += xStep
                }
                yy += 2
            }
            val avg = if (count > 0) (lumaSum / count).toInt() else 0
            val ratio = if (count > 0) bright.toFloat() / samples else 0f
            if (isSubtitleRow(avg, ratio)) {
                if (start < 0) start = y
            } else if (start >= 0) {
                val band = finish(start, y, h)
                if (band != null && (best == null || band.height > best.height)) best = band
                start = -1
            }
            y += ROW_STEP
        }
        if (start >= 0) {
            val band = finish(start, h, h)
            if (band != null && (best == null || band.height > best.height)) best = band
        }
        return best
    }

    private fun finish(top: Int, bottom: Int, h: Int): Band? {
        val height = bottom - top
        if (height < 12 || height > 260) return null
        return Band(top, bottom, zoneOf(top, bottom, h), 0.5f, 1)
    }

    /**
     * 动态缩放增强：字幕高度小于 [MIN_BAND_HEIGHT] 像素时等比放大 2~4 倍再送 OCR。
     * 放大倍数按「目标高度 160 像素」反推，并夹在 [2,4]。
     */
    fun cropAndEnhance(src: Bitmap, band: Band, enabled: Boolean): Bitmap {
        val pad = (band.height * 0.4f).toInt()
        val top = max(0, band.top - pad)
        val bottom = min(src.height, band.bottom + pad)
        val cropH = max(1, bottom - top)
        val crop = Bitmap.createBitmap(src, 0, top, src.width, cropH)
        if (!enabled) return crop
        if (cropH >= MIN_BAND_HEIGHT) return crop
        val scale = (160f / cropH).coerceIn(2f, 4f)
        val nw = max(1, (crop.width * scale).toInt())
        val nh = max(1, (cropH * scale).toInt())
        val scaled = Bitmap.createScaledBitmap(crop, nw, nh, true)
        if (scaled !== crop) crop.recycle()
        return scaled
    }
}
