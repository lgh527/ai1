package com.lingxu.zhiying.security

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.os.Process
import java.io.File
import java.security.MessageDigest

/**
 * 企业级安全防御
 *
 * 1. 动态签名校验：启动时读取当前 APK 的 SHA-256 签名，与硬编码在代码里的原生签名比对，
 *    一旦被二次打包（重签名），直接 killProcess 闪退。
 * 2. 反调试：Debug.isDebuggerConnected() + /proc/self/status 的 TracerPid 双重探测。
 * 3. 反 Hook 环境探测：常见 Xposed / Frida 特征文件与类名扫描。
 *
 * 注意：CI（GitHub Actions）会用 keytool 生成临时证书，并用 sed 把
 * YOUR_APP_SIGNATURE_PLACEHOLDER 替换成真实的 SHA-256 十六进制串。
 */
object SignatureGuard {

    /** CI 构建时会被 sed 替换为真实签名指纹（32 组大写十六进制，无冒号） */
    private const val EXPECTED_SIGNATURE = "YOUR_APP_SIGNATURE_PLACEHOLDER"

    private const val PLACEHOLDER = "YOUR_APP_SIGNATURE_PLACEHOLDER"

    /** 是否严格模式：签名占位符未被替换时（本地调试构建）不闪退 */
    var strictMode: Boolean = true

    data class Verdict(
        val pass: Boolean,
        val reason: String,
        val currentSignature: String
    )

    fun verify(context: Context): Verdict {
        // ---- 反调试 ----
        if (Debug.isDebuggerConnected()) {
            return Verdict(false, "检测到调试器注入", currentSignature(context))
        }
        if (isTracerAttached()) {
            return Verdict(false, "检测到进程被跟踪", currentSignature(context))
        }
        // ---- 反 Hook ----
        if (isHookFrameworkPresent()) {
            return Verdict(false, "检测到 Hook 框架", currentSignature(context))
        }
        // ---- 签名校验 ----
        val current = currentSignature(context)
        if (EXPECTED_SIGNATURE == PLACEHOLDER) {
            // 占位符未替换：说明是开发期构建，记录但不处决
            return Verdict(true, "开发构建：签名占位符未注入", current)
        }
        return if (current.equals(EXPECTED_SIGNATURE, ignoreCase = true)) {
            Verdict(true, "签名校验通过", current)
        } else {
            Verdict(false, "签名不匹配，疑似二次打包", current)
        }
    }

    /** 校验失败时的处决动作 */
    fun execute(activity: Activity?, verdict: Verdict) {
        if (verdict.pass) return
        if (!strictMode) return
        android.util.Log.e("SignatureGuard", "安全校验失败：${verdict.reason}")
        try {
            activity?.finishAffinity()
        } catch (_: Throwable) {
        }
        try {
            Process.killProcess(Process.myPid())
        } catch (_: Throwable) {
        }
        kotlin.system.exitProcess(0)
    }

    fun currentSignature(context: Context): String {
        return try {
            val pm = context.packageManager
            val pkg = context.packageName
            val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
                val histories = info.signingInfo
                when {
                    histories == null -> null
                    histories.hasMultipleSigners() -> histories.apkContentsSigners?.firstOrNull()?.toByteArray()
                    else -> histories.signingCertificateHistory?.firstOrNull()?.toByteArray()
                }
            } else {
                @Suppress("DEPRECATION")
                val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES)
                @Suppress("DEPRECATION")
                info.signatures?.firstOrNull()?.toByteArray()
            }
            if (sigBytes == null) "" else sha256Hex(sigBytes)
        } catch (e: Throwable) {
            ""
        }
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        val sb = StringBuilder(digest.size * 2)
        digest.forEach { b ->
            val v = b.toInt() and 0xFF
            if (v < 0x10) sb.append('0')
            sb.append(Integer.toHexString(v))
        }
        return sb.toString().uppercase()
    }

    private fun isTracerAttached(): Boolean {
        return try {
            val f = File("/proc/self/status")
            if (!f.exists()) return false
            f.useLines { lines ->
                lines.firstOrNull { it.startsWith("TracerPid:") }
                    ?.substringAfter(":")?.trim()?.toIntOrNull()?.let { it != 0 } ?: false
            }
        } catch (e: Throwable) {
            false
        }
    }

    private fun isHookFrameworkPresent(): Boolean {
        val paths = listOf(
            "/system/framework/XposedBridge.jar",
            "/system/lib/libxposed_art.so",
            "/data/local/tmp/re.frida.server",
            "/system/bin/frida-server"
        )
        if (paths.any { File(it).exists() }) return true
        val classes = listOf("de.robv.android.xposed.XposedHelpers", "de.robv.android.xposed.IXposedHookLoadPackage")
        classes.forEach { cn ->
            try {
                Class.forName(cn)
                return true
            } catch (_: Throwable) {
            }
        }
        return false
    }
}
