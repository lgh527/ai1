package com.lingxu.zhiying.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 文本匹配算法
 *
 * 1. Bigram 词频相似度：文本拆成相邻双字，算交集/并集比例，容忍错别字与 OCR 漏字。
 * 2. 拼音相似度：借助 [PinyinTable] 投影到拼音空间，比对声母与韵母，
 *    彻底解决 ASR 同音字干扰（"直到" vs "知道"）。
 * 3. 滑窗包含度：剧本一句话往往只是 ASR 长文本中的一小段，
 *    直接在长文本上滑窗取最大相似度，避免整段比对被稀释。
 */
object TextSimilarity {

    /** 声母表：用于拆分拼音 */
    private val INITIALS = listOf(
        "zh", "ch", "sh", "b", "p", "m", "f", "d", "t", "n", "l",
        "g", "k", "h", "j", "q", "x", "r", "z", "c", "s", "y", "w"
    )

    private val PUNCT = Regex("[\\s\\p{Punct}\\u201C\\u201D\\u2018\\u2019\\u300A\\u300B\\u3008\\u3009\\u3010\\u3011\\uFF08\\uFF09\\u2026\\u2014\\uFF5E\\uFF0C\\u3002\\uFF01\\uFF1F\\u3001\\uFF1B\\uFF1A]")

    fun normalize(s: String): String =
        PUNCT.replace(s, "").lowercase().filter { it.isLetterOrDigit() || it.code in 0x4E00..0x9FA5 }

    // ---------- 1. Bigram ----------

    fun bigrams(s: String): Set<String> {
        val t = normalize(s)
        if (t.isEmpty()) return emptySet()
        if (t.length == 1) return setOf(t)
        val out = LinkedHashSet<String>(t.length)
        for (i in 0 until t.length - 1) out.add(t.substring(i, i + 2))
        return out
    }

    /** Jaccard：交集 / 并集 */
    fun bigramSimilarity(a: String, b: String): Float {
        val sa = bigrams(a)
        val sb = bigrams(b)
        if (sa.isEmpty() || sb.isEmpty()) return 0f
        val inter = sa.intersect(sb).size
        val union = sa.union(sb).size
        if (union == 0) return 0f
        // 长度差过大时做轻微惩罚，避免短句蹭上长句
        val lenPenalty = min(sa.size, sb.size).toFloat() / max(sa.size, sb.size).toFloat()
        return (inter.toFloat() / union) * (0.6f + 0.4f * lenPenalty)
    }

    // ---------- 2. 拼音 ----------

    private fun splitPinyin(py: String): Pair<String, String> {
        val lower = py.lowercase()
        for (ini in INITIALS) {
            if (lower.startsWith(ini) && lower.length > ini.length) {
                return ini to lower.substring(ini.length)
            }
        }
        return "" to lower
    }

    /** 两个拼音的相似度：全等 1.0，声母同 0.45，韵母同 0.45 */
    private fun pinyinCharScore(p1: String, p2: String): Float {
        if (p1 == p2) return 1f
        if (p1.length < 2 || p2.length < 2) return 0f
        val (i1, f1) = splitPinyin(p1)
        val (i2, f2) = splitPinyin(p2)
        var score = 0f
        if (i1.isNotEmpty() && i1 == i2) {
            score += 0.45f
        } else if (fuzzyInitial(i1, i2)) {
            // 平翘舌、n/l、f/h 视为近音，给少量分数
            score += 0.15f
        }
        // 前后鼻音视为同韵
        if (f1 == f2 || nasalEqual(f1, f2)) {
            score += 0.45f
        }
        return score.coerceIn(0f, 1f)
    }

    private fun nasalEqual(f1: String, f2: String): Boolean {
        val a = f1.removeSuffix("n").removeSuffix("ng")
        val b = f2.removeSuffix("n").removeSuffix("ng")
        return a.isNotEmpty() && a == b && (f1.endsWith("n") || f1.endsWith("ng")) &&
                (f2.endsWith("n") || f2.endsWith("ng"))
    }

    private fun fuzzyInitial(i1: String, i2: String): Boolean {
        val groups = listOf(setOf("z", "zh"), setOf("c", "ch"), setOf("s", "sh"), setOf("n", "l"), setOf("f", "h"))
        return groups.any { i1 in it && i2 in it }
    }

    /** 逐字对齐（长度不同则按短的一方截断），取平均拼音相似度 */
    fun pinyinSimilarity(a: String, b: String): Float {
        val pa = PinyinTable.of(normalize(a))
        val pb = PinyinTable.of(normalize(b))
        if (pa.isEmpty() || pb.isEmpty()) return 0f
        val n = min(pa.size, pb.size)
        var sum = 0f
        for (i in 0 until n) sum += pinyinCharScore(pa[i], pb[i])
        val lenRatio = n.toFloat() / max(pa.size, pb.size).toFloat()
        return (sum / n) * (0.5f + 0.5f * lenRatio)
    }

    // ---------- 3. 滑窗包含度 ----------

    /**
     * 在长文本 longText 中滑窗寻找与 shortText 最相似的片段。
     * 窗口取 shortText 长度的 0.8~1.6 倍，步长 2 字。
     */
    fun bestWindowMatch(shortText: String, longText: String): Float {
        val s = normalize(shortText)
        val l = normalize(longText)
        if (s.isEmpty() || l.isEmpty()) return 0f
        if (l.length <= s.length + 2) return combined(s, l)
        var best = 0f
        val base = s.length
        val ratios = listOf(0.8f, 1.0f, 1.25f, 1.6f)
        for (r in ratios) {
            val win = max(2, (base * r).toInt())
            var i = 0
            while (i + win <= l.length) {
                val v = combined(s, l.substring(i, i + win))
                if (v > best) best = v
                i += 2
            }
            // 末尾补一窗
            val tail = l.substring(max(0, l.length - win))
            best = max(best, combined(s, tail))
        }
        return best
    }

    /**
     * 综合相似度。
     *
     * 取「加权融合」与「单通道最高分」的较大值：
     *   · 错别字/漏字场景 → Bigram 高、拼音低，加权会把它拉下去，所以保留 Bigram 单通道
     *   · ASR 同音字场景 → 拼音高、Bigram 低，同理保留拼音单通道
     * 只有两个通道都不行时，才判定为不匹配。
     */
    fun combined(a: String, b: String): Float {
        val bs = bigramSimilarity(a, b)
        val ps = pinyinSimilarity(a, b)
        val blended = bs * 0.55f + ps * 0.45f
        return maxOf(blended, bs * 0.92f, ps * 0.92f)
    }

    /**
     * 时长-字数一致性因子。
     *
     * 中文正常语速约 3.5 字/秒。若剧本句字数与「片段时长 × 3.5」差得太远，
     * 说明这句台词不太可能整段落在这个片段里，给一个衰减。
     * 只惩罚明显离谱的情况（偏差 > 80%），避免误伤短句。
     */
    fun durationFactor(scriptLine: String, durationMs: Long): Float {
        if (durationMs <= 0) return 1f
        val chars = normalize(scriptLine).length
        if (chars == 0) return 1f
        val expected = durationMs / 1000f * 3.5f
        val diff = kotlin.math.abs(expected - chars)
        return if (diff > expected * 0.8f) 0.6f else 1f
    }

    /**
     * 一条素材 vs 一句剧本的最终得分。
     * OCR 文本通常就是台词，权重高；ASR 可能含背景杂音，走滑窗。
     */
    fun score(scriptLine: String, ocrText: String, asrText: String): Pair<Float, Float> {
        val visual = if (ocrText.isBlank()) 0f else bestWindowMatch(scriptLine, ocrText)
        val audio = if (asrText.isBlank()) 0f else bestWindowMatch(scriptLine, asrText)
        return visual to audio
    }

    /** 交叉融合：两通道都有信号时相互印证，取加权并给出加成 */
    fun fuse(visual: Float, audio: Float): Float {
        if (visual <= 0f) return audio * 0.85f
        if (audio <= 0f) return visual * 0.9f
        // 双轨印证（1+1>2）：字幕和语音在同一句剧本上都达到可信阈值，
        // 说明两条独立通道相互印证，直接判定为满分命中
        if (visual >= CONFIRM_THRESHOLD && audio >= CONFIRM_THRESHOLD) return 1f
        val base = visual * 0.55f + audio * 0.45f
        // 方向一致时给印证加成
        val agreement = 1f - min(1f, abs(visual - audio) * 2f)
        val boosted = base + 0.25f * base * agreement
        return boosted.coerceIn(0f, 1f)
    }

    /** 双轨印证阈值：两个通道都超过它才认定互相印证 */
    const val CONFIRM_THRESHOLD = 0.45f
}
