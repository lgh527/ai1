package com.lingxu.zhiying.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/**
 * 视频探针：读取时长与分辨率，用于拼接前的编码格式一致性判定。
 */
object VideoProbe {

    data class Info(
        val durationMs: Long,
        val width: Int,
        val height: Int,
        val vCodec: String,
        val aCodec: String
    )

    fun probe(path: String): Info {
        var info = Info(0L, 0, 0, "", "")
        try {
            val session = FFprobeKit.execute(
                "-v error -select_streams v:0 -show_entries stream=width,height,codec_name " +
                        "-show_entries format=duration -of default=noprint_wrappers=1 \"$path\""
            )
            val out = session.output ?: ""
            var w = 0; var h = 0; var v = ""; var dur = 0.0
            out.split('\n').forEach { line ->
                val kv = line.split('=', limit = 2)
                if (kv.size != 2) return@forEach
                when (kv[0].trim()) {
                    "width" -> w = kv[1].trim().toIntOrNull() ?: w
                    "height" -> h = kv[1].trim().toIntOrNull() ?: h
                    "codec_name" -> if (v.isEmpty()) v = kv[1].trim()
                    "duration" -> dur = kv[1].trim().toDoubleOrNull() ?: dur
                }
            }
            val asess = FFprobeKit.execute(
                "-v error -select_streams a:0 -show_entries stream=codec_name -of csv=p=0 \"$path\""
            )
            val a = (asess.output ?: "").trim().lineSequence().firstOrNull()?.trim() ?: ""
            info = Info((dur * 1000).toLong(), w, h, v, a)
        } catch (e: Throwable) {
            LogX.e("VideoProbe", "probe 失败: ${e.message}")
        }
        return info
    }
}

/**
 * 视觉特征提取管线
 *
 * 1. FFmpeg 以 fps=2 抽帧为 JPG
 * 2. 首帧 / 尾帧生成 aHash 感知指纹
 * 3. 逐帧做字幕带检测 + 动态缩放增强，交给 OcrEngine 识别
 */
class FrameExtractor(private val context: Context) {

    private val workDir: File
        get() = File(context.cacheDir, "frames").apply { if (!exists()) mkdirs() }

    /** 抽帧，返回按时间顺序排列的 JPG 文件 */
    fun extract(videoPath: String, clipId: Int, fps: Int = 2): List<File> {
        val dir = File(workDir, "c$clipId").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }
        val pattern = File(dir, "f_%04d.jpg").absolutePath
        // -vf fps=2 抽帧，-q:v 3 保证画质足够 OCR，同时体积可控
        val cmd = "-hide_banner -loglevel error -y -i \"$videoPath\" -vf fps=$fps -q:v 3 \"$pattern\""
        val session = FFmpegKit.execute(cmd)
        if (!ReturnCode.isSuccess(session.returnCode)) {
            LogX.w("FrameExtractor", "抽帧非零退出，尝试降级为单帧: ${session.output}")
            val single = File(dir, "f_0001.jpg").absolutePath
            FFmpegKit.execute("-hide_banner -loglevel error -y -i \"$videoPath\" -frames:v 1 -q:v 3 \"$single\"")
        }
        return dir.listFiles { f -> f.name.endsWith(".jpg") }
            ?.sortedBy { it.name }
            ?: emptyList()
    }

    /** 提取首帧与尾帧（用于 aHash 与视觉归位） */
    fun extractHeadTail(videoPath: String, clipId: Int): Pair<Bitmap?, Bitmap?> {
        val dir = File(workDir, "ht$clipId").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }
        val head = File(dir, "head.jpg").absolutePath
        val tail = File(dir, "tail.jpg").absolutePath
        FFmpegKit.execute("-hide_banner -loglevel error -y -i \"$videoPath\" -frames:v 1 -q:v 2 \"$head\"")
        // sseof -0.5 从倒数 0.5 秒处取一帧，作为尾帧
        FFmpegKit.execute("-hide_banner -loglevel error -y -sseof -0.5 -i \"$videoPath\" -frames:v 1 -q:v 2 \"$tail\"")
        val hb = decodeSampled(head, 256)
        var tb = decodeSampled(tail, 256)
        if (tb == null) tb = hb
        return hb to tb
    }

    fun decodeSampled(path: String, maxSide: Int): Bitmap? {
        val f = File(path)
        if (!f.exists() || f.length() <= 0) return null
        return try {
            val opt = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opt)
            var sample = 1
            while (opt.outWidth / sample > maxSide * 2 || opt.outHeight / sample > maxSide * 2) sample *= 2
            val opt2 = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(path, opt2)
        } catch (e: Throwable) {
            LogX.w("FrameExtractor", "解码失败 $path: ${e.message}")
            null
        }
    }

    fun clean(clipId: Int) {
        File(workDir, "c$clipId").deleteRecursively()
        File(workDir, "ht$clipId").deleteRecursively()
    }

    fun cleanAll() {
        workDir.deleteRecursively()
    }
}
