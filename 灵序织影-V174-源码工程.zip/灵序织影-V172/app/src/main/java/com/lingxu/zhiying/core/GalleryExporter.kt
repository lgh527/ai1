package com.lingxu.zhiying.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File

/**
 * 成片导出：通过 MediaStore API 安全写入系统相册
 *
 * 适配 Android 10+ 分区存储与 Android 13+ 的 READ_MEDIA_VIDEO 权限：
 *   1. insert 时置 IS_PENDING = 1，避免半成品出现在相册里被用户看到；
 *   2. 写完后置 IS_PENDING = 0 正式提交；
 *   3. Android 9 及以下退回 DATA 列直写文件路径。
 */
object GalleryExporter {

    private const val DIR_NAME = "灵序织影"

    fun export(context: Context, src: File, displayName: String = defaultName()): Uri? {
        if (!src.exists() || src.length() <= 0) {
            LogX.e("GalleryExporter", "成片文件不存在")
            return null
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                exportQ(context, src, displayName)
            } else {
                exportLegacy(context, src, displayName)
            }
        } catch (e: Throwable) {
            LogX.e("GalleryExporter", "导出失败", e)
            null
        }
    }

    private fun exportQ(context: Context, src: File, displayName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.TITLE, displayName)
            put(MediaStore.Video.Media.RELATIVE_PATH, "${android.os.Environment.DIRECTORY_MOVIES}/$DIR_NAME")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: run {
            LogX.e("GalleryExporter", "MediaStore.insert 返回 null")
            return null
        }
        resolver.openOutputStream(uri)?.use { out ->
            src.inputStream().use { input -> input.copyTo(out, 1024 * 512) }
        } ?: run {
            resolver.delete(uri, null, null)
            LogX.e("GalleryExporter", "无法打开输出流")
            return null
        }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        LogX.i("GalleryExporter", "已存入相册：Movies/$DIR_NAME/$displayName")
        return uri
    }

    @Suppress("DEPRECATION")
    private fun exportLegacy(context: Context, src: File, displayName: String): Uri? {
        val movies = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_MOVIES
        )
        val dir = File(movies, DIR_NAME).apply { if (!exists()) mkdirs() }
        val target = File(dir, displayName)
        src.copyTo(target, overwrite = true)

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATA, target.absolutePath)
        }
        val uri = context.contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
        )
        // 通知相册刷新
        context.sendBroadcast(
            android.content.Intent(android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(target))
        )
        return uri
    }

    fun defaultName(): String {
        val sdf = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.CHINA)
        return "灵序织影_${sdf.format(java.util.Date())}.mp4"
    }
}
