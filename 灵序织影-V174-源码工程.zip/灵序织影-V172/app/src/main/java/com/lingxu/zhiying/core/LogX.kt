package com.lingxu.zhiying.core

import android.util.Log

/** 统一日志出口，发布版可一键静默 */
object LogX {
    var enabled: Boolean = true
    private const val TAG = "LingXu"

    fun i(scope: String, msg: String) {
        if (enabled) Log.i(TAG, "[$scope] $msg")
    }

    fun w(scope: String, msg: String) {
        if (enabled) Log.w(TAG, "[$scope] $msg")
    }

    fun e(scope: String, msg: String, t: Throwable? = null) {
        if (enabled) Log.e(TAG, "[$scope] $msg", t)
    }
}
