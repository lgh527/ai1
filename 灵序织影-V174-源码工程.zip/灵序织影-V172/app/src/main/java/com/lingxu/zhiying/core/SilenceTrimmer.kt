package com.lingxu.zhiying.core

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit

/**
 * 静音自动裁剪
 *
 * 切片首尾常常带有上一句/下一句的残音或纯静音，直接拼接会出现「卡顿感」。
 * 这里用 FFmpeg 的 silencedetect 滤镜探测首尾静音段，算出建议的入点/出点。
 *
 * 注意：这是**辅助建议**，最终入出点仍由用户在校对卡片上确认。
 * SenseVoice 离线识别不提供逐字时间戳，所以无法做到「按字级精确裁切」，
 * 只能按静音边界裁——这一点必须诚实对待。
 */
object SilenceTrimmer {

    data class Trim(val inMs: Long, val outMs: Long, val durationMs: Long) {
        val valid: Boolean get() = outMs > inMs && inMs >= 0
    }

    private val SILENCE = Regex("silence_(start|end):\\s*(-?[0-9.]+)")
    private val DURATION = Regex("Duration:\\s*(\\d+):(\\d+):([0-9.]+)")

    /**
     * @param noiseDb 静音判定阈值，默认 -35dB
     * @param minSilence 最短静音时长（秒），默认 0.35s
     */
    fun detect(path: String, noiseDb: Int = -35, minSilence: Float = 0.35f): Trim? {
        return try {
            val durationMs = probeDurationMs(path)
            // silencedetect 的输出在 stderr，FFprobeKit/FFmpegKit 都会收进 output
            val session = FFmpegKit.execute(
                "-hide_banner -i \"$path\" -af silencedetect=n=${noiseDb}dB:d=$minSilence -f null -"
            )
            val out = session.output ?: ""
            val starts = ArrayList<Double>()
            val ends = ArrayList<Double>()
            SILENCE.findAll(out).forEach { m ->
                val v = m.groupValues[2].toDoubleOrNull() ?: return@forEach
                if (m.groupValues[1] == "start") starts.add(v) else ends.add(v)
            }
            var inMs = 0L
            var outMs = durationMs

            // 开头静音：第一段静音从 0 附近开始 → 入点推到它的结束处
            if (starts.isNotEmpty() && starts[0] <= 0.25 && ends.isNotEmpty()) {
                inMs = (ends[0] * 1000).toLong()
            }
            // 结尾静音：最后一段静音没有结束标记（一直到片尾）→ 出点拉到它的开始处
            if (starts.isNotEmpty()) {
                val lastStart = starts.last()
                val lastEnd = ends.lastOrNull() ?: -1.0
                if (lastEnd < lastStart && durationMs > 0 &&
                    (durationMs / 1000.0 - lastStart) <= (minSilence + 1.5)
                ) {
                    outMs = (lastStart * 1000).toLong()
                }
            }
            // 安全边界：至少保留 0.3 秒内容，且裁剪量不超过总长的 40%
            val maxTrim = (durationMs * 0.4).toLong()
            if (inMs > maxTrim) inMs = maxTrim
            if (durationMs > 0 && durationMs - outMs > maxTrim) outMs = durationMs - maxTrim
            if (outMs - inMs < 300) return null

            Trim(inMs, outMs, durationMs)
        } catch (e: Throwable) {
            LogX.w("SilenceTrimmer", "静音检测失败: ${e.message}")
            null
        }
    }

    fun probeDurationMs(path: String): Long {
        return try {
            val s = FFprobeKit.execute("-hide_banner -i \"$path\"")
            val out = s.output ?: ""
            DURATION.find(out)?.let { m ->
                val h = m.groupValues[1].toLongOrNull() ?: 0L
                val mi = m.groupValues[2].toLongOrNull() ?: 0L
                val sec = m.groupValues[3].toDoubleOrNull() ?: 0.0
                h * 3600_000 + mi * 60_000 + (sec * 1000).toLong()
            } ?: VideoProbe.probe(path).durationMs
        } catch (e: Throwable) {
            0L
        }
    }
}
