package com.lingxu.zhiying.core

/**
 * 文件名自然排序
 *
 * 切片素材通常命名为 1.mp4 / 2.mp4 / … / 10.mp4，
 * 按字符串排序会得到 1、10、2 的错误顺序。
 * 自然排序把数字段按数值比较，得到 1、2、10。
 *
 * 这个顺序是一个**很强的先验**：多数情况下用户上传的切片本身就接近剧情顺序，
 * 只是局部乱序。对齐时给「与自然顺序接近」的候选一点加分，
 * 能显著减少 DP 在模糊得分下的误判。
 */
object NaturalOrder {

    private val TOKEN = Regex("(\\d+)|(\\D+)")

    fun compare(a: String, b: String): Int {
        val pa = TOKEN.findAll(a).map { it.value }.toList()
        val pb = TOKEN.findAll(b).map { it.value }.toList()
        val n = minOf(pa.size, pb.size)
        for (i in 0 until n) {
            val x = pa[i]; val y = pb[i]
            val nx = x.all { it.isDigit() }
            val ny = y.all { it.isDigit() }
            val c = if (nx && ny) {
                (x.toLongOrNull() ?: 0L).compareTo(y.toLongOrNull() ?: 0L)
            } else {
                x.compareTo(y)
            }
            if (c != 0) return c
        }
        return pa.size - pb.size
    }

    /** 按文件名自然排序，返回排序后的下标序列 */
    fun sortedIndices(names: List<String>): List<Int> =
        names.indices.sortedWith { i, j -> compare(names[i], names[j]) }

    /**
     * 自然顺序先验得分：切片在自然序中的位置与剧本句位置的接近程度。
     * 完全一致给满分，偏离越远越低；素材数量与句数不等时按比例归一。
     */
    fun priorBonus(naturalPos: Int, clipCount: Int, scriptPos: Int, scriptCount: Int): Float {
        if (clipCount <= 1 || scriptCount <= 1) return 0f
        val a = naturalPos.toFloat() / (clipCount - 1)
        val b = scriptPos.toFloat() / (scriptCount - 1)
        val dist = kotlin.math.abs(a - b)
        return (1f - dist).coerceIn(0f, 1f)
    }
}
