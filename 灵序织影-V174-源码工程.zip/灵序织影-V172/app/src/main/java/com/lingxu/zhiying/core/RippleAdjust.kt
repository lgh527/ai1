package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip

/**
 * 涟漪重排算法（Ripple Adjust）
 *
 * 用户点 ⬆️ 上移 / ⬇️ 下移 时，不只是简单交换两张卡片：
 * 交换后以该位置为中心，自动划定上下各 [RADIUS] 个片段的局部区间，
 * 对区间内**未锁定**的片段重新跑一次微型 DP 矩阵推演，
 * 瞬间平衡局部时序连贯性；锁定片段与区间外片段一律不动。
 */
object RippleAdjust {

    const val RADIUS = 3

    /**
     * @param index    用户操作的位置
     * @param upward   true = 上移，false = 下移
     * @return 受影响的卡片数量（0 表示本次操作无效，例如已到边界或两侧都锁定）
     */
    fun move(
        clips: MutableList<AlignedClip>,
        matrix: Array<Array<DpAligner.Cell>>,
        index: Int,
        upward: Boolean
    ): Int {
        if (index !in clips.indices) return 0
        val target = if (upward) index - 1 else index + 1
        if (target !in clips.indices) return 0
        if (clips[index].locked && clips[target].locked) return 0

        // 1. 先做物理交换
        val tmp = clips[index]
        clips[index] = clips[target]
        clips[target] = tmp

        // 2. 同步矩阵行顺序，保证 matrix[i] 始终对应 clips[i]
        if (matrix.size > maxOf(index, target)) {
            val t = matrix[index]
            matrix[index] = matrix[target]
            matrix[target] = t
        }

        // 3. 重排 order 字段
        clips.forEachIndexed { i, c -> c.order = i + 1 }

        // 4. 划定涟漪区间并做微型 DP
        val center = target
        val lo = (center - RADIUS).coerceAtLeast(0)
        val hi = (center + RADIUS).coerceAtMost(clips.size - 1)

        // 区间外的最近已确认坐标作为硬边界
        val minScript = clips.subList(0, lo).map { it.scriptIndex }.filter { it >= 0 }.maxOrNull() ?: 0
        val maxScript = clips.subList(hi + 1, clips.size).map { it.scriptIndex }
            .filter { it >= 0 }.minOrNull() ?: (matrix.firstOrNull()?.size?.minus(1) ?: 0)

        if (maxScript < minScript) return 1

        val resolved = DpAligner.resolveRange(clips, matrix, lo, hi, minScript, maxScript)
        var touched = 1
        resolved.forEachIndexed { i, scriptIdx ->
            if (scriptIdx == -2) return@forEachIndexed
            if (i in clips.indices && scriptIdx >= 0 && clips[i].scriptIndex != scriptIdx) {
                clips[i].scriptIndex = scriptIdx
                if (i < matrix.size && scriptIdx < matrix[i].size) {
                    val cell = matrix[i][scriptIdx]
                    clips[i].visualScore = cell.visual
                    clips[i].audioScore = cell.audio
                    clips[i].finalScore = cell.score
                }
                touched++
            }
        }
        LogX.i("RippleAdjust", "涟漪区间 [$lo,$hi] 重排完成，影响 $touched 张卡片")
        return touched
    }
}
