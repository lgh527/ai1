package com.lingxu.zhiying.security

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * 强混淆授权验证
 *
 * 核心密钥不以明文字符串存在，而是拆成 byteArray 并通过位运算 XOR 混淆，
 * 反编译后只能看到一堆无意义的字节数组与异或常量，拿不到原始密钥。
 *
 * 激活码生成：设备码（ANDROID_ID + 硬件指纹）作为 message，
 * 混淆后的密钥作为 key，做 HmacSHA256，取前 32 位大写十六进制。
 * 一机一码，换机即失效，彻底阻断白嫖。
 */
object ActivationManager {

    /** XOR 混淆后的密钥字节（真实密钥 = OBFUSCATED[i] xor MASK[i % MASK.size]） */
    private val OBFUSCATED = intArrayOf(
        0x5A, 0x1F, 0xC3, 0x88, 0x2E, 0x71, 0xD4, 0x09,
        0x6B, 0xE2, 0x43, 0x9C, 0x17, 0xAF, 0x50, 0xD8,
        0x31, 0x64, 0xB9, 0x0F, 0x7C, 0x25, 0xEE, 0x8A,
        0x13, 0xF6, 0x4D, 0xC0, 0x92, 0x3B, 0x68, 0xE5
    )

    private val MASK = intArrayOf(0x37, 0x5C, 0xA1, 0xE4, 0x19, 0x83, 0xF2, 0x6D)

    private const val PREF = "lingxu_auth"
    private const val KEY_ACTIVATED = "activated_code"

    /** 运行时还原密钥，用完立即置空引用 */
    private fun deobfuscateKey(): ByteArray {
        val out = ByteArray(OBFUSCATED.size)
        for (i in OBFUSCATED.indices) {
            out[i] = (OBFUSCATED[i] xor MASK[i % MASK.size]).toByte()
        }
        return out
    }

    @SuppressLint("HardwareIds")
    fun deviceCode(context: Context): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        } catch (e: Throwable) {
            "unknown"
        }
        val hardware = "${Build.BRAND}|${Build.MODEL}|${Build.BOARD}|${Build.HARDWARE}"
        val raw = "$androidId#$hardware"
        // 设备码对外只展示 12 位，避免完整信息泄露
        val digest = sha256(raw.toByteArray())
        return digest.substring(0, 12).uppercase()
    }

    /** 由设备码推导 32 位激活码 */
    fun activationCode(context: Context): String {
        val message = deviceCode(context)
        val key = deobfuscateKey()
        return try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(key, "HmacSHA256"))
            val result = mac.doFinal(message.toByteArray(Charsets.UTF_8))
            val hex = StringBuilder(result.size * 2)
            result.forEach { b ->
                val v = b.toInt() and 0xFF
                if (v < 0x10) hex.append('0')
                hex.append(Integer.toHexString(v))
            }
            hex.toString().uppercase().substring(0, 32)
        } catch (e: Throwable) {
            "0".repeat(32)
        } finally {
            key.fill(0) // 立即擦除内存中的密钥
        }
    }

    fun isActivated(context: Context): Boolean {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return sp.getString(KEY_ACTIVATED, null) == activationCode(context)
    }

    fun activate(context: Context, input: String): Boolean {
        val ok = input.trim().uppercase() == activationCode(context)
        if (ok) {
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY_ACTIVATED, input.trim().uppercase()).apply()
        }
        return ok
    }

    fun deactivate(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().remove(KEY_ACTIVATED).apply()
    }

    private fun sha256(bytes: ByteArray): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val d = md.digest(bytes)
        val sb = StringBuilder(d.size * 2)
        d.forEach { b ->
            val v = b.toInt() and 0xFF
            if (v < 0x10) sb.append('0')
            sb.append(Integer.toHexString(v))
        }
        return sb.toString()
    }
}
