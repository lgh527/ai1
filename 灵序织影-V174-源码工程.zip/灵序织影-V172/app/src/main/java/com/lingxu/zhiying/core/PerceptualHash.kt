package com.lingxu.zhiying.core

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/**
 * 感知哈希指纹（aHash）
 *
 * 把画面缩放为 8x8 灰度图，与 64 个像素的平均亮度逐一对比，
 * 大于均值记 1、否则记 0，得到 64 位二进制指纹。
 * 用于「静音 / 无字幕片段」的视觉归位与相邻镜头连续性判定。
 */
object PerceptualHash {

    private const val SIZE = 8

    fun aHash(bitmap: Bitmap?): Long {
        if (bitmap == null) return 0L
        val small = try {
            Bitmap.createScaledBitmap(bitmap, SIZE, SIZE, true)
        } catch (e: Throwable) {
            return 0L
        }
        val gray = IntArray(SIZE * SIZE)
        var sum = 0
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val p = small.getPixel(x, y)
                // ITU-R BT.601 亮度
                val g = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
                gray[y * SIZE + x] = g
                sum += g
            }
        }
        if (small !== bitmap) small.recycle()
        val avg = sum / (SIZE * SIZE)
        var hash = 0L
        for (i in gray.indices) {
            hash = hash shl 1
            if (gray[i] > avg) hash = hash or 1L
        }
        return hash
    }

    /** 汉明距离：两个指纹有多少位不同 */
    fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    /** 相似度 0f..1f，汉明距离越小越像 */
    fun similarity(a: Long, b: Long): Float {
        if (a == 0L || b == 0L) return 0f
        return 1f - hamming(a, b) / 64f
    }

    fun toHex(hash: Long): String = String.format("%016X", hash)

    /** 生成 4x4 的可视化色块，用于卡片上的「视觉指纹」展示 */
    fun toBlocks(hash: Long): List<Boolean> {
        val out = ArrayList<Boolean>(64)
        for (i in 0 until 64) {
            out.add((hash ushr (63 - i)) and 1L == 1L)
        }
        return out
    }

    /** 两个片段的「首尾衔接度」：前一段尾帧 vs 后一段首帧 */
    fun continuity(prevTail: Long, nextHead: Long): Float = similarity(prevTail, nextHead)

    /** 判断是否为近乎相同的画面（阈值 0.85 由调用方掌握，这里给出差值） */
    fun diffBits(prevTail: Long, nextHead: Long): Int = abs(hamming(prevTail, nextHead))
}
