package com.lingxu.zhiying.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** 纯代码 UI 工具箱：深色系 #05080E 科技风 */
object Ui {

    const val BG_DEEP = "#05080E"
    const val BG_CARD = "#0E1420"
    const val BG_INPUT = "#0A0F18"
    const val LINE_SOFT = "#1B2432"
    const val TEXT_MAIN = "#E6F1FF"
    const val TEXT_SUB = "#7C8CA3"
    const val CYAN = "#00E5FF"
    const val GREEN = "#00FF9D"
    const val RED = "#FF4D6D"
    const val AMBER = "#FFB020"
    const val PURPLE = "#9D6BFF"

    fun dp(context: Context, value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.resources.displayMetrics).toInt()

    fun sp(context: Context, value: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value, context.resources.displayMetrics)

    /** 圆角卡片背景 */
    fun cardBg(context: Context, fill: String = BG_CARD, stroke: String = LINE_SOFT, radius: Float = 16f): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, radius).toFloat()
            setColor(Color.parseColor(fill))
            setStroke(dp(context, 1f), Color.parseColor(stroke))
        }
    }

    /** 主行动按钮：青色渐变 */
    fun primaryBg(context: Context, enabled: Boolean = true): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 14f).toFloat()
            if (enabled) {
                orientation = GradientDrawable.Orientation.LEFT_RIGHT
                colors = intArrayOf(Color.parseColor("#00E5FF"), Color.parseColor("#0077FF"))
            } else {
                setColor(Color.parseColor("#182031"))
            }
        }
    }

    fun ghostBg(context: Context): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 12f).toFloat()
            setColor(Color.parseColor("#111A28"))
            setStroke(dp(context, 1f), Color.parseColor(LINE_SOFT))
        }
    }

    fun chipBg(context: Context, colorHex: String): GradientDrawable {
        val c = Color.parseColor(colorHex)
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 999f).toFloat()
            setColor(Color.argb(38, Color.red(c), Color.green(c), Color.blue(c)))
            setStroke(dp(context, 1f), Color.argb(140, Color.red(c), Color.green(c), Color.blue(c)))
        }
    }

    fun text(
        context: Context,
        content: String,
        sizeSp: Float = 14f,
        color: String = TEXT_MAIN,
        bold: Boolean = false,
        maxLines: Int = Int.MAX_VALUE
    ): TextView {
        return TextView(context).apply {
            text = content
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            this.maxLines = maxLines
            if (maxLines == 1) ellipsize = android.text.TextUtils.TruncateAt.END
        }
    }

    fun emojiButton(context: Context, emoji: String, label: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = "$emoji $label"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor(TEXT_MAIN))
            gravity = Gravity.CENTER
            background = ghostBg(context)
            setPadding(dp(context, 12f), dp(context, 9f), dp(context, 12f), dp(context, 9f))
            isClickable = true
            isFocusable = true
            val out = TypedValue()
            context.theme.resolveAttribute(android.R.attr.selectableItemBackground, out, true)
            foreground = context.getDrawable(out.resourceId)
            setOnClickListener { onClick() }
        }
    }

    fun vbox(context: Context, paddingDp: Float = 0f): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(context, paddingDp)
        setPadding(p, p, p, p)
    }

    fun hbox(context: Context, gravity: Int = Gravity.CENTER_VERTICAL): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        this.gravity = gravity
    }

    fun lp(width: Int, height: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(width, height).apply { if (weight > 0f) this.weight = weight }

    fun matchWrap(): LinearLayout.LayoutParams = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    fun margin(lp: LinearLayout.LayoutParams, context: Context, l: Float = 0f, t: Float = 0f, r: Float = 0f, b: Float = 0f) {
        lp.setMargins(dp(context, l), dp(context, t), dp(context, r), dp(context, b))
    }
}

/**
 * 视觉指纹展示：把 64 位 aHash 画成 8x8 色块，
 * 用户一眼就能看出两个片段的画面是否连续。
 */
class HashView(context: Context) : View(context) {

    private var blocks: List<Boolean> = List(64) { false }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setHash(hash: Long) {
        blocks = (0 until 64).map { i -> (hash ushr (63 - i)) and 1L == 1L }
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = Ui.dp(context, 34f)
        setMeasuredDimension(
            resolveSize(size, widthMeasureSpec),
            resolveSize(size, heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cell = minOf(width, height) / 8f
        for (i in 0 until 64) {
            val x = (i % 8) * cell
            val y = (i / 8) * cell
            paint.color = if (blocks[i]) Color.parseColor(Ui.CYAN) else Color.parseColor("#16202E")
            canvas.drawRect(x + 0.5f, y + 0.5f, x + cell - 0.5f, y + cell - 0.5f, paint)
        }
    }
}
