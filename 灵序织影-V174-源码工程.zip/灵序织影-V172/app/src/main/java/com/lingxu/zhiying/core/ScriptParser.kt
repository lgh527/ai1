package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.ScriptLine

/**
 * 第一步：剧本解析
 *
 * 支持自动剥离台词前缀：
 *   男主: 你到底想干什么
 *   【旁白】三年后，他回来了
 *   张三（怒吼）：给我站住！
 *   1. 第一句
 */
object ScriptParser {

    // 角色名 + 冒号（中英）
    private val ROLE_PREFIX = Regex("^\\s*([\\u4e00-\\u9fa5A-Za-z0-9_·]{1,12})\\s*[:：]\\s*(.*)$")

    // 【旁白】 / [场景] / （动作）
    private val BRACKET_PREFIX = Regex("^\\s*[【\\[（(]([^】\\]）)]{1,20})[】\\]）)]\\s*(.*)$")

    // 序号前缀：1. / 1、 / 第1句 / 00:01:23
    private val INDEX_PREFIX = Regex("^\\s*(?:\\d{1,4}[.、)）]|第\\s*\\d{1,4}\\s*[句行场]|\\d{1,2}:\\d{2}(?::\\d{2})?)\\s*(.*)$")

    // 纯场景提示行，不含台词，直接丢弃
    private val SCENE_ONLY = Regex("^(场景|镜头|画面|转场|△|▲)[：:]?.{0,40}$")

    /** 太短的行不具备对齐价值 */
    private const val MIN_CHARS = 2

    /**
     * 剧本切割：换行 + 标点（。！？；…!?）双重切分。
     *
     * 这一条极其关键：用户粘贴的剧本常常是连续段落而不是每句一行，
     * 若只按换行切，整篇会被当成一句，得分矩阵全废、对齐结果必然全乱。
     */
    private val SENTENCE_SPLIT = Regex("[\n\r]+|[。！？；…!?;]+")

    /** 单句过长说明还没切干净，按逗号再切一次 */
    private val CLAUSE_SPLIT = Regex("[，,、：:]")
    private const val MAX_LINE_CHARS = 40

    fun parse(raw: String): List<ScriptLine> {
        if (raw.isBlank()) return emptyList()
        val out = ArrayList<ScriptLine>()
        SENTENCE_SPLIT.split(raw).forEach { piece ->
            val trimmed = piece.trim()
            if (trimmed.isEmpty()) return@forEach
            // 一句里可能还带着「角色: 台词」的多段，先按角色前缀拆开
            splitByRole(trimmed).forEach { seg ->
                val one = normalize(seg)
                if (one.second.length < MIN_CHARS) return@forEach
                if (one.second.length > MAX_LINE_CHARS) {
                    // 过长再按逗号切，避免出现一整段当成一句
                    CLAUSE_SPLIT.split(one.second).forEach { sub ->
                        val t = stripPunctTail(sub.trim())
                        if (t.length >= MIN_CHARS) {
                            out.add(ScriptLine(index = out.size, text = t, role = one.first))
                        }
                    }
                } else {
                    out.add(ScriptLine(index = out.size, text = one.second, role = one.first))
                }
            }
        }
        return out
    }

    /** 把「张三: 你好 李四: 你也好」这种连写拆开 */
    private fun splitByRole(text: String): List<String> {
        val parts = ArrayList<String>()
        val matcher = Regex("(?=[\u4e00-\u9fa5A-Za-z0-9_·]{1,10}[:：])").split(text)
        matcher.filter { it.isNotBlank() }.forEach { parts.add(it.trim()) }
        return if (parts.isEmpty()) listOf(text) else parts
    }

    /** @return Pair(角色名, 纯净台词) */
    private fun normalize(input: String): Pair<String, String> {
        var s = input.trim().replace("\r", "")
        if (s.isEmpty()) return "" to ""

        // 剥离序号
        INDEX_PREFIX.find(s)?.let { s = it.groupValues[1].ifBlank { s } }

        var role = ""
        // 剥离【旁白】这类方括号前缀，旁白/独白不当作角色
        BRACKET_PREFIX.find(s)?.let { m ->
            val tag = m.groupValues[1].trim()
            val rest = m.groupValues[2].trim()
            if (rest.isNotEmpty()) {
                role = tag
                s = rest
            }
        }
        // 剥离 男主: 前缀
        ROLE_PREFIX.find(s)?.let { m ->
            val cand = m.groupValues[1].trim()
            val rest = m.groupValues[2].trim()
            // 避免把 "8:30 开会" 之类误判为角色
            if (rest.isNotEmpty() && cand.length <= 12 && !cand.all { it.isDigit() }) {
                role = cand
                s = rest
            }
        }

        s = stripPunctTail(s)
        if (SCENE_ONLY.matches(s)) return role to ""
        return role to s
    }

    /** 去掉行尾标点，提升与 ASR 文本的比对命中率 */
    private fun stripPunctTail(s: String): String {
        var out = s.trim()
        while (out.isNotEmpty() && out.last() in "。！？!?…，,、；;：: ~～-—\"'”’》〉)）") {
            out = out.dropLast(1)
        }
        return out.trim()
    }
}
