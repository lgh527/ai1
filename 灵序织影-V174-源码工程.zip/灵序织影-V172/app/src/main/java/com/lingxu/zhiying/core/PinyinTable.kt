package com.lingxu.zhiying.core

/**
 * 内置高频汉字拼音映射表（不带声调）
 *
 * 用途：把 OCR / ASR / 剧本三方文本统一投影到拼音空间，
 * 再比对声母与韵母，彻底解决 ASR 同音字（"知道"→"直到"）造成的干扰。
 *
 * 表外汉字退化为「原字符」参与比对，不影响整体相似度趋势。
 */
object PinyinTable {

    private val MAP: Map<Char, String> = buildMap {
        putPairs(
            "我 wo", "你 ni", "他 ta", "她 ta", "它 ta", "们 men", "的 de", "地 de", "得 de",
            "是 shi", "在 zai", "有 you", "和 he", "了 le", "不 bu", "人 ren", "这 zhe", "那 na",
            "上 shang", "下 xia", "中 zhong", "为 wei", "之 zhi", "也 ye", "就 jiu", "都 dou",
            "而 er", "及 ji", "与 yu", "或 huo", "一个 yi", "没 mei", "要 yao", "说 shuo",
            "会 hui", "到 dao", "来 lai", "去 qu", "过 guo", "还 hai", "很 hen", "多 duo",
            "少 shao", "好 hao", "坏 huai", "大 da", "小 xiao", "高 gao", "低 di", "长 chang",
            "短 duan", "新 xin", "旧 jiu", "老 lao", "年 nian", "月 yue", "日 ri", "时 shi",
            "分 fen", "秒 miao", "天 tian", "夜 ye", "早 zao", "晚 wan", "今 jin", "明 ming",
            "昨 zuo", "现 xian", "已 yi", "经 jing", "将 jiang", "正 zheng", "才 cai", "刚 gang",
            "别 bie", "再 zai", "又 you", "却 que", "只 zhi", "把 ba", "被 bei", "让 rang",
            "给 gei", "从 cong", "向 xiang", "对 dui", "于 yu", "比 bi", "跟 gen", "按 an",
            "着 zhe", "过 guo", "起 qi", "出 chu", "入 ru", "回 hui", "走 zou", "跑 pao",
            "看 kan", "见 jian", "听 ting", "闻 wen", "吃 chi", "喝 he", "睡 shui", "醒 xing",
            "爱 ai", "恨 hen", "喜欢 huan", "讨 tao", "厌 yan", "怕 pa", "敢 gan", "想 xiang",
            "念 nian", "思 si", "情 qing", "心 xin", "意 yi", "志 zhi", "神 shen", "魂 hun",
            "家 jia", "国 guo", "城 cheng", "乡 xiang", "路 lu", "街 jie", "门 men", "窗 chuang",
            "车 che", "船 chuan", "机 ji", "站 zhan", "桥 qiao", "山 shan", "水 shui", "河 he",
            "海 hai", "湖 hu", "风 feng", "雨 yu", "雪 xue", "云 yun", "雷 lei", "电 dian",
            "火 huo", "光 guang", "暗 an", "黑 hei", "白 bai", "红 hong", "黄 huang", "蓝 lan",
            "绿 lv", "青 qing", "紫 zi", "色 se", "声 sheng", "音 yin", "话 hua", "语 yu",
            "字 zi", "文 wen", "书 shu", "本 ben", "纸 zhi", "笔 bi", "画 hua", "图 tu",
            "影 ying", "片 pian", "镜 jing", "头 tou", "眼 yan", "耳 er", "口 kou", "鼻 bi",
            "手 shou", "足 zu", "脚 jiao", "身 shen", "体 ti", "脸 lian", "发 fa", "血 xue",
            "骨 gu", "肉 rou", "病 bing", "药 yao", "死 si", "生 sheng", "活 huo", "命 ming",
            "钱 qian", "金 jin", "银 yin", "铁 tie", "铜 tong", "石 shi", "玉 yu", "木 mu",
            "林 lin", "森 sen", "树 shu", "草 cao", "花 hua", "叶 ye", "根 gen", "果 guo",
            "食 shi", "饭 fan", "菜 cai", "肉 rou", "鱼 yu", "酒 jiu", "茶 cha", "糖 tang",
            "盐 yan", "油 you", "米 mi", "面 mian", "衣 yi", "裤 ku", "鞋 xie", "帽 mao",
            "工 gong", "作 zuo", "事 shi", "业 ye", "职 zhi", "位 wei", "公 gong", "司 si",
            "学 xue", "校 xiao", "生 sheng", "师 shi", "教 jiao", "考 kao", "试 shi", "题 ti",
            "答 da", "问 wen", "知 zhi", "识 shi", "能 neng", "力 li", "法 fa", "律 lv",
            "规 gui", "则 ze", "道 dao", "理 li", "真 zhen", "假 jia", "对 dui", "错 cuo",
            "成 cheng", "功 gong", "败 bai", "胜 sheng", "负 fu", "输 shu", "赢 ying", "比 bi",
            "赛 sai", "场 chang", "馆 guan", "店 dian", "市 shi", "买 mai", "卖 mai", "价 jia",
            "格 ge", "贵 gui", "便 bian", "宜 yi", "元 yuan", "块 kuai", "角 jiao", "号 hao",
            "第 di", "次 ci", "每 mei", "些 xie", "个 ge", "只 zhi", "条 tiao", "件 jian",
            "张 zhang", "本 ben", "部 bu", "群 qun", "队 dui", "组 zu", "班 ban", "排 pai",
            "列 lie", "行 xing", "间 jian", "里 li", "内 nei", "外 wai", "前 qian", "后 hou",
            "左 zuo", "右 you", "边 bian", "旁 pang", "中 zhong", "央 yang", "顶 ding", "底 di",
            "谁 shui", "什 shen", "么 me", "怎 zen", "样 yang", "哪 na", "里 li", "为 wei",
            "何 he", "吗 ma", "呢 ne", "吧 ba", "啊 a", "呀 ya", "哇 wa", "哦 o", "嗯 en",
            "哈 ha", "嘿 hei", "哼 heng", "喂 wei", "唉 ai", "哎 ai", "哟 yo", "啦 la",
            "哥 ge", "弟 di", "姐 jie", "妹 mei", "爸 ba", "妈 ma", "爷 ye", "奶 nai",
            "儿 er", "女 nv", "男 nan", "朋 peng", "友 you", "敌 di", "客 ke", "主 zhu",
            "王 wang", "李 li", "张 zhang", "刘 liu", "陈 chen", "杨 yang", "赵 zhao", "黄 huang",
            "周 zhou", "吴 wu", "徐 xu", "孙 sun", "马 ma", "朱 zhu", "胡 hu", "郭 guo",
            "林 lin", "何 he", "罗 luo", "郑 zheng", "梁 liang", "谢 xie", "宋 song", "唐 tang",
            "许 xu", "韩 han", "冯 feng", "邓 deng", "曹 cao", "彭 peng", "曾 zeng", "肖 xiao",
            "田 tian", "董 dong", "潘 pan", "袁 yuan", "蔡 cai", "蒋 jiang", "余 yu", "杜 du",
            "叶 ye", "程 cheng", "苏 su", "魏 wei", "吕 lv", "丁 ding", "任 ren", "沈 shen",
            "姚 yao", "卢 lu", "姜 jiang", "崔 cui", "钟 zhong", "谭 tan", "陆 lu", "汪 wang",
            "范 fan", "金 jin", "石 shi", "廖 liao", "贾 jia", "夏 xia", "韦 wei", "付 fu",
            "方 fang", "白 bai", "邹 zou", "孟 meng", "熊 xiong", "秦 qin", "邱 qiu", "江 jiang",
            "尹 yin", "薛 xue", "闫 yan", "段 duan", "雷 lei", "侯 hou", "龙 long", "史 shi",
            "陶 tao", "黎 li", "贺 he", "顾 gu", "毛 mao", "郝 hao", "龚 gong", "邵 shao",
            "万 wan", "钱 qian", "严 yan", "覃 qin", "武 wu", "戴 dai", "莫 mo", "孔 kong",
            "向 xiang", "汤 tang", "满 man", "快 kuai", "慢 man", "急 ji", "缓 huan", "轻 qing",
            "重 zhong", "难 nan", "易 yi", "繁 fan", "简 jian", "深 shen", "浅 qian", "远 yuan",
            "近 jin", "强 qiang", "弱 ruo", "刚 gang", "柔 rou", "冷 leng", "热 re", "温 wen",
            "凉 liang", "干 gan", "湿 shi", "净 jing", "脏 zang", "空 kong", "满 man", "整 zheng",
            "零 ling", "一 yi", "二 er", "三 san", "四 si", "五 wu", "六 liu", "七 qi",
            "八 ba", "九 jiu", "十 shi", "百 bai", "千 qian", "亿 yi", "半 ban", "双 shuang",
            "单 dan", "独 du", "共 gong", "同 tong", "异 yi", "各 ge", "自 zi", "己 ji",
            "彼 bi", "此 ci", "其 qi", "某 mou", "无 wu", "非 fei", "否 fou", "肯 ken",
            "必 bi", "须 xu", "应 ying", "该 gai", "可 ke", "许 xu", "宁 ning", "肯 ken",
            "愿 yuan", "望 wang", "盼 pan", "等 deng", "待 dai", "候 hou", "叫 jiao", "喊 han",
            "哭 ku", "笑 xiao", "闹 nao", "静 jing", "动 dong", "停 ting", "开 kai", "关 guan",
            "锁 suo", "钥 yao", "匙 chi", "找 zhao", "寻 xun", "查 cha", "验 yan", "证 zheng",
            "明 ming", "确 que", "清 qing", "楚 chu", "糊 hu", "涂 tu", "乱 luan", "序 xu",
            "灵 ling", "织 zhi", "剪 jian", "辑 ji", "导 dao", "演 yan", "剧 ju", "幕 mu",
            "镜 jing", "帧 zhen", "素 su", "材 cai", "本 ben", "轴 zhou", "轨 gui", "配 pei",
            "乐 le", "效 xiao", "特 te", "转 zhuan", "切 qie", "拼 pin", "接 jie", "合 he",
            "分 fen", "段 duan", "集 ji", "章 zhang", "卷 juan", "册 ce", "页 ye", "版 ban"
        )
    }

    private fun MutableMap<Char, String>.putPairs(vararg pairs: String) {
        pairs.forEach { p ->
            val kv = p.split(' ')
            if (kv.size == 2) {
                kv[0].forEach { ch -> put(ch, kv[1]) }
            }
        }
    }

    /** 单字转拼音，表外字返回原字符 */
    fun of(ch: Char): String = MAP[ch] ?: ch.toString()

    fun of(text: String): List<String> = text.map { of(it) }

    val coverage: Int get() = MAP.size
}
