package com.lingxu.zhiying.core

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File

/**
 * Uri → 真实文件路径解析
 *
 * FFmpeg 需要可读的文件路径。相册选出的 content:// 优先走 DATA 列拿真实路径，
 * 拿不到（分区存储限制）就把流复制进 cacheDir，保证后续管线一定能读到。
 */
object MediaResolver {

    data class Resolved(val path: String, val displayName: String, val size: Long)

    fun resolve(context: Context, uri: Uri): Resolved? {
        val name = queryName(context, uri) ?: "clip_${System.currentTimeMillis()}.mp4"
        val direct = queryDataPath(context, uri)
        if (direct != null) {
            val f = File(direct)
            if (f.exists() && f.canRead() && f.length() > 0) {
                return Resolved(f.absolutePath, name, f.length())
            }
        }
        // 复制到私有缓存
        return try {
            val dir = File(context.cacheDir, "inputs").apply { if (!exists()) mkdirs() }
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val out = File(dir, "${System.currentTimeMillis()}_$safe")
            context.contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { output -> input.copyTo(output, 1024 * 256) }
            } ?: return null
            if (out.length() <= 0) {
                out.delete()
                return null
            }
            Resolved(out.absolutePath, name, out.length())
        } catch (e: Throwable) {
            LogX.e("MediaResolver", "复制素材失败", e)
            null
        }
    }

    private fun queryName(context: Context, uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        } catch (e: Throwable) {
            null
        } finally {
            cursor?.close()
        }
    }

    @Suppress("DEPRECATION")
    private fun queryDataPath(context: Context, uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        } catch (e: Throwable) {
            null
        } finally {
            cursor?.close()
        }
    }

    /** 批量解析相册中所有视频（不依赖用户逐个点选） */
    fun queryAllVideos(context: Context, limit: Int = 200): List<Resolved> {
        val out = ArrayList<Resolved>()
        var cursor: Cursor? = null
        try {
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_TAKEN
            )
            cursor = context.contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Video.Media.DATE_TAKEN} DESC"
            )
            if (cursor != null) {
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                while (cursor.moveToNext() && out.size < limit) {
                    val id = cursor.getLong(idCol)
                    val u = Uri.withAppendedPath(collection, id.toString())
                    out.add(
                        Resolved(
                            path = u.toString(),
                            displayName = cursor.getString(nameCol) ?: "video_$id",
                            size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            LogX.e("MediaResolver", "查询相册失败（检查 READ_MEDIA_VIDEO 权限）", e)
        } finally {
            cursor?.close()
        }
        return out
    }
}
