package com.lingxu.zhiying.core

import com.lingxu.zhiying.model.AlignedClip

/**
 * 重复片段检测
 *
 * 用户明确要求：26 段切片拼出来必须是 26 段不重复的内容，
 * 总时长对得上、但里面有重复画面是不行的。
 *
 * 重复有两种来源：
 *  1. **同一个文件被导入两次**（路径/URI 相同）——直接判重
 *  2. **不同文件、内容相同**（同一支视频被导出了两份，或素材包里带了副本）
 *     ——用 aHash 首尾帧 + 文本双重判据
 *
 * 判重后默认**不参与拼接**，但卡片上仍会显示并标红，让用户自己决定是否保留。
 */
object DuplicateDetector {

    private const val HASH_SIM_THRESHOLD = 0.96f
    private const val TEXT_SIM_THRESHOLD = 0.85f

    data class Duplicate(val index: Int, val duplicateOf: Int, val reason: String, val similarity: Float)

    /**
     * 扫描重复
     * @return 每个被判为重复的片段的说明
     */
    fun scan(clips: List<AlignedClip>): List<Duplicate> {
        val out = ArrayList<Duplicate>()
        val dropped = HashSet<Int>()
        for (i in clips.indices) {
            if (i in dropped) continue
            val a = clips[i]
            for (j in i + 1 until clips.size) {
                if (j in dropped) continue
                val b = clips[j]

                // 判据 1：同一个文件
                if (a.feature.uri == b.feature.uri) {
                    out.add(Duplicate(j, i, "同一文件被导入两次", 1f))
                    b.isDuplicate = true
                    b.duplicateOf = i
                    dropped.add(j)
                    continue
                }

                // 判据 2：画面几乎完全一样
                val headSim = PerceptualHash.similarity(a.feature.headHash, b.feature.headHash)
                val tailSim = PerceptualHash.similarity(a.feature.tailHash, b.feature.tailHash)
                val visualSim = maxOf(headSim, tailSim)
                if (visualSim >= HASH_SIM_THRESHOLD) {
                    val ta = a.extractedLine()
                    val tb = b.extractedLine()
                    val textSim = if (ta.isBlank() || tb.isBlank()) 1f else TextSimilarity.combined(ta, tb)
                    if (textSim >= TEXT_SIM_THRESHOLD) {
                        out.add(
                            Duplicate(
                                j, i,
                                "内容与第 ${i + 1} 段重复（画面 ${(visualSim * 100).toInt()}%、文本 ${(textSim * 100).toInt()}%）",
                                visualSim
                            )
                        )
                        b.isDuplicate = true
                        b.duplicateOf = i
                        dropped.add(j)
                    }
                }
            }
        }
        return out
    }

    /** 参与拼接的片段（排除重复项） */
    fun renderList(clips: List<AlignedClip>): List<AlignedClip> = clips.filter { !it.isDuplicate }

    /**
     * 时长审计：拼接后的理论总时长 vs 原始素材总时长
     * 用来验证「26 段拼出来是不是 26 段的总和」
     */
    data class DurationAudit(
        val clipCount: Int,
        val renderedCount: Int,
        val duplicateCount: Int,
        val sourceTotalMs: Long,
        val renderTotalMs: Long,
        val trimRemovedMs: Long
    ) {
        fun summary(): String {
            val sb = StringBuilder()
            sb.append("片段总数 $clipCount 段，参与拼接 $renderedCount 段")
            if (duplicateCount > 0) sb.append("，已剔除重复 $duplicateCount 段")
            sb.append("\n素材原始总时长 ${fmt(sourceTotalMs)}")
            sb.append("\n预计成片时长 ${fmt(renderTotalMs)}")
            if (trimRemovedMs > 0) sb.append("（裁剪共去掉 ${fmt(trimRemovedMs)}）")
            if (duplicateCount == 0 && trimRemovedMs == 0L && renderTotalMs == sourceTotalMs) {
                sb.append("\n✅ 无重复、无裁剪，成片时长与素材总和完全一致")
            } else if (duplicateCount > 0) {
                sb.append("\n⚠️ 若不剔除重复，成片会多出一段重复画面")
            }
            return sb.toString()
        }

        private fun fmt(ms: Long): String {
            val s = ms / 1000
            return "${s / 60}分${s % 60}秒"
        }
    }

    fun audit(clips: List<AlignedClip>): DurationAudit {
        val rendered = renderList(clips)
        val srcTotal = clips.sumOf { it.feature.durationMs }
        var renderTotal = 0L
        var trimmed = 0L
        rendered.forEach { c ->
            val dur = c.feature.durationMs
            val inMs = if (c.trimInMs > 0) c.trimInMs else 0L
            val outMs = if (c.trimOutMs > 0) c.trimOutMs else dur
            val seg = (outMs - inMs).coerceAtLeast(0L)
            renderTotal += seg
            trimmed += (dur - seg).coerceAtLeast(0L)
        }
        return DurationAudit(
            clipCount = clips.size,
            renderedCount = rendered.size,
            duplicateCount = clips.size - rendered.size,
            sourceTotalMs = srcTotal,
            renderTotalMs = renderTotal,
            trimRemovedMs = trimmed
        )
    }

    /** 清除所有重复标记（用户可手动恢复被剔除的片段） */
    fun clearMarks(clips: List<AlignedClip>) {
        clips.forEach { it.isDuplicate = false; it.duplicateOf = -1 }
    }

    /** 把指定片段恢复为参与拼接 */
    fun restore(clip: AlignedClip) {
        clip.isDuplicate = false
        clip.duplicateOf = -1
    }

    private fun AlignedClip.extractedLine(): String =
        if (feature.asrText.isNotBlank()) feature.asrText else feature.ocrText
}
