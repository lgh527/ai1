package com.lingxu.zhiying.core

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/**
 * 极速视频拼接引擎（FFmpeg Concat）
 *
 * 策略：
 *  1. 先探明所有片段的分辨率 / 编码是否一致；
 *  2. 一致 → `-f concat -c copy` 无损流拷贝，秒级出片，不消耗 CPU 重编码；
 *  3. 不一致或流拷贝失败 → 自动降级 `libx264 -crf 18` 快速重编码，保证必定出片。
 */
class ConcatEngine(private val context: Context) {

    private val workDir: File
        get() = File(context.cacheDir, "concat").apply { if (!exists()) mkdirs() }

    enum class Mode { COPY, REENCODE, AUTO }

    /** 待拼接片段：带可选的帧级裁剪入出点（毫秒，-1 表示不裁） */
    data class TrimItem(val path: String, val inMs: Long = -1L, val outMs: Long = -1L) {
        val needTrim: Boolean get() = (inMs > 0) || (outMs > 0)
    }

    /**
     * @param paths 已按最终顺序排好的视频绝对路径
     * @return 成片文件，失败返回 null
     */
    fun concat(paths: List<String>, mode: Mode = Mode.AUTO, progress: (String) -> Unit = {}): File? =
        concatPaths(paths, mode, progress)

    /**
     * 带帧级裁剪的拼接。
     *
     * 只要有任何一个片段设了入出点，就无法整体 -c copy（切点不在关键帧上会花屏），
     * 因此对**需要裁剪的片段**先单独精确重编码成中间文件，其余片段保持原样，
     * 再统一走拼接流程——把重编码的代价限制在真正需要的片段上。
     */
    fun concatTrimmed(
        items: List<TrimItem>,
        mode: Mode = Mode.AUTO,
        progress: (String) -> Unit = {}
    ): File? {
        if (items.isEmpty()) return null
        val needCut = items.any { it.needTrim }
        val prepared: List<String> = if (!needCut) {
            items.map { it.path }
        } else {
            progress("检测到 ${items.count { it.needTrim }} 个片段设了裁剪点，先精确切分…")
            items.mapIndexed { i, it ->
                if (!it.needTrim) it.path
                else (cutSegment(it.path, i, it.inMs, it.outMs)?.absolutePath ?: it.path)
            }
        }
        return concatPaths(prepared, mode, progress)
    }

    /** -ss/-to 精确裁剪单个片段（放在 -i 之后是帧精确模式） */
    private fun cutSegment(src: String, index: Int, inMs: Long, outMs: Long): File? {
        val out = File(workDir, "cut_$index.mp4")
        if (out.exists()) out.delete()
        val sb = StringBuilder("-hide_banner -loglevel error -y -i \"$src\" ")
        if (inMs > 0) sb.append("-ss ").append(String.format("%.3f", inMs / 1000.0)).append(" ")
        if (outMs > 0 && outMs > inMs) sb.append("-to ").append(String.format("%.3f", outMs / 1000.0)).append(" ")
        sb.append("-c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p ")
        sb.append("-c:a aac -b:a 192k -avoid_negative_ts make_zero \"${out.absolutePath}\"")
        val session = FFmpegKit.execute(sb.toString())
        return if (ReturnCode.isSuccess(session.returnCode) && out.exists() && out.length() > 1024) {
            out
        } else {
            LogX.w("ConcatEngine", "裁剪失败，使用原片段: ${session.output}")
            null
        }
    }

    /** 真正的拼接实现 */
    private fun concatPaths(paths: List<String>, mode: Mode, progress: (String) -> Unit): File? {
        if (paths.isEmpty()) return null
        val valid = paths.filter { File(it).exists() && File(it).length() > 0 }
        if (valid.isEmpty()) {
            LogX.e("ConcatEngine", "没有任何可用素材")
            return null
        }

        val out = File(workDir, "lingxu_final_${System.currentTimeMillis()}.mp4")
        if (out.exists()) out.delete()
        val list = writeListFile(valid)

        val canCopy = mode == Mode.COPY || (mode == Mode.AUTO && isHomogeneous(valid))
        if (canCopy) {
            progress("检测到编码一致，启用无损极速拼接（-c copy）…")
            val cmd = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"${list.absolutePath}\" " +
                    "-c copy -movflags +faststart \"${out.absolutePath}\""
            val session = FFmpegKit.execute(cmd)
            if (ReturnCode.isSuccess(session.returnCode) && out.exists() && out.length() > 1024) {
                LogX.i("ConcatEngine", "无损拼接成功：${out.length() / 1024} KB")
                return out
            }
            LogX.w("ConcatEngine", "流拷贝失败，降级重编码：${session.output}")
            out.delete()
        }

        progress("素材编码不一致，降级为 libx264 -crf 18 重编码…")
        // 统一到 1080 宽、偶数高，避免分辨率冲突导致花屏（嵌套引号在 FFmpegKit 解析器里不稳，这里不用）
        val vf = "scale=1080:-2:force_original_aspect_ratio=decrease,fps=30,setsar=1"
        val cmd2 = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"${list.absolutePath}\" " +
                "-vf \"$vf\" -c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p " +
                "-c:a aac -b:a 192k -ar 44100 -ac 2 -movflags +faststart \"${out.absolutePath}\""
        val s2 = FFmpegKit.execute(cmd2)
        if (ReturnCode.isSuccess(s2.returnCode) && out.exists() && out.length() > 1024) {
            LogX.i("ConcatEngine", "重编码拼接成功：${out.length() / 1024 / 1024} MB")
            return out
        }

        // 最后兜底：逐个转成统一中间格式再拷贝
        progress("二次兜底：统一转码中间片段…")
        val intermediates = valid.mapIndexed { i, p -> transcodeOne(p, i) }.filterNotNull()
        if (intermediates.isEmpty()) {
            LogX.e("ConcatEngine", "拼接彻底失败：${s2.output}")
            return null
        }
        val list2 = writeListFile(intermediates.map { it.absolutePath })
        val cmd3 = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"${list2.absolutePath}\" " +
                "-c copy -movflags +faststart \"${out.absolutePath}\""
        val s3 = FFmpegKit.execute(cmd3)
        return if (ReturnCode.isSuccess(s3.returnCode) && out.exists()) out else null
    }

    private fun transcodeOne(src: String, index: Int): File? {
        val tmp = File(workDir, "seg_$index.mp4")
        if (tmp.exists()) tmp.delete()
        val cmd = "-hide_banner -loglevel error -y -i \"$src\" " +
                "-vf \"scale=1080:-2:force_original_aspect_ratio=decrease,fps=30,setsar=1\" " +
                "-c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p " +
                "-c:a aac -b:a 192k -ar 44100 -ac 2 \"${tmp.absolutePath}\""
        val session = FFmpegKit.execute(cmd)
        return if (ReturnCode.isSuccess(session.returnCode) && tmp.exists()) tmp else null
    }

    /** 判断素材是否「同质」：分辨率与视频编码全一致，才能安全 -c copy */
    private fun isHomogeneous(paths: List<String>): Boolean {
        var w = -1; var h = -1; var codec = ""
        for (p in paths) {
            val info = VideoProbe.probe(p)
            if (info.width <= 0) return false
            if (w == -1) { w = info.width; h = info.height; codec = info.vCodec }
            else if (w != info.width || h != info.height || codec != info.vCodec) return false
        }
        return true
    }

    private fun writeListFile(paths: List<String>): File {
        val f = File(workDir, "list_${System.currentTimeMillis()}.txt")
        f.bufferedWriter().use { bw ->
            paths.forEach { p ->
                // concat demuxer 要求单引号内的 ' 转义为 '\''
                val escaped = p.replace("'", "'\\''")
                bw.write("file '$escaped'")
                bw.newLine()
            }
        }
        return f
    }

    fun cleanAll() {
        workDir.deleteRecursively()
    }
}
