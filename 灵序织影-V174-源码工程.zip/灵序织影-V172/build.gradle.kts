// 灵序织影 V172 终极融合版 —— 根构建脚本
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
