# 防混淆规则（虽然未开启混淆，但作为备用保留）
-keep class com.lingxu.zhiying.** { *; }
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.google.gson.** { *; }
-keep class com.google.mlkit.** { *; }
-keep class com.google.mediapipe.** { *; }
-keep public class * extends android.app.Activity