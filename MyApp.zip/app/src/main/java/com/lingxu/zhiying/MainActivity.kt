package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout
    
    private val REQ_CODE_PERM = 100

    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private var deviceId: String = ""

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var tvMatchDetails: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnStitch: Button
    private lateinit var btnSave: Button
    private lateinit var btnCalibrate: Button
    private lateinit var tvClipCount: TextView
    private var isModelsReady = false
    
    private var currentClips: MutableList<AndroidBridge.MatchedClip> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            checkPermissions()
            setupBaseUI()

            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }

            val isActivated = prefs.getBoolean("is_activated", false)
            if (isActivated) {
                showMainApp()
            } else {
                showAuthScreen()
            }

        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString()).setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
        }
    }

    private fun setupBaseUI() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(80, 200, 80, 80)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        authLayout.addView(TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        authLayout.addView(TextView(this).apply { text = "首次使用请复制设备码获取激活码"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) })

        tvDeviceCode = TextView(this).apply {
            text = deviceId
            setTextColor(Color.parseColor("#10B981"))
            textSize = 28f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "设备码已复制", Toast.LENGTH_SHORT).show()
            }
        }
        authLayout.addView(tvDeviceCode)

        etActivationCode = EditText(this).apply {
            hint = "请输入 32 位激活码"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(30, 30, 30, 30)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        authLayout.addView(etActivationCode)

        authLayout.addView(Button(this).apply {
            text = "立即激活"
            setBackgroundColor(Color.parseColor("#2563EB"))
            setTextColor(Color.WHITE)
            setPadding(0, 30, 0, 30)
            setOnClickListener { verifyActivation() }
        })
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) {
            Toast.makeText(this, "激活码格式错误，应为 32 位", Toast.LENGTH_SHORT).show()
            return
        }

        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decryptedKeyBytes = ByteArray(obfuscatedBytes.size)
        for (i in obfuscatedBytes.indices) {
            decryptedKeyBytes[i] = (obfuscatedBytes[i].toInt() xor xorKey).toByte()
        }
        val realKey = String(decryptedKeyBytes)

        try {
            val mac = Mac.getInstance("HmacSHA256")
            val secretKeySpec = SecretKeySpec(realKey.toByteArray(), "HmacSHA256")
            mac.init(secretKeySpec)
            val hashBytes = mac.doFinal(deviceId.toByteArray())
            val hexString = hashBytes.joinToString("") { "%02x".format(it) }.uppercase()
            val expectedCode = hexString.substring(0, 32)

            if (input == expectedCode) {
                Toast.makeText(this, "激活成功，永久有效！", Toast.LENGTH_LONG).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE
                showMainApp()
            } else {
                Toast.makeText(this, "激活码错误，请核对后重试", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) {
            mainLayout.visibility = View.VISIBLE
            return
        }

        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        mainLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(60, 100, 60, 100) }
        
        mainLayout.addView(TextView(this).apply { text = "灵序织影 (已授权)"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 30) })
        mainLayout.addView(TextView(this).apply { text = "第一步：输入剧情脚本"; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0,0,0,10) })
        etScript = EditText(this).apply { hint = "长文直接粘贴"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(30,30,30,30); minLines = 4; gravity = Gravity.TOP }
        mainLayout.addView(etScript)
        
        mainLayout.addView(TextView(this).apply { text = "第二步：导入视频素材"; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0,20,0,10) })
        btnImport = Button(this).apply { text = "📥 导入视频素材"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        tvClipCount = TextView(this).apply { text = "已导入素材：0 个"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 13f; setPadding(0,10,0,10) }
        mainLayout.addView(btnImport); mainLayout.addView(tvClipCount)
        
        mainLayout.addView(TextView(this).apply { text = "第三步：智能合成与校准"; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0,20,0,10) })
        btnMatch = Button(this).apply { text = "🧠 智能剧情对齐"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setOnClickListener { startMatching() } }
        btnCalibrate = Button(this).apply { text = "🔍 手动智能校准台"; setBackgroundColor(Color.parseColor("#8B5CF6")); setTextColor(Color.WHITE); visibility = View.GONE; setOnClickListener { showCalibrateDialog() } }
        tvMatchDetails = TextView(this).apply { setTextColor(Color.parseColor("#A7F3D0")); textSize = 13f; setBackgroundColor(Color.parseColor("#1E293B")); setPadding(20,20,20,20); visibility = View.GONE; maxLines = 15; isVerticalScrollBarEnabled = true }
        btnStitch = Button(this).apply { text = "🎬 渲染完整视频 (原画质)"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); setPadding(0,30,0,30); setOnClickListener { startStitching() } }
        btnSave = Button(this).apply { text = "💾 保存至相册 (MP4)"; setBackgroundColor(Color.parseColor("#D97706")); setTextColor(Color.WHITE); setPadding(0,30,0,30); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0,20,0,20) }
        tvStatus = TextView(this).apply { text = "准备就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 14f; gravity = Gravity.CENTER }

        mainLayout.addView(btnMatch); mainLayout.addView(btnCalibrate); mainLayout.addView(tvMatchDetails); mainLayout.addView(btnStitch); mainLayout.addView(btnSave); mainLayout.addView(progressBar); mainLayout.addView(tvStatus)
        
        val scrollView = ScrollView(this).apply { isFillViewport = true; addView(mainLayout) }
        rootLayout.addView(scrollView)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎加载成功"
            }
        }
    }

    private fun showCalibrateDialog() {
        if (currentClips.isEmpty()) return
        
        val builder = AlertDialog.Builder(this)
        builder.setTitle("手动校准（点击选择剧本台词）")
        val items = ArrayList<String>()
        for (i in currentClips.indices) {
            val c = currentClips[i]
            items.add("${i + 1}. [视频]: ${c.text.take(10)}...\n[剧本]: ${c.targetText.take(10)}...")
        }
        builder.setItems(items.toTypedArray()) { _, which ->
            val clip = currentClips[which]
            val options = ArrayList<String>()
            for (s in bridge.sentences) {
                options.add(s)
            }
            AlertDialog.Builder(this)
                .setTitle("选择这截视频真正对应的剧本句")
                .setItems(options.toTypedArray()) { _, idx ->
                    val targetText = bridge.sentences[idx]
                    val newClip = AndroidBridge.MatchedClip(clip.fileName, clip.text, targetText, 1.0f, idx)
                    currentClips[which] = newClip
                    Toast.makeText(this, "已重锚定并锁定！", Toast.LENGTH_SHORT).show()
                }
                .show()
        }
        builder.setNegativeButton("关闭", null)
        builder.show()
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        tvMatchDetails.visibility = View.GONE
        tvStatus.text = "正在读取本地视频..."
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val videoList = mutableListOf<Map<String, Any>>()
                val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                
                cursor?.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                        val name = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        videoList.add(mapOf("id" to id, "name" to name))
                    }
                }

                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (videoList.isEmpty()) return@withContext
                    showVideoSelectionDialog(videoList)
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { btnImport.isEnabled = true }
            }
        }
    }

    private fun showVideoSelectionDialog(videoList: List<Map<String, Any>>) {
        val names = videoList.map { it["name"] as String }.toTypedArray()
        val checkedItems = BooleanArray(videoList.size)

        AlertDialog.Builder(this)
            .setTitle("选择视频素材")
            .setMultiChoiceItems(names, checkedItems) { _, which, isChecked -> checkedItems[which] = isChecked }
            .setPositiveButton("确定导入") { _, _ ->
                val selectedVideos = mutableListOf<Map<String, Any>>()
                for (i in checkedItems.indices) {
                    if (checkedItems[i]) selectedVideos.add(videoList[i])
                }
                if (selectedVideos.isNotEmpty()) downloadSelectedVideos(selectedVideos)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun downloadSelectedVideos(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        btnImport.isEnabled = false
        tvStatus.text = "正在导入素材..."
        
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val successfulNames = mutableListOf<String>()
            
            for (i in videos.indices) {
                val id = videos[i]["id"] as Long
                val name = videos[i]["name"] as String
                withContext(Dispatchers.Main) {
                    tvStatus.text = "正在处理 (${i+1}/${videos.size}): $name"
                    progressBar.progress = ((i.toFloat() / videos.size) * 100).toInt()
                }

                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val uniqueName = "${System.currentTimeMillis()}_$name"
                    val destFile = File(bridge.uploadDir, uniqueName)
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
                    successfulNames.add(uniqueName)
                } catch (e: Throwable) { }
                delay(1)
            }

            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                btnImport.isEnabled = true
                if (successfulNames.isNotEmpty()) {
                    bridge.uploadedClips.clear()
                    bridge.uploadedClips.addAll(successfulNames)
                    tvClipCount.text = "已导入素材：${successfulNames.size} 个"
                    tvStatus.text = "素材导入成功"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                }
            }
        }
    }

    private fun startMatching() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty() || bridge.uploadedClips.isEmpty() || !isModelsReady) return
        
        btnMatch.isEnabled = false; btnStitch.isEnabled = false; btnImport.isEnabled = false
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvMatchDetails.visibility = View.GONE
        tvStatus.text = "AI 正在全局精准对齐中..."

        CoroutineScope(Dispatchers.Main).launch {
            bridge.parseEpisodes(script, onProgress = { p, msg ->
                progressBar.progress = p; tvStatus.text = msg
            }, onSuccess = { matchDetailStr, resultClips ->
                progressBar.visibility = View.GONE
                btnMatch.isEnabled = true; btnStitch.isEnabled = true; btnImport.isEnabled = true
                tvStatus.text = "剧情对齐完成，可微调或渲染"
                tvMatchDetails.text = matchDetailStr
                tvMatchDetails.visibility = View.VISIBLE
                btnCalibrate.visibility = View.VISIBLE
                currentClips = resultClips.toMutableList()
            }, onError = { err ->
                progressBar.visibility = View.GONE
                btnMatch.isEnabled = true; btnStitch.isEnabled = true; btnImport.isEnabled = true
                tvStatus.text = "对齐失败: $err"
            })
        }
    }

    private fun startStitching() {
        if (bridge.parsedEpisodesJson == null) return
        btnStitch.isEnabled = false; btnMatch.isEnabled = false; btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "正在渲染原画质视频..."

        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(bridge.parsedEpisodesJson!!, onProgress = { p, msg ->
                progressBar.progress = p; tvStatus.text = msg
            }, onSuccess = { finalFilePath ->
                progressBar.visibility = View.GONE
                btnStitch.isEnabled = true; btnMatch.isEnabled = true; btnImport.isEnabled = true
                btnSave.visibility = View.VISIBLE; btnSave.tag = finalFilePath
                tvStatus.text = "渲染完成！请保存至相册"
            }, onError = { err ->
                progressBar.visibility = View.GONE
                btnStitch.isEnabled = true; btnMatch.isEnabled = true; btnImport.isEnabled = true
                tvStatus.text = "渲染失败: $err"
            })
        }
    }

    private fun saveToGallery() {
        val filePath = btnSave.tag as? String ?: return
        val sourceFile = File(filePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) return

        btnSave.isEnabled = false
        tvStatus.text = "正在保存 MP4..."
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val resolver = contentResolver
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val uri = resolver.insert(collection, contentValues)
                uri?.let {
                    resolver.openOutputStream(it)?.use { outputStream -> FileInputStream(sourceFile).use { inputStream -> inputStream.copyTo(outputStream) } }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        contentValues.clear(); contentValues.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, contentValues, null, null)
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "视频已保存至相册", Toast.LENGTH_LONG).show()
                    btnSave.visibility = View.GONE; btnSave.isEnabled = true; tvStatus.text = "视频已保存至相册"
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { btnSave.isEnabled = true; Toast.makeText(this@MainActivity, "保存失败", Toast.LENGTH_LONG).show() }
            }
        }
    }
}