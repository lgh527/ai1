package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout
    private lateinit var calibrateLayout: LinearLayout
    
    private lateinit var calibrateListContainer: LinearLayout
    
    private val REQ_CODE_PERM = 100

    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private var deviceId: String = ""

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnStitch: Button
    private lateinit var btnCalibrate: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private var isModelsReady = false
    
    private var currentClips: MutableList<AndroidBridge.MatchedClip> = ArrayList()
    private var calibrateIteration = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            checkPermissions()
            rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
            setContentView(rootLayout)

            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }

            if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString()).setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(80, 200, 80, 80)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        authLayout.addView(TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        authLayout.addView(TextView(this).apply { text = "复制设备码联系管理员获取激活码"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) })
        
        tvDeviceCode = TextView(this).apply {
            text = deviceId
            setTextColor(Color.parseColor("#10B981"))
            textSize = 28f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "设备码已复制", Toast.LENGTH_SHORT).show()
            }
        }
        authLayout.addView(tvDeviceCode)

        etActivationCode = EditText(this).apply {
            hint = "请输入 32 位激活码"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(30, 30, 30, 30)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        authLayout.addView(etActivationCode)

        authLayout.addView(Button(this).apply {
            text = "立即激活"
            setBackgroundColor(Color.parseColor("#2563EB"))
            setTextColor(Color.WHITE)
            setPadding(0, 30, 0, 30)
            setOnClickListener { verifyActivation() }
        })
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "激活码应为 32 位", Toast.LENGTH_SHORT).show(); return }
        
        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decryptedKeyBytes = ByteArray(obfuscatedBytes.size)
        for (i in obfuscatedBytes.indices) decryptedKeyBytes[i] = (obfuscatedBytes[i].toInt() xor xorKey).toByte()
        val realKey = String(decryptedKeyBytes)

        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(realKey.toByteArray(), "HmacSHA256"))
            val expected = mac.doFinal(deviceId.toByteArray()).joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expected) {
                Toast.makeText(this, "激活成功", Toast.LENGTH_SHORT).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE
                showMainApp()
            } else Toast.makeText(this, "激活码错误", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) { mainLayout.visibility = View.VISIBLE; return }
        bridge = AndroidBridge(this)
        
        mainLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(50, 70, 50, 70) }
        mainLayout.addView(TextView(this).apply { text = "AI 剧情对齐工作区"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 30) })
        
        etScript = EditText(this).apply { hint = "粘贴剧本长文..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(28, 24, 28, 24); minLines = 4; gravity = Gravity.TOP }
        mainLayout.addView(etScript)

        tvClipCount = TextView(this).apply { text = "已导入素材：0 个"; setTextColor(Color.parseColor("#7DD3FC")); setPadding(0, 20, 0, 10) }
        mainLayout.addView(tvClipCount)

        btnImport = Button(this).apply { text = "📥 导入视频素材"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        mainLayout.addView(btnImport)

        btnMatch = Button(this).apply { text = "🧠 AI 深度解析对齐"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setOnClickListener { startMatching() } }
        mainLayout.addView(btnMatch)

        btnCalibrate = Button(this).apply { text = "🔍 进入智能校准台"; setBackgroundColor(Color.parseColor("#8B5CF6")); setTextColor(Color.WHITE); visibility = View.GONE; setOnClickListener { showCalibrateLayout() } }
        mainLayout.addView(btnCalibrate)

        btnSave = Button(this).apply { text = "💾 保存至相册"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        mainLayout.addView(btnSave)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0, 20, 0, 10) }
        mainLayout.addView(progressBar)

        tvStatus = TextView(this).apply { text = "准备就绪"; setTextColor(Color.parseColor("#10B981")); gravity = Gravity.CENTER }
        mainLayout.addView(tvStatus)

        rootLayout.addView(ScrollView(this).apply { addView(mainLayout) })

        buildCalibrateLayout()

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎加载成功"
            }
        }
    }

    // ===== 智能校准台 =====
    private fun buildCalibrateLayout() {
        calibrateLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(40, 60, 40, 60); visibility = View.GONE }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(Button(this).apply { text = "← 返回"; setBackgroundColor(Color.parseColor("#64748B")); setTextColor(Color.WHITE); setOnClickListener { calibrateLayout.visibility = View.GONE; mainLayout.visibility = View.VISIBLE } })
        calibrateLayout.addView(header)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(Button(this).apply { 
            text = "🔄 智能校对"; setBackgroundColor(Color.parseColor("#F59E0B")); setTextColor(Color.WHITE); 
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { intelligentCalibrate() } 
        })
        actionRow.addView(Button(this).apply { 
            text = "🔒 锁定绿项"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); 
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { lockCorrectClips() } 
        })
        calibrateLayout.addView(actionRow)

        calibrateLayout.addView(Button(this).apply { text = "⚡ 按当前顺序合成"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setOnClickListener { startStitching() } })

        calibrateListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 20, 0, 20) }
        calibrateLayout.addView(ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f); addView(calibrateListContainer) })
        rootLayout.addView(calibrateLayout)
    }

    private fun showCalibrateLayout() {
        mainLayout.visibility = View.GONE
        calibrateLayout.visibility = View.VISIBLE
        renderCalibrateList()
    }

    private fun renderCalibrateList() {
        calibrateListContainer.removeAllViews()
        for (idx in currentClips.indices) {
            val clip = currentClips[idx]
            val isGreen = clip.score >= 0.6f
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor(if (clip.locked) "#1E3A2E" else if (isGreen) "#14532D" else "#4C1D1D"))
                setPadding(20, 16, 20, 16)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 8, 0, 8) }
            }
            card.addView(TextView(this).apply { text = "${if (clip.locked) "🔒" else if (isGreen) "✅" else "❌"} #${idx + 1} ${clip.fileName.take(15)}"; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
            card.addView(TextView(this).apply { text = "🎤 视频：${clip.text}"; setTextColor(Color.WHITE); textSize = 12f })
            card.addView(TextView(this).apply { text = "📖 剧本：${clip.targetText}"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 12f })
            calibrateListContainer.addView(card)
        }
    }

    private fun intelligentCalibrate() {
        if (currentClips.isEmpty()) return
        calibrateIteration++
        calibrateListContainer.removeAllViews()
        calibrateListContainer.addView(TextView(this).apply { text = "🔄 第 $calibrateIteration 次智能校对..."; setTextColor(Color.parseColor("#0EA5E9")); gravity = Gravity.CENTER; setPadding(0, 100, 0, 100) })

        CoroutineScope(Dispatchers.Main).launch {
            val result = withContext(Dispatchers.Default) { bridge.recalibrate(currentClips, bridge.sentences) }
            currentClips = result
            renderCalibrateList()
            Toast.makeText(this@MainActivity, "校对完成", Toast.LENGTH_SHORT).show()
        }
    }

    private fun lockCorrectClips() {
        val newList = ArrayList<AndroidBridge.MatchedClip>()
        for (clip in currentClips) {
            if (!clip.locked && clip.score >= 0.6f) newList.add(AndroidBridge.MatchedClip(clip.fileName, clip.text, clip.targetText, clip.score, clip.scriptPos, true))
            else newList.add(clip)
        }
        currentClips = newList
        renderCalibrateList()
        Toast.makeText(this, "已锁定绿项", Toast.LENGTH_SHORT).show()
    }

    // ===== 业务主流程 =====
    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false
        CoroutineScope(Dispatchers.IO).launch {
            val names = ArrayList<String>()
            val ids = ArrayList<Long>()
            val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME), null, null, null)
            if (cursor != null) {
                while (cursor.moveToNext()) { ids.add(cursor.getLong(0)); names.add(cursor.getString(1) ?: "unknown") }
                cursor.close()
            }
            withContext(Dispatchers.Main) {
                btnImport.isEnabled = true
                if (names.isEmpty()) return@withContext
                val checked = BooleanArray(names.size)
                AlertDialog.Builder(this@MainActivity).setTitle("选择视频").setMultiChoiceItems(names.toTypedArray(), checked) { _, i, c -> checked[i] = c }
                    .setPositiveButton("导入") { _, _ ->
                        val selIds = ArrayList<Long>()
                        for (i in checked.indices) if (checked[i]) selIds.add(ids[i])
                        if (selIds.isNotEmpty()) downloadVideos(selIds)
                    }.show()
            }
        }
    }

    private fun downloadVideos(ids: List<Long>) {
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val files = ArrayList<String>()
            for (i in ids.indices) {
                withContext(Dispatchers.Main) { progressBar.progress = (i * 100 / ids.size) }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, ids[i])
                    val n = "${System.currentTimeMillis()}_$i.mp4"
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(File(bridge.uploadDir, n)).use { output -> input.copyTo(output) } }
                    files.add(n)
                } catch (e: Exception) {}
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                bridge.uploadedClips.clear(); bridge.uploadedClips.addAll(files)
                tvClipCount.text = "已导入素材：${files.size} 个"
            }
        }
    }

    private fun startMatching() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty() || bridge.uploadedClips.isEmpty() || !isModelsReady) return
        btnMatch.isEnabled = false; btnImport.isEnabled = false; progressBar.visibility = View.VISIBLE
        
        CoroutineScope(Dispatchers.Main).launch {
            bridge.parseEpisodes(script, 
                { p, msg -> progressBar.progress = p; tvStatus.text = msg },
                { result ->
                    currentClips = result.toMutableList()
                    progressBar.visibility = View.GONE
                    tvStatus.text = "✅ 对齐完成"
                    btnMatch.isEnabled = true; btnImport.isEnabled = true
                    btnCalibrate.visibility = View.VISIBLE
                },
                { err -> progressBar.visibility = View.GONE; tvStatus.text = "失败: $err"; btnMatch.isEnabled = true; btnImport.isEnabled = true }
            )
        }
    }

    private fun startStitching() {
        if (currentClips.isEmpty()) return
        currentClips.sortBy { it.scriptPos }
        calibrateLayout.visibility = View.GONE
        mainLayout.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        
        val fileNames = ArrayList<String>()
        for (c in currentClips) fileNames.add(c.fileName)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(fileNames, 
                { p, msg -> progressBar.progress = p; tvStatus.text = msg },
                { path -> progressBar.visibility = View.GONE; tvStatus.text = "✅ 渲染完成"; btnSave.visibility = View.VISIBLE; btnSave.tag = path },
                { err -> progressBar.visibility = View.GONE; tvStatus.text = "失败: $err" }
            )
        }
    }

    private fun saveToGallery() {
        val filePath = btnSave.tag as? String ?: return
        val sourceFile = File(filePath)
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影"); put(MediaStore.Video.Media.IS_PENDING, 1) }
                }
                val resolver = contentResolver
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val uri = resolver.insert(collection, contentValues)
                uri?.let {
                    resolver.openOutputStream(it)?.use { outputStream -> FileInputStream(sourceFile).use { inputStream -> inputStream.copyTo(outputStream) } }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { contentValues.clear(); contentValues.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, contentValues, null, null) }
                }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "已保存到相册", Toast.LENGTH_LONG).show(); btnSave.visibility = View.GONE }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "保存失败", Toast.LENGTH_LONG).show() } }
        }
    }
}