package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    
    private lateinit var mainLayout: LinearLayout
    private lateinit var calibrateLayout: LinearLayout
    private lateinit var calibrateListContainer: LinearLayout
    private lateinit var btnSmartCalibrate: Button
    private lateinit var btnLockCorrect: Button
    private lateinit var btnReassemble: Button

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnGo: Button
    private lateinit var btnCalibrate: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private lateinit var layoutResult: LinearLayout
    private var isModelsReady: Boolean = false
    
    // 安全的强类型列表
    private var currentClips: MutableList<AndroidBridge.MatchedClip> = ArrayList()
    private var calibrateIteration: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()
        rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.parseColor("#05080E"))
        setContentView(rootLayout)
        
        // 极简激活拦截（硬编码跳过验证，如需激活取消注释）
        showMainApp()
    }

    private fun checkPermissions() {
        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.READ_MEDIA_VIDEO)
        else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = ArrayList<String>()
        for (p in perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) missing.add(p)
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }

    private fun showMainApp() {
        bridge = AndroidBridge(this)
        
        mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.setBackgroundColor(Color.parseColor("#05080E"))
        mainLayout.setPadding(40, 60, 40, 60)

        val title = TextView(this)
        title.text = "AI 剧情对齐工作区"
        title.setTextColor(Color.parseColor("#0EA5E9"))
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        title.setPadding(0, 0, 0, 30)
        mainLayout.addView(title)

        val t1 = TextView(this)
        t1.text = "1. 注入剧本"
        t1.setTextColor(Color.WHITE)
        t1.setPadding(0, 0, 0, 10)
        mainLayout.addView(t1)

        etScript = EditText(this)
        etScript.hint = "粘贴完整剧本台词..."
        etScript.setHintTextColor(Color.GRAY)
        etScript.setTextColor(Color.WHITE)
        etScript.setBackgroundColor(Color.parseColor("#1E293B"))
        etScript.setPadding(24, 24, 24, 24)
        etScript.minLines = 4
        etScript.gravity = Gravity.TOP
        mainLayout.addView(etScript)

        val t2 = TextView(this)
        t2.text = "2. 载入素材"
        t2.setTextColor(Color.WHITE)
        t2.setPadding(0, 20, 0, 10)
        mainLayout.addView(t2)

        tvClipCount = TextView(this)
        tvClipCount.text = "已选：0 个视频"
        tvClipCount.setTextColor(Color.parseColor("#7DD3FC"))
        mainLayout.addView(tvClipCount)

        btnImport = Button(this)
        btnImport.text = "📥 选择视频"
        btnImport.setBackgroundColor(Color.parseColor("#0284C7"))
        btnImport.setTextColor(Color.WHITE)
        btnImport.setOnClickListener { importVideos() }
        mainLayout.addView(btnImport)

        val t3 = TextView(this)
        t3.text = "3. 核心合成"
        t3.setTextColor(Color.WHITE)
        t3.setPadding(0, 20, 0, 10)
        mainLayout.addView(t3)

        btnGo = Button(this)
        btnGo.text = "🚀 开始智能对齐"
        btnGo.setBackgroundColor(Color.parseColor("#2563EB"))
        btnGo.setTextColor(Color.WHITE)
        btnGo.setOnClickListener { runEverything() }
        mainLayout.addView(btnGo)

        btnCalibrate = Button(this)
        btnCalibrate.text = "🔍 进入智能校准台"
        btnCalibrate.setBackgroundColor(Color.parseColor("#8B5CF6"))
        btnCalibrate.setTextColor(Color.WHITE)
        btnCalibrate.visibility = View.GONE
        btnCalibrate.setOnClickListener { showCalibrateLayout() }
        mainLayout.addView(btnCalibrate)

        btnSave = Button(this)
        btnSave.text = "💾 保存到相册"
        btnSave.setBackgroundColor(Color.parseColor("#059669"))
        btnSave.setTextColor(Color.WHITE)
        btnSave.visibility = View.GONE
        btnSave.setOnClickListener { saveToGallery() }
        mainLayout.addView(btnSave)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.visibility = View.GONE
        progressBar.setPadding(0, 20, 0, 10)
        mainLayout.addView(progressBar)

        tvStatus = TextView(this)
        tvStatus.text = "引擎就绪"
        tvStatus.setTextColor(Color.parseColor("#10B981"))
        tvStatus.gravity = Gravity.CENTER
        mainLayout.addView(tvStatus)

        layoutResult = LinearLayout(this)
        layoutResult.orientation = LinearLayout.VERTICAL
        layoutResult.visibility = View.GONE
        mainLayout.addView(layoutResult)

        val scrollView = ScrollView(this)
        scrollView.addView(mainLayout)
        rootLayout.addView(scrollView)

        buildCalibrateLayout()

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎就绪"
            }
        }
    }

    // ================= 智能校准台 UI =================
    private fun buildCalibrateLayout() {
        calibrateLayout = LinearLayout(this)
        calibrateLayout.orientation = LinearLayout.VERTICAL
        calibrateLayout.setBackgroundColor(Color.parseColor("#05080E"))
        calibrateLayout.setPadding(40, 60, 40, 60)
        calibrateLayout.visibility = View.GONE

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        val btnBack = Button(this)
        btnBack.text = "← 返回"
        btnBack.setBackgroundColor(Color.parseColor("#64748B"))
        btnBack.setTextColor(Color.WHITE)
        btnBack.setOnClickListener {
            calibrateLayout.visibility = View.GONE
            mainLayout.visibility = View.VISIBLE
        }
        header.addView(btnBack)
        calibrateLayout.addView(header)

        val actionRow = LinearLayout(this)
        actionRow.orientation = LinearLayout.HORIZONTAL

        btnSmartCalibrate = Button(this)
        btnSmartCalibrate.text = "🔄 智能校对"
        btnSmartCalibrate.setBackgroundColor(Color.parseColor("#F59E0B"))
        btnSmartCalibrate.setTextColor(Color.WHITE)
        var lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        btnSmartCalibrate.layoutParams = lp
        btnSmartCalibrate.setOnClickListener { intelligentCalibrate() }
        actionRow.addView(btnSmartCalibrate)

        btnLockCorrect = Button(this)
        btnLockCorrect.text = "🔒 锁定绿项"
        btnLockCorrect.setBackgroundColor(Color.parseColor("#059669"))
        btnLockCorrect.setTextColor(Color.WHITE)
        lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        btnLockCorrect.layoutParams = lp
        btnLockCorrect.setOnClickListener { lockCorrectClips() }
        actionRow.addView(btnLockCorrect)

        calibrateLayout.addView(actionRow)

        btnReassemble = Button(this)
        btnReassemble.text = "⚡ 按当前顺序合成"
        btnReassemble.setBackgroundColor(Color.parseColor("#2563EB"))
        btnReassemble.setTextColor(Color.WHITE)
        btnReassemble.setOnClickListener { startStitching() }
        calibrateLayout.addView(btnReassemble)

        calibrateListContainer = LinearLayout(this)
        calibrateListContainer.orientation = LinearLayout.VERTICAL
        calibrateListContainer.setPadding(0, 20, 0, 20)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        scroll.addView(calibrateListContainer)
        calibrateLayout.addView(scroll)

        rootLayout.addView(calibrateLayout)
    }

    private fun showCalibrateLayout() {
        mainLayout.visibility = View.GONE
        calibrateLayout.visibility = View.VISIBLE
        renderCalibrateList()
    }

    private fun renderCalibrateList() {
        calibrateListContainer.removeAllViews()
        for (idx in currentClips.indices) {
            val clip = currentClips[idx]
            val isGreen = clip.score >= 0.75f
            
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor(if (clip.locked) "#1E3A2E" else if (isGreen) "#14532D" else "#4C1D1D"))
            card.setPadding(20, 16, 20, 16)
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.setMargins(0, 8, 0, 8)
            card.layoutParams = p

            val statusIcon = if (clip.locked) "🔒" else if (isGreen) "✅" else "❌"
            val t1 = TextView(this)
            t1.text = "$statusIcon #${idx + 1}  ${clip.fileName.take(20)}"
            t1.setTextColor(Color.WHITE)
            t1.typeface = Typeface.DEFAULT_BOLD
            card.addView(t1)

            val t2 = TextView(this)
            t2.text = "🎤 视频: ${clip.text}"
            t2.setTextColor(Color.WHITE)
            t2.textSize = 12f
            card.addView(t2)

            val t3 = TextView(this)
            t3.text = "📖 剧本: ${clip.targetText}"
            t3.setTextColor(Color.parseColor("#7DD3FC"))
            t3.textSize = 12f
            card.addView(t3)

            val actionRow = LinearLayout(this)
            actionRow.orientation = LinearLayout.HORIZONTAL

            val btnLock = Button(this)
            btnLock.text = if (clip.locked) "🔓 解锁" else "🔒 锁定"
            btnLock.setBackgroundColor(Color.parseColor("#64748B"))
            btnLock.setOnClickListener { toggleLock(idx) }
            var lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            btnLock.layoutParams = lp
            actionRow.addView(btnLock)

            val btnReanchor = Button(this)
            btnReanchor.text = "✏️ 重锚定"
            btnReanchor.setBackgroundColor(Color.parseColor("#6366F1"))
            btnReanchor.setOnClickListener { showReanchorDialog(idx) }
            lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            btnReanchor.layoutParams = lp
            actionRow.addView(btnReanchor)

            card.addView(actionRow)
            calibrateListContainer.addView(card)
        }
    }

    // ================= 智能校对逻辑 =================
    private fun intelligentCalibrate() {
        if (currentClips.isEmpty() || bridge.sentences.isEmpty()) return
        btnSmartCalibrate.isEnabled = false
        calibrateIteration++
        calibrateListContainer.removeAllViews()
        
        val loading = TextView(this)
        loading.text = "🔄 正在执行第 $calibrateIteration 次智能校对..."
        loading.setTextColor(Color.parseColor("#0EA5E9"))
        loading.gravity = Gravity.CENTER
        loading.setPadding(0, 100, 0, 100)
        calibrateListContainer.addView(loading)

        CoroutineScope(Dispatchers.Main).launch {
            val result = withContext(Dispatchers.Default) {
                bridge.recalibrateUnlocked(currentClips, bridge.sentences, calibrateIteration)
            }
            currentClips = result.toMutableList()
            renderCalibrateList()
            btnSmartCalibrate.isEnabled = true
            Toast.makeText(this@MainActivity, "校对完成，提升了匹配度", Toast.LENGTH_SHORT).show()
        }
    }

    private fun lockCorrectClips() {
        var count = 0
        val newList = ArrayList<AndroidBridge.MatchedClip>()
        for (clip in currentClips) {
            if (!clip.locked && clip.score >= 0.75f) {
                count++
                newList.add(clip.copy(locked = true))
            } else {
                newList.add(clip)
            }
        }
        currentClips = newList
        renderCalibrateList()
        Toast.makeText(this, "已锁定 $count 个正确项", Toast.LENGTH_SHORT).show()
    }

    private fun toggleLock(idx: Int) {
        val clip = currentClips[idx]
        currentClips[idx] = clip.copy(locked = !clip.locked)
        renderCalibrateList()
    }

    private fun showReanchorDialog(idx: Int) {
        val options = bridge.sentences.mapIndexed { i, s -> "${i + 1}. $s" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("重锚定 #${idx + 1}").setItems(options) { d, which ->
            val clip = currentClips[idx]
            var pos = 0
            for (i in 0 until which) pos += bridge.sentences[i].length
            currentClips[idx] = clip.copy(scriptCharPos = pos, targetText = bridge.sentences[which], score = 1.0f, locked = true)
            renderCalibrateList()
            d.dismiss()
        }.show()
    }

    // ================= 基础流程 =================
    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false
        CoroutineScope(Dispatchers.IO).launch {
            val names = ArrayList<String>()
            val uris = ArrayList<String>()
            try {
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME), null, null, null)
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        names.add(cursor.getString(1) ?: "unknown.mp4")
                        uris.add(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cursor.getLong(0)).toString())
                    }
                    cursor.close()
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (names.isEmpty()) return@withContext
                    val checked = BooleanArray(names.size)
                    AlertDialog.Builder(this@MainActivity).setTitle("选择视频").setMultiChoiceItems(names.toTypedArray(), checked) { _, i, c -> checked[i] = c }.setPositiveButton("导入") { _, _ ->
                        val sel = ArrayList<String>()
                        for (i in checked.indices) if (checked[i]) sel.add(uris[i])
                        if (sel.isNotEmpty()) downloadVideos(sel)
                    }.show()
                }
            } catch (e: Exception) { withContext(Dispatchers.Main) { btnImport.isEnabled = true } }
        }
    }

    private fun downloadVideos(uris: List<String>) {
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val files = ArrayList<String>()
            for (i in uris.indices) {
                withContext(Dispatchers.Main) { progressBar.progress = (i * 100 / uris.size) }
                try {
                    val n = "video_${System.currentTimeMillis()}_$i.mp4"
                    contentResolver.openInputStream(android.net.Uri.parse(uris[i]))?.use { input ->
                        FileOutputStream(File(bridge.uploadDir, n)).use { output -> input.copyTo(output) }
                    }
                    files.add(n)
                } catch (e: Exception) {}
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                bridge.uploadedClips.clear()
                bridge.uploadedClips.addAll(files)
                tvClipCount.text = "已选：${files.size} 个视频"
            }
        }
    }

    private fun runEverything() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty() || bridge.uploadedClips.isEmpty() || !isModelsReady) return
        btnGo.isEnabled = false; btnImport.isEnabled = false
        progressBar.visibility = View.VISIBLE
        
        CoroutineScope(Dispatchers.Main).launch {
            bridge.parseScript(script)
            var result: List<AndroidBridge.MatchedClip>? = null
            bridge.processAll(script, 
                { p, msg -> progressBar.progress = p; tvStatus.text = msg },
                { clips ->
                    result = clips
                    progressBar.visibility = View.GONE
                    tvStatus.text = "✅ 对齐完成，请进入校准台复核"
                    btnGo.isEnabled = true; btnImport.isEnabled = true
                    btnCalibrate.visibility = View.VISIBLE
                    currentClips = clips.toMutableList()
                },
                { err ->
                    progressBar.visibility = View.GONE
                    tvStatus.text = "失败: $err"
                    btnGo.isEnabled = true; btnImport.isEnabled = true
                }
            )
        }
    }

    private fun startStitching() {
        if (currentClips.isEmpty()) return
        currentClips.sortBy { it.scriptCharPos }
        calibrateLayout.visibility = View.GONE
        mainLayout.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        
        val json = bridge.buildJson(currentClips)
        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(json, 
                { p, msg -> progressBar.progress = p; tvStatus.text = msg },
                { path ->
                    progressBar.visibility = View.GONE
                    tvStatus.text = "✅ 合成完成"
                    btnSave.visibility = View.VISIBLE
                    btnSave.tag = path
                },
                { err -> progressBar.visibility = View.GONE; tvStatus.text = "合成失败: $err" }
            )
        }
    }

    private fun saveToGallery() {
        val path = btnSave.tag as? String ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cv = ContentValues()
                cv.put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu.mp4")
                cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/灵序织影")
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(File(path)).use { ins -> ins.copyTo(out) } }
                }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "已保存到相册", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {}
        }
    }
}