package com.lingxu.zhiying

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout
    private lateinit var calibrateLayout: LinearLayout
    private lateinit var calibrateListContainer: LinearLayout
    private lateinit var btnSmartCalibrate: Button
    private lateinit var btnLockCorrect: Button
    private lateinit var btnReassemble: Button
    private val REQ_CODE_PERM = 100
    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private var deviceId = ""
    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var tvStepHint: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnGo: Button
    private lateinit var btnCalibrate: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private lateinit var layoutResult: LinearLayout
    private var isModelsReady = false
    private var currentClips: MutableList<AndroidBridge.MatchedClip> = mutableListOf()
    private var calibrateIteration = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        deviceId = prefs.getString("device_id", null) ?: UUID.randomUUID().toString()
            .replace("-", "").take(8).uppercase().also { prefs.edit().putString("device_id", it).apply() }
        if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
    }

    private fun checkPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_VIDEO)
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(80, 180, 80, 80); gravity = Gravity.CENTER_HORIZONTAL
        }
        authLayout.addView(TextView(this).apply {
            text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        authLayout.addView(TextView(this).apply {
            text = "AI 智能剧情对齐剪辑"; setTextColor(Color.GRAY); textSize = 14f
            gravity = Gravity.CENTER; setPadding(0, 12, 0, 50)
        })
        authLayout.addView(TextView(this).apply {
            text = "本机设备码（点击复制）"; setTextColor(Color.GRAY); textSize = 13f; gravity = Gravity.CENTER
        })
        tvDeviceCode = TextView(this).apply {
            text = deviceId; setTextColor(Color.parseColor("#10B981"))
            textSize = 32f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER
            setPadding(0, 10, 0, 40)
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "已复制", Toast.LENGTH_SHORT).show()
            }
        }
        etActivationCode = EditText(this).apply {
            hint = "输入 32 位激活码"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(30, 30, 30, 30); gravity = Gravity.CENTER; textSize = 15f
        }
        authLayout.addView(tvDeviceCode)
        authLayout.addView(etActivationCode)
        authLayout.addView(Button(this).apply {
            text = "激活"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE)
            setTextSize(16f); setPadding(0, 30, 0, 30)
            setOnClickListener { verifyActivation() }
        })
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "激活码应为 32 位", Toast.LENGTH_SHORT).show(); return }
        val ob = byteArrayOf(0x16,0x3B,0x38,0x31,0x06,0x2E,0x1A,0x3A,0x39,0x03,0x16,0x3D,0x39,0x52,0x1B,0x35,0x30,0x16,0x12,0x0B,0x02,0x5A,0x13,0x3B,0x39,0x30,0x3B,0x17,0x39,0x3B,0x13,0x1E)
        val key = String(ByteArray(ob.size) { (ob[it].toInt() xor 0x5A).toByte() })
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
            val expected = mac.doFinal(deviceId.toByteArray()).joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expected) {
                Toast.makeText(this, "激活成功", Toast.LENGTH_SHORT).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE; showMainApp()
            } else Toast.makeText(this, "激活码错误", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun bigButton(text: String, color: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; setBackgroundColor(Color.parseColor(color)); setTextColor(Color.WHITE); setTextSize(17f)
        setPadding(0, 30, 0, 30); setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 14, 0, 0) }
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) { mainLayout.visibility = View.VISIBLE; return }
        bridge = AndroidBridge(this) { runOnUiThread { Toast.makeText(this, it, Toast.LENGTH_SHORT).show() } }
        mainLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(50, 70, 50, 70) }
        mainLayout.addView(TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        mainLayout.addView(TextView(this).apply { text = "剧本 ↔ 视频台词 智能对齐剪辑"; setTextColor(Color.GRAY); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, 6, 0, 26) })
        mainLayout.addView(TextView(this).apply { text = "第一步 · 粘贴剧本"; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, 8) })
        etScript = EditText(this).apply { hint = "把剧本台词整段粘进来\n（必须带标点或换行分句）"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(28, 24, 28, 24); minLines = 4; gravity = Gravity.TOP }
        mainLayout.addView(etScript)
        mainLayout.addView(TextView(this).apply { text = "第二步 · 选视频素材"; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 24, 0, 8) })
        tvClipCount = TextView(this).apply { text = "已选：0 个视频"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 13f; setPadding(0, 0, 0, 8) }
        btnImport = bigButton("📥 选择视频", "#0284C7") { importVideos() }
        mainLayout.addView(tvClipCount); mainLayout.addView(btnImport)
        mainLayout.addView(TextView(this).apply { text = "第三步 · 一键出片"; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 24, 0, 8) })
        btnGo = bigButton("🚀 开始智能对齐与合成", "#2563EB") { runEverything() }
        mainLayout.addView(btnGo)
        btnCalibrate = bigButton("🔍 智能校准台 · 逐句复核", "#8B5CF6") { showCalibrateLayout() }
        btnCalibrate.visibility = View.GONE; mainLayout.addView(btnCalibrate)
        btnSave = bigButton("💾 保存到手机相册", "#059669") { saveToGallery() }
        btnSave.visibility = View.GONE; mainLayout.addView(btnSave)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 20, 0, 10) } }
        tvStepHint = TextView(this).apply { text = ""; setTextColor(Color.parseColor("#F59E0B")); textSize = 13f; gravity = Gravity.CENTER }
        tvStatus = TextView(this).apply { text = "准备就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        mainLayout.addView(progressBar); mainLayout.addView(tvStepHint); mainLayout.addView(tvStatus)
        layoutResult = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#1E293B")); setPadding(20, 20, 20, 20); visibility = View.GONE; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 20, 0, 0) } }
        mainLayout.addView(layoutResult)
        rootLayout.addView(ScrollView(this).apply { isFillViewport = true; addView(mainLayout) })
        buildCalibrateLayout()
        CoroutineScope(Dispatchers.Main).launch { bridge.modelsReadyFlow.collect { ready -> isModelsReady = ready; if (ready) tvStatus.text = "AI 引擎就绪" } }
    }

    private fun buildCalibrateLayout() {
        calibrateLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(40, 60, 40, 60); visibility = View.GONE }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(Button(this).apply { text = "← 返回"; setBackgroundColor(Color.parseColor("#64748B")); setTextColor(Color.WHITE); textSize = 13f; minWidth = 0; minimumWidth = 0; setOnClickListener { calibrateLayout.visibility = View.GONE; mainLayout.visibility = View.VISIBLE } })
        header.addView(TextView(this).apply { text = "  🔍 智能校准台"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 20f; typeface = Typeface.DEFAULT_BOLD })
        calibrateLayout.addView(header)
        calibrateLayout.addView(TextView(this).apply { text = "✅绿标=三维度全部通过（100%可信）\n❌红标=需人工确认\n🔒=人工锁定（永不被自动改写）"; setTextColor(Color.GRAY); textSize = 12f; setPadding(0, 10, 0, 12) })
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnSmartCalibrate = Button(this).apply { text = "🔄 智能校对"; setBackgroundColor(Color.parseColor("#F59E0B")); setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 22, 0, 22); minWidth = 0; minimumWidth = 0; layoutParams = LinearLayout.LayoutParams(0, -2, 1f); setOnClickListener { intelligentCalibrate() } }
        btnLockCorrect = Button(this).apply { text = "🔒 回锁正确项"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 22, 0, 22); minWidth = 0; minimumWidth = 0; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(10, 0, 0, 0) }; setOnClickListener { lockCorrectClips() } }
        actionRow.addView(btnSmartCalibrate); actionRow.addView(btnLockCorrect)
        calibrateLayout.addView(actionRow)
        btnReassemble = Button(this).apply { text = "⚡ 按当前顺序重新合成"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); textSize = 15f; setPadding(0, 24, 0, 24); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 0) }; setOnClickListener { reassembleFromCalibrate() } }
        calibrateLayout.addView(btnReassemble)
        calibrateListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 14, 0, 14) }
        calibrateLayout.addView(ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); addView(calibrateListContainer) })
        rootLayout.addView(calibrateLayout)
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false; btnSave.visibility = View.GONE; layoutResult.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = mutableListOf<Map<String, Any>>()
                val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
                contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c -> while (c.moveToNext()) list.add(mapOf("id" to c.getLong(0), "name" to c.getString(1))) }
                withContext(Dispatchers.Main) { btnImport.isEnabled = true; if (list.isNotEmpty()) selectVideosDialog(list) else Toast.makeText(this@MainActivity, "相册里没找到视频", Toast.LENGTH_SHORT).show() }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { btnImport.isEnabled = true } }
        }
    }

    private fun selectVideosDialog(list: List<Map<String, Any>>) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 20) }
        val cbAll = CheckBox(this).apply { text = "全选"; setTextColor(Color.parseColor("#0284C7")); textSize = 16f; typeface = Typeface.DEFAULT_BOLD }
        container.addView(cbAll)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cbs = mutableListOf<CheckBox>()
        list.forEach { m -> cbs.add(CheckBox(this).apply { text = m["name"] as String; setTextColor(Color.parseColor("#334155")); textSize = 14f; setPadding(0, 10, 0, 10); setOnCheckedChangeListener { _, _ -> cbAll.isChecked = cbs.all { it.isChecked } } }.also { layout.addView(it) }) }
        container.addView(ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 600); addView(layout) })
        cbAll.setOnCheckedChangeListener { _, c -> cbs.forEach { it.isChecked = c } }
        AlertDialog.Builder(this).setTitle("选择要拼接的视频").setView(container).setPositiveButton("确定") { _, _ -> val sel = list.filterIndexed { i, _ -> cbs[i].isChecked }; if (sel.isNotEmpty()) downloadVideos(sel) }.setNegativeButton("取消", null).show()
    }

    private fun downloadVideos(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0; tvStatus.text = "正在导入视频..."
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles(); val names = mutableListOf<String>()
            videos.forEachIndexed { i, m ->
                withContext(Dispatchers.Main) { tvStatus.text = "导入 ${i + 1}/${videos.size}"; progressBar.progress = ((i + 1f) / videos.size * 100).toInt() }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, m["id"] as Long)
                    val n = "${System.currentTimeMillis()}_${m["name"]}"
                    FileOutputStream(File(bridge.uploadDir, n)).use { o -> contentResolver.openInputStream(uri)?.use { it.copyTo(o) } }
                    names.add(n)
                } catch (_: Throwable) {}
            }
            withContext(Dispatchers.Main) { progressBar.visibility = View.GONE; if (names.isNotEmpty()) { bridge.uploadedClips.clear(); bridge.uploadedClips.addAll(names); tvClipCount.text = "已选：${names.size} 个视频"; tvStatus.text = "视频导入完成" } }
        }
    }

    private fun runEverything() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty()) { Toast.makeText(this, "请先粘贴剧本", Toast.LENGTH_SHORT).show(); return }
        if (bridge.uploadedClips.isEmpty()) { Toast.makeText(this, "请先选择视频", Toast.LENGTH_SHORT).show(); return }
        if (!isModelsReady) { Toast.makeText(this, "AI 引擎加载中，请稍等", Toast.LENGTH_SHORT).show(); return }
        btnGo.isEnabled = false; btnImport.isEnabled = false; btnCalibrate.visibility = View.GONE; btnSave.visibility = View.GONE; layoutResult.visibility = View.GONE; progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        CoroutineScope(Dispatchers.Main).launch {
            tvStepHint.text = "第一步：分析剧本与视频台词..."
            var alignOk = false
            bridge.parseAndAlign(script, { p, msg -> progressBar.progress = (p * 0.7f).toInt(); tvStatus.text = msg }, { result -> currentClips = result.toMutableList(); alignOk = true }, { }, { e -> tvStepHint.text = "对齐失败：$e"; btnGo.isEnabled = true; btnImport.isEnabled = true; progressBar.visibility = View.GONE })
            if (!alignOk || currentClips.isEmpty()) return@launch
            tvStepHint.text = "第二步：自动拼接视频..."
            val json = bridge.buildJson(currentClips)
            bridge.stitchVideo(json, { p, msg -> progressBar.progress = 70 + (p * 0.3f).toInt(); tvStatus.text = msg }, { path -> progressBar.visibility = View.GONE; tvStepHint.text = ""; tvStatus.text = "✅ 完成！可进入校准台复核"; btnGo.isEnabled = true; btnImport.isEnabled = true; btnCalibrate.visibility = View.VISIBLE; btnSave.visibility = View.VISIBLE; btnSave.tag = path; showResultSummary() }, { e -> progressBar.visibility = View.GONE; tvStepHint.text = "合成失败：$e"; btnGo.isEnabled = true; btnImport.isEnabled = true })
        }
    }

    private fun showResultSummary() {
        layoutResult.removeAllViews(); layoutResult.visibility = View.VISIBLE
        val total = currentClips.size; val green = currentClips.count { bridge.judgeAlignment(it).isGreen }; val red = total - green
        layoutResult.addView(TextView(this).apply { text = "📊 初次对齐结果"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, 10) })
        layoutResult.addView(TextView(this).apply { text = "共 $total 个片段  |  ✅ $green  |  ❌ $red\n绿色=三维度（相似度+字数比+关键词）全部通过，100%可信。"; setTextColor(if (red > 0) Color.parseColor("#F59E0B") else Color.parseColor("#10B981")); textSize = 13f })
    }

    private fun showCalibrateLayout() { mainLayout.visibility = View.GONE; calibrateLayout.visibility = View.VISIBLE; renderCalibrateList() }

    private fun renderCalibrateList() {
        calibrateListContainer.removeAllViews()
        if (currentClips.isEmpty()) { calibrateListContainer.addView(TextView(this).apply { text = "还没有对齐结果，请先执行智能对齐"; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, 60, 0, 60) }); return }
        val total = currentClips.size; val judgments = currentClips.map { bridge.judgeAlignment(it) }; val green = judgments.count { it.isGreen }; val red = total - green; val locked = currentClips.count { it.locked }
        calibrateListContainer.addView(TextView(this).apply { text = if (red == 0) "🎉 全部通过！$total/$total 绿标  |  🔒 已锁定 $locked" else "📊 总 $total  |  ✅绿 $green  |  ❌红 $red  |  🔒锁 $locked"; setTextColor(if (red == 0) Color.parseColor("#10B981") else Color.parseColor("#0EA5E9")); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, 14) })
        currentClips.forEachIndexed { idx, clip ->
            val judgment = judgments[idx]; val isGreen = judgment.isGreen
            val statusIcon = when { clip.locked -> "🔒"; isGreen -> "✅"; else -> "❌" }
            val bgColor = when { clip.locked -> Color.parseColor("#1E3A2E"); isGreen -> Color.parseColor("#14532D"); else -> Color.parseColor("#4C1D1D") }
            val textColor = when { clip.locked -> Color.parseColor("#10B981"); isGreen -> Color.parseColor("#34D399"); else -> Color.parseColor("#F87171") }
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bgColor); setPadding(20, 16, 20, 16); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) } }
            card.addView(TextView(this).apply { text = "$statusIcon #${idx + 1}  ${clip.fileName.substringAfter("_").take(20)}"; setTextColor(textColor); textSize = 13f; typeface = Typeface.DEFAULT_BOLD })
            card.addView(TextView(this).apply { val t = clip.text.ifEmpty { "（未识别）" }; text = "🎤 视频台词：${if (t.length > 38) t.take(38) + "…" else t}"; setTextColor(Color.WHITE); textSize = 12f; setPadding(0, 6, 0, 0) })
            card.addView(TextView(this).apply { val t = clip.targetText; text = "📖 剧本台词：${if (t.length > 38) t.take(38) + "…" else t}"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 12f; setPadding(0, 3, 0, 3) })
            card.addView(TextView(this).apply { text = "🔍 ${judgment.reason}"; setTextColor(textColor); textSize = 11f; setPadding(0, 3, 0, 8) })
            val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actionRow.addView(makeActionBtn(if (clip.locked) "🔓 解锁" else if (isGreen) "🔒 确认锁定" else "🔒 强制锁定", if (clip.locked) "#64748B" else if (isGreen) "#059669" else "#D97706") { toggleLock(idx) })
            actionRow.addView(makeActionBtn("✏️ 重锚定", "#6366F1") { showReanchorDialog(idx) })
            card.addView(actionRow); calibrateListContainer.addView(card)
        }
    }

    private fun makeActionBtn(text: String, color: String, onClick: () -> Unit): Button = Button(this).apply { this.text = text; setBackgroundColor(Color.parseColor(color)); setTextColor(Color.WHITE); textSize = 12f; minWidth = 0; minimumWidth = 0; setPadding(0, 16, 0, 16); layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, 6, 0) }; setOnClickListener { onClick() } }

    private fun intelligentCalibrate() {
        if (currentClips.isEmpty()) { Toast.makeText(this, "还没有对齐结果", Toast.LENGTH_SHORT).show(); return }
        if (bridge.sentences.isEmpty()) { Toast.makeText(this, "剧本句子未加载", Toast.LENGTH_SHORT).show(); return }
        val unlockedCount = currentClips.count { !it.locked }
        if (unlockedCount == 0) { Toast.makeText(this, "全部已锁定，无需校对", Toast.LENGTH_LONG).show(); return }
        val beforeGreen = currentClips.count { bridge.judgeAlignment(it).isGreen }
        calibrateIteration++; btnSmartCalibrate.isEnabled = false; btnLockCorrect.isEnabled = false; btnReassemble.isEnabled = false
        calibrateListContainer.removeAllViews()
        calibrateListContainer.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, 120, 0, 120)
            addView(ProgressBar(this@MainActivity).apply { layoutParams = LinearLayout.LayoutParams(90, 90) })
            addView(TextView(this@MainActivity).apply { text = "🔄 第 $calibrateIteration 次智能校对中...\n正在分析 $unlockedCount 个未锁定片段"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 0) })
        })
        CoroutineScope(Dispatchers.Main).launch {
            delay(180)
            val strategy = if (calibrateIteration % 2 == 1) "相似度匹配" else "字数对比匹配"
            val result = withContext(Dispatchers.Default) { bridge.recalibrateUnlocked(currentClips, bridge.sentences, calibrateIteration) }
            currentClips = result.clips.toMutableList()
            val afterGreen = currentClips.count { bridge.judgeAlignment(it).isGreen }
            renderCalibrateList(); btnSmartCalibrate.isEnabled = true; btnLockCorrect.isEnabled = true; btnReassemble.isEnabled = true
            val greenDelta = afterGreen - beforeGreen
            val msg = when { currentClips.all { it.locked } -> "🎉 全部锁定，无需再校对"; greenDelta > 0 -> "第 $calibrateIteration 次（$strategy）：✅绿 $beforeGreen → $afterGreen（+$greenDelta）"; result.improved > 0 -> "第 $calibrateIteration 次（$strategy）：改进了 ${result.improved} 个，但尚未达标。请再点一次或手动重锚定"; else -> "第 $calibrateIteration 次（$strategy）：无法再改进。请点红项「✏️ 重锚定」手动修正" }
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun lockCorrectClips() {
        if (currentClips.isEmpty()) return
        var lockedNow = 0
        currentClips = currentClips.map { if (!it.locked && bridge.judgeAlignment(it).isGreen) { lockedNow++; it.copy(locked = true) } else it }.toMutableList()
        renderCalibrateList()
        Toast.makeText(this, if (lockedNow > 0) "已回锁 $lockedNow 个绿标项，后续校对不会重置它们" else "当前没有可回锁的绿标项", Toast.LENGTH_LONG).show()
    }

    private fun toggleLock(idx: Int) {
        if (idx !in currentClips.indices) return
        val clip = currentClips[idx]; currentClips[idx] = clip.copy(locked = !clip.locked)
        renderCalibrateList(); Toast.makeText(this, if (currentClips[idx].locked) "已锁定 #${idx + 1}（永不改动）" else "已解锁 #${idx + 1}", Toast.LENGTH_SHORT).show()
    }

    private fun showReanchorDialog(idx: Int) {
        if (bridge.sentences.isEmpty()) return
        val options = bridge.sentences.mapIndexed { i, s -> "${i + 1}. $s" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("✏️ 重锚定 #${idx + 1}").setItems(options) { d, which ->
            val clip = currentClips[idx]; var pos = 0; for (i in 0 until which) pos += bridge.sentences[i].length
            currentClips[idx] = clip.copy(scriptCharPos = pos, targetText = bridge.sentences[which], score = 1.0f, locked = true)
            renderCalibrateList(); Toast.makeText(this, "已重锚定到第 ${which + 1} 句并锁定", Toast.LENGTH_SHORT).show(); d.dismiss()
        }.setNegativeButton("取消", null).show()
    }

    private fun reassembleFromCalibrate() {
        if (currentClips.isEmpty()) return
        currentClips.sortWith(compareBy({ it.scriptCharPos }, { it.fileName }))
        val json = bridge.buildJson(currentClips); calibrateLayout.visibility = View.GONE; mainLayout.visibility = View.VISIBLE; progressBar.visibility = View.VISIBLE; progressBar.progress = 0; tvStatus.text = "正在按校准后的顺序重新合成..."
        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(json, { p, msg -> progressBar.progress = p; tvStatus.text = msg }, { path -> progressBar.visibility = View.GONE; tvStatus.text = "✅ 重新合成完成，可保存"; btnSave.visibility = View.VISIBLE; btnSave.tag = path; btnCalibrate.visibility = View.VISIBLE; showResultSummary() }, { e -> progressBar.visibility = View.GONE; tvStatus.text = "合成失败：$e" })
        }
    }

    private fun saveToGallery() {
        val path = btnSave.tag as? String ?: return; val f = File(path); if (!f.exists()) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cv = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4"); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); if (Build.VERSION.SDK_INT >= 29) { put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/灵序织影"); put(MediaStore.Video.Media.IS_PENDING, 1) } }
                val uri = contentResolver.insert(if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)?.use { o -> FileInputStream(f).use { it.copyTo(o) } }
                if (Build.VERSION.SDK_INT >= 29) { cv.clear(); cv.put(MediaStore.Video.Media.IS_PENDING, 0); contentResolver.update(uri, cv, null, null) }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "已保存到相册", Toast.LENGTH_LONG).show(); btnSave.visibility = View.GONE }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "保存失败", Toast.LENGTH_LONG).show() } }
        }
    }
}