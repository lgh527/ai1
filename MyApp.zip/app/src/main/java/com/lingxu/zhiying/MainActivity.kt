package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout
    private lateinit var calibrateLayout: LinearLayout
    private lateinit var calibrateListContainer: LinearLayout
    private lateinit var btnSmartCalibrate: Button
    private lateinit var btnLockCorrect: Button
    private lateinit var btnReassemble: Button
    private val REQ_CODE_PERM = 100
    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private var deviceId = ""
    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var tvStepHint: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnGo: Button
    private lateinit var btnCalibrate: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private lateinit var layoutResult: LinearLayout
    private var isModelsReady = false
    private var currentClips: MutableList<AndroidBridge.MatchedClip> = mutableListOf()
    private var calibrateIteration = 0

    data class VideoItem(val id: Long, val name: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()
        rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.parseColor("#05080E"))
        setContentView(rootLayout)
        
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        var savedId = prefs.getString("device_id", null)
        if (savedId == null) {
            savedId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
            prefs.edit().putString("device_id", savedId).apply()
        }
        deviceId = savedId
        
        if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
    }

    private fun checkPermissions() {
        val perms: List<String> = if (Build.VERSION.SDK_INT >= 33) {
            listOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this)
        authLayout.orientation = LinearLayout.VERTICAL
        authLayout.setBackgroundColor(Color.parseColor("#05080E"))
        authLayout.setPadding(80, 180, 80, 80)
        authLayout.gravity = Gravity.CENTER_HORIZONTAL

        val title = TextView(this)
        title.text = "灵序织影"
        title.setTextColor(Color.parseColor("#0EA5E9"))
        title.textSize = 32f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        authLayout.addView(title)

        val subTitle = TextView(this)
        subTitle.text = "AI 智能剧情对齐剪辑"
        subTitle.setTextColor(Color.GRAY)
        subTitle.textSize = 14f
        subTitle.gravity = Gravity.CENTER
        subTitle.setPadding(0, 12, 0, 50)
        authLayout.addView(subTitle)

        val tip = TextView(this)
        tip.text = "本机设备码（点击复制）"
        tip.setTextColor(Color.GRAY)
        tip.textSize = 13f
        tip.gravity = Gravity.CENTER
        authLayout.addView(tip)

        tvDeviceCode = TextView(this)
        tvDeviceCode.text = deviceId
        tvDeviceCode.setTextColor(Color.parseColor("#10B981"))
        tvDeviceCode.textSize = 32f
        tvDeviceCode.typeface = Typeface.MONOSPACE
        tvDeviceCode.gravity = Gravity.CENTER
        tvDeviceCode.setPadding(0, 10, 0, 40)
        tvDeviceCode.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("DeviceCode", deviceId))
            Toast.makeText(this@MainActivity, "已复制", Toast.LENGTH_SHORT).show()
        }
        authLayout.addView(tvDeviceCode)

        etActivationCode = EditText(this)
        etActivationCode.hint = "输入 32 位激活码"
        etActivationCode.setHintTextColor(Color.GRAY)
        etActivationCode.setTextColor(Color.WHITE)
        etActivationCode.setBackgroundColor(Color.parseColor("#1E293B"))
        etActivationCode.setPadding(30, 30, 30, 30)
        etActivationCode.gravity = Gravity.CENTER
        etActivationCode.textSize = 15f
        authLayout.addView(etActivationCode)

        val btnActivate = Button(this)
        btnActivate.text = "激活"
        btnActivate.setBackgroundColor(Color.parseColor("#2563EB"))
        btnActivate.setTextColor(Color.WHITE)
        btnActivate.textSize = 16f
        btnActivate.setPadding(0, 30, 0, 30)
        btnActivate.setOnClickListener { verifyActivation() }
        authLayout.addView(btnActivate)

        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) {
            Toast.makeText(this, "激活码应为 32 位", Toast.LENGTH_SHORT).show()
            return
        }
        
        val ob = intArrayOf(22, 59, 56, 49, 6, 46, 26, 58, 57, 3, 22, 61, 57, 82, 27, 53, 48, 22, 18, 11, 2, 90, 19, 59, 57, 48, 59, 23, 57, 59, 19, 30)
        val keyBytes = ByteArray(ob.size)
        for (i in ob.indices) {
            keyBytes[i] = (ob[i] xor 90).toByte()
        }
        val key = String(keyBytes)
        
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
            val hashBytes = mac.doFinal(deviceId.toByteArray())
            val hexStr = hashBytes.joinToString("") { "%02x".format(it) }.uppercase()
            val expected = hexStr.substring(0, 32)
            
            if (input == expected) {
                Toast.makeText(this, "激活成功", Toast.LENGTH_SHORT).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE
                showMainApp()
            } else {
                Toast.makeText(this, "激活码错误", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createBtn(text: String, color: String, onClickAction: () -> Unit): Button {
        val btn = Button(this)
        btn.text = text
        btn.setBackgroundColor(Color.parseColor(color))
        btn.setTextColor(Color.WHITE)
        btn.textSize = 17f
        btn.setPadding(0, 30, 0, 30)
        btn.setOnClickListener { onClickAction() }
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 14, 0, 0)
        btn.layoutParams = params
        return btn
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) {
            mainLayout.visibility = View.VISIBLE
            return
        }
        
        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        
        mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.setBackgroundColor(Color.parseColor("#05080E"))
        mainLayout.setPadding(50, 70, 50, 70)

        val title = TextView(this)
        title.text = "灵序织影"
        title.setTextColor(Color.parseColor("#0EA5E9"))
        title.textSize = 26f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        mainLayout.addView(title)

        val subTitle = TextView(this)
        subTitle.text = "剧本 ↔ 视频台词 智能对齐剪辑"
        subTitle.setTextColor(Color.GRAY)
        subTitle.textSize = 13f
        subTitle.gravity = Gravity.CENTER
        subTitle.setPadding(0, 6, 0, 26)
        mainLayout.addView(subTitle)

        val t1 = TextView(this)
        t1.text = "第一步 · 粘贴剧本"
        t1.setTextColor(Color.WHITE)
        t1.textSize = 15f
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.setPadding(0, 0, 0, 8)
        mainLayout.addView(t1)

        etScript = EditText(this)
        etScript.hint = "把剧本台词整段粘进来\n（必须带标点或换行分句）"
        etScript.setHintTextColor(Color.GRAY)
        etScript.setTextColor(Color.WHITE)
        etScript.setBackgroundColor(Color.parseColor("#1E293B"))
        etScript.setPadding(28, 24, 28, 24)
        etScript.minLines = 4
        etScript.gravity = Gravity.TOP
        mainLayout.addView(etScript)

        val t2 = TextView(this)
        t2.text = "第二步 · 选视频素材"
        t2.setTextColor(Color.WHITE)
        t2.textSize = 15f
        t2.typeface = Typeface.DEFAULT_BOLD
        t2.setPadding(0, 24, 0, 8)
        mainLayout.addView(t2)

        tvClipCount = TextView(this)
        tvClipCount.text = "已选：0 个视频"
        tvClipCount.setTextColor(Color.parseColor("#7DD3FC"))
        tvClipCount.textSize = 13f
        tvClipCount.setPadding(0, 0, 0, 8)
        mainLayout.addView(tvClipCount)

        btnImport = createBtn("📥 选择视频", "#0284C7") { importVideos() }
        mainLayout.addView(btnImport)

        val t3 = TextView(this)
        t3.text = "第三步 · 一键出片"
        t3.setTextColor(Color.WHITE)
        t3.textSize = 15f
        t3.typeface = Typeface.DEFAULT_BOLD
        t3.setPadding(0, 24, 0, 8)
        mainLayout.addView(t3)

        btnGo = createBtn("🚀 开始智能对齐与合成", "#2563EB") { runEverything() }
        mainLayout.addView(btnGo)

        btnCalibrate = createBtn("🔍 智能校准台 · 逐句复核", "#8B5CF6") { showCalibrateLayout() }
        btnCalibrate.visibility = View.GONE
        mainLayout.addView(btnCalibrate)

        btnSave = createBtn("💾 保存到手机相册", "#059669") { saveToGallery() }
        btnSave.visibility = View.GONE
        mainLayout.addView(btnSave)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.visibility = View.GONE
        val pParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        pParams.setMargins(0, 20, 0, 10)
        progressBar.layoutParams = pParams
        mainLayout.addView(progressBar)

        tvStepHint = TextView(this)
        tvStepHint.text = ""
        tvStepHint.setTextColor(Color.parseColor("#F59E0B"))
        tvStepHint.textSize = 13f
        tvStepHint.gravity = Gravity.CENTER
        mainLayout.addView(tvStepHint)

        tvStatus = TextView(this)
        tvStatus.text = "准备就绪"
        tvStatus.setTextColor(Color.parseColor("#10B981"))
        tvStatus.textSize = 14f
        tvStatus.gravity = Gravity.CENTER
        tvStatus.setPadding(0, 8, 0, 8)
        mainLayout.addView(tvStatus)

        layoutResult = LinearLayout(this)
        layoutResult.orientation = LinearLayout.VERTICAL
        layoutResult.setBackgroundColor(Color.parseColor("#1E293B"))
        layoutResult.setPadding(20, 20, 20, 20)
        layoutResult.visibility = View.GONE
        val lParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lParams.setMargins(0, 20, 0, 0)
        layoutResult.layoutParams = lParams
        mainLayout.addView(layoutResult)

        val scrollView = ScrollView(this)
        scrollView.isFillViewport = true
        scrollView.addView(mainLayout)
        rootLayout.addView(scrollView)

        buildCalibrateLayout()

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎就绪"
            }
        }
    }

    private fun buildCalibrateLayout() {
        calibrateLayout = LinearLayout(this)
        calibrateLayout.orientation = LinearLayout.VERTICAL
        calibrateLayout.setBackgroundColor(Color.parseColor("#05080E"))
        calibrateLayout.setPadding(40, 60, 40, 60)
        calibrateLayout.visibility = View.GONE

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL

        val btnBack = Button(this)
        btnBack.text = "← 返回"
        btnBack.setBackgroundColor(Color.parseColor("#64748B"))
        btnBack.setTextColor(Color.WHITE)
        btnBack.textSize = 13f
        btnBack.minWidth = 0
        btnBack.minimumWidth = 0
        btnBack.setOnClickListener {
            calibrateLayout.visibility = View.GONE
            mainLayout.visibility = View.VISIBLE
        }
        header.addView(btnBack)

        val title = TextView(this)
        title.text = "  🔍 智能校准台"
        title.setTextColor(Color.parseColor("#0EA5E9"))
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        header.addView(title)
        calibrateLayout.addView(header)

        val tip = TextView(this)
        tip.text = "✅绿标=三维度全部通过（100%可信）\n❌红标=需人工确认\n🔒=人工锁定（永不被自动改写）"
        tip.setTextColor(Color.GRAY)
        tip.textSize = 12f
        tip.setPadding(0, 10, 0, 12)
        calibrateLayout.addView(tip)

        val actionRow = LinearLayout(this)
        actionRow.orientation = LinearLayout.HORIZONTAL

        btnSmartCalibrate = Button(this)
        btnSmartCalibrate.text = "🔄 智能校对"
        btnSmartCalibrate.setBackgroundColor(Color.parseColor("#F59E0B"))
        btnSmartCalibrate.setTextColor(Color.WHITE)
        btnSmartCalibrate.textSize = 14f
        btnSmartCalibrate.setPadding(0, 22, 0, 22)
        btnSmartCalibrate.minWidth = 0
        btnSmartCalibrate.minimumWidth = 0
        var lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        btnSmartCalibrate.layoutParams = lp
        btnSmartCalibrate.setOnClickListener { intelligentCalibrate() }
        actionRow.addView(btnSmartCalibrate)

        btnLockCorrect = Button(this)
        btnLockCorrect.text = "🔒 回锁正确项"
        btnLockCorrect.setBackgroundColor(Color.parseColor("#059669"))
        btnLockCorrect.setTextColor(Color.WHITE)
        btnLockCorrect.textSize = 14f
        btnLockCorrect.setPadding(0, 22, 0, 22)
        btnLockCorrect.minWidth = 0
        btnLockCorrect.minimumWidth = 0
        lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(10, 0, 0, 0)
        btnLockCorrect.layoutParams = lp
        btnLockCorrect.setOnClickListener { lockCorrectClips() }
        actionRow.addView(btnLockCorrect)

        calibrateLayout.addView(actionRow)

        btnReassemble = Button(this)
        btnReassemble.text = "⚡ 按当前顺序重新合成"
        btnReassemble.setBackgroundColor(Color.parseColor("#2563EB"))
        btnReassemble.setTextColor(Color.WHITE)
        btnReassemble.textSize = 15f
        btnReassemble.setPadding(0, 24, 0, 24)
        lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 10, 0, 0)
        btnReassemble.layoutParams = lp
        btnReassemble.setOnClickListener { reassembleFromCalibrate() }
        calibrateLayout.addView(btnReassemble)

        calibrateListContainer = LinearLayout(this)
        calibrateListContainer.orientation = LinearLayout.VERTICAL
        calibrateListContainer.setPadding(0, 14, 0, 14)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        scroll.addView(calibrateListContainer)
        calibrateLayout.addView(scroll)

        rootLayout.addView(calibrateLayout)
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        layoutResult.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = mutableListOf<VideoItem>()
                val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(0)
                        val name = cursor.getString(1) ?: "unknown.mp4"
                        list.add(VideoItem(id, name))
                    }
                    cursor.close()
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (list.isNotEmpty()) selectVideosDialog(list)
                    else Toast.makeText(this@MainActivity, "相册里没找到视频", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { btnImport.isEnabled = true }
            }
        }
    }

    private fun selectVideosDialog(list: List<VideoItem>) {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(40, 20, 40, 20)

        val cbAll = CheckBox(this)
        cbAll.text = "全选"
        cbAll.setTextColor(Color.parseColor("#0284C7"))
        cbAll.textSize = 16f
        cbAll.typeface = Typeface.DEFAULT_BOLD
        container.addView(cbAll)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val cbs = mutableListOf<CheckBox>()
        for (m in list) {
            val cb = CheckBox(this)
            cb.text = m.name
            cb.setTextColor(Color.parseColor("#334155"))
            cb.textSize = 14f
            cb.setPadding(0, 10, 0, 10)
            cb.setOnCheckedChangeListener { _, _ ->
                var allChecked = true
                for (c in cbs) { if (!c.isChecked) { allChecked = false; break } }
                cbAll.isChecked = allChecked
            }
            cbs.add(cb)
            layout.addView(cb)
        }

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 600)
        scroll.addView(layout)
        container.addView(scroll)

        cbAll.setOnCheckedChangeListener { _, isChecked ->
            for (cb in cbs) cb.isChecked = isChecked
        }

        AlertDialog.Builder(this)
            .setTitle("选择要拼接的视频")
            .setView(container)
            .setPositiveButton("确定") { _, _ ->
                val sel = mutableListOf<VideoItem>()
                for (i in cbs.indices) {
                    if (cbs[i].isChecked) sel.add(list[i])
                }
                if (sel.isNotEmpty()) downloadVideos(sel)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun downloadVideos(videos: List<VideoItem>) {
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        tvStatus.text = "正在导入视频..."
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val names = mutableListOf<String>()
            for (i in videos.indices) {
                val m = videos[i]
                withContext(Dispatchers.Main) {
                    tvStatus.text = "导入 ${i + 1}/${videos.size}"
                    progressBar.progress = ((i + 1f) / videos.size * 100f).toInt()
                }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, m.id)
                    val n = "${System.currentTimeMillis()}_${m.name}"
                    val outFile = File(bridge.uploadDir, n)
                    val inputStream = contentResolver.openInputStream(uri)
                    if (inputStream != null) {
                        val outputStream = FileOutputStream(outFile)
                        inputStream.copyTo(outputStream)
                        inputStream.close()
                        outputStream.close()
                        names.add(n)
                    }
                } catch (_: Throwable) {}
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                if (names.isNotEmpty()) {
                    bridge.uploadedClips.clear()
                    bridge.uploadedClips.addAll(names)
                    tvClipCount.text = "已选：${names.size} 个视频"
                    tvStatus.text = "视频导入完成"
                }
            }
        }
    }

    private fun runEverything() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty()) { Toast.makeText(this, "请先粘贴剧本", Toast.LENGTH_SHORT).show(); return }
        if (bridge.uploadedClips.isEmpty()) { Toast.makeText(this, "请先选择视频", Toast.LENGTH_SHORT).show(); return }
        if (!isModelsReady) { Toast.makeText(this, "AI 引擎加载中，请稍等", Toast.LENGTH_SHORT).show(); return }
        
        btnGo.isEnabled = false; btnImport.isEnabled = false
        btnCalibrate.visibility = View.GONE; btnSave.visibility = View.GONE
        layoutResult.visibility = View.GONE; progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        
        CoroutineScope(Dispatchers.Main).launch {
            tvStepHint.text = "第一步：分析剧本与视频台词..."
            var alignOk = false
            bridge.parseAndAlign(script, 
                { p, msg -> 
                    progressBar.progress = (p * 0.7f).toInt()
                    tvStatus.text = msg 
                }, 
                { result -> 
                    currentClips = result.toMutableList()
                    alignOk = true 
                }, 
                { }, 
                { e -> 
                    tvStepHint.text = "对齐失败：$e"
                    btnGo.isEnabled = true; btnImport.isEnabled = true
                    progressBar.visibility = View.GONE 
                }
            )
            if (!alignOk || currentClips.isEmpty()) return@launch
            
            tvStepHint.text = "第二步：自动拼接视频..."
            val json = bridge.buildJson(currentClips)
            bridge.stitchVideo(json, 
                { p, msg -> 
                    progressBar.progress = 70 + (p * 0.3f).toInt()
                    tvStatus.text = msg 
                }, 
                { path -> 
                    progressBar.visibility = View.GONE
                    tvStepHint.text = ""
                    tvStatus.text = "✅ 完成！可进入校准台复核"
                    btnGo.isEnabled = true; btnImport.isEnabled = true
                    btnCalibrate.visibility = View.VISIBLE
                    btnSave.visibility = View.VISIBLE
                    btnSave.tag = path
                    showResultSummary() 
                }, 
                { e -> 
                    progressBar.visibility = View.GONE
                    tvStepHint.text = "合成失败：$e"
                    btnGo.isEnabled = true; btnImport.isEnabled = true 
                }
            )
        }
    }

    private fun showResultSummary() {
        layoutResult.removeAllViews()
        layoutResult.visibility = View.VISIBLE
        val total = currentClips.size
        var green = 0
        for (clip in currentClips) {
            if (bridge.judgeAlignment(clip).isGreen) green++
        }
        val red = total - green

        val t1 = TextView(this)
        t1.text = "📊 初次对齐结果"
        t1.setTextColor(Color.parseColor("#0EA5E9"))
        t1.textSize = 15f
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.setPadding(0, 0, 0, 10)
        layoutResult.addView(t1)

        val t2 = TextView(this)
        t2.text = "共 $total 个片段  |  ✅ $green  |  ❌ $red\n绿色=三维度（相似度+字数比+关键词）全部通过，100%可信。"
        t2.setTextColor(if (red > 0) Color.parseColor("#F59E0B") else Color.parseColor("#10B981"))
        t2.textSize = 13f
        layoutResult.addView(t2)
    }

    private fun showCalibrateLayout() {
        mainLayout.visibility = View.GONE
        calibrateLayout.visibility = View.VISIBLE
        renderCalibrateList()
    }

    private fun renderCalibrateList() {
        calibrateListContainer.removeAllViews()
        if (currentClips.isEmpty()) {
            val tv = TextView(this)
            tv.text = "还没有对齐结果，请先执行智能对齐"
            tv.setTextColor(Color.GRAY)
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, 60, 0, 60)
            calibrateListContainer.addView(tv)
            return
        }
        
        val total = currentClips.size
        var green = 0
        var locked = 0
        val judgments = mutableListOf<AndroidBridge.Judgment>()
        for (clip in currentClips) {
            val j = bridge.judgeAlignment(clip)
            judgments.add(j)
            if (j.isGreen) green++
            if (clip.locked) locked++
        }
        val red = total - green

        val headerText = TextView(this)
        headerText.text = if (red == 0) "🎉 全部通过！$total/$total 绿标  |  🔒 已锁定 $locked" else "📊 总 $total  |  ✅绿 $green  |  ❌红 $red  |  🔒锁 $locked"
        headerText.setTextColor(if (red == 0) Color.parseColor("#10B981") else Color.parseColor("#0EA5E9"))
        headerText.textSize = 14f
        headerText.typeface = Typeface.DEFAULT_BOLD
        headerText.setPadding(0, 0, 0, 14)
        calibrateListContainer.addView(headerText)

        for (idx in currentClips.indices) {
            val clip = currentClips[idx]
            val judgment = judgments[idx]
            val isGreen = judgment.isGreen
            
            var statusIcon = "❌"
            if (clip.locked) statusIcon = "🔒"
            else if (isGreen) statusIcon = "✅"

            var bgColor = Color.parseColor("#4C1D1D")
            if (clip.locked) bgColor = Color.parseColor("#1E3A2E")
            else if (isGreen) bgColor = Color.parseColor("#14532D")

            var textColor = Color.parseColor("#F87171")
            if (clip.locked) textColor = Color.parseColor("#10B981")
            else if (isGreen) textColor = Color.parseColor("#34D399")

            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(bgColor)
            card.setPadding(20, 16, 20, 16)
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.setMargins(0, 6, 0, 6)
            card.layoutParams = p

            val t1 = TextView(this)
            t1.text = "$statusIcon #${idx + 1}  ${clip.fileName.substringAfter("_").take(20)}"
            t1.setTextColor(textColor)
            t1.textSize = 13f
            t1.typeface = Typeface.DEFAULT_BOLD
            card.addView(t1)

            val t2 = TextView(this)
            var txt = clip.text
            if (txt.isEmpty()) txt = "（未识别）"
            if (txt.length > 38) txt = txt.take(38) + "…"
            t2.text = "🎤 视频台词：$txt"
            t2.setTextColor(Color.WHITE)
            t2.textSize = 12f
            t2.setPadding(0, 6, 0, 0)
            card.addView(t2)

            val t3 = TextView(this)
            var tgt = clip.targetText
            if (tgt.length > 38) tgt = tgt.take(38) + "…"
            t3.text = "📖 剧本台词：$tgt"
            t3.setTextColor(Color.parseColor("#7DD3FC"))
            t3.textSize = 12f
            t3.setPadding(0, 3, 0, 3)
            card.addView(t3)

            val t4 = TextView(this)
            t4.text = "🔍 ${judgment.reason}"
            t4.setTextColor(textColor)
            t4.textSize = 11f
            t4.setPadding(0, 3, 0, 8)
            card.addView(t4)

            val actionRow = LinearLayout(this)
            actionRow.orientation = LinearLayout.HORIZONTAL
            
            val btnLock = Button(this)
            if (clip.locked) btnLock.text = "🔓 解锁"
            else if (isGreen) btnLock.text = "🔒 确认锁定"
            else btnLock.text = "🔒 强制锁定"
            
            btnLock.setBackgroundColor(Color.parseColor(if (clip.locked) "#64748B" else if (isGreen) "#059669" else "#D97706"))
            btnLock.setTextColor(Color.WHITE)
            btnLock.textSize = 12f
            btnLock.minWidth = 0
            btnLock.minimumWidth = 0
            btnLock.setPadding(0, 16, 0, 16)
            val lp1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp1.setMargins(0, 0, 6, 0)
            btnLock.layoutParams = lp1
            btnLock.setOnClickListener { toggleLock(idx) }
            actionRow.addView(btnLock)

            val btnReanchor = Button(this)
            btnReanchor.text = "✏️ 重锚定"
            btnReanchor.setBackgroundColor(Color.parseColor("#6366F1"))
            btnReanchor.setTextColor(Color.WHITE)
            btnReanchor.textSize = 12f
            btnReanchor.minWidth = 0
            btnReanchor.minimumWidth = 0
            btnReanchor.setPadding(0, 16, 0, 16)
            val lp2 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp2.setMargins(0, 0, 6, 0)
            btnReanchor.layoutParams = lp2
            btnReanchor.setOnClickListener { showReanchorDialog(idx) }
            actionRow.addView(btnReanchor)

            card.addView(actionRow)
            calibrateListContainer.addView(card)
        }
    }

    private fun intelligentCalibrate() {
        if (currentClips.isEmpty()) { Toast.makeText(this, "还没有对齐结果", Toast.LENGTH_SHORT).show(); return }
        if (bridge.sentences.isEmpty()) { Toast.makeText(this, "剧本句子未加载", Toast.LENGTH_SHORT).show(); return }
        
        var unlockedCount = 0
        for (clip in currentClips) { if (!clip.locked) unlockedCount++ }
        
        if (unlockedCount == 0) { Toast.makeText(this, "全部已锁定，无需校对", Toast.LENGTH_LONG).show(); return }
        
        var beforeGreen = 0
        for (clip in currentClips) { if (bridge.judgeAlignment(clip).isGreen) beforeGreen++ }
        
        calibrateIteration++
        btnSmartCalibrate.isEnabled = false
        btnLockCorrect.isEnabled = false
        btnReassemble.isEnabled = false

        calibrateListContainer.removeAllViews()
        val loading = LinearLayout(this)
        loading.orientation = LinearLayout.VERTICAL
        loading.gravity = Gravity.CENTER
        loading.setPadding(0, 120, 0, 120)
        
        val pb = ProgressBar(this)
        pb.layoutParams = LinearLayout.LayoutParams(90, 90)
        loading.addView(pb)
        
        val tv = TextView(this)
        tv.text = "🔄 第 $calibrateIteration 次智能校对中...\n正在分析 $unlockedCount 个未锁定片段"
        tv.setTextColor(Color.parseColor("#0EA5E9"))
        tv.textSize = 15f
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, 20, 0, 0)
        loading.addView(tv)
        
        calibrateListContainer.addView(loading)

        CoroutineScope(Dispatchers.Main).launch {
            delay(180L)
            val strategy = if (calibrateIteration % 2 == 1) "相似度匹配" else "字数对比匹配"
            val result = withContext(Dispatchers.Default) { bridge.recalibrateUnlocked(currentClips, bridge.sentences, calibrateIteration) }
            currentClips = result.clips.toMutableList()
            
            var afterGreen = 0
            for (clip in currentClips) { if (bridge.judgeAlignment(clip).isGreen) afterGreen++ }
            
            renderCalibrateList()
            btnSmartCalibrate.isEnabled = true
            btnLockCorrect.isEnabled = true
            btnReassemble.isEnabled = true

            val greenDelta = afterGreen - beforeGreen
            var msg = ""
            if (currentClips.all { it.locked }) {
                msg = "🎉 全部锁定，无需再校对"
            } else if (greenDelta > 0) {
                msg = "第 $calibrateIteration 次（$strategy）：✅绿 $beforeGreen → $afterGreen（+$greenDelta）"
            } else if (result.improved > 0) {
                msg = "第 $calibrateIteration 次（$strategy）：改进了 ${result.improved} 个，但尚未达标。请再点一次或手动重锚定"
            } else {
                msg = "第 $calibrateIteration 次（$strategy）：无法再改进。请点红项「✏️ 重锚定」手动修正"
            }
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun lockCorrectClips() {
        if (currentClips.isEmpty()) return
        var lockedNow = 0
        val newList = mutableListOf<AndroidBridge.MatchedClip>()
        for (clip in currentClips) {
            if (!clip.locked && bridge.judgeAlignment(clip).isGreen) {
                lockedNow++
                newList.add(clip.copy(locked = true))
            } else {
                newList.add(clip)
            }
        }
        currentClips = newList
        renderCalibrateList()
        Toast.makeText(this, if (lockedNow > 0) "已回锁 $lockedNow 个绿标项，后续校对不会重置它们" else "当前没有可回锁的绿标项", Toast.LENGTH_LONG).show()
    }

    private fun toggleLock(idx: Int) {
        if (idx < 0 || idx >= currentClips.size) return
        val clip = currentClips[idx]
        currentClips[idx] = clip.copy(locked = !clip.locked)
        renderCalibrateList()
        Toast.makeText(this, if (currentClips[idx].locked) "已锁定 #${idx + 1}（永不改动）" else "已解锁 #${idx + 1}", Toast.LENGTH_SHORT).show()
    }

    private fun showReanchorDialog(idx: Int) {
        if (bridge.sentences.isEmpty()) return
        val options = bridge.sentences.mapIndexed { i, s -> "${i + 1}. $s" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("✏️ 重锚定 #${idx + 1}").setItems(options) { d, which ->
            val clip = currentClips[idx]
            var pos = 0
            for (i in 0 until which) pos += bridge.sentences[i].length
            currentClips[idx] = clip.copy(scriptCharPos = pos, targetText = bridge.sentences[which], score = 1.0f, locked = true)
            renderCalibrateList()
            Toast.makeText(this, "已重锚定到第 ${which + 1} 句并锁定", Toast.LENGTH_SHORT).show()
            d.dismiss()
        }.setNegativeButton("取消", null).show()
    }

    private fun reassembleFromCalibrate() {
        if (currentClips.isEmpty()) return
        currentClips.sortWith(compareBy({ it.scriptCharPos }, { it.fileName }))
        val json = bridge.buildJson(currentClips)
        calibrateLayout.visibility = View.GONE
        mainLayout.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        tvStatus.text = "正在按校准后的顺序重新合成..."
        
        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(json, 
                { p, msg -> 
                    progressBar.progress = p
                    tvStatus.text = msg 
                }, 
                { path -> 
                    progressBar.visibility = View.GONE
                    tvStatus.text = "✅ 重新合成完成，可保存"
                    btnSave.visibility = View.VISIBLE
                    btnSave.tag = path
                    btnCalibrate.visibility = View.VISIBLE
                    showResultSummary() 
                }, 
                { e -> 
                    progressBar.visibility = View.GONE
                    tvStatus.text = "合成失败：$e" 
                }
            )
        }
    }

    private fun saveToGallery() {
        val path = btnSave.tag as? String ?: return
        val f = File(path)
        if (!f.exists()) return
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cv = ContentValues()
                cv.put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= 29) {
                    cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/灵序织影")
                    cv.put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(
                    if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI, 
                    cv
                )
                if (uri != null) {
                    val out = contentResolver.openOutputStream(uri)
                    if (out != null) {
                        val ins = FileInputStream(f)
                        ins.copyTo(out)
                        ins.close()
                        out.close()
                    }
                    if (Build.VERSION.SDK_INT >= 29) {
                        cv.clear()
                        cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                        contentResolver.update(uri, cv, null, null)
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "已保存到相册", Toast.LENGTH_LONG).show()
                    btnSave.visibility = View.GONE 
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "保存失败", Toast.LENGTH_LONG).show() 
                }
            }
        }
    }
}