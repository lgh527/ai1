package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout
    private lateinit var calibrateLayout: LinearLayout
    
    private lateinit var calibrateListContainer: LinearLayout

    private val REQ_CODE_PERM = 100
    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private var deviceId: String = ""

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnGo: Button
    private lateinit var btnCalibrate: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private var isModelsReady: Boolean = false
    private var currentClips: MutableList<AndroidBridge.MatchedClip> = ArrayList()
    private var calibrateIteration: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            checkPermissions()
            rootLayout = FrameLayout(this)
            rootLayout.setBackgroundColor(Color.parseColor("#05080E"))
            setContentView(rootLayout)

            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }

            if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString()).setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.READ_MEDIA_VIDEO)
        else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = ArrayList<String>()
        for (p in perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) missing.add(p)
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this)
        authLayout.orientation = LinearLayout.VERTICAL
        authLayout.setBackgroundColor(Color.parseColor("#05080E"))
        authLayout.setPadding(80, 200, 80, 80)
        authLayout.gravity = Gravity.CENTER_HORIZONTAL

        val title = TextView(this)
        title.text = "灵序织影"
        title.setTextColor(Color.parseColor("#0EA5E9"))
        title.textSize = 32f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        authLayout.addView(title)

        tvDeviceCode = TextView(this)
        tvDeviceCode.text = deviceId
        tvDeviceCode.setTextColor(Color.parseColor("#10B981"))
        tvDeviceCode.textSize = 28f
        tvDeviceCode.typeface = Typeface.MONOSPACE
        tvDeviceCode.gravity = Gravity.CENTER
        tvDeviceCode.setPadding(0, 20, 0, 40)
        tvDeviceCode.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("d", deviceId))
            Toast.makeText(this@MainActivity, "已复制", Toast.LENGTH_SHORT).show()
        }
        authLayout.addView(tvDeviceCode)

        etActivationCode = EditText(this)
        etActivationCode.hint = "请输入 32 位激活码"
        etActivationCode.setHintTextColor(Color.GRAY)
        etActivationCode.setTextColor(Color.WHITE)
        etActivationCode.setBackgroundColor(Color.parseColor("#1E293B"))
        etActivationCode.setPadding(30, 30, 30, 30)
        etActivationCode.gravity = Gravity.CENTER
        authLayout.addView(etActivationCode)

        val btnActivate = Button(this)
        btnActivate.text = "激活"
        btnActivate.setBackgroundColor(Color.parseColor("#2563EB"))
        btnActivate.setTextColor(Color.WHITE)
        btnActivate.setPadding(0, 30, 0, 30)
        btnActivate.setOnClickListener { verifyActivation() }
        authLayout.addView(btnActivate)

        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "格式错误，应为 32 位", Toast.LENGTH_SHORT).show(); return }
        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decryptedKeyBytes = ByteArray(obfuscatedBytes.size)
        for (i in obfuscatedBytes.indices) decryptedKeyBytes[i] = (obfuscatedBytes[i].toInt() xor xorKey).toByte()
        val realKey = String(decryptedKeyBytes)
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(realKey.toByteArray(), "HmacSHA256"))
            val expected = mac.doFinal(deviceId.toByteArray()).joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expected) {
                Toast.makeText(this, "激活成功", Toast.LENGTH_SHORT).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE
                showMainApp()
            } else Toast.makeText(this, "激活码错误", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) { mainLayout.visibility = View.VISIBLE; return }
        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        
        mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.setBackgroundColor(Color.parseColor("#05080E"))
        mainLayout.setPadding(50, 70, 50, 70)

        val title = TextView(this)
        title.text = "AI 剧情智能对齐剪辑"
        title.setTextColor(Color.parseColor("#0EA5E9"))
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        title.setPadding(0, 0, 0, 30)
        mainLayout.addView(title)

        etScript = EditText(this)
        etScript.hint = "把剧本台词整段粘进来..."
        etScript.setHintTextColor(Color.GRAY)
        etScript.setTextColor(Color.WHITE)
        etScript.setBackgroundColor(Color.parseColor("#1E293B"))
        etScript.setPadding(28, 24, 28, 24)
        etScript.minLines = 4
        etScript.gravity = Gravity.TOP
        mainLayout.addView(etScript)

        tvClipCount = TextView(this)
        tvClipCount.text = "已选：0 个视频"
        tvClipCount.setTextColor(Color.parseColor("#7DD3FC"))
        tvClipCount.setPadding(0, 20, 0, 10)
        mainLayout.addView(tvClipCount)

        btnImport = Button(this)
        btnImport.text = "📥 选择视频"
        btnImport.setBackgroundColor(Color.parseColor("#0284C7"))
        btnImport.setTextColor(Color.WHITE)
        btnImport.setOnClickListener { importVideos() }
        mainLayout.addView(btnImport)

        btnGo = Button(this)
        btnGo.text = "🚀 开始智能对齐"
        btnGo.setBackgroundColor(Color.parseColor("#2563EB"))
        btnGo.setTextColor(Color.WHITE)
        btnGo.setOnClickListener { runEverything() }
        mainLayout.addView(btnGo)

        btnCalibrate = Button(this)
        btnCalibrate.text = "🔍 进入智能校准台"
        btnCalibrate.setBackgroundColor(Color.parseColor("#8B5CF6"))
        btnCalibrate.setTextColor(Color.WHITE)
        btnCalibrate.visibility = View.GONE
        btnCalibrate.setOnClickListener { showCalibrateLayout() }
        mainLayout.addView(btnCalibrate)

        btnSave = Button(this)
        btnSave.text = "💾 保存到相册"
        btnSave.setBackgroundColor(Color.parseColor("#059669"))
        btnSave.setTextColor(Color.WHITE)
        btnSave.visibility = View.GONE
        btnSave.setOnClickListener { saveToGallery() }
        mainLayout.addView(btnSave)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.visibility = View.GONE
        progressBar.setPadding(0, 20, 0, 10)
        mainLayout.addView(progressBar)

        tvStatus = TextView(this)
        tvStatus.text = "准备就绪"
        tvStatus.setTextColor(Color.parseColor("#10B981"))
        tvStatus.gravity = Gravity.CENTER
        mainLayout.addView(tvStatus)

        val scrollView = ScrollView(this)
        scrollView.addView(mainLayout)
        rootLayout.addView(scrollView)

        buildCalibrateLayout()

        // 彻底抛弃 Flow，使用最原始的 Handler 轮询
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (bridge.isModelsLoaded) {
                    isModelsReady = true
                    tvStatus.text = "AI 引擎就绪"
                } else {
                    handler.postDelayed(this, 500L)
                }
            }
        }, 500L)
    }

    private fun buildCalibrateLayout() {
        calibrateLayout = LinearLayout(this)
        calibrateLayout.orientation = LinearLayout.VERTICAL
        calibrateLayout.setBackgroundColor(Color.parseColor("#05080E"))
        calibrateLayout.setPadding(40, 60, 40, 60)
        calibrateLayout.visibility = View.GONE

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        val btnBack = Button(this)
        btnBack.text = "← 返回"
        btnBack.setBackgroundColor(Color.parseColor("#64748B"))
        btnBack.setTextColor(Color.WHITE)
        btnBack.setOnClickListener { calibrateLayout.visibility = View.GONE; mainLayout.visibility = View.VISIBLE }
        header.addView(btnBack)
        calibrateLayout.addView(header)

        val actionRow = LinearLayout(this)
        actionRow.orientation = LinearLayout.HORIZONTAL

        val btnSmartCalibrate = Button(this)
        btnSmartCalibrate.text = "🔄 智能校对"
        btnSmartCalibrate.setBackgroundColor(Color.parseColor("#F59E0B"))
        btnSmartCalibrate.setTextColor(Color.WHITE)
        var lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        btnSmartCalibrate.layoutParams = lp
        btnSmartCalibrate.setOnClickListener { intelligentCalibrate() }
        actionRow.addView(btnSmartCalibrate)

        val btnLockCorrect = Button(this)
        btnLockCorrect.text = "🔒 锁定绿项"
        btnLockCorrect.setBackgroundColor(Color.parseColor("#059669"))
        btnLockCorrect.setTextColor(Color.WHITE)
        lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        btnLockCorrect.layoutParams = lp
        btnLockCorrect.setOnClickListener { lockCorrectClips() }
        actionRow.addView(btnLockCorrect)

        calibrateLayout.addView(actionRow)

        val btnReassemble = Button(this)
        btnReassemble.text = "⚡ 按当前顺序合成"
        btnReassemble.setBackgroundColor(Color.parseColor("#2563EB"))
        btnReassemble.setTextColor(Color.WHITE)
        btnReassemble.setOnClickListener { startStitching() }
        calibrateLayout.addView(btnReassemble)

        calibrateListContainer = LinearLayout(this)
        calibrateListContainer.orientation = LinearLayout.VERTICAL
        calibrateListContainer.setPadding(0, 20, 0, 20)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        scroll.addView(calibrateListContainer)
        calibrateLayout.addView(scroll)
        rootLayout.addView(calibrateLayout)
    }

    private fun showCalibrateLayout() {
        mainLayout.visibility = View.GONE
        calibrateLayout.visibility = View.VISIBLE
        renderCalibrateList()
    }

    private fun renderCalibrateList() {
        calibrateListContainer.removeAllViews()
        for (idx in currentClips.indices) {
            val clip = currentClips[idx]
            val isGreen = clip.score >= 0.75f
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor(if (clip.locked) "#1E3A2E" else if (isGreen) "#14532D" else "#4C1D1D"))
            card.setPadding(20, 16, 20, 16)
            val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            p.setMargins(0, 8, 0, 8)
            card.layoutParams = p

            val statusIcon = if (clip.locked) "🔒" else if (isGreen) "✅" else "❌"
            val t1 = TextView(this)
            t1.text = "$statusIcon #${idx + 1}  ${clip.fileName.take(20)}"
            t1.setTextColor(Color.WHITE)
            t1.typeface = Typeface.DEFAULT_BOLD
            card.addView(t1)

            val t2 = TextView(this)
            t2.text = "🎤 视频: ${clip.text}"
            t2.setTextColor(Color.WHITE)
            t2.textSize = 12f
            card.addView(t2)

            val t3 = TextView(this)
            t3.text = "📖 剧本: ${clip.targetText}"
            t3.setTextColor(Color.parseColor("#7DD3FC"))
            t3.textSize = 12f
            card.addView(t3)

            val actionRow = LinearLayout(this)
            actionRow.orientation = LinearLayout.HORIZONTAL

            val btnLock = Button(this)
            btnLock.text = if (clip.locked) "🔓 解锁" else "🔒 锁定"
            btnLock.setBackgroundColor(Color.parseColor("#64748B"))
            btnLock.setOnClickListener { toggleLock(idx) }
            var lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            btnLock.layoutParams = lp
            actionRow.addView(btnLock)

            val btnReanchor = Button(this)
            btnReanchor.text = "✏️ 重锚定"
            btnReanchor.setBackgroundColor(Color.parseColor("#6366F1"))
            btnReanchor.setOnClickListener { showReanchorDialog(idx) }
            lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            btnReanchor.layoutParams = lp
            actionRow.addView(btnReanchor)

            card.addView(actionRow)
            calibrateListContainer.addView(card)
        }
    }

    private fun intelligentCalibrate() {
        if (currentClips.isEmpty() || bridge.sentences.isEmpty()) return
        calibrateIteration++
        calibrateListContainer.removeAllViews()
        
        val loading = TextView(this)
        loading.text = "🔄 正在执行第 $calibrateIteration 次智能校对..."
        loading.setTextColor(Color.parseColor("#0EA5E9"))
        loading.gravity = Gravity.CENTER
        loading.setPadding(0, 100, 0, 100)
        calibrateListContainer.addView(loading)

        CoroutineScope(Dispatchers.Main).launch {
            val result = withContext(Dispatchers.Default) {
                bridge.recalibrateUnlocked(currentClips, bridge.sentences, calibrateIteration)
            }
            currentClips = result
            renderCalibrateList()
            Toast.makeText(this@MainActivity, "校对完成，提升了匹配度", Toast.LENGTH_SHORT).show()
        }
    }

    private fun lockCorrectClips() {
        var count = 0
        val newList = ArrayList<AndroidBridge.MatchedClip>()
        for (clip in currentClips) {
            if (!clip.locked && clip.score >= 0.75f) {
                count++
                newList.add(AndroidBridge.MatchedClip(clip.fileName, clip.text, clip.targetText, clip.score, clip.scriptCharPos, true))
            } else {
                newList.add(clip)
            }
        }
        currentClips = newList
        renderCalibrateList()
        Toast.makeText(this, "已锁定 $count 个正确项", Toast.LENGTH_SHORT).show()
    }

    private fun toggleLock(idx: Int) {
        val clip = currentClips[idx]
        currentClips[idx] = AndroidBridge.MatchedClip(clip.fileName, clip.text, clip.targetText, clip.score, clip.scriptCharPos, !clip.locked)
        renderCalibrateList()
    }

    private fun showReanchorDialog(idx: Int) {
        val options = ArrayList<String>()
        for (i in bridge.sentences.indices) {
            options.add("${i + 1}. ${bridge.sentences[i]}")
        }
        AlertDialog.Builder(this).setTitle("重锚定 #${idx + 1}").setItems(options.toTypedArray()) { d, which ->
            val clip = currentClips[idx]
            var pos = 0
            for (i in 0 until which) pos += bridge.sentences[i].length
            currentClips[idx] = AndroidBridge.MatchedClip(clip.fileName, clip.text, bridge.sentences[which], 1.0f, pos, true)
            renderCalibrateList()
            d.dismiss()
        }.show()
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val names = ArrayList<String>()
                val ids = ArrayList<Long>()
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME), null, null, null)
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        ids.add(cursor.getLong(0))
                        names.add(cursor.getString(1) ?: "unknown")
                    }
                    cursor.close()
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (names.isEmpty()) {
                        Toast.makeText(this@MainActivity, "相册无视频", Toast.LENGTH_SHORT).show()
                        return@withContext
                    }
                    val checked = BooleanArray(names.size)
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("选择视频")
                        .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, c -> checked[i] = c }
                        .setPositiveButton("导入") { _, _ ->
                            val selIds = ArrayList<Long>()
                            for (i in checked.indices) if (checked[i]) selIds.add(ids[i])
                            if (selIds.isNotEmpty()) downloadVideos(selIds)
                        }.show()
                }
            } catch (e: Exception) { withContext(Dispatchers.Main) { btnImport.isEnabled = true } }
        }
    }

    private fun downloadVideos(ids: List<Long>) {
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val files = ArrayList<String>()
            for (i in ids.indices) {
                withContext(Dispatchers.Main) { progressBar.progress = (i * 100 / ids.size) }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, ids[i])
                    val n = "v_${System.currentTimeMillis()}_$i.mp4"
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(File(bridge.uploadDir, n)).use { output -> input.copyTo(output) }
                    }
                    files.add(n)
                } catch (e: Exception) {}
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                bridge.uploadedClips.clear()
                bridge.uploadedClips.addAll(files)
                tvClipCount.text = "已选：${files.size} 个"
            }
        }
    }

    private fun runEverything() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty() || bridge.uploadedClips.isEmpty() || !isModelsReady) return
        btnGo.isEnabled = false; btnImport.isEnabled = false
        progressBar.visibility = View.VISIBLE
        
        CoroutineScope(Dispatchers.Main).launch {
            bridge.parseAndAlign(script, 
                { p, msg -> progressBar.progress = p; tvStatus.text = msg },
                { result ->
                    currentClips = result.toMutableList()
                    progressBar.visibility = View.GONE
                    tvStatus.text = "✅ 对齐完成"
                    btnGo.isEnabled = true; btnImport.isEnabled = true
                    btnCalibrate.visibility = View.VISIBLE
                },
                { err ->
                    progressBar.visibility = View.GONE
                    tvStatus.text = "失败: $err"
                    btnGo.isEnabled = true; btnImport.isEnabled = true
                }
            )
        }
    }

    private fun startStitching() {
        if (currentClips.isEmpty()) return
        currentClips.sortBy { it.scriptCharPos }
        calibrateLayout.visibility = View.GONE
        mainLayout.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        
        val fileNames = ArrayList<String>()
        for (c in currentClips) fileNames.add(c.fileName)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(fileNames, 
                { p, msg -> progressBar.progress = p; tvStatus.text = msg },
                { path ->
                    progressBar.visibility = View.GONE
                    tvStatus.text = "✅ 合成完成"
                    btnSave.visibility = View.VISIBLE
                    btnSave.tag = path
                },
                { err -> progressBar.visibility = View.GONE; tvStatus.text = "合成失败: $err" }
            )
        }
    }

    private fun saveToGallery() {
        val path = btnSave.tag as? String ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cv = ContentValues()
                cv.put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu.mp4")
                cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/灵序织影")
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(File(path)).use { ins -> ins.copyTo(out) } }
                }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "已保存到相册", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {}
        }
    }
}