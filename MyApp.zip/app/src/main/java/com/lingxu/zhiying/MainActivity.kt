package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout
    
    private val REQ_CODE_PERM = 100
    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private lateinit var btnActivate: Button
    private var deviceId: String = ""

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnAutoCalibrate: Button
    private lateinit var btnReset: Button
    private lateinit var btnStitch: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView
    private lateinit var layoutClipList: LinearLayout
    private var isModelsReady = false

    private var currentClips: MutableList<AndroidBridge.MatchedClip> = mutableListOf()
    private var initialClips: List<AndroidBridge.MatchedClip> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            checkPermissions()
            setupBaseUI()
            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }
            if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString()).setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun setupBaseUI() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(80, 200, 80, 80); gravity = Gravity.CENTER_HORIZONTAL }
        val title = TextView(this).apply { text = "灵序织影 V128"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val tvTip = TextView(this).apply { text = "终极防呆智能版"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) }
        tvDeviceCode = TextView(this).apply {
            text = deviceId; setTextColor(Color.parseColor("#10B981")); textSize = 28f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER; setPadding(0, 0, 0, 40)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "设备码已复制", Toast.LENGTH_SHORT).show()
            }
        }
        etActivationCode = EditText(this).apply { hint = "请输入 32 位激活码"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(30, 30, 30, 30); gravity = Gravity.CENTER; textSize = 14f }
        btnActivate = Button(this).apply { text = "立即激活"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setPadding(0, 30, 0, 30); setOnClickListener { verifyActivation() } }
        authLayout.addView(title); authLayout.addView(tvTip); authLayout.addView(tvDeviceCode); authLayout.addView(etActivationCode); authLayout.addView(btnActivate)
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "格式错误，应为 32 位", Toast.LENGTH_SHORT).show(); return }
        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decryptedKeyBytes = ByteArray(obfuscatedBytes.size)
        for (i in obfuscatedBytes.indices) decryptedKeyBytes[i] = (obfuscatedBytes[i].toInt() xor xorKey).toByte()
        val realKey = String(decryptedKeyBytes)
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(realKey.toByteArray(), "HmacSHA256"))
            val hashBytes = mac.doFinal(deviceId.toByteArray())
            val expectedCode = hashBytes.joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expectedCode) {
                Toast.makeText(this, "激活成功！", Toast.LENGTH_LONG).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE; showMainApp()
            } else Toast.makeText(this, "激活码错误", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) { mainLayout.visibility = View.VISIBLE; return }
        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        
        mainLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(60, 100, 60, 100) }
        
        val title = TextView(this).apply { text = "AI 极速智能防呆剪辑引擎"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 30) }
        val tvStep1 = TextView(this).apply { text = "第一步：输入剧情文本"; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0,0,0,10) }
        etScript = EditText(this).apply { hint = "在此粘贴您的剧本长文..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(30,30,30,30); minLines = 4; gravity = Gravity.TOP }
        
        val tvStep2 = TextView(this).apply { text = "第二步：导入 AI 视频切片"; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0,20,0,10) }
        btnImport = Button(this).apply { text = "📥 导入视频素材"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        tvClipCount = TextView(this).apply { text = "已导入素材：0 个"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 13f; setPadding(0,10,0,10) }
        
        val tvStep3 = TextView(this).apply { text = "第三步：AI 智能解析与深度校准"; setTextColor(Color.WHITE); textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0,20,0,10) }
        btnMatch = Button(this).apply { text = "🚀 启动 AI 剧情智能深度解析"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setOnClickListener { startMatching() } }
        
        val btnContainer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        btnAutoCalibrate = Button(this).apply { 
            text = "🪄 AI 坐标绝对校准"; 
            setBackgroundColor(Color.parseColor("#8B5CF6")) 
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            visibility = View.GONE
            setOnClickListener { autoCalibrate() } 
        }
        btnReset = Button(this).apply { 
            text = "🔄 重置"; 
            setBackgroundColor(Color.parseColor("#64748B")) 
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.4f).apply { setMargins(10, 0, 0, 0) }
            visibility = View.GONE
            setOnClickListener { resetOrder() } 
        }
        btnContainer.addView(btnAutoCalibrate)
        btnContainer.addView(btnReset)

        layoutClipList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#1E293B")); setPadding(20,20,20,20); visibility = View.GONE }
        
        btnStitch = Button(this).apply { text = "⚡ 确认排序，极速无损合成"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); setPadding(0,30,0,30); setOnClickListener { startStitching() } }
        btnSave = Button(this).apply { text = "💾 导出并保存至相册 (MP4)"; setBackgroundColor(Color.parseColor("#D97706")); setTextColor(Color.WHITE); setPadding(0,30,0,30); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0,20,0,20) }
        tvStatus = TextView(this).apply { text = "AI 核心引擎就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 14f; gravity = Gravity.CENTER }

        mainLayout.addView(title); mainLayout.addView(tvStep1); mainLayout.addView(etScript); mainLayout.addView(tvStep2); mainLayout.addView(btnImport); mainLayout.addView(tvClipCount); mainLayout.addView(tvStep3); mainLayout.addView(btnMatch); mainLayout.addView(btnContainer); mainLayout.addView(layoutClipList); mainLayout.addView(btnStitch); mainLayout.addView(btnSave); mainLayout.addView(progressBar); mainLayout.addView(tvStatus)
        val scrollView = ScrollView(this).apply { isFillViewport = true; addView(mainLayout) }
        rootLayout.addView(scrollView)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 语音识别模型加载成功"
            }
        }
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false; btnSave.visibility = View.GONE; layoutClipList.visibility = View.GONE; btnAutoCalibrate.visibility = View.GONE; btnReset.visibility = View.GONE; tvStatus.text = "正在读取本地视频..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val videoList = mutableListOf<Map<String, Any>>()
                val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                cursor?.use { while (it.moveToNext()) videoList.add(mapOf("id" to it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)), "name" to it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)))) }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (videoList.isNotEmpty()) showVideoSelectionDialog(videoList)
                }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { btnImport.isEnabled = true } }
        }
    }

    private fun showVideoSelectionDialog(videoList: List<Map<String, Any>>) {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 20) }
        val cbSelectAll = CheckBox(this).apply { text = "✅ 全选所有视频"; setTextColor(Color.parseColor("#0284C7")); textSize = 16f; typeface = Typeface.DEFAULT_BOLD }
        container.addView(cbSelectAll)
        val scroll = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 600) }
        val listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checkBoxes = mutableListOf<CheckBox>()

        videoList.forEach { video ->
            val cb = CheckBox(this).apply {
                text = video["name"] as String
                setTextColor(Color.parseColor("#334155"))
                textSize = 14f
                setPadding(0, 10, 0, 10)
                setOnCheckedChangeListener { _, _ -> cbSelectAll.isChecked = checkBoxes.all { it.isChecked } }
            }
            checkBoxes.add(cb); listLayout.addView(cb)
        }
        scroll.addView(listLayout); container.addView(scroll)
        cbSelectAll.setOnCheckedChangeListener { _, isChecked -> checkBoxes.forEach { it.isChecked = isChecked } }

        AlertDialog.Builder(this).setTitle("选择视频素材").setView(container)
            .setPositiveButton("确定导入") { _, _ ->
                val selectedVideos = mutableListOf<Map<String, Any>>()
                for (i in checkBoxes.indices) if (checkBoxes[i].isChecked) selectedVideos.add(videoList[i])
                if (selectedVideos.isNotEmpty()) downloadSelectedVideos(selectedVideos)
            }.setNegativeButton("取消", null).show()
    }

    private fun downloadSelectedVideos(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0; btnImport.isEnabled = false; tvStatus.text = "正在导入素材..."
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val successfulNames = mutableListOf<String>()
            for (i in videos.indices) {
                val id = videos[i]["id"] as Long; val name = videos[i]["name"] as String
                withContext(Dispatchers.Main) { tvStatus.text = "正在处理 (${i+1}/${videos.size}): $name"; progressBar.progress = ((i.toFloat() / videos.size) * 100).toInt() }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val uniqueName = "${System.currentTimeMillis()}_$name"
                    val destFile = File(bridge.uploadDir, uniqueName)
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
                    successfulNames.add(uniqueName)
                } catch (e: Throwable) { }
                delay(1)
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE; btnImport.isEnabled = true
                if (successfulNames.isNotEmpty()) {
                    bridge.uploadedClips.clear(); bridge.uploadedClips.addAll(successfulNames)
                    tvClipCount.text = "已导入素材：${successfulNames.size} 个"
                    tvStatus.text = "素材导入成功"; tvStatus.setTextColor(Color.parseColor("#10B981"))
                }
            }
        }
    }

    private fun startMatching() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty() || bridge.uploadedClips.isEmpty() || !isModelsReady) return
        btnMatch.isEnabled = false; btnStitch.isEnabled = false; btnImport.isEnabled = false; btnAutoCalibrate.visibility = View.GONE; btnReset.visibility = View.GONE
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0; layoutClipList.visibility = View.GONE; tvStatus.text = "AI 正在构建全局最优路径..."
        CoroutineScope(Dispatchers.Main).launch {
            bridge.parseEpisodes(script, { p, msg -> 
                progressBar.progress = p; tvStatus.text = msg 
            }, { initialList ->
                progressBar.visibility = View.GONE
                btnStitch.isEnabled = true
                btnAutoCalibrate.visibility = View.VISIBLE
                btnReset.visibility = View.VISIBLE
                tvStatus.text = "AI 智能解析完成！"
                currentClips = initialList.toMutableList()
                initialClips = initialList.toList() 
                renderClipList() 
            }, {
                btnMatch.isEnabled = true; btnImport.isEnabled = true
            }, { err -> 
                progressBar.visibility = View.GONE; btnMatch.isEnabled = true; btnStitch.isEnabled = true; btnImport.isEnabled = true; tvStatus.text = "解析失败: $err" 
            })
        }
    }

    private fun autoCalibrate() {
        if (currentClips.isEmpty()) return
        val validClips = currentClips.filter { it.scriptPos >= 0 }
            .sortedWith(compareBy({ it.scriptPos }, { -it.score }, { it.fileName })).toMutableList()
        val silentClips = currentClips.filter { it.scriptPos < 0 }
        if (silentClips.isNotEmpty()) {
            silentClips.forEachIndexed { idx, silent ->
                val insertIndex = (validClips.size * (idx + 1) / (silentClips.size + 1))
                validClips.add(insertIndex, silent)
            }
        }
        currentClips = validClips
        renderClipList()
        Toast.makeText(this, "已按剧本绝对坐标完成 AI 强制校准！", Toast.LENGTH_SHORT).show()
    }

    private fun resetOrder() {
        if (initialClips.isEmpty()) return
        currentClips = initialClips.toMutableList()
        renderClipList()
        Toast.makeText(this, "已重置为初始 AI 排序", Toast.LENGTH_SHORT).show()
    }

    private fun renderClipList() {
        layoutClipList.removeAllViews()
        layoutClipList.visibility = View.VISIBLE
        
        val header = TextView(this).apply { 
            text = "🎬 AI 解析结果 (长按上下箭头快速微调)" 
            setTextColor(Color.parseColor("#0EA5E9"))
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 20)
        }
        layoutClipList.addView(header)

        currentClips.forEachIndexed { index, clip ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 10, 0, 10) }
            val color = when {
                clip.score >= 0.6f -> Color.parseColor("#10B981") 
                clip.score >= 0.3f -> Color.parseColor("#F59E0B") 
                clip.score == -2f -> Color.parseColor("#94A3B8") 
                else -> Color.parseColor("#EF4444")              
            }
            val tvInfo = TextView(this).apply {
                val statusIcon = if (clip.score >= 0.6f) "✅" else if (clip.score >= 0.3f) "⚠️" else if (clip.score == -2f) "⏳" else "❌"
                
                // 智能空镜推荐提示
                val coordStr = if (clip.scriptPos >= 0) {
                    "剧本定位: ${String.format("%04d", clip.scriptPos)}"
                } else {
                    val prevPos = if (index > 0) currentClips[index - 1].scriptPos else 0
                    val nextPos = if (index < currentClips.size - 1) currentClips[index + 1].scriptPos else 9999
                    "⚠️ 空镜 (AI建议插入在 $prevPos ~ $nextPos 之间)"
                }
                
                text = "${index + 1}. ${clip.fileName.substringAfter("_")} [$coordStr]\n" +
                       "$statusIcon 听写: ${clip.text}\n" +
                       "📖 剧本: ${clip.targetText}\n" +
                       "得分: ${if (clip.score == -2f) "计算中..." else String.format("%.2f", clip.score)}"
                
                setTextColor(color); textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(0, 0, 20, 0)
            }
            
            val btnLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(5, 0, 5, 0) }
            val btnUp = Button(this).apply { text = "⬆️"; isEnabled = index > 0; setOnClickListener { moveClip(index, index - 1) }; layoutParams = btnLayoutParams; minWidth = 0; minimumWidth = 0 }
            val btnDown = Button(this).apply { text = "⬇️"; isEnabled = index < currentClips.size - 1; setOnClickListener { moveClip(index, index + 1) }; layoutParams = btnLayoutParams; minWidth = 0; minimumWidth = 0 }

            row.addView(tvInfo); row.addView(btnUp); row.addView(btnDown)
            layoutClipList.addView(row)
            layoutClipList.addView(View(this).apply { setBackgroundColor(Color.parseColor("#334155")); layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1) })
        }
    }

    // 【V128 核心防呆】：拖拽时自动校验坐标
    private fun moveClip(fromIndex: Int, toIndex: Int) {
        if (fromIndex < 0 || toIndex >= currentClips.size) return
        
        val currentClip = currentClips[fromIndex]
        val targetClip = currentClips[toIndex]
        
        // 如果两个都有声，且坐标倒置了，直接弹窗拦截！
        if (currentClip.scriptPos >= 0 && targetClip.scriptPos >= 0) {
            if (fromIndex < toIndex && currentClip.scriptPos > targetClip.scriptPos) {
                AlertDialog.Builder(this)
                    .setTitle("🚫 智能防错拦截")
                    .setMessage("该片段属于剧本 ${currentClip.scriptPos} 位置，不能排在 ${targetClip.scriptPos} 位置之后！\n\n(如果强行移动，可能导致剧情逻辑错乱)")
                    .setPositiveButton("强行移动") { _, _ ->
                        val item = currentClips.removeAt(fromIndex)
                        currentClips.add(toIndex, item)
                        renderClipList()
                    }
                    .setNegativeButton("取消", null)
                    .show()
                return
            } else if (fromIndex > toIndex && currentClip.scriptPos < targetClip.scriptPos) {
                AlertDialog.Builder(this)
                    .setTitle("🚫 智能防错拦截")
                    .setMessage("该片段属于剧本 ${currentClip.scriptPos} 位置，不能排在 ${targetClip.scriptPos} 位置之前！")
                    .setPositiveButton("强行移动") { _, _ ->
                        val item = currentClips.removeAt(fromIndex)
                        currentClips.add(toIndex, item)
                        renderClipList()
                    }
                    .setNegativeButton("取消", null)
                    .show()
                return
            }
        }
        
        val item = currentClips.removeAt(fromIndex)
        currentClips.add(toIndex, item)
        renderClipList()
    }

    private fun startStitching() {
        if (currentClips.isEmpty()) return
        bridge.parsedEpisodesJson = bridge.buildJsonFromClips(currentClips)
        btnStitch.isEnabled = false; btnMatch.isEnabled = false; btnImport.isEnabled = false; btnSave.visibility = View.GONE; btnAutoCalibrate.visibility = View.GONE; btnReset.visibility = View.GONE
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0; tvStatus.text = "正在极速无损合成 (原画质)..."
        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(bridge.parsedEpisodesJson!!, { p, msg -> progressBar.visibility = View.VISIBLE; progressBar.progress = p; tvStatus.text = msg }, { finalFilePath ->
                progressBar.visibility = View.GONE; btnStitch.isEnabled = true; btnMatch.isEnabled = true; btnImport.isEnabled = true
                btnSave.visibility = View.VISIBLE; btnSave.tag = finalFilePath; tvStatus.text = "合成完成！请保存至相册"
            }, { err -> progressBar.visibility = View.GONE; btnStitch.isEnabled = true; btnMatch.isEnabled = true; btnImport.isEnabled = true; tvStatus.text = "合成失败: $err" })
        }
    }

    private fun saveToGallery() {
        val filePath = btnSave.tag as? String ?: return
        val sourceFile = File(filePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) return
        btnSave.isEnabled = false; tvStatus.text = "正在保存 MP4..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影"); put(MediaStore.Video.Media.IS_PENDING, 1) }
                }
                val resolver = contentResolver
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val uri = resolver.insert(collection, contentValues)
                uri?.let {
                    resolver.openOutputStream(it)?.use { outputStream -> FileInputStream(sourceFile).use { inputStream -> inputStream.copyTo(outputStream) } }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { contentValues.clear(); contentValues.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, contentValues, null, null) }
                }
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "视频已保存至相册", Toast.LENGTH_LONG).show(); btnSave.visibility = View.GONE; btnSave.isEnabled = true; tvStatus.text = "视频已保存至相册" }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { btnSave.isEnabled = true; Toast.makeText(this@MainActivity, "保存失败", Toast.LENGTH_LONG).show() } }
        }
    }
}