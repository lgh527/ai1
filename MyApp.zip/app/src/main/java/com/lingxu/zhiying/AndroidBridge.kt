package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = mutableListOf<String>()
    var parsedEpisodesJson: String? = null
    var sentences: List<String> = ArrayList()

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null

    class MatchedClip(val fileName: String, val text: String, val targetText: String, val score: Float, val scriptPos: Int) {
        var locked: Boolean = false
    }

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                withContext(Dispatchers.Main) { 
                    initASR()
                    _modelsReadyFlow.value = asrRecognizer != null 
                }
            } catch (e: Throwable) { 
                _modelsReadyFlow.value = false 
            }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try { workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() } } catch (e: Exception) { }
        }
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = File(modelDir, "model.int8.onnx").absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun cleanAndFilterText(text: String): String {
        val stopWords = setOf('啊', '哎', '哦', '嗯', '呃', '的', '了', '是', '在', '有', '这', '那', '个', '就', '不', '和', '也', '你', '我', '他', '她', '它', '们', '说', '着', '去', '来', '把', '被', '让', '给', '上', '下', '里', '外')
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "").filter { it !in stopWords }
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    suspend fun parseEpisodes(script: String, onProgress: (Int, String) -> Unit, onSuccess: (String, List<MatchedClip>) -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有找到视频文件")

            val fullScript = script.split(Regex("\\n-{3,}\\n"))[0] 
            sentences = ArrayList()
            val rawSegs = fullScript.split(Regex("[\\n。！？；…]+"))
            for (raw in rawSegs) {
                val seg = raw.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
                if (seg.length >= 2) sentences.add(seg)
            }
            val scriptClean = cleanAndFilterText(fullScript)

            val matchDetails = StringBuilder()
            val clipResults = mutableListOf<MatchedClip>()

            for ((index, clip) in clips.withIndex()) {
                withContext(Dispatchers.Main) { onProgress(((index+1).toFloat()/clips.size*100).toInt(), "AI雷达扫描中: ${index+1}/${clips.size}") }
                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"volume=2.0\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
                
                var text = ""
                if (ReturnCode.isSuccess(session.returnCode)) { text = recognizeAudio(wavFile); wavFile.delete() }
                
                val cleanText = cleanAndFilterText(text)
                var finalScore = 0f
                var targetText = "（空镜头/无声音）"
                var scriptPos = 999999
                
                if (cleanText.length >= 5) {
                    var bestMatchIndex = 0; var highestScore = -1f
                    val windowSize = minOf(cleanText.length + 10, scriptClean.length)
                    for (i in 0..(scriptClean.length - windowSize) step 2) {
                        val windowText = scriptClean.substring(i, i + windowSize)
                        val score = lcsLength(cleanText, windowText).toFloat() / cleanText.length
                        if (score > highestScore) { highestScore = score; bestMatchIndex = i }
                    }
                    finalScore = highestScore
                    if (finalScore >= 0.35f) {
                        scriptPos = bestMatchIndex
                        for (s in sentences) {
                            val idx = scriptClean.indexOf(s)
                            if (idx >= scriptPos - 5 && idx <= scriptPos + 5) { targetText = s; break }
                        }
                    }
                }
                clipResults.add(MatchedClip(clip, if (cleanText.isEmpty()) "（无声音）" else text, targetText, finalScore, scriptPos))
                delay(10)
            }

            val sortedClips = clipResults.sortedBy { it.scriptPos }

            val epObj = JsonObject()
            epObj.addProperty("episode_id", 1)
            val scenesArr = JsonArray(); val matchedClipsArr = JsonArray()
            matchDetails.append("【对齐结果预览】\n")
            sortedClips.forEachIndexed { idx, item ->
                scenesArr.add("第 ${idx + 1} 段"); matchedClipsArr.add(item.fileName)
                if (item.score < 0.1f) matchDetails.append("第 ${idx + 1} 段 (⚠️ 未识别)\n")
                else matchDetails.append("第 ${idx + 1} 段 (匹配度: ${String.format("%.2f", item.score)})\n")
            }
            epObj.add("scenes", scenesArr); epObj.add("clips", matchedClipsArr)
            parsedEpisodesJson = JsonArray().apply { add(epObj) }.toString()

            withContext(Dispatchers.Main) { onSuccess(matchDetails.toString(), sortedClips) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release(); result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootObj = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootObj.size()) {
                val epObj = rootObj.get(epIdx).asJsonObject
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "准备拼接...") }
                val listFile = File(workDir, "concat_list_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_${System.currentTimeMillis()}.mp4")
                
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(50, "极速无损拼接中...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy -avoid_negative_ts make_zero \"${outFile.absolutePath}\"")
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "格式差异重编码中...") }
                    session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v mpeg4 -qscale:v 1 -c:a aac -f mp4 \"${outFile.absolutePath}\"")
                    if (!ReturnCode.isSuccess(session.returnCode)) throw Exception("拼接失败")
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "渲染完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}