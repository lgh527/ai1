package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = ArrayList<String>()
    var sentences: List<String> = ArrayList()
    var isModelsLoaded = false
    private var asrRecognizer: OfflineRecognizer? = null

    data class MatchedClip(
        val fileName: String, val text: String, val targetText: String,
        val score: Float, val scriptCharPos: Int, val locked: Boolean = false
    )

    init {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                copyAssets()
                initASR()
                isModelsLoaded = asrRecognizer != null
            } catch (e: Throwable) { isModelsLoaded = false }
        }
    }

    private fun copyAssets() {
        val names = arrayOf("model.int8.onnx", "tokens.txt")
        for (name in names) {
            val out = File(modelDir, name)
            if (!out.exists()) {
                try { context.assets.open("models/$name").use { i -> FileOutputStream(out).use { i.copyTo(it) } } } catch (_: Throwable) {}
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = File(modelDir, "model.int8.onnx").absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 2
                )
            )
            asrRecognizer = OfflineRecognizer(config)
        } catch (_: Throwable) {}
    }

    fun cleanTempFiles() {
        uploadDir.listFiles()?.forEach { it.delete() }
    }

    fun parseScript(script: String) {
        sentences = ArrayList()
        val rawSegs = script.split(Regex("[\\n。！？；…]+"))
        for (raw in rawSegs) {
            val seg = raw.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
            if (seg.length >= 2) sentences.add(seg)
        }
    }

    suspend fun parseAndAlign(script: String, onProgress: (Int, String) -> Unit, onComplete: (List<MatchedClip>) -> Unit, onError: (String) -> Unit) {
        withContext(Dispatchers.IO) {
            try {
                parseScript(script)
                if (sentences.isEmpty()) throw Exception("剧本分不出句子")
                
                val results = ArrayList<MatchedClip>()
                for (i in uploadedClips.indices) {
                    withContext(Dispatchers.Main) { onProgress(i * 100 / uploadedClips.size, "识别 ${i+1}/${uploadedClips.size}") }
                    val video = File(uploadDir, uploadedClips[i])
                    val wav = File(workDir, "temp_$i.wav")
                    
                    val cmd = "-y -vn -i \"${video.absolutePath}\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wav.absolutePath}\""
                    if (ReturnCode.isSuccess(FFmpegKit.execute(cmd).returnCode)) {
                        val text = recognize(wav)
                        wav.delete()
                        val cleanText = text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
                        var bestIdx = -1
                        var bestScore = 0f
                        
                        if (cleanText.length >= 3) {
                            for (j in sentences.indices) {
                                val sc = lcs(cleanText, sentences[j]).toFloat() / maxOf(cleanText.length, sentences[j].length)
                                if (sc > bestScore) { bestScore = sc; bestIdx = j }
                            }
                        }
                        val targetText = if (bestIdx != -1) sentences[bestIdx] else "（未找到对应）"
                        val pos = if (bestIdx != -1) bestIdx else 9999 + i
                        results.add(MatchedClip(uploadedClips[i], text, targetText, bestScore, pos))
                    }
                }
                results.sortBy { it.scriptCharPos }
                withContext(Dispatchers.Main) { onComplete(results) }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { onError(e.message ?: "错误") }
            }
        }
    }

    fun recalibrateUnlocked(clips: List<MatchedClip>, sentences: List<String>, iteration: Int): MutableList<MatchedClip> {
        val newClips = ArrayList<MatchedClip>()
        for (c in clips) newClips.add(c)

        for (i in newClips.indices) {
            if (newClips[i].locked) continue
            val clean = newClips[i].text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
            if (clean.isEmpty()) continue
            
            var prevIdx = -1
            for (j in i - 1 downTo 0) if (newClips[j].locked) { prevIdx = newClips[j].scriptCharPos; break }
            var nextIdx = sentences.size
            for (j in i + 1 until newClips.size) if (newClips[j].locked) { nextIdx = newClips[j].scriptCharPos; break }
            
            var bestIdx = newClips[i].scriptCharPos
            var bestScore = newClips[i].score
            
            val start = maxOf(0, prevIdx)
            val end = minOf(sentences.size - 1, nextIdx)
            if (start <= end) {
                for (j in start..end) {
                    val sc = lcs(clean, sentences[j]).toFloat() / maxOf(clean.length, sentences[j].length)
                    if (sc > bestScore + 0.05f) {
                        bestScore = sc
                        bestIdx = j
                    }
                }
            }
            if (bestIdx >= 0 && bestIdx < sentences.size) {
                val old = newClips[i]
                newClips[i] = MatchedClip(old.fileName, old.text, sentences[bestIdx], bestScore, bestIdx, false)
            }
        }
        newClips.sortBy { it.scriptCharPos }
        return newClips
    }

    suspend fun stitchVideo(fileNames: List<String>, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        withContext(Dispatchers.IO) {
            try {
                val listFile = File(workDir, "concat.txt")
                val outFile = File(workDir, "final.mp4")
                listFile.writeText("")
                for (name in fileNames) {
                    listFile.appendText("file '${File(uploadDir, name).absolutePath}'\n")
                }
                withContext(Dispatchers.Main) { onProgress(80, "极速拼接中...") }
                val cmd = "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\""
                var session = FFmpegKit.execute(cmd)
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(90, "格式差异重编码中...") }
                    val cmd2 = "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 23 -c:a aac \"${outFile.absolutePath}\""
                    session = FFmpegKit.execute(cmd2)
                }
                listFile.delete()
                withContext(Dispatchers.Main) { onSuccess(outFile.absolutePath) }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { onError(e.message ?: "错误") } }
        }
    }

    private fun recognize(wav: File): String {
        val rec = asrRecognizer ?: return ""
        return try {
            val bytes = wav.readBytes()
            if (bytes.size <= 44) return ""
            val sb = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(sb.remaining()) { sb.get() / 32768.0f }
            val stream = rec.createStream()
            stream.acceptWaveform(audio, 16000)
            rec.decode(stream)
            val r = rec.getResult(stream)
            stream.release()
            r.text
        } catch (e: Throwable) { "" }
    }

    private fun lcs(a: String, b: String): Int {
        val m = a.length; val n = b.length
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (a[i - 1] == b[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }
}