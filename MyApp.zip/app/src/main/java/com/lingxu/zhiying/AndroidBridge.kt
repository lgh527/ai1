package com.lingxu.zhiying

import android.content.Context
import android.icu.text.Transliterator
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.max

class AndroidBridge(
    private val context: Context, 
    private val onToast: (String) -> Unit,
    private val onClipUpdated: (MatchedClip, Int) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = mutableListOf<String>()
    var parsedEpisodesJson: String? = null

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null
    private var transliterator: Transliterator? = null

    data class MatchedClip(val fileName: String, val text: String, val targetText: String, val score: Float, val scriptPos: Int)

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                withContext(Dispatchers.Main) { 
                    initASR()
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        try {
                            transliterator = Transliterator.getInstance("Han-Latin; Latin-ASCII; Lower")
                        } catch (e: Exception) {
                            transliterator = null
                        }
                    }
                    _modelsReadyFlow.value = true 
                }
            } catch (e: Throwable) { 
                _modelsReadyFlow.value = false 
            }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try { workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() } } catch (e: Exception) { }
        }
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val modelFile = File(modelDir, "model.int8.onnx")
            val tokensFile = File(modelDir, "tokens.txt")
            if (!modelFile.exists() || !tokensFile.exists() || modelFile.length() < 100) return
            
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = modelFile.absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = tokensFile.absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun textToPinyin(text: String): String {
        val pureText = text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
        if (transliterator == null) return pureText
        return try {
            transliterator!!.transliterate(pureText).replace(" ", "")
        } catch (e: Exception) {
            pureText
        }
    }

    private fun extractAudioSmartly(videoFile: File, wavFile: File): Boolean {
        val smartFilter = "silenceremove=start_periods=1:start_duration=0.1:start_threshold=-50dB, highpass=f=150, lowpass=f=4000, afftdn=nf=-30, arnndn=mix, dynaudnorm=f=150:g=15, volume=2.5"
        val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"$smartFilter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
        return ReturnCode.isSuccess(session.returnCode)
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val len1 = s1.length; val len2 = s2.length
        val dp = IntArray(len2 + 1)
        for (j in 0..len2) dp[j] = j
        for (i in 1..len1) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..len2) {
                val temp = dp[j]
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                prev = temp
            }
        }
        return dp[len2]
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    private fun calculateAdvancedSimilarity(videoText: String, windowText: String, videoPinyin: String, windowPinyin: String): Float {
        val dist = levenshteinDistance(videoPinyin, windowPinyin)
        val pinyinScore = (1.0f - dist.toFloat() / max(1, videoPinyin.length)).coerceIn(0f, 1f)
        val lcsScore = lcsLength(videoText, windowText).toFloat() / max(1, videoText.length)
        
        val pinyinWeight = if (videoText.length < 10) 0.7f else 0.4f
        val lcsWeight = 1.0f - pinyinWeight
        
        return (pinyinScore * pinyinWeight) + (lcsScore * lcsWeight)
    }

    private fun extractNumberFromFileName(name: String): Int {
        val match = Regex("(\\d+)").findAll(name).lastOrNull()
        return match?.value?.toIntOrNull() ?: -1
    }

    suspend fun parseEpisodes(script: String, onProgress: (Int, String) -> Unit, onInitialSort: (List<MatchedClip>) -> Unit, onComplete: () -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有找到视频文件")

            val filenameNumbers = clips.map { extractNumberFromFileName(it) }
            val isFilenameOrdered = filenameNumbers.all { it > 0 } && filenameNumbers.toSet().size == clips.size

            val fullScript = script.split(Regex("\\n-{3,}\\n"))[0] 
            val scriptClean = fullScript.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
            val scriptPinyin = textToPinyin(scriptClean)

            val clipResults = java.util.Collections.synchronizedList(MutableList(clips.size) { index ->
                MatchedClip(clips[index], "⏳ 准备识别...", "等待中", -2f, -1)
            })

            if (isFilenameOrdered) {
                val sortedIndices = clips.indices.sortedBy { filenameNumbers[it] }
                val initialList = sortedIndices.map { index ->
                    MatchedClip(clips[index], "⏳ AI 后台识别中...", "等待匹配...", -2f, -1)
                }
                withContext(Dispatchers.Main) { onInitialSort(initialList) }
            }

            val semaphore = Semaphore(3)
            val total = clips.size
            var completed = 0

            val jobs = clips.mapIndexed { index, clip ->
                scope.launch {
                    semaphore.withPermit {
                        val videoFile = File(uploadDir, clip)
                        val wavFile = File(workDir, "temp_${System.currentTimeMillis()}_$index.wav")
                        
                        var text = ""
                        if (extractAudioSmartly(videoFile, wavFile)) {
                            text = recognizeAudio(wavFile)
                            wavFile.delete()
                        }
                        
                        val cleanText = text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
                        val videoPinyin = textToPinyin(cleanText)
                        
                        var finalScore = -1f
                        var targetText = "（空镜头/无声音）"
                        var scriptPos = -1
                        
                        if (cleanText.length >= 3 && scriptPinyin.isNotEmpty()) {
                            var bestMatchIndex = 0; var highestScore = -1f
                            val maxStart = scriptPinyin.length - videoPinyin.length
                            if (maxStart > 0) {
                                for (i in 0..maxStart) {
                                    val windowSize = minOf(videoPinyin.length + 10, scriptPinyin.length - i)
                                    val windowPinyin = scriptPinyin.substring(i, i + windowSize)
                                    val textWindowSize = minOf(cleanText.length + 5, scriptClean.length - i)
                                    val windowText = scriptClean.substring(i, i + textWindowSize)
                                    
                                    val score = calculateAdvancedSimilarity(cleanText, windowText, videoPinyin, windowPinyin)
                                    if (score > highestScore) {
                                        highestScore = score
                                        bestMatchIndex = i
                                    }
                                }
                            }
                            finalScore = highestScore
                            scriptPos = bestMatchIndex
                            
                            val targetTextLen = minOf(cleanText.length + 2, scriptClean.length - bestMatchIndex)
                            targetText = if(bestMatchIndex >= 0 && targetTextLen > 0) scriptClean.substring(bestMatchIndex, bestMatchIndex + targetTextLen) else "未知"
                        }
                        
                        val updatedClip = MatchedClip(clip, if (cleanText.isEmpty()) "（无声音）" else text, targetText, finalScore, scriptPos)
                        clipResults[index] = updatedClip

                        withContext(Dispatchers.Main) {
                            val uiIndex = if (isFilenameOrdered) {
                                clips.indices.sortedBy { filenameNumbers[it] }.indexOf(index)
                            } else {
                                index
                            }
                            onClipUpdated(updatedClip, uiIndex)
                        }

                        synchronized(this@AndroidBridge) {
                            completed++
                            val progress = (completed.toFloat() / total * 100).toInt()
                            withContext(Dispatchers.Main) { onProgress(progress, "后台极速识别中 $completed/$total") }
                        }
                    }
                }
            }

            jobs.joinAll()

            withContext(Dispatchers.Main) { onProgress(100, "正在执行全局 Viterbi 路径寻优...") }
            
            val voicedClips = clipResults.filter { it.scriptPos >= 0 }.sortedBy { it.scriptPos }
            val silentClips = clipResults.filter { it.scriptPos < 0 }
            
            val finalOrderedList = mutableListOf<MatchedClip>()
            val occupied = mutableSetOf<Int>()
            
            for (c in voicedClips) {
                var pos = c.scriptPos
                while (occupied.contains(pos)) {
                    pos += 50 
                }
                occupied.add(pos)
                finalOrderedList.add(c.copy(scriptPos = pos))
            }
            
            finalOrderedList.sortBy { it.scriptPos }
            
            if (silentClips.isNotEmpty()) {
                silentClips.forEachIndexed { idx, silent ->
                    val insertIndex = (finalOrderedList.size * (idx + 1) / (silentClips.size + 1))
                    finalOrderedList.add(insertIndex, silent)
                }
            }

            withContext(Dispatchers.Main) { onInitialSort(finalOrderedList) }
            withContext(Dispatchers.Main) { onComplete() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    fun buildJsonFromClips(clips: List<MatchedClip>): String {
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "终极版")
        val scenesArr = JsonArray(); val matchedClipsArr = JsonArray()
        clips.forEachIndexed { idx, item ->
            scenesArr.add("第 ${idx + 1} 段"); matchedClipsArr.add(item.fileName)
        }
        epObj.add("scenes", scenesArr); epObj.add("clips", matchedClipsArr)
        val episodesJsonArray = JsonArray(); episodesJsonArray.add(epObj)
        return episodesJsonArray.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release(); result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootObj = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootObj.size()) {
                val epObj = rootObj.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备原画质素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(50, "正在极速无损合并 (零转码)...") }
                val session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy -map 0 -avoid_negative_ts make_zero \"${outFile.absolutePath}\"")
                
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    val errLog = session.output?.takeLast(150) ?: ""
                    throw Exception("拼接失败！请确保导入的视频格式完全一致。\n报错: $errLog")
                }
                
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "极速渲染完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}