package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.maxOf
import kotlin.math.minOf
import kotlin.math.sqrt
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.ln
import kotlin.math.exp

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    val uploadedClips = mutableListOf<String>()
    var sentences: List<String> = emptyList()
    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()
    private var asrRecognizer: OfflineRecognizer? = null
    private var uvrSeparator: OfflineSourceSeparation? = null

    data class MatchedClip(
        val fileName: String, val text: String, val targetText: String,
        val score: Float, val scriptCharPos: Int,
        val uvrApplied: Boolean = false, val locked: Boolean = false
    )

    data class CalibrateResult(val clips: List<MatchedClip>, val improved: Int, val lockedCount: Int)

    data class Judgment(val isGreen: Boolean, val textSimilarity: Float, val charRatio: Float, val keywordOverlap: Float, val reason: String)

    private data class PrepResult(val index: Int, val fileName: String, val text: String, val uvrApplied: Boolean)

    init {
        scope.launch {
            try {
                copyAssets()
                withContext(Dispatchers.Main) { initASR(); initUVR(); _modelsReadyFlow.value = asrRecognizer != null }
            } catch (_: Throwable) { _modelsReadyFlow.value = false }
        }
    }

    private fun copyAssets() {
        listOf("model.int8.onnx","tokens.txt","UVR_MDXNET_9482.onnx").forEach { name ->
            val out = File(modelDir, name)
            if (!out.exists()) {
                try { context.assets.open("models/$name").use { i -> FileOutputStream(out).use { i.copyTo(it) } } } catch (_: Throwable) {}
            }
        }
    }

    private fun initASR() {
        try {
            val modelFile = File(modelDir, "model.int8.onnx")
            val tokensFile = File(modelDir, "tokens.txt")
            if (!modelFile.exists() || !tokensFile.exists()) return
            asrRecognizer = OfflineRecognizer(OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = modelFile.absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = tokensFile.absolutePath, numThreads = 4
                )
            ))
        } catch (_: Throwable) {}
    }

    private fun initUVR() {
        try {
            val m = File(modelDir, "UVR_MDXNET_9482.onnx")
            if (!m.exists()) return
            uvrSeparator = OfflineSourceSeparation(OfflineSourceSeparationConfig(
                model = OfflineSourceSeparationModelConfig(uvr = OfflineSourceSeparationUvrModelConfig(model = m.absolutePath, voc = "vocals", nonVoc = "accompaniment"))
            ))
        } catch (_: Throwable) {}
    }

    fun cleanTempFiles() {
        scope.launch { workDir.listFiles()?.filter { it.name.startsWith("temp_") || it.name.startsWith("concat_") || it.name.startsWith("norm_") || it.name.startsWith("uvr_") }?.forEach { it.deleteRecursively() } }
    }

    private fun extractWav(video: File, wav: File): Boolean {
        val filter = "highpass=f=180,lowpass=f=3800,acompressor=threshold=0.1:ratio=3:attack=20:release=200,volume=2.5"
        val s = FFmpegKit.execute("-y -vn -i \"${video.absolutePath}\" -af \"$filter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wav.absolutePath}\"")
        return ReturnCode.isSuccess(s.returnCode) && wav.exists() && wav.length() > 2000
    }

    private fun needVocalSeparation(wav: File): Boolean {
        val bytes = wav.readBytes(); if (bytes.size < 16000) return false
        val buf = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val samples = FloatArray(buf.remaining()) { buf.get() / 32768f }
        val fl = 1600; val nFrames = samples.size / fl; if (nFrames < 5) return false
        val energies = FloatArray(nFrames) { i -> var e = 0f; for (j in i * fl until minOf((i + 1) * fl, samples.size)) e += samples[j] * samples[j]; sqrt(e / fl) }
        val sorted = energies.sorted()
        val speechTh = maxOf(sorted[(sorted.size * 0.6).toInt()], 0.02f)
        val silenceTh = sorted[(sorted.size * 0.15).toInt()].coerceAtLeast(0.002f)
        val speechFlags = BooleanArray(nFrames) { energies[it] > speechTh }
        var speechCount = 0; var gapEnergySum = 0f; var gapFrames = 0; var inGap = false
        for (i in 1 until nFrames) {
            if (speechFlags[i]) { speechCount++; inGap = false }
            else if (speechFlags[i - 1] && !speechFlags[i]) { inGap = true }
            else if (inGap && !speechFlags[i]) { gapEnergySum += energies[i]; gapFrames++ }
        }
        if (speechCount < 2 || gapFrames < 2) return false
        val gapToSilence = if (silenceTh > 0f) (gapEnergySum / gapFrames) / silenceTh else 0f
        var flatSum = 0f; var counted = 0
        for (i in 1 until nFrames) {
            if (!speechFlags[i] && energies[i] > silenceTh * 2) {
                val start = i * fl; val end = minOf((i + 1) * fl, samples.size); if (end - start < 256) continue
                val N = 256; val re = FloatArray(N); val im = FloatArray(N)
                for (k in 0 until N) { var sr = 0f; var si = 0f; for (n in 0 until N) { val a = -2.0 * PI * k * n / N; sr += samples[start + n] * cos(a).toFloat(); si += samples[start + n] * sin(a).toFloat() }; re[k] = sr; im[k] = si }
                var logSum = 0f; var linSum = 0f
                for (k in 1 until N / 2) { val mag = sqrt(re[k] * re[k] + im[k] * im[k]) + 1e-6f; logSum += ln(mag); linSum += mag }
                flatSum += exp(logSum / (N / 2 - 1)) / (linSum / (N / 2 - 1)); counted++
            }
        }
        val avgFlat = if (counted > 0) flatSum / counted else 1f
        return gapToSilence > 3.0f && avgFlat < 0.35f
    }

    private fun separateVocals(wav: File): File? {
        val sep = uvrSeparator ?: return null
        return try {
            val outDir = File(workDir, "uvr_${System.currentTimeMillis()}").apply { mkdirs() }
            sep.separate(wav.absolutePath, outDir.absolutePath)
            outDir.listFiles()?.firstOrNull { it.name.contains("vocals", true) || it.name.contains("voc", true) }
        } catch (_: Throwable) { null }
    }

    private fun voiceSegments(wav: File): List<Pair<Float, Float>> {
        val bytes = wav.readBytes(); if (bytes.size < 2000) return emptyList()
        val buf = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val samples = FloatArray(buf.remaining()) { buf.get() / 32768f }
        val fl = 1600
        val energies = (0 until samples.size / fl).map { i -> var e = 0f; for (j in i * fl until minOf((i + 1) * fl, samples.size)) e += samples[j] * samples[j]; sqrt(e / fl) }
        if (energies.isEmpty()) return emptyList()
        val sorted = energies.sorted(); val th = maxOf(sorted[(sorted.size * 0.3).toInt().coerceIn(0, sorted.lastIndex)], 0.012f)
        val segs = mutableListOf<Pair<Float, Float>>(); var inSp = false; var st = 0f
        energies.forEachIndexed { i, e -> val t = i * 0.1f; if (e > th && !inSp) { inSp = true; st = t } else if (e <= th && inSp) { inSp = false; if (t - st > 0.25f) segs.add(st to t) } }
        if (inSp) segs.add(st to energies.size * 0.1f)
        return segs
    }

    private fun recognizeSegments(wav: File, segs: List<Pair<Float, Float>>): String {
        val rec = asrRecognizer ?: return ""
        val bytes = wav.readBytes(); if (bytes.size <= 44) return ""
        val all = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val audio = FloatArray(all.remaining()) { all.get() / 32768f }
        val sb = StringBuilder()
        for ((s, e) in segs) {
            val a = (s * 16000).toInt().coerceIn(0, audio.size - 1); val b = (e * 16000).toInt().coerceIn(a + 1, audio.size)
            val chunk = audio.copyOfRange(a, b); if (chunk.size < 800) continue
            try {
                val stream = rec.createStream(); stream.acceptWaveform(chunk, 16000); rec.decode(stream)
                val r = rec.getResult(stream); stream.release(); if (r.text.isNotBlank()) sb.append(r.text)
            } catch (_: Throwable) {}
        }
        return sb.toString()
    }

    private fun lcs(a: String, b: String): Int {
        val m = a.length; val n = b.length; if (m == 0 || n == 0) return 0
        var prev = IntArray(n + 1); var cur = IntArray(n + 1)
        for (i in 1..m) { for (j in 1..n) { cur[j] = if (a[i - 1] == b[j - 1]) prev[j - 1] + 1 else maxOf(prev[j], cur[j - 1]) }; val t = prev; prev = cur; cur = t }
        return prev[n]
    }

    private fun matchScore(clean: String, sentence: String, qGrams: Set<String>, sGrams: Set<String>): Float {
        if (clean.length < 3) return 0.05f
        val overlap = if (qGrams.isEmpty() || sGrams.isEmpty()) 0f else qGrams.intersect(sGrams).size.toFloat() / maxOf(qGrams.size, sGrams.size)
        val lcsScore = (2f * lcs(clean, sentence)) / (clean.length + sentence.length)
        val ratio = minOf(clean.length, sentence.length).toFloat() / maxOf(clean.length, sentence.length)
        val lenPenalty = if (ratio < 0.35f && maxOf(clean.length, sentence.length) > 10) 0.4f else 1f
        return (0.6f * overlap + 0.4f * lcsScore) * lenPenalty
    }

    fun judgeAlignment(clip: MatchedClip): Judgment {
        if (clip.locked) return Judgment(true, 1f, 1f, 1f, "🔒 人工锁定（100%确认）")
        val clean = clip.text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
        if (clean.length < 2) return Judgment(false, 0f, 0f, 0f, "未识别到有效台词（<2字），必须人工确认")
        val target = clip.targetText.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
        if (target.length < 2) return Judgment(false, 0f, 0f, 0f, "剧本台词无效（<2字）")
        val sim = (2f * lcs(clean, target)) / (clean.length + target.length)
        val ratio = minOf(clean.length, target.length).toFloat() / maxOf(clean.length, target.length)
        val g1: Set<String> = if (clean.length >= 2) (0 until clean.length - 1).map { clean.substring(it, it + 2) }.toSet() else emptySet<String>()
        val g2: Set<String> = if (target.length >= 2) (0 until target.length - 1).map { target.substring(it, it + 2) }.toSet() else emptySet<String>()
        val jaccard = if (g1.isEmpty() || g2.isEmpty()) 0f else g1.intersect(g2).size.toFloat() / g1.union(g2).size
        val simOk = sim >= 0.75f; val ratioOk = ratio >= 0.70f; val jacOk = jaccard >= 0.50f
        val isGreen = simOk && ratioOk && jacOk
        val reason = if (isGreen) "✅ 三维验证通过（相似度${"%.2f".format(sim)}·字数比${"%.2f".format(ratio)}·关键词${"%.2f".format(jaccard)}）"
        else {
            val fails = mutableListOf<String>()
            if (!simOk) fails.add("相似度${"%.2f".format(sim)}<0.75")
            if (!ratioOk) fails.add("字数比${"%.2f".format(ratio)}<0.70(${clean.length}/${target.length}字)")
            if (!jacOk) fails.add("关键词${"%.2f".format(jaccard)}<0.50")
            "❌ 未通过：${fails.joinToString(" · ")}"
        }
        return Judgment(isGreen, sim, ratio, jaccard, reason)
    }

    private fun viterbiAlign(preps: List<PrepResult>, sentences: List<String>, sentGrams: List<Set<String>>): IntArray {
        val n = preps.size; val m = sentences.size; if (n == 0 || m == 0) return IntArray(n)
        val scores = Array(n) { i -> val clean = preps[i].text.replace(Regex("[^\\u4e00-\\u9fa5]"), ""); val qGrams: Set<String> = if (clean.length >= 2) (0 until clean.length - 1).map { clean.substring(it, it + 2) }.toSet() else emptySet<String>(); FloatArray(m) { j -> matchScore(clean, sentences[j], qGrams, sentGrams[j]) } }
        val expected = FloatArray(n) { i -> if (n == 1) (m - 1) / 2f else i.toFloat() * (m - 1) / (n - 1) }
        val lambda = 0.08f; val prior = Array(n) { i -> FloatArray(m) { j -> -lambda * abs(j - expected[i]) } }
        val dp = Array(n) { FloatArray(m) }; val parent = Array(n) { IntArray(m) { -1 } }
        for (j in 0 until m) dp[0][j] = scores[0][j] + prior[0][j]
        for (i in 1 until n) {
            var bestVal = dp[i - 1][0]; var bestArg = 0
            for (j in 0 until m) { if (dp[i - 1][j] > bestVal) { bestVal = dp[i - 1][j]; bestArg = j }; dp[i][j] = scores[i][j] + prior[i][j] + bestVal; parent[i][j] = bestArg }
        }
        var endJ = 0; var best = dp[n - 1][0]
        for (j in 1 until m) if (dp[n - 1][j] > best) { best = dp[n - 1][j]; endJ = j }
        val result = IntArray(n); var curJ = endJ
        for (i in n - 1 downTo 0) { result[i] = curJ; if (i > 0) curJ = parent[i][curJ].coerceAtLeast(0) }
        return result
    }

    fun recalibrateUnlocked(clips: List<MatchedClip>, sentences: List<String>, iteration: Int): CalibrateResult {
        val n = clips.size; val m = sentences.size; if (n == 0 || m == 0) return CalibrateResult(clips, 0, 0)
        val starts = IntArray(m); var c = 0; for (j in 0 until m) { starts[j] = c; c += sentences[j].length }
        fun sentIdxOf(charPos: Int): Int { var best = 0; for (j in 0 until m) if (starts[j] <= charPos) best = j; return best }
        val anchors = mutableListOf<Pair<Int, Int>>(); clips.forEachIndexed { idx, clip -> if (clip.locked) anchors.add(Pair(idx, sentIdxOf(clip.scriptCharPos))) }
        val newClips = clips.toMutableList(); var improved = 0; val useSim = iteration % 2 == 1
        for (i in 0 until n) {
            if (newClips[i].locked) continue
            val prevA = anchors.lastOrNull { it.first < i }; val nextA = anchors.firstOrNull { it.first > i }
            val loSent = if (prevA != null) prevA.second + 1 else 0; val hiSent = if (nextA != null) nextA.second - 1 else m - 1
            if (loSent > hiSent) continue
            val clean = newClips[i].text.replace(Regex("[^\\u4e00-\\u9fa5]"), ""); val cleanLen = clean.length
            val qGrams: Set<String> = if (cleanLen >= 2) (0 until cleanLen - 1).map { clean.substring(it, it + 2) }.toSet() else emptySet<String>()
            var bestSentIdx = loSent; var bestScore = -1f
            for (j in loSent..hiSent) {
                val sText = sentences[j]
                val score = if (useSim) { val sGrams: Set<String> = if (sText.length >= 2) (0 until sText.length - 1).map { sText.substring(it, it + 2) }.toSet() else emptySet<String>(); matchScore(clean, sText, qGrams, sGrams) }
                else { if (cleanLen == 0) 0.02f else 1f / (1f + abs(cleanLen - sText.length) * 0.25f) }
                if (score > bestScore) { bestScore = score; bestSentIdx = j }
            }
            val currentJ = judgeAlignment(newClips[i])
            val willChange = bestScore > newClips[i].score + 0.03f
            if (willChange) { newClips[i] = newClips[i].copy(scriptCharPos = starts[bestSentIdx], targetText = sentences[bestSentIdx], score = bestScore); improved++ }
            val newJ = judgeAlignment(newClips[i])
            if (newJ.isGreen && !newClips[i].locked) { newClips[i] = newClips[i].copy(locked = true) }
        }
        val sorted = newClips.sortedWith(compareBy({ it.scriptCharPos }, { it.fileName }))
        return CalibrateResult(sorted, improved, sorted.count { it.locked })
    }

    suspend fun parseAndAlign(script: String, onProgress: (Int, String) -> Unit, onComplete: (List<MatchedClip>) -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList(); if (clips.isEmpty()) throw Exception("还没有选视频")
            val scriptClean = script.replace(Regex("[^\\u4e00-\\u9fa5]"), ""); if (scriptClean.isEmpty()) throw Exception("剧本里没有中文")
            val sentList = mutableListOf<String>(); val sentenceRanges = mutableListOf<IntRange>(); var cursor = 0
            script.split(Regex("[\\n。！？；…]+")).forEach { raw -> val seg = raw.replace(Regex("[^\\u4e00-\\u9fa5]"), ""); if (seg.length >= 2 && cursor < scriptClean.length) { val end = minOf(cursor + seg.length, scriptClean.length); sentList.add(scriptClean.substring(cursor, end)); sentenceRanges.add(cursor until end); cursor = end } }
            if (sentList.isEmpty()) throw Exception("剧本分不出句子，请加标点或换行")
            sentences = sentList
            val sentGrams = sentList.map { s -> val g: Set<String> = if (s.length >= 2) (0 until s.length - 1).map { s.substring(it, it + 2) }.toSet() else emptySet<String>(); g }
            val prepChannel = Channel<PrepResult>(Channel.UNLIMITED)
            val jobs = clips.indices.map { idx ->
                scope.launch(Dispatchers.Default) {
                    val clip = clips[idx]; val video = File(uploadDir, clip); val wavRaw = File(workDir, "temp_${System.currentTimeMillis()}_$idx.wav")
                    var text = ""; var uvrApplied = false
                    if (extractWav(video, wavRaw)) {
                        val needUVR = needVocalSeparation(wavRaw)
                        val workingWav = if (needUVR) { val v = separateVocals(wavRaw); if (v != null) { uvrApplied = true; v } else wavRaw } else wavRaw
                        text = recognizeSegments(workingWav, voiceSegments(workingWav))
                        if (workingWav != wavRaw) workingWav.delete()
                    }
                    wavRaw.delete(); prepChannel.send(PrepResult(idx, clip, text, uvrApplied))
                }
            }
            launch { jobs.forEach { it.join() }; prepChannel.close() }
            val collected = mutableListOf<PrepResult>()
            for (prep in prepChannel) { collected.add(prep); withContext(Dispatchers.Main) { onProgress(collected.size * 60 / clips.size, "识别中 ${collected.size}/${clips.size}") } }
            val preps = collected.sortedBy { it.index }
            withContext(Dispatchers.Main) { onProgress(70, "智能对齐中...") }
            val alignIndices = viterbiAlign(preps, sentList, sentGrams)
            val results = mutableListOf<MatchedClip>()
            preps.forEachIndexed { i, prep ->
                val sentIdx = alignIndices[i]; val range = sentenceRanges[sentIdx]
                val clean = prep.text.replace(Regex("[^\\u4e00-\\u9fa5]"), ""); val targetText = sentList[sentIdx]
                val qGrams: Set<String> = if (clean.length >= 2) (0 until clean.length - 1).map { clean.substring(it, it + 2) }.toSet() else emptySet<String>()
                val score = if (clean.isEmpty()) 0f else matchScore(clean, targetText, qGrams, sentGrams[sentIdx])
                val clip = MatchedClip(prep.fileName, if (clean.isEmpty()) "（没识别到，顺序仍正确）" else prep.text, targetText, score, range.first, prep.uvrApplied, false)
                val judged = judgeAlignment(clip)
                results.add(if (judged.isGreen) clip.copy(locked = true) else clip)
            }
            val ordered = results.sortedWith(compareBy({ it.scriptCharPos }, { it.fileName }))
            withContext(Dispatchers.Main) { onProgress(100, "对齐完成"); onComplete(ordered); onDone() }
        } catch (e: Throwable) { withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") } }
    }

    fun buildJson(clips: List<MatchedClip>): String {
        val ep = JsonObject().apply { addProperty("episode_id", 1); addProperty("title", "对齐版") }
        val sc = JsonArray(); val cl = JsonArray(); clips.forEachIndexed { i, c -> sc.add("段${i + 1}"); cl.add(c.fileName) }
        ep.add("scenes", sc); ep.add("clips", cl); return JsonArray().apply { add(ep) }.toString()
    }

    suspend fun stitchVideo(json: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val arr = JsonParser.parseString(json).asJsonArray
            val clips = arr.get(0).asJsonObject.getAsJsonArray("clips").map { it.asString }
            if (clips.isEmpty()) throw Exception("没有片段可拼接")
            val base = File(uploadDir, clips[0]); val baseInfo = probe(base) ?: throw Exception("无法读取视频信息")
            withContext(Dispatchers.Main) { onProgress(5, "准备拼接...") }
            val workNorm = File(workDir, "norm_${System.currentTimeMillis()}").apply { mkdirs() }
            val stage1 = mutableListOf<File>(); var convertedAny = false
            clips.forEachIndexed { i, name ->
                val f = File(uploadDir, name); if (!f.exists()) return@forEachIndexed
                val info = probe(f)
                val consistent = info != null && info.width == baseInfo.width && info.height == baseInfo.height && info.vcodec == baseInfo.vcodec && info.acodec == baseInfo.acodec && abs(info.fps - baseInfo.fps) < 0.5f
                if (consistent) stage1.add(f) else {
                    convertedAny = true; val out = File(workNorm, "conv_$i.mp4")
                    withContext(Dispatchers.Main) { onProgress(10 + i * 30 / clips.size, "统一格式 ${i + 1}/${clips.size}") }
                    val cmd = "-y -i \"${f.absolutePath}\" -vf \"scale=${baseInfo.width}:${baseInfo.height}:force_original_aspect_ratio=decrease,pad=${baseInfo.width}:${baseInfo.height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${baseInfo.fps}\" -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -ar 48000 -ac 2 \"${out.absolutePath}\""
                    val s = FFmpegKit.execute(cmd)
                    if (ReturnCode.isSuccess(s.returnCode) && out.exists()) stage1.add(out) else stage1.add(f)
                }
            }
            withContext(Dispatchers.Main) { onProgress(55, "时间戳对齐...") }
            val stage2 = stage1.mapIndexed { i, f -> val out = File(workNorm, "pts_$i.mp4"); val s = FFmpegKit.execute("-y -fflags +genpts -i \"${f.absolutePath}\" -c copy -avoid_negative_ts make_zero -video_track_timescale 90000 \"${out.absolutePath}\""); if (ReturnCode.isSuccess(s.returnCode) && out.exists()) out else f }
            val listFile = File(workDir, "concat_${System.currentTimeMillis()}.txt"); val outFile = File(workDir, "lingxu_${System.currentTimeMillis()}.mp4")
            listFile.bufferedWriter().use { w -> stage2.forEach { w.write("file '${it.absolutePath}'\n") } }
            withContext(Dispatchers.Main) { onProgress(75, if (convertedAny) "自动拼接中..." else "快速拼接中...") }
            val session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy -avoid_negative_ts make_zero -fflags +genpts -map 0:v:0 -map 0:a:0? \"${outFile.absolutePath}\"")
            if (!ReturnCode.isSuccess(session.returnCode)) throw Exception("拼接失败，请检查视频格式：${session.output?.takeLast(150)}")
            listFile.delete(); workNorm.deleteRecursively()
            withContext(Dispatchers.Main) { onProgress(100, "完成"); onSuccess(outFile.absolutePath) }
        } catch (e: Throwable) { withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") } }
    }

    private data class VideoInfo(val width: Int, val height: Int, val vcodec: String, val acodec: String, val fps: Float)
    private fun probe(f: File): VideoInfo? {
        return try {
            val s = com.arthenica.ffmpegkit.FFprobeKit.getMediaInformation(f.absolutePath)
            val info = s.mediaInformation ?: return null; val streams = info.streams
            val v = streams.firstOrNull { it.type == "video" } ?: return null; val a = streams.firstOrNull { it.type == "audio" }
            VideoInfo(v.width, v.height, v.codec ?: "", a?.codec ?: "none", v.averageFrameRate?.toFloat() ?: 30f)
        } catch (_: Throwable) { null }
    }
}