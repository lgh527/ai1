package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.max
import kotlin.math.abs
import kotlin.math.sqrt

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = mutableListOf<String>()
    var parsedEpisodesJson: String? = null

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null

    data class MatchedClip(val fileName: String, val text: String, val targetText: String, val score: Float, val scriptPos: Int)

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                withContext(Dispatchers.Main) { 
                    initASR()
                    _modelsReadyFlow.value = true 
                }
            } catch (e: Throwable) { 
                _modelsReadyFlow.value = false 
            }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try { workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() } } catch (e: Exception) { }
        }
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = File(modelDir, "model.int8.onnx").absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun extractAudioSmartly(videoFile: File, wavFile: File): Boolean {
        val smartFilter = "highpass=f=200, lowpass=f=3500, volume=2.0"
        val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"$smartFilter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
        return ReturnCode.isSuccess(session.returnCode)
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    suspend fun parseEpisodes(script: String, onProgress: (Int, String) -> Unit, onInitialSort: (List<MatchedClip>) -> Unit, onComplete: () -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有找到视频文件")

            val fullScript = script.split(Regex("\\n-{3,}\\n"))[0] 
            val scriptClean = fullScript.replace(Regex("[^\\u4e00-\\u9fa5]"), "")

            val clipResults = mutableListOf<MatchedClip>()

            for ((index, clip) in clips.withIndex()) {
                withContext(Dispatchers.Main) { onProgress(((index+1).toFloat()/clips.size*100).toInt(), "AI 纯汉字深度解析中: ${index+1}/${clips.size}") }
                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}_$index.wav")
                
                var text = ""
                if (extractAudioSmartly(videoFile, wavFile)) {
                    text = recognizeAudio(wavFile)
                    wavFile.delete()
                }
                
                val cleanText = text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
                
                var finalScore = -1f
                var targetText = "（空镜头/无声音）"
                var scriptPos = -1
                
                if (cleanText.length >= 3) {
                    var bestMatchIndex = 0; var highestScore = -1f
                    val videoLen = cleanText.length
                    
                    val maxStart = scriptClean.length - videoLen
                    if (maxStart > 0) {
                        for (i in 0..maxStart) {
                            val windowEnd = minOf(scriptClean.length, i + videoLen + 15)
                            val windowText = scriptClean.substring(i, windowEnd)
                            val score = lcsLength(cleanText, windowText).toFloat() / videoLen
                            if (score > highestScore) {
                                highestScore = score
                                bestMatchIndex = i
                            }
                        }
                    }
                    finalScore = highestScore
                    scriptPos = bestMatchIndex
                    
                    val targetTextLen = minOf(videoLen + 5, scriptClean.length - bestMatchIndex)
                    targetText = if(targetTextLen > 0) scriptClean.substring(bestMatchIndex, bestMatchIndex + targetTextLen) else "未知"
                }
                
                clipResults.add(MatchedClip(clip, if (cleanText.isEmpty()) "（无声音）" else text, targetText, finalScore, scriptPos))
                delay(10)
            }

            val voicedClips = clipResults.filter { it.scriptPos >= 0 }.sortedBy { it.scriptPos }
            val silentClips = clipResults.filter { it.scriptPos < 0 }
            
            val finalOrderedList = mutableListOf<MatchedClip>()
            val occupied = mutableSetOf<Int>()
            
            for (c in voicedClips) {
                var pos = c.scriptPos
                while (occupied.contains(pos)) {
                    pos += 50
                }
                occupied.add(pos)
                finalOrderedList.add(MatchedClip(c.fileName, c.text, c.targetText, c.score, pos))
            }
            
            finalOrderedList.sortBy { it.scriptPos }
            
            if (silentClips.isNotEmpty()) {
                silentClips.forEachIndexed { idx, silent ->
                    val insertIndex = (finalOrderedList.size * (idx + 1) / (silentClips.size + 1))
                    finalOrderedList.add(insertIndex, silent)
                }
            }

            withContext(Dispatchers.Main) { onInitialSort(finalOrderedList) }
            withContext(Dispatchers.Main) { onComplete() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    fun buildJsonFromClips(clips: List<MatchedClip>): String {
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "终极版")
        val scenesArr = JsonArray(); val matchedClipsArr = JsonArray()
        clips.forEachIndexed { idx, item ->
            scenesArr.add("第 ${idx + 1} 段"); matchedClipsArr.add(item.fileName)
        }
        epObj.add("scenes", scenesArr); epObj.add("clips", matchedClipsArr)
        val episodesJsonArray = JsonArray(); episodesJsonArray.add(epObj)
        return episodesJsonArray.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release(); result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootObj = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootObj.size()) {
                val epObj = rootObj.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备原画质素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(50, "正在极速无损合成 (零转码)...") }
                val session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy -map 0 -avoid_negative_ts make_zero \"${outFile.absolutePath}\"")
                
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    val errLog = session.output?.takeLast(150) ?: ""
                    throw Exception("合成失败！请确保导入的视频格式完全一致。\n报错: $errLog")
                }
                
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "极速合成完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}