package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = mutableListOf<String>()
    var parsedEpisodesJson: String? = null

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var tfliteInterpreter: Interpreter? = null
    private var asrRecognizer: OfflineRecognizer? = null
    private val vocabMap = mutableMapOf<String, Int>()
    private val maxSeqLength = 128 

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                loadVocab()
                withContext(Dispatchers.Main) { initTFLite(); initASR(); _modelsReadyFlow.value = true }
            } catch (e: Throwable) { _modelsReadyFlow.value = false }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() }
            } catch (e: Exception) { }
        }
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt", "minilm.tflite")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = File(modelDir, "model.int8.onnx").absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun loadVocab() {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            if (!tokensFile.exists()) return
            tokensFile.forEachLine { line ->
                val parts = line.trim().split(" ")
                if (parts.size >= 2) vocabMap[parts[0]] = parts[1].toIntOrNull() ?: 0
            }
        } catch (e: Throwable) { }
    }

    private fun initTFLite() {
        try {
            val modelFile = File(modelDir, "minilm.tflite")
            if(!modelFile.exists()) return
            val modelBuffer = loadModelFile(modelFile)
            val options = Interpreter.Options().apply { setNumThreads(4) }
            tfliteInterpreter = Interpreter(modelBuffer, options)
        } catch (e: Throwable) { }
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val inputStream = FileInputStream(file)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, fileChannel.size())
    }

    private fun cleanAndFilterText(text: String): String {
        val stopWords = setOf('啊', '哎', '哦', '嗯', '呃', '的', '了', '是', '在', '有', '这', '那', '个', '就', '不', '和', '也', '你', '我', '他', '她', '它', '们', '说', '着', '去', '来', '把', '被', '让', '给', '上', '下', '里', '外')
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "").filter { it !in stopWords }
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    private fun findBestMatch(videoText: String, scriptClean: String): Pair<Int, Float> {
        if (scriptClean.isEmpty() || videoText.isEmpty()) return Pair(0, 0f)
        val videoLen = videoText.length
        if (videoLen < 5) {
            val idx = scriptClean.indexOf(videoText)
            return if (idx != -1) Pair(idx, 1.0f) else Pair(0, 0f)
        }

        var bestMatchIndex = 0; var highestScore = -1f
        val windowSize = minOf(videoLen + 10, scriptClean.length)
        val step = 2

        for (i in 0..(scriptClean.length - windowSize) step step) {
            val windowText = scriptClean.substring(i, i + windowSize)
            val score = lcsLength(videoText, windowText).toFloat() / videoLen
            if (score > highestScore) { highestScore = score; bestMatchIndex = i }
        }
        return Pair(bestMatchIndex, highestScore)
    }

    suspend fun parseEpisodes(script: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有找到视频文件")

            val fullScript = script.split(Regex("\\n-{3,}\\n"))[0] 
            val scriptClean = cleanAndFilterText(fullScript)

            val matchDetails = StringBuilder()
            val clipResults = mutableListOf<Quadruple<String, Int, Float, String>>()

            for ((index, clip) in clips.withIndex()) {
                withContext(Dispatchers.Main) { onProgress(((index+1).toFloat()/clips.size*100).toInt(), "AI雷达扫描中: ${index+1}/${clips.size}") }
                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"volume=2.0\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
                
                var text = ""
                if (ReturnCode.isSuccess(session.returnCode)) { text = recognizeAudio(wavFile); wavFile.delete() }
                
                val cleanText = cleanAndFilterText(text)
                if (cleanText.length < 5) clipResults.add(Quadruple(clip, 999999, 0f, text))
                else {
                    val (matchPos, score) = findBestMatch(cleanText, scriptClean)
                    clipResults.add(Quadruple(clip, matchPos, score, text))
                }
                delay(10)
            }

            val sortedClips = clipResults.sortedWith(compareBy<Quadruple<String, Int, Float, String>> { it.second }.thenByDescending { it.third })

            val epObj = JsonObject()
            epObj.addProperty("episode_id", 1)
            epObj.addProperty("title", "纯血 AI 绝对对齐结果")
            val scenesArr = JsonArray(); val matchedClipsArr = JsonArray()
            matchDetails.append("【纯血 AI 绝对对齐结果】\n")
            sortedClips.forEachIndexed { idx, item ->
                scenesArr.add("第 ${idx + 1} 段剧情"); matchedClipsArr.add(item.first)
                val previewHeard = if (item.fourth.length > 50) item.fourth.take(50) + "..." else item.fourth
                if (item.third < 0.1f) {
                    matchDetails.append("第 ${idx + 1} 段 (⚠️ 未识别到声音)\n👂 \"$previewHeard\"\n\n")
                } else {
                    matchDetails.append("第 ${idx + 1} 段 (坐标: ${item.second}, 匹配度: ${String.format("%.2f", item.third)})\n👂 \"$previewHeard\"\n\n")
                }
            }
            epObj.add("scenes", scenesArr); epObj.add("clips", matchedClipsArr)
            val episodesJsonArray = JsonArray(); episodesJsonArray.add(epObj)

            parsedEpisodesJson = episodesJsonArray.toString() 
            withContext(Dispatchers.Main) { onSuccess(matchDetails.toString()) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release(); result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootObj = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootObj.size()) {
                val epObj = rootObj.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(40, "正在尝试极速原画质拼接...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")
                
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "格式差异，启动原分辨率重编码拼接(较慢)...") }
                    session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v mpeg4 -qscale:v 1 -c:a aac -f mp4 \"${outFile.absolutePath}\"")
                    if (!ReturnCode.isSuccess(session.returnCode)) throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "渲染完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}