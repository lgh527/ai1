package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = mutableListOf<String>()
    var parsedEpisodesJson: String? = null

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null

    data class MatchedClip(val fileName: String, val text: String, val score: Float)

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                withContext(Dispatchers.Main) { 
                    initASR()
                    _modelsReadyFlow.value = true 
                }
            } catch (e: Throwable) { 
                _modelsReadyFlow.value = false 
            }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try { workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() } } catch (e: Exception) { }
        }
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(model = File(modelDir, "model.int8.onnx").absolutePath, language = "auto", useInverseTextNormalization = true),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun cleanAndFilterText(text: String): String {
        val stopWords = setOf('啊', '哎', '哦', '嗯', '呃', '的', '了', '是', '在', '有', '这', '那', '个', '就', '不', '和', '也', '你', '我', '他', '她', '它', '们', '说', '着', '去', '来', '把', '被', '让', '给', '上', '下', '里', '外')
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "").filter { it !in stopWords }
    }

    private fun extractAudioSmartly(videoFile: File, wavFile: File): Boolean {
        val smartFilter = "highpass=f=200, lowpass=f=3500, afftdn=nf=-25, dynaudnorm=f=150:g=15, volume=2.5"
        val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"$smartFilter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
        return ReturnCode.isSuccess(session.returnCode)
    }

    // 恢复最稳定的 LCS 算法
    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    private fun findBestMatch(videoText: String, scriptClean: String): Pair<Int, Float> {
        if (scriptClean.isEmpty() || videoText.isEmpty()) return Pair(0, 0f)
        val videoLen = videoText.length
        if (videoLen < 5) {
            val idx = scriptClean.indexOf(videoText)
            return if (idx != -1) Pair(idx, 1.0f) else Pair(0, 0f)
        }
        var bestMatchIndex = 0; var highestScore = -1f
        val windowSize = minOf(videoLen + 20, scriptClean.length)
        val step = 2
        for (i in 0..(scriptClean.length - windowSize) step step) {
            val windowText = scriptClean.substring(i, i + windowSize)
            // 分数完全基于 LCS 与视频文本长度之比
            val score = lcsLength(videoText, windowText).toFloat() / videoLen
            if (score > highestScore) { highestScore = score; bestMatchIndex = i }
        }
        return Pair(bestMatchIndex, highestScore)
    }

    suspend fun parseEpisodes(script: String, onProgress: (Int, String) -> Unit, onSuccess: (List<MatchedClip>) -> Unit, onError: (String) -> Unit) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有找到视频文件")

            val fullScript = script.split(Regex("\\n-{3,}\\n"))[0] 
            val scriptClean = cleanAndFilterText(fullScript)

            val clipResults = mutableListOf<Triple<String, Int, Float>>()
            val finalResults = mutableListOf<MatchedClip>()

            for ((index, clip) in clips.withIndex()) {
                withContext(Dispatchers.Main) { onProgress(((index+1).toFloat()/clips.size*100).toInt(), "AI 雷达扫描中: ${index+1}/${clips.size}") }
                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                
                var text = ""
                if (extractAudioSmartly(videoFile, wavFile)) {
                    text = recognizeAudio(wavFile)
                    wavFile.delete()
                }
                
                val cleanText = cleanAndFilterText(text)
                if (cleanText.length < 5) {
                    val fallbackPos = (index * (scriptClean.length / clips.size))
                    clipResults.add(Triple(clip, fallbackPos, 0f))
                    finalResults.add(MatchedClip(clip, text, 0f))
                } else {
                    val (matchPos, score) = findBestMatch(cleanText, scriptClean)
                    clipResults.add(Triple(clip, matchPos, score))
                    finalResults.add(MatchedClip(clip, text, score))
                }
                delay(10)
            }

            // 单纯按坐标排序，不再做多余的强制交换操作
            val sortedList = clipResults.sortedWith(compareBy<Triple<String, Int, Float>> { it.second }.thenByDescending { it.third })

            val finalSortedList = sortedList.map { triple ->
                val matched = finalResults.find { it.fileName == triple.first }!!
                MatchedClip(triple.first, matched.text, triple.third)
            }

            withContext(Dispatchers.Main) { onSuccess(finalSortedList) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    fun buildJsonFromClips(clips: List<MatchedClip>): String {
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "精配版")
        val scenesArr = JsonArray(); val matchedClipsArr = JsonArray()
        clips.forEachIndexed { idx, item ->
            scenesArr.add("第 ${idx + 1} 段"); matchedClipsArr.add(item.fileName)
        }
        epObj.add("scenes", scenesArr); epObj.add("clips", matchedClipsArr)
        val episodesJsonArray = JsonArray(); episodesJsonArray.add(epObj)
        return episodesJsonArray.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release(); result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootObj = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootObj.size()) {
                val epObj = rootObj.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备原画质素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(50, "正在极速无损合并 (零转码)...") }
                val session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy -map 0 -avoid_negative_ts make_zero \"${outFile.absolutePath}\"")
                
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    val errLog = session.output?.takeLast(150) ?: ""
                    throw Exception("拼接失败！请确保导入的视频格式完全一致。\n报错: $errLog")
                }
                
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "极速渲染完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}