package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.k2fsa.sherpa.onnx.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AndroidBridge(private val context: Context) {
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }
    
    val uploadedClips = mutableListOf<String>()
    var sentences: List<String> = ArrayList()
    var isModelsLoaded = false
    private var asrRecognizer: OfflineRecognizer? = null

    interface ProgressListener {
        fun onProgress(p: Int, msg: String)
        fun onComplete(result: List<MatchedClip>)
        fun onStitchSuccess(path: String) {}
        fun onError(err: String)
    }

    class MatchedClip(
        val fileName: String, val text: String, val targetText: String,
        val score: Float, val scriptPos: Int
    ) {
        var locked: Boolean = false
    }

    init {
        Thread {
            try {
                copyAssets()
                initASR()
                isModelsLoaded = asrRecognizer != null
            } catch (e: Throwable) { isModelsLoaded = false }
        }.start()
    }

    fun cleanTempFiles() {
        uploadDir.listFiles()?.forEach { it.delete() }
    }

    private fun copyAssets() {
        val files = listOf("model.int8.onnx", "tokens.txt")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try { context.assets.open("models/$file").use { i -> FileOutputStream(outFile).use { i.copyTo(it) } } } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath, 
                        language = "auto", 
                        useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, 
                    numThreads = 4
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { 
            e.printStackTrace() 
        }
    }

    private fun cleanAndFilterText(text: String): String {
        val stopWords = setOf('啊', '哎', '哦', '嗯', '呃', '的', '了', '是', '在', '有', '这', '那', '个', '就', '不', '和', '也', '你', '我', '他', '她', '它', '们', '说', '着', '去', '来', '把', '被', '让', '给', '上', '下', '里', '外')
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "").filter { it !in stopWords }
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    fun parseEpisodes(script: String, listener: ProgressListener) {
        try {
            val clips = uploadedClips.toList()
            if (clips.isEmpty()) throw Exception("没有视频")

            sentences = ArrayList()
            val rawSegs = script.split(Regex("[\\n。！？；…]+"))
            for (raw in rawSegs) {
                val seg = raw.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
                if (seg.length >= 2) sentences.add(seg)
            }
            val scriptClean = cleanAndFilterText(script)

            val clipResults = ArrayList<MatchedClip>()
            for ((index, clip) in clips.withIndex()) {
                listener.onProgress(((index+1).toFloat()/clips.size*100).toInt(), "解析: ${index+1}/${clips.size}")
                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"volume=2.0\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
                
                var text = ""
                if (ReturnCode.isSuccess(session.returnCode)) { text = recognizeAudio(wavFile); wavFile.delete() }
                val cleanText = cleanAndFilterText(text)
                
                var finalScore = 0f
                var targetText = "（空镜）"
                var scriptPos = 9999 + index
                
                if (cleanText.length >= 3) {
                    var bestMatchIndex = 0; var highestScore = -1f
                    val windowSize = minOf(cleanText.length + 10, scriptClean.length)
                    if (scriptClean.length >= windowSize) {
                        for (i in 0..(scriptClean.length - windowSize) step 2) {
                            val windowText = scriptClean.substring(i, i + windowSize)
                            val score = lcsLength(cleanText, windowText).toFloat() / cleanText.length
                            if (score > highestScore) { highestScore = score; bestMatchIndex = i }
                        }
                    }
                    finalScore = highestScore
                    if (finalScore >= 0.35f) {
                        scriptPos = bestMatchIndex
                        for (s in sentences) {
                            if (scriptClean.indexOf(s) >= scriptPos - 5 && scriptClean.indexOf(s) <= scriptPos + 5) { targetText = s; break }
                        }
                    }
                }
                clipResults.add(MatchedClip(clip, text, targetText, finalScore, scriptPos))
                Thread.sleep(10)
            }
            val ordered = clipResults.sortedBy { it.scriptPos }
            listener.onComplete(ordered)
        } catch (e: Throwable) { listener.onError(e.message ?: "错误") }
    }

    fun recalibrate(clips: List<MatchedClip>, sentences: List<String>): MutableList<MatchedClip> {
        val newClips = ArrayList<MatchedClip>()
        for (c in clips) newClips.add(c)
        for (i in newClips.indices) {
            if (newClips[i].locked) continue
            val clean = cleanAndFilterText(newClips[i].text)
            if (clean.isEmpty()) continue
            
            var prevIdx = -1
            for (j in i - 1 downTo 0) if (newClips[j].locked) { prevIdx = newClips[j].scriptPos; break }
            var nextIdx = sentences.size
            for (j in i + 1 until newClips.size) if (newClips[j].locked) { nextIdx = newClips[j].scriptPos; break }
            
            var bestPos = newClips[i].scriptPos
            var bestScore = newClips[i].score
            for (j in maxOf(0, prevIdx)..minOf(sentences.size - 1, nextIdx)) {
                val sc = lcsLength(clean, sentences[j]).toFloat() / maxOf(clean.length, sentences[j].length)
                if (sc > bestScore + 0.05f) { 
                    bestScore = sc; bestPos = j; 
                    val old = newClips[i]
                    newClips[i] = MatchedClip(old.fileName, old.text, sentences[j], sc, j)
                }
            }
        }
        newClips.sortBy { it.scriptPos }
        return newClips
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000); recognizer.decode(stream)
            val result = recognizer.getResult(stream); stream.release(); result.text
        } catch (e: Throwable) { "" }
    }

    fun stitchVideo(fileNames: List<String>, listener: ProgressListener) {
        try {
            val listFile = File(workDir, "concat.txt")
            val outFile = File(workDir, "final.mp4")
            listFile.bufferedWriter().use { out -> for (i in fileNames) out.write("file '${File(uploadDir, i).absolutePath}'\n") }
            
            listener.onProgress(50, "正在极速拼接...")
            var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")
            if (!ReturnCode.isSuccess(session.returnCode)) {
                listener.onProgress(70, "格式差异重编码中...")
                session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v mpeg4 -qscale:v 1 -c:a aac -f mp4 \"${outFile.absolutePath}\"")
            }
            listFile.delete()
            listener.onStitchSuccess(outFile.absolutePath)
        } catch (e: Throwable) { listener.onError(e.message ?: "错误") }
    }
}