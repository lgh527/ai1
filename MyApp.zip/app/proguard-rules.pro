# 保留模型推理的必要类
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class org.tensorflow.lite.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.google.gson.** { *; }
# 保留 JNI 接口和 Android 组件
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep public class * extends android.app.Activity
-keep public class com.lingxu.zhiying.MainActivity { *; }
-keep public class com.lingxu.zhiying.AndroidBridge { *; }
-keepclasseswithmembers class * { native <methods>; }
# 彻底混淆我们自己写的核心业务代码
-repackageclasses 'a'
-allowaccessmodification
-optimizationpasses 5
-dontpreverify
# 移除 Log 调用（防运行信息泄露）
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}