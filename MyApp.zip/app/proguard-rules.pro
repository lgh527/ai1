-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep public class * extends android.app.Activity
-repackageclasses 'a'
-allowaccessmodification
-optimizationpasses 5
-dontpreverify