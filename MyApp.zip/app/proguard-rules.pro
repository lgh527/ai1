-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep public class * extends android.app.Activity
-dontpreverify
-dontwarn org.slf4j.**
-dontwarn com.k2fsa.sherpa.onnx.**