# 保留模型推理的必要类
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
# 保留 JNI 接口和 Android 组件
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep public class * extends android.app.Activity
# 混淆业务代码
-repackageclasses 'a'
-allowaccessmodification
-optimizationpasses 5
-dontpreverify