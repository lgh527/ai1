package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout

    private val REQ_CODE_PERM = 100

    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private lateinit var btnActivate: Button
    private var deviceId: String = ""

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnStitch: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView

    private lateinit var recyclerView: RecyclerView
    private lateinit var cardAdapter: ClipAdapter
    
    private lateinit var tvStats: TextView
    private lateinit var btnCalibrate: Button
    private lateinit var btnLockGreen: Button
    private lateinit var btnUnlockAll: Button
    private var calibrateRound = 0
    private var isCalibrating = false
    private var isModelsReady = false
    private var currentJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            checkPermissions()
            setupBaseUI()

            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }

            if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString())
                .setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun setupBaseUI() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(80, 200, 80, 80)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val tvTip = TextView(this).apply { text = "首次使用请复制下方设备码发给卖家获取激活码"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) }
        tvDeviceCode = TextView(this).apply {
            text = deviceId
            setTextColor(Color.parseColor("#10B981"))
            textSize = 28f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "设备码已复制", Toast.LENGTH_SHORT).show()
            }
        }
        etActivationCode = EditText(this).apply {
            hint = "请输入 32 位激活码"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(30, 30, 30, 30)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        btnActivate = Button(this).apply {
            text = "立即激活"
            setBackgroundColor(Color.parseColor("#2563EB"))
            setTextColor(Color.WHITE)
            setPadding(0, 30, 0, 30)
            setOnClickListener { verifyActivation() }
        }
        authLayout.addView(title); authLayout.addView(tvTip); authLayout.addView(tvDeviceCode); authLayout.addView(etActivationCode); authLayout.addView(btnActivate)
        rootLayout.addView(authLayout)
    }

    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "激活码格式错误，应为 32 位", Toast.LENGTH_SHORT).show(); return }
        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decrypted = ByteArray(obfuscatedBytes.size) { i -> (obfuscatedBytes[i].toInt() xor xorKey).toByte() }
        val realKey = String(decrypted)
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(realKey.toByteArray(), "HmacSHA256"))
            val hashBytes = mac.doFinal(deviceId.toByteArray())
            val expected = hashBytes.joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expected) {
                Toast.makeText(this, "激活成功，永久有效！", Toast.LENGTH_LONG).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE
                showMainApp()
            } else Toast.makeText(this, "激活码错误，请核对后重试", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    private fun showMainApp() {
        if (::mainLayout.isInitialized) { mainLayout.visibility = View.VISIBLE; return }

        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        mainLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(50, 80, 50, 80) }

        val title = TextView(this).apply { text = "灵序织影 · 智能校准"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 20) }

        val tvStep1 = TextView(this).apply { text = "第一步：输入剧情脚本"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, 8) }
        etScript = EditText(this).apply { hint = "长文直接粘贴"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(24, 20, 24, 20); minLines = 3; gravity = Gravity.TOP }
        val tvStep2 = TextView(this).apply { text = "第二步：导入视频素材"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnImport = Button(this).apply { text = "📥 导入视频素材"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        tvClipCount = TextView(this).apply { text = "已导入素材：0 个"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 12f; setPadding(0, 8, 0, 8) }

        val tvStep3 = TextView(this).apply { text = "第三步：智能对齐 + 多轮校对"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnMatch = Button(this).apply { text = "🧠 智能剧情对齐 (首次)"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setOnClickListener { startMatching() } }

        tvStats = TextView(this).apply {
            text = "等待首次对齐..."
            setTextColor(Color.parseColor("#F59E0B"))
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        
        val calibrateRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 8) }
        btnCalibrate = Button(this).apply {
            text = "🔄 智能校对"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#7C3AED"))
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            isEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { runCalibration() }
        }
        btnLockGreen = Button(this).apply {
            text = "🔒 锁定绿项"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#059669"))
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { lockGreens() }
        }
        btnUnlockAll = Button(this).apply {
            text = "🔓 全部解锁"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { unlockAll() }
        }
        calibrateRow.addView(btnCalibrate); calibrateRow.addView(btnLockGreen); calibrateRow.addView(btnUnlockAll)

        recyclerView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(400))
            cardAdapter = ClipAdapter()
            adapter = cardAdapter
        }

        val tvStep4 = TextView(this).apply { text = "第四步：渲染输出"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnStitch = Button(this).apply { text = "🎬 渲染完整视频 (原画质)"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); setPadding(0, 24, 0, 24); setOnClickListener { startStitching() } }
        btnSave = Button(this).apply { text = "💾 保存至相册 (MP4)"; setBackgroundColor(Color.parseColor("#D97706")); setTextColor(Color.WHITE); setPadding(0, 24, 0, 24); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0, 16, 0, 16) }
        tvStatus = TextView(this).apply { text = "准备就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 13f; gravity = Gravity.CENTER }

        mainLayout.addView(title)
        mainLayout.addView(tvStep1); mainLayout.addView(etScript)
        mainLayout.addView(tvStep2); mainLayout.addView(btnImport); mainLayout.addView(tvClipCount)
        mainLayout.addView(tvStep3); mainLayout.addView(btnMatch); mainLayout.addView(tvStats)
        mainLayout.addView(calibrateRow); mainLayout.addView(recyclerView)
        mainLayout.addView(tvStep4); mainLayout.addView(btnStitch); mainLayout.addView(btnSave)
        mainLayout.addView(progressBar); mainLayout.addView(tvStatus)

        val scrollView = ScrollView(this).apply { isFillViewport = true; addView(mainLayout) }
        rootLayout.addView(scrollView)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎加载成功"
            }
        }
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    inner class ClipAdapter : RecyclerView.Adapter<ClipAdapter.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 10, 16, 10)
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 }
            }
            val header = TextView(this@MainActivity).apply { textSize = 12f; setTypeface(null, Typeface.BOLD) }
            val heardLine = TextView(this@MainActivity).apply { textSize = 12f; setPadding(0, 4, 0, 4); setLineSpacing(0f, 1.2f) }
            val scriptLine = TextView(this@MainActivity).apply { textSize = 12f; setLineSpacing(0f, 1.2f) }
            val lockBtn = Button(this@MainActivity).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f); setPadding(16, 4, 16, 4); setTextColor(Color.WHITE) }
            val btnRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, 8, 0, 0) }
            btnRow.addView(lockBtn)
            
            card.addView(header)
            card.addView(heardLine)
            card.addView(scriptLine)
            card.addView(btnRow)
            return ViewHolder(card, header, heardLine, scriptLine, lockBtn)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val m = bridge.allMatches[position]
            val isGreen = m.score >= AndroidBridge.GREEN_THRESHOLD
            val scoreColor = when {
                m.locked -> "#38BDF8"
                isGreen -> "#10B981"
                m.score >= AndroidBridge.YELLOW_THRESHOLD -> "#F59E0B"
                else -> "#EF4444"
            }
            val bgColor = if (m.locked) "#1E293B" else "#0F172A"
            val lockIcon = if (m.locked) "🔒" else if (isGreen) "✅" else "❌"

            holder.card.setBackgroundColor(Color.parseColor(bgColor))
            holder.header.text = "$lockIcon 第${position+1}段 · 匹配度 ${String.format("%.2f", m.score)} · 坐标 ${m.coord}"
            holder.header.setTextColor(Color.parseColor(scoreColor))
            holder.heardLine.text = "🎤 视频台词：\n${if (m.heardText.isBlank()) "(无声音/纯音乐)" else m.heardText}"
            holder.heardLine.setTextColor(Color.parseColor("#94A3B8"))
            holder.scriptLine.text = "📖 剧本匹配：\n${if (m.scriptText.isBlank()) "(未匹配)" else m.scriptText}"
            holder.scriptLine.setTextColor(Color.parseColor("#7DD3FC"))

            holder.lockBtn.text = if (m.locked) "🔓 解锁" else "🔒 锁定"
            holder.lockBtn.setBackgroundColor(Color.parseColor(scoreColor))
            holder.lockBtn.setOnClickListener {
                bridge.toggleLock(position)
                notifyItemChanged(position)
                updateStats()
            }
        }

        override fun getItemCount(): Int = bridge.allMatches.size

        inner class ViewHolder(val card: LinearLayout, val header: TextView, val heardLine: TextView, val scriptLine: TextView, val lockBtn: Button) : RecyclerView.ViewHolder(card)
    }

    private fun resetButtonStates() {
        btnImport.isEnabled = true
        btnMatch.isEnabled = true
        btnMatch.text = "🧠 智能剧情对齐 (首次)"
        btnStitch.isEnabled = true
        btnCalibrate.isEnabled = bridge.allMatches.isNotEmpty()
        btnCalibrate.text = "🔄 智能校对"
        progressBar.visibility = View.GONE
        isCalibrating = false
    }

    private fun importVideos() {
        if (!btnImport.isEnabled) return
        currentJob?.cancel()
        Toast.makeText(this, "正在读取相册...", Toast.LENGTH_SHORT).show()
        
        btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        tvStatus.text = "正在读取本地视频..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val videoList = mutableListOf<Map<String, Any>>()
                val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                cursor?.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                        val name = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        videoList.add(mapOf("id" to id, "name" to name))
                    }
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (videoList.isEmpty()) { tvStatus.text = "未找到视频"; return@withContext }
                    showVideoSelectionDialog(videoList)
                }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { btnImport.isEnabled = true; tvStatus.text = "读取失败" } }
        }
    }

    private fun showVideoSelectionDialog(videoList: List<Map<String, Any>>) {
        val names = videoList.map { it["name"] as String }.toTypedArray()
        val checkedItems = BooleanArray(videoList.size)
        val checkBoxes = mutableListOf<CheckBox>()

        val scrollView = ScrollView(this)
        val listLayout = LinearLayout(this).apply { 
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 10)
            setBackgroundColor(Color.WHITE)
        }
        
        for (i in names.indices) {
            val cb = CheckBox(this).apply {
                text = names[i]
                setTextColor(Color.BLACK)
                textSize = 14f
                isChecked = false
                setOnCheckedChangeListener { _, isChecked -> checkedItems[i] = isChecked }
            }
            checkBoxes.add(cb)
            listLayout.addView(cb)
        }
        scrollView.addView(listLayout)
        
        val container = LinearLayout(this).apply { 
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        
        val cbAll = CheckBox(this).apply {
            text = "全选 / 取消全选"
            setTextColor(Color.BLACK)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(40, 20, 40, 10)
            setOnCheckedChangeListener { _, isChecked ->
                for (i in checkBoxes.indices) {
                    checkBoxes[i].isChecked = isChecked
                    checkedItems[i] = isChecked
                }
            }
        }
        
        container.addView(cbAll)
        container.addView(scrollView)

        AlertDialog.Builder(this)
            .setTitle("选择视频素材（共 ${names.size} 个）")
            .setView(container)
            .setPositiveButton("确定导入") { _, _ ->
                val selected = mutableListOf<Map<String, Any>>()
                for (i in checkedItems.indices) if (checkedItems[i]) selected.add(videoList[i])
                if (selected.isNotEmpty()) downloadSelectedVideos(selected)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun downloadSelectedVideos(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        btnImport.isEnabled = false
        tvStatus.text = "正在导入素材..."
        
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val successful = mutableListOf<String>()
            for (i in videos.indices) {
                val id = videos[i]["id"] as Long
                val name = videos[i]["name"] as String
                withContext(Dispatchers.Main) {
                    tvStatus.text = "正在处理 (${i+1}/${videos.size}): ${name.take(20)}"
                    progressBar.progress = ((i.toFloat() / videos.size) * 100).toInt()
                }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val uniqueName = "${System.currentTimeMillis()}_$name"
                    val destFile = File(bridge.uploadDir, uniqueName)
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
                    successful.add(uniqueName)
                } catch (e: Throwable) { }
                delay(1)
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                btnImport.isEnabled = true
                if (successful.isNotEmpty()) {
                    bridge.uploadedClips.clear()
                    bridge.uploadedClips.addAll(successful)
                    bridge.resetMatches()
                    
                    tvClipCount.text = "已导入素材：${successful.size} 个"
                    tvStatus.text = "素材导入成功，请点击智能对齐"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                    
                    calibrateRound = 0
                    cardAdapter.notifyDataSetChanged()
                    updateStats()
                    resetButtonStates()
                    btnCalibrate.isEnabled = false
                }
            }
        }
    }

    // 【核心升级 1】首扫自动触发校对，并带来全景进度条
    private fun startMatching() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty()) { Toast.makeText(this, "请先输入剧情脚本", Toast.LENGTH_SHORT).show(); return }
        if (bridge.uploadedClips.isEmpty()) { Toast.makeText(this, "请先导入视频素材", Toast.LENGTH_SHORT).show(); return }
        if (!isModelsReady) { Toast.makeText(this, "AI 引擎尚未就绪，请稍候", Toast.LENGTH_SHORT).show(); return }

        Toast.makeText(this, "已启动：AI 识别并自动校准中...", Toast.LENGTH_SHORT).show()
        
        btnMatch.isEnabled = false; btnMatch.text = "🧠 正在智能对齐与校对..."
        btnStitch.isEnabled = false; btnImport.isEnabled = false; btnCalibrate.isEnabled = false
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "启动 AI 全局扫描与识别..."
        calibrateRound = 0
        
        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                // 第一阶段：真实对齐（0% - 70%）
                bridge.initialMatch(script, onProgress = { p, msg ->
                    progressBar.progress = (p * 0.7).toInt()
                    tvStatus.text = msg
                }, onSuccess = {
                    // 第一阶段完成，立刻进入第二阶段：后台自动校对（70% - 100%）
                    tvStatus.text = "AI 识别完毕，后台正在自动校准错位..."
                    progressBar.progress = 70
                    
                    // 延迟一下让UI展示
                    launch {
                        delay(300) 
                        val result = withContext(Dispatchers.Default) { bridge.smartCalibrateOnce() }
                        calibrateRound++
                        progressBar.progress = 100
                        cardAdapter.notifyDataSetChanged()
                        updateStats()
                        
                        Toast.makeText(this@MainActivity, "✅ 首扫+自动校对完成，请查看结果", Toast.LENGTH_LONG).show()
                        tvStatus.text = "首扫+自动校准完成！绿卡已最大化，可手动微调"
                        tvStatus.setTextColor(Color.parseColor("#10B981"))
                    }
                }, onError = { err ->
                    tvStatus.text = "对齐失败：$err"
                    tvStatus.setTextColor(Color.parseColor("#EF4444"))
                })
            } finally {
                // 确保 100% 跑完后按钮复活
                launch {
                    delay(500) // 让进度条走满视觉缓冲
                    resetButtonStates()
                }
            }
        }
    }

    // 【核心升级 2】手动校对可视化进度条
    private fun runCalibration() {
        if (isCalibrating || bridge.allMatches.isEmpty()) return
        
        Toast.makeText(this, "已点击，正在执行智能校对...", Toast.LENGTH_SHORT).show()
        isCalibrating = true
        btnCalibrate.isEnabled = false
        btnCalibrate.text = "🔄 正在计算..."
        btnMatch.isEnabled = false
        btnStitch.isEnabled = false
        
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        tvStatus.text = "正在重新计算坐标与插空..."
        tvStatus.setTextColor(Color.parseColor("#F59E0B"))

        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                // 模拟进度条平滑走动，同时后台执行计算
                val progressAnim = launch {
                    for (i in 1..90) {
                        delay(10)
                        progressBar.progress = i
                    }
                }

                val result = withContext(Dispatchers.Default) { bridge.smartCalibrateOnce() }
                progressAnim.cancel() // 计算完成，停止动画
                
                progressBar.progress = 100
                calibrateRound++
                cardAdapter.notifyDataSetChanged()
                updateStats()

                if (result.improvedCount > 0) {
                    Toast.makeText(this@MainActivity, "✅ 校对完成，推平了 ${result.improvedCount} 项", Toast.LENGTH_SHORT).show()
                    tvStatus.text = "第 ${calibrateRound} 轮：校准 ${result.improvedCount} 项 | 🟢绿 ${result.stillGreen} 🔴红 ${result.stillRed}"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                } else {
                    Toast.makeText(this@MainActivity, "当前已是最优状态", Toast.LENGTH_SHORT).show()
                    tvStatus.text = "第 ${calibrateRound} 轮：全剧完美对齐 | 🟢绿 ${result.stillGreen} 🔴红 ${result.stillRed}"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                }
            } catch (e: Throwable) {
                tvStatus.text = "校准失败：${e.message}"
                tvStatus.setTextColor(Color.parseColor("#EF4444"))
            } finally {
                // 延迟一下让用户看到 100% 的进度条
                delay(500) 
                isCalibrating = false
                resetButtonStates()
            }
        }
    }

    private fun lockGreens() {
        val count = bridge.lockGreenItems()
        Toast.makeText(this, if (count > 0) "已锁定 $count 个绿项" else "没有未锁定的绿项", Toast.LENGTH_SHORT).show()
        cardAdapter.notifyDataSetChanged()
        updateStats()
    }

    private fun unlockAll() {
        val count = bridge.unlockAll()
        Toast.makeText(this, "已解锁 $count 项", Toast.LENGTH_SHORT).show()
        cardAdapter.notifyDataSetChanged()
        updateStats()
    }

    private fun updateStats() {
        if (bridge.allMatches.isEmpty()) {
            tvStats.text = "等待首次对齐..."
            return
        }
        val green = bridge.allMatches.count { it.score >= AndroidBridge.GREEN_THRESHOLD }
        val red = bridge.allMatches.size - green
        val locked = bridge.allMatches.count { it.locked }
        tvStats.text = "总计 ${bridge.allMatches.size} 段 | 🟢绿 $green 🔴红 $red | 🔒锁定 $locked"
        
        if (red == 0) {
            tvStats.setTextColor(Color.parseColor("#10B981"))
        } else {
            tvStats.setTextColor(Color.parseColor("#F59E0B"))
        }
    }

    private fun startStitching() {
        if (bridge.allMatches.isEmpty()) { Toast.makeText(this, "请先完成对齐", Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(this, "已启动：正在渲染视频...", Toast.LENGTH_SHORT).show()
        
        btnStitch.isEnabled = false; btnMatch.isEnabled = false; btnImport.isEnabled = false; btnCalibrate.isEnabled = false
        btnSave.visibility = View.GONE
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "正在渲染原画质视频..."

        currentJob?.cancel()
        currentJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                bridge.stitchVideo(bridge.buildEpisodesJson(), onProgress = { p, msg ->
                    progressBar.progress = p; tvStatus.text = msg
                }, onSuccess = { finalFilePath ->
                    btnSave.visibility = View.VISIBLE; btnSave.tag = finalFilePath
                    btnSave.isEnabled = true
                    tvStatus.text = "渲染完成！请保存至相册"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                }, onError = { err ->
                    btnSave.visibility = View.GONE
                    tvStatus.text = "渲染失败：$err"
                    tvStatus.setTextColor(Color.parseColor("#EF4444"))
                })
            } finally {
                resetButtonStates()
            }
        }
    }

    private fun saveToGallery() {
        val filePath = btnSave.tag as? String
        if (filePath == null) return
        val sourceFile = File(filePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            Toast.makeText(this, "视频文件丢失，请重新渲染", Toast.LENGTH_SHORT).show()
            return
        }
        
        btnSave.isEnabled = false
        tvStatus.text = "正在保存 MP4..."
        
        CoroutineScope(Dispatchers.Main).launch {
            try {
                withContext(Dispatchers.IO) {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影")
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                    }
                    val resolver = contentResolver
                    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    val uri = resolver.insert(collection, contentValues)
                    uri?.let {
                        resolver.openOutputStream(it)?.use { output -> FileInputStream(sourceFile).use { input -> input.copyTo(output) } }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            contentValues.clear(); contentValues.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, contentValues, null, null)
                        }
                    }
                }
                Toast.makeText(this@MainActivity, "视频已保存至相册", Toast.LENGTH_LONG).show()
                btnSave.visibility = View.GONE
                tvStatus.text = "视频已保存至相册"
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "保存失败: ${e.message}", Toast.LENGTH_LONG).show()
                tvStatus.text = "保存失败"
            } finally {
                btnSave.isEnabled = true
            }
        }
    }
}