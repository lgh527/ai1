package com.lingxu.zhiying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive // 【关键修复】导入 JsonPrimitive 解决类型不匹配报错
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

data class ClipMatch(
    val id: Int,
    val clipName: String,
    val heardText: String,
    val heardClean: String,
    var scriptText: String,
    var coord: Int,
    var score: Float,
    var locked: Boolean = false,
    val rawOcr: String = "",
    val rawAsr: String = ""
)

data class CalibrateResult(
    val improvedCount: Int,
    val stillRed: Int,
    val stillGreen: Int
)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.65f
        const val YELLOW_THRESHOLD = 0.40f
        const val IMPROVE_EPSILON = 0.05f 
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()

    private var scriptClean: String = ""
    private var scriptFull: String = ""

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var tfliteInterpreter: Interpreter? = null
    private var asrRecognizer: OfflineRecognizer? = null
    private val vocabMap = mutableMapOf<String, Int>()
    
    private val textRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                loadVocab()
                withContext(Dispatchers.Main) { initTFLite(); initASR(); _modelsReadyFlow.value = true }
            } catch (e: Throwable) { _modelsReadyFlow.value = false }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_") || it.name.startsWith("ocr_")) it.delete() }
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) { }
        }
    }

    fun resetMatches() {
        allMatches.clear()
        scriptClean = ""
        scriptFull = ""
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt", "minilm.tflite")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun loadVocab() {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            if (!tokensFile.exists()) return
            tokensFile.forEachLine { line ->
                val parts = line.trim().split(" ")
                if (parts.size >= 2) vocabMap[parts[0]] = parts[1].toIntOrNull() ?: 0
            }
        } catch (e: Throwable) { }
    }

    private fun initTFLite() {
        try {
            val modelFile = File(modelDir, "minilm.tflite")
            if (!modelFile.exists()) return
            val modelBuffer = loadModelFile(modelFile)
            tfliteInterpreter = Interpreter(modelBuffer, Interpreter.Options().apply { setNumThreads(4) })
        } catch (e: Throwable) { }
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val inputStream = FileInputStream(file)
        val channel = inputStream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
    }

    private fun cleanAndFilterText(text: String): String {
        var cleaned = text.replace(Regex("[^\\u4e00-\\u9fa5a-zA-Z]"), "")
        val watermarks = listOf("抖音", "快手", "号", "aqwbQ", "安庆晚报", "字幕组", "视频", "关注", "点赞", "转发", "评论", "影视", "音乐", "MV", "完整版", "致谢", "宣传部", "政府", "促进会", "作词", "作曲")
        for (wm in watermarks) {
            cleaned = cleaned.replace(wm, "")
        }
        return cleaned
    }

    private fun convertToPinyin(text: String): String {
        val sb = StringBuilder()
        for (char in text) {
            if (char.code in 0x4E00..0x9FFF) {
                val pinyins = android.icu.text.Transliterator.getInstance("Han-Latin/Names; Latin-ASCII; Lower").transliterate(char.toString())
                sb.append(pinyins.replace(" ", ""))
            } else {
                sb.append(char.lowercaseChar())
            }
        }
        return sb.toString()
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        if (abs(m - n) > maxOf(m, n) / 2) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    private fun lcsEndOffset(heard: String, window: String): Int {
        val m = heard.length; val n = window.length
        if (m == 0 || n == 0) return 0
        val dp = Array(m + 1) { IntArray(n + 1) }
        var endJ = 0
        var maxV = 0
        for (i in 1..m) for (j in 1..n) {
            dp[i][j] = if (heard[i - 1] == window[j - 1]) dp[i - 1][j - 1] + 1 else maxOf(dp[i - 1][j], dp[i][j - 1])
            if (dp[i][j] > maxV) { maxV = dp[i][j]; endJ = j }
        }
        return endJ
    }

    data class PosScore(val pos: Int, val score: Float, val window: String)
    private data class FusionResult(val pos: Int, val score: Float, val source: String, val window: String)

    private fun findBestPositionInRange(heard: String, script: String, searchStart: Int, searchEnd: Int, isCalibration: Boolean = false): PosScore {
        val heardLen = heard.length
        if (heardLen == 0) return PosScore(searchStart, 0f, "")

        val safeStart = searchStart.coerceIn(0, script.length)
        val safeEnd = searchEnd.coerceIn(safeStart, script.length)
        if (safeStart >= script.length) return PosScore(script.length, 0f, "")

        val heardPinyin = convertToPinyin(heard)
        
        val windowSize = minOf(heardLen + 20, script.length - safeStart)
        var bestScore = -1f
        var bestPos = safeStart
        var bestWindow = ""

        var pos = safeStart
        val maxPos = minOf(safeEnd - windowSize, script.length - windowSize)
        val step = if (isCalibration) 1 else 2
        
        if (maxPos < safeStart) {
            val actualWindow = script.substring(safeStart, minOf(safeStart + windowSize, script.length))
            val actualWindowPinyin = convertToPinyin(actualWindow)
            val score = lcsLength(heardPinyin, actualWindowPinyin).toFloat() / heardPinyin.length
            return PosScore(safeStart, score, actualWindow)
        }

        while (pos <= maxPos) {
            val window = script.substring(pos, pos + windowSize)
            val windowPinyin = convertToPinyin(window)
            val lcs = lcsLength(heardPinyin, windowPinyin)
            val score = lcs.toFloat() / heardPinyin.length 
            
            if (score > bestScore) {
                bestScore = score
                bestPos = pos
                bestWindow = window
            }
            pos += step
        }
        
        return PosScore(bestPos, bestScore, bestWindow)
    }

    private fun crossValidationLocate(ocrText: String, asrText: String, hint: Int, expectedLen: Int, isCalibration: Boolean): FusionResult {
        val hasOcr = ocrText.length >= 2
        val hasAsr = asrText.length >= 2
        if (!hasOcr && !hasAsr) return FusionResult(hint, 0f, "无信号", "")

        var bestOcrResult: PosScore? = null
        var bestAsrResult: PosScore? = null

        if (hasOcr) {
            bestOcrResult = findBestPositionInRange(ocrText, scriptClean, hint, minOf(scriptClean.length, hint + expectedLen * 3), isCalibration)
        }
        if (hasAsr) {
            bestAsrResult = findBestPositionInRange(asrText, scriptClean, hint, minOf(scriptClean.length, hint + expectedLen * 3), isCalibration)
        }

        if (bestOcrResult != null && bestAsrResult != null) {
            val ocrScore = bestOcrResult.score
            val asrScore = bestAsrResult.score
            val ocrPos = bestOcrResult.pos
            val asrPos = bestAsrResult.pos

            if (abs(ocrPos - asrPos) <= 30) {
                val fusedScore = minOf(1.0f, (ocrScore + asrScore) / 2f + 0.2f)
                val finalPos = if (ocrScore > asrScore) ocrPos else asrPos
                val finalWindow = if (ocrScore > asrScore) bestOcrResult.window else bestAsrResult.window
                return FusionResult(finalPos, fusedScore, "视听交叉印证", finalWindow)
            }
        }

        val bestSingle = listOfNotNull(bestOcrResult, bestAsrResult).maxByOrNull { it.score }
        if (bestSingle != null) {
            return FusionResult(bestSingle.pos, bestSingle.score, if (bestSingle == bestOcrResult) "纯视觉" else "纯听觉", bestSingle.window)
        }

        return FusionResult(hint, 0f, "无效", "")
    }

    private fun naturalCompare(a: String, b: String): Int {
        val regex = Regex("(\\d+)|(\\D+)")
        val aParts = regex.findAll(a).map { it.value }.toList()
        val bParts = regex.findAll(b).map { it.value }.toList()
        val len = minOf(aParts.size, bParts.size)
        for (i in 0 until len) {
            val p1 = aParts[i]
            val p2 = bParts[i]
            val isNum1 = p1.all { it.isDigit() }
            val isNum2 = p2.all { it.isDigit() }
            if (isNum1 && isNum2) {
                val n1 = p1.toLongOrNull() ?: 0L
                val n2 = p2.toLongOrNull() ?: 0L
                val cmp = n1.compareTo(n2)
                if (cmp != 0) return cmp
            } else {
                val cmp = p1.compareTo(p2)
                if (cmp != 0) return cmp
            }
        }
        return aParts.size - bParts.size
    }

    private fun isFileNameSequential(files: List<String>): Boolean {
        var foundCount = 0
        val numbers = mutableListOf<Long>()
        for (f in files) {
            val nums = Regex("\\d+").findAll(f).map { it.value.toLongOrNull() ?: 0L }.toList()
            if (nums.isNotEmpty()) {
                foundCount++
                numbers.add(nums.last())
            }
        }
        if (foundCount >= files.size * 0.8) {
            var decreaseCount = 0
            for (i in 0 until numbers.size - 1) {
                if (numbers[i] >= numbers[i + 1]) decreaseCount++
            }
            if (decreaseCount > numbers.size * 0.2) return false
            return true
        }
        return false
    }

    private fun extractOcrText(videoFile: File): String {
        val tempDir = File(workDir, "ocr_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        val ocrResultBuilder = StringBuilder()
        var lastText = ""
        
        try {
            val session = FFmpegKit.execute("-y -i \"${videoFile.absolutePath}\" -vf fps=2 -q:v 2 \"${tempDir.absolutePath}/frame_%04d.jpg\"")
            
            if (ReturnCode.isSuccess(session.returnCode)) {
                val frames = tempDir.listFiles()?.sortedBy { it.name } ?: emptyList()
                var processed = 0
                for (frame in frames) {
                    val fullBitmap = BitmapFactory.decodeFile(frame.absolutePath) ?: continue
                    
                    val sw = maxOf(1, fullBitmap.width / 2)
                    val sh = maxOf(1, fullBitmap.height / 2)
                    val scaledBitmap = Bitmap.createScaledBitmap(fullBitmap, sw, sh, true)
                    if (fullBitmap != scaledBitmap) fullBitmap.recycle()
                    
                    val image = InputImage.fromBitmap(scaledBitmap, 0)
                    val visionText = Tasks.await(textRecognizer.process(image))
                    scaledBitmap.recycle()
                    
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val lineText = line.text
                            if (lineText.contains("抖音") || lineText.contains("快手") || lineText.contains("号") || 
                                lineText.contains("致谢") || lineText.contains("政府") || lineText.contains("宣传部") ||
                                lineText.contains("促进会") || lineText.contains("作词") || lineText.contains("作曲")) {
                                continue
                            }
                            
                            val boundingBox = line.boundingBox
                            if (boundingBox != null && boundingBox.top > scaledBitmap.height * 0.85) {
                                continue
                            }

                            val cleanText = cleanAndFilterText(lineText)
                            if (cleanText.length >= 2 && cleanText != lastText && !isTextSimilar(cleanText, lastText)) {
                                ocrResultBuilder.append(cleanText).append(" ")
                                lastText = cleanText
                            }
                        }
                    }
                    if (++processed % 20 == 0) System.gc()
                }
            }
        } catch (e: Throwable) {
        } finally {
            tempDir.listFiles()?.forEach { it.delete() }
            tempDir.delete()
        }
        return ocrResultBuilder.toString().trim()
    }

    private fun isTextSimilar(t1: String, t2: String): Boolean {
        if (t2.isEmpty() || t1.isEmpty()) return false
        val maxLen = maxOf(t1.length, t2.length)
        val common = lcsLength(t1, t2)
        return (common.toFloat() / maxLen) > 0.8f
    }

    suspend fun initialMatch(script: String, forceAI: Boolean, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sortedClips = uploadedClips.toList().sortedWith { o1, o2 ->
                naturalCompare(o1, o2)
            }
            
            if (sortedClips.isEmpty()) throw Exception("没有找到视频文件")

            scriptFull = script
            scriptClean = cleanAndFilterText(script)
            
            allMatches.clear()
            val totalClips = sortedClips.size

            // 【核心功能】如果剧本为空，直接按文件名直通，全绿灯！
            if (scriptClean.isEmpty()) {
                for ((index, clip) in sortedClips.withIndex()) {
                    allMatches.add(
                        ClipMatch(
                            id = index,
                            clipName = clip,
                            heardText = "【极速直拼模式 (按文件名)】",
                            heardClean = "",
                            scriptText = "【直接拼接】",
                            coord = index, // 按顺序排
                            score = 1.0f, // 直接拉满
                            locked = true // 直接锁定
                        )
                    )
                }
                withContext(Dispatchers.Main) { onSuccess() }
                return
            }

            val isDirectSequence = if (forceAI) false else isFileNameSequential(sortedClips)

            var currentScriptPos = 0 

            for ((index, clip) in sortedClips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / totalClips * 100).toInt(), "扫描 ${index + 1}/${totalClips}: ${clip.take(15)}")
                }
                
                val remainClips = totalClips - index
                val remainLen = scriptClean.length - currentScriptPos
                val expectedLen = maxOf(1, remainLen / remainClips)

                if (isDirectSequence) {
                    val finalCoord = currentScriptPos
                    val actualEnd = minOf(finalCoord + expectedLen, scriptClean.length)
                    val finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, actualEnd) else ""
                    
                    allMatches.add(
                        ClipMatch(
                            id = index,
                            clipName = clip,
                            heardText = "【文件名序列直通】",
                            heardClean = "",
                            scriptText = finalWindow,
                            coord = finalCoord,
                            score = 0.8f,
                            locked = false
                        )
                    )
                    currentScriptPos = actualEnd
                    delay(5)
                    continue
                }

                val videoFile = File(uploadDir, clip)
                
                val asrText = withContext(Dispatchers.IO) {
                    var text = ""
                    val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                    val session = FFmpegKit.execute(
                        "-y -vn -i \"${videoFile.absolutePath}\" -t 30 -af \"highpass=f=200, lowpass=f=3400, volume=2.5\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                    )
                    if (ReturnCode.isSuccess(session.returnCode)) {
                        text = recognizeAudio(wavFile)
                        wavFile.delete()
                    }
                    text
                }
                val cleanAsr = cleanAndFilterText(asrText)

                val ocrText = withContext(Dispatchers.IO) { extractOcrText(videoFile) }
                val cleanOcr = cleanAndFilterText(ocrText)

                val fusion = crossValidationLocate(cleanOcr, cleanAsr, currentScriptPos, expectedLen, false)

                var finalCoord = currentScriptPos
                var finalScore = 0f
                var finalWindow = ""

                if (fusion.score >= GREEN_THRESHOLD && lcsLength(fusion.window, if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr) >= 4) {
                    finalCoord = fusion.pos
                    finalScore = fusion.score
                    finalWindow = fusion.window
                    val heard = if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr
                    currentScriptPos = minOf(scriptClean.length, finalCoord + lcsEndOffset(heard, fusion.window))
                } else {
                    finalCoord = currentScriptPos
                    finalScore = 0f 
                    finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, minOf(finalCoord + 50, scriptClean.length)) else ""
                }

                allMatches.add(
                    ClipMatch(
                        id = index,
                        clipName = clip,
                        heardText = if (cleanOcr.isNotBlank()) "【底部字幕】$cleanOcr\n【语音】$cleanAsr" else "【语音】$cleanAsr",
                        heardClean = if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr,
                        scriptText = finalWindow,
                        coord = finalCoord,
                        score = finalScore,
                        locked = false,
                        rawOcr = cleanOcr,
                        rawAsr = cleanAsr
                    )
                )
                delay(5)
            }

            val finalSorted = allMatches.sortedBy { it.coord }
            allMatches.clear()
            allMatches.addAll(finalSorted)

            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) {
            return@withContext CalibrateResult(0, 0, 0)
        }

        var improved = 0
        val n = allMatches.size
        var i = 0

        while (i < n) {
            if (allMatches[i].locked) {
                i++
                continue
            }

            val rangeStart = i
            while (i < n && !allMatches[i].locked) {
                i++
            }
            val rangeEnd = i - 1

            var lowerBound = 0
            for (j in rangeStart - 1 downTo 0) {
                if (allMatches[j].locked) {
                    lowerBound = allMatches[j].coord + allMatches[j].scriptText.length
                    break
                }
            }

            var upperBound = scriptClean.length
            for (j in rangeEnd + 1 until n) {
                if (allMatches[j].locked) {
                    upperBound = allMatches[j].coord
                    break
                }
            }

            if (upperBound <= lowerBound) upperBound = lowerBound + 50

            for (idx in rangeStart..rangeEnd) {
                val m = allMatches[idx]
                
                val fusion = crossValidationLocate(m.rawOcr, m.rawAsr, lowerBound, upperBound - lowerBound, true)

                if (fusion.score > m.score + IMPROVE_EPSILON && fusion.score >= YELLOW_THRESHOLD) {
                    allMatches[idx] = m.copy(
                        scriptText = fusion.window,
                        coord = fusion.pos,
                        score = fusion.score
                    )
                    improved++
                }
            }
        }

        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
                allMatches[i] = allMatches[i].copy(locked = true)
                count++
            }
        }
        return count
    }

    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (allMatches[i].locked) {
                allMatches[i] = allMatches[i].copy(locked = false)
                count++
            }
        }
        return count
    }

    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index] = allMatches[index].copy(locked = !allMatches[index].locked)
        return allMatches[index].locked
    }

    fun moveUp(index: Int) {
        if (index > 0 && index < allMatches.size) {
            val item = allMatches.removeAt(index)
            allMatches.add(index - 1, item)
        }
    }

    fun moveDown(index: Int) {
        if (index >= 0 && index < allMatches.size - 1) {
            val item = allMatches.removeAt(index)
            allMatches.add(index + 1, item)
        }
    }

    fun recalculateMatchAt(index: Int) {
        if (index !in allMatches.indices) return
        val m = allMatches[index]
        if (m.locked) return
        
        var lowerBound = 0
        for (j in index - 1 downTo 0) {
            if (allMatches[j].locked) {
                lowerBound = allMatches[j].coord + allMatches[j].scriptText.length
                break
            }
        }
        var upperBound = scriptClean.length
        for (j in index + 1 until allMatches.size) {
            if (allMatches[j].locked) {
                upperBound = allMatches[j].coord
                break
            }
        }
        
        if (lowerBound == 0 && index > 0) lowerBound = maxOf(0, allMatches[index - 1].coord - 500)
        if (upperBound == scriptClean.length && index < allMatches.size - 1) upperBound = minOf(scriptClean.length, allMatches[index + 1].coord + 500)

        if (upperBound <= lowerBound) upperBound = lowerBound + 500

        val fusion = crossValidationLocate(m.rawOcr, m.rawAsr, lowerBound, upperBound - lowerBound, true)

        if (fusion.score < GREEN_THRESHOLD) {
            allMatches[index] = m.copy(
                scriptText = fusion.window,
                coord = fusion.pos,
                score = 0f 
            )
        } else {
            allMatches[index] = m.copy(
                scriptText = fusion.window,
                coord = fusion.pos,
                score = fusion.score
            )
        }
    }

    fun buildEpisodesJsonByUIOrder(): String {
        if (allMatches.isEmpty()) return "[]"
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "AI 校准后对齐结果")
        val scenesArr = JsonArray()
        val clipsArr = JsonArray()
        allMatches.forEachIndexed { idx, m ->
            // 【关键修复】使用 JsonPrimitive 包装 String 类型，解决编译错误
            scenesArr.add(JsonPrimitive("第 ${idx + 1} 段 · 匹配度${String.format("%.2f", m.score)}"))
            clipsArr.add(JsonPrimitive(m.clipName))
        }
        epObj.add("scenes", scenesArr)
        epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000)
            recognizer.decode(stream)
            val result = recognizer.getResult(stream)
            stream.release()
            result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")

                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(40, "正在尝试极速原画质拼接...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")

                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "格式差异，启动 H.264 重编码拼接(较慢)...") }
                    session = FFmpegKit.execute(
                        "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${outFile.absolutePath}\""
                    )
                    if (!ReturnCode.isSuccess(session.returnCode)) {
                        throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                    }
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) {
                onProgress(100, "渲染完成")
                onSuccess(lastOutputPath)
            }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}