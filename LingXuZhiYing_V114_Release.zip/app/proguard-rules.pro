# 混淆已关闭，此规则仅作保险
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class org.tensorflow.tflite.** { *; }
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.google.gson.** { *; }
-keep class com.google.mlkit.** { *; }
-keep public class * extends android.app.Activity