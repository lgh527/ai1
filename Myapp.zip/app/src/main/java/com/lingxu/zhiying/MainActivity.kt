package com.lingxu.zhiying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var bridge: AndroidBridge
    private lateinit var rootLayout: FrameLayout
    private lateinit var authLayout: LinearLayout
    private lateinit var mainLayout: LinearLayout

    private val REQ_CODE_PERM = 100

    private lateinit var tvDeviceCode: TextView
    private lateinit var etActivationCode: EditText
    private lateinit var btnActivate: Button
    private var deviceId: String = ""

    private lateinit var etScript: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnImport: Button
    private lateinit var btnMatch: Button
    private lateinit var btnStitch: Button
    private lateinit var btnSave: Button
    private lateinit var tvClipCount: TextView

    // ====== 智能校准相关 ======
    private lateinit var cardContainer: LinearLayout
    private lateinit var tvStats: TextView
    private lateinit var btnCalibrate: Button
    private lateinit var btnLockGreen: Button
    private lateinit var btnUnlockAll: Button
    private var calibrateRound = 0
    private var isCalibrating = false
    private var isModelsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            checkPermissions()
            setupBaseUI()

            val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            deviceId = prefs.getString("device_id", null) ?: run {
                val newId = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
                prefs.edit().putString("device_id", newId).apply()
                newId
            }

            if (prefs.getBoolean("is_activated", false)) showMainApp() else showAuthScreen()
        } catch (e: Throwable) {
            AlertDialog.Builder(this).setTitle("启动异常").setMessage(e.stackTraceToString())
                .setPositiveButton("关闭", null).show()
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_CODE_PERM)
    }

    private fun setupBaseUI() {
        rootLayout = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05080E")) }
        setContentView(rootLayout)
    }

    private fun showAuthScreen() {
        authLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#05080E"))
            setPadding(80, 200, 80, 80)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply { text = "灵序织影"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val tvTip = TextView(this).apply { text = "首次使用请复制下方设备码发给卖家获取激活码"; setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) }
        tvDeviceCode = TextView(this).apply {
            text = deviceId
            setTextColor(Color.parseColor("#10B981"))
            textSize = 28f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DeviceCode", deviceId))
                Toast.makeText(this@MainActivity, "设备码已复制", Toast.LENGTH_SHORT).show()
            }
        }
        etActivationCode = EditText(this).apply {
            hint = "请输入 32 位激活码"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(30, 30, 30, 30)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        btnActivate = Button(this).apply {
            text = "立即激活"
            setBackgroundColor(Color.parseColor("#2563EB"))
            setTextColor(Color.WHITE)
            setPadding(0, 30, 0, 30)
            setOnClickListener { verifyActivation() }
        }
        authLayout.addView(title); authLayout.addView(tvTip); authLayout.addView(tvDeviceCode); authLayout.addView(etActivationCode); authLayout.addView(btnActivate)
        rootLayout.addView(authLayout)
    }

    // ================= XOR 深度混淆解密 =================
    private fun verifyActivation() {
        val input = etActivationCode.text.toString().trim().uppercase()
        if (input.length != 32) { Toast.makeText(this, "激活码格式错误，应为 32 位", Toast.LENGTH_SHORT).show(); return }
        val obfuscatedBytes = byteArrayOf(0x16, 0x3B, 0x38, 0x31, 0x06, 0x2E, 0x1A, 0x3A, 0x39, 0x03, 0x16, 0x3D, 0x39, 0x52, 0x1B, 0x35, 0x30, 0x16, 0x12, 0x0B, 0x02, 0x5A, 0x13, 0x3B, 0x39, 0x30, 0x3B, 0x17, 0x39, 0x3B, 0x13, 0x1E)
        val xorKey = 0x5A
        val decrypted = ByteArray(obfuscatedBytes.size) { i -> (obfuscatedBytes[i].toInt() xor xorKey).toByte() }
        val realKey = String(decrypted)
        try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(realKey.toByteArray(), "HmacSHA256"))
            val hashBytes = mac.doFinal(deviceId.toByteArray())
            val expected = hashBytes.joinToString("") { "%02x".format(it) }.uppercase().substring(0, 32)
            if (input == expected) {
                Toast.makeText(this, "激活成功，永久有效！", Toast.LENGTH_LONG).show()
                getSharedPreferences("app_prefs", Context.MODE_PRIVATE).edit().putBoolean("is_activated", true).apply()
                authLayout.visibility = View.GONE
                showMainApp()
            } else Toast.makeText(this, "激活码错误，请核对后重试", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "验证异常", Toast.LENGTH_SHORT).show() }
    }

    // ================= 主界面业务 =================
    private fun showMainApp() {
        if (::mainLayout.isInitialized) { mainLayout.visibility = View.VISIBLE; return }

        bridge = AndroidBridge(this) { msg -> runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
        mainLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05080E")); setPadding(50, 80, 50, 80) }

        val title = TextView(this).apply { text = "灵序织影 · 智能校准"; setTextColor(Color.parseColor("#0EA5E9")); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 20) }

        val tvStep1 = TextView(this).apply { text = "第一步：输入剧情脚本"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, 8) }
        etScript = EditText(this).apply { hint = "长文直接粘贴"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1E293B")); setPadding(24, 20, 24, 20); minLines = 3; gravity = Gravity.TOP }
        val tvStep2 = TextView(this).apply { text = "第二步：导入视频素材"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnImport = Button(this).apply { text = "📥 导入视频素材"; setBackgroundColor(Color.parseColor("#0284C7")); setTextColor(Color.WHITE); setOnClickListener { importVideos() } }
        tvClipCount = TextView(this).apply { text = "已导入素材：0 个"; setTextColor(Color.parseColor("#7DD3FC")); textSize = 12f; setPadding(0, 8, 0, 8) }

        val tvStep3 = TextView(this).apply { text = "第三步：智能对齐 + 多轮校对"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnMatch = Button(this).apply { text = "🧠 智能剧情对齐 (首次)"; setBackgroundColor(Color.parseColor("#2563EB")); setTextColor(Color.WHITE); setOnClickListener { startMatching() } }

        // ====== 校准控制区 ======
        tvStats = TextView(this).apply {
            text = "等待首次对齐..."
            setTextColor(Color.parseColor("#F59E0B"))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        val calibrateRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 4, 0, 8) }
        btnCalibrate = Button(this).apply {
            text = "🔄 智能校对"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#7C3AED"))
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            isEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { runCalibration() }
        }
        btnLockGreen = Button(this).apply {
            text = "🔒 锁定绿项"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#059669"))
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 }
            setOnClickListener { lockGreens() }
        }
        btnUnlockAll = Button(this).apply {
            text = "🔓 全部解锁"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { unlockAll() }
        }
        calibrateRow.addView(btnCalibrate); calibrateRow.addView(btnLockGreen); calibrateRow.addView(btnUnlockAll)

        // ====== 卡片容器 ======
        cardContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cardScroll = ScrollView(this).apply {
            addView(cardContainer)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(320))
            setPadding(0, 8, 0, 8)
        }
        refreshCards()

        val tvStep4 = TextView(this).apply { text = "第四步：渲染输出"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, 16, 0, 8) }
        btnStitch = Button(this).apply { text = "🎬 渲染完整视频 (原画质)"; setBackgroundColor(Color.parseColor("#059669")); setTextColor(Color.WHITE); setPadding(0, 24, 0, 24); setOnClickListener { startStitching() } }
        btnSave = Button(this).apply { text = "💾 保存至相册 (MP4)"; setBackgroundColor(Color.parseColor("#D97706")); setTextColor(Color.WHITE); setPadding(0, 24, 0, 24); visibility = View.GONE; setOnClickListener { saveToGallery() } }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE; setPadding(0, 16, 0, 16) }
        tvStatus = TextView(this).apply { text = "准备就绪"; setTextColor(Color.parseColor("#10B981")); textSize = 13f; gravity = Gravity.CENTER }

        mainLayout.addView(title)
        mainLayout.addView(tvStep1); mainLayout.addView(etScript)
        mainLayout.addView(tvStep2); mainLayout.addView(btnImport); mainLayout.addView(tvClipCount)
        mainLayout.addView(tvStep3); mainLayout.addView(btnMatch); mainLayout.addView(tvStats)
        mainLayout.addView(calibrateRow); mainLayout.addView(cardScroll)
        mainLayout.addView(tvStep4); mainLayout.addView(btnStitch); mainLayout.addView(btnSave)
        mainLayout.addView(progressBar); mainLayout.addView(tvStatus)

        val scrollView = ScrollView(this).apply { isFillViewport = true; addView(mainLayout) }
        rootLayout.addView(scrollView)

        CoroutineScope(Dispatchers.Main).launch {
            bridge.modelsReadyFlow.collect { ready ->
                isModelsReady = ready
                if (ready) tvStatus.text = "AI 引擎加载成功"
            }
        }
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    // ================= 导入视频 =================
    private fun importVideos() {
        if (!btnImport.isEnabled) return
        btnImport.isEnabled = false
        btnSave.visibility = View.GONE
        tvStatus.text = "正在读取本地视频..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val videoList = mutableListOf<Map<String, Any>>()
                val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
                val cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                cursor?.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                        val name = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        videoList.add(mapOf("id" to id, "name" to name))
                    }
                }
                withContext(Dispatchers.Main) {
                    btnImport.isEnabled = true
                    if (videoList.isEmpty()) { tvStatus.text = "未找到视频"; return@withContext }
                    showVideoSelectionDialog(videoList)
                }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { btnImport.isEnabled = true; tvStatus.text = "读取失败" } }
        }
    }

    private fun showVideoSelectionDialog(videoList: List<Map<String, Any>>) {
        val names = videoList.map { it["name"] as String }.toTypedArray()
        val checkedItems = BooleanArray(videoList.size)
        AlertDialog.Builder(this)
            .setTitle("选择视频素材（可多选）")
            .setMultiChoiceItems(names, checkedItems) { _, which, isChecked -> checkedItems[which] = isChecked }
            .setPositiveButton("确定导入") { _, _ ->
                val selected = mutableListOf<Map<String, Any>>()
                for (i in checkedItems.indices) if (checkedItems[i]) selected.add(videoList[i])
                if (selected.isNotEmpty()) downloadSelectedVideos(selected)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun downloadSelectedVideos(videos: List<Map<String, Any>>) {
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        btnImport.isEnabled = false
        tvStatus.text = "正在导入素材..."
        CoroutineScope(Dispatchers.IO).launch {
            bridge.cleanTempFiles()
            val successful = mutableListOf<String>()
            for (i in videos.indices) {
                val id = videos[i]["id"] as Long
                val name = videos[i]["name"] as String
                withContext(Dispatchers.Main) {
                    tvStatus.text = "正在处理 (${i+1}/${videos.size}): ${name.take(20)}"
                    progressBar.progress = ((i.toFloat() / videos.size) * 100).toInt()
                }
                try {
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val uniqueName = "${System.currentTimeMillis()}_$name"
                    val destFile = File(bridge.uploadDir, uniqueName)
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
                    successful.add(uniqueName)
                } catch (e: Throwable) { }
                delay(1)
            }
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                btnImport.isEnabled = true
                if (successful.isNotEmpty()) {
                    bridge.uploadedClips.clear()
                    bridge.uploadedClips.addAll(successful)
                    bridge.resetMatches()
                    tvClipCount.text = "已导入素材：${successful.size} 个"
                    tvStatus.text = "素材导入成功，请点击智能对齐"
                    tvStatus.setTextColor(Color.parseColor("#10B981"))
                    refreshCards()
                    updateStats()
                    btnCalibrate.isEnabled = false
                    calibrateRound = 0
                }
            }
        }
    }

    // ================= 首次智能对齐 =================
    private fun startMatching() {
        val script = etScript.text.toString().trim()
        if (script.isEmpty()) { Toast.makeText(this, "请先输入剧情脚本", Toast.LENGTH_SHORT).show(); return }
        if (bridge.uploadedClips.isEmpty()) { Toast.makeText(this, "请先导入视频素材", Toast.LENGTH_SHORT).show(); return }
        if (!isModelsReady) { Toast.makeText(this, "AI 引擎尚未就绪，请稍候", Toast.LENGTH_SHORT).show(); return }

        btnMatch.isEnabled = false; btnStitch.isEnabled = false; btnImport.isEnabled = false; btnCalibrate.isEnabled = false
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "AI 首次全局对齐中..."
        calibrateRound = 0

        CoroutineScope(Dispatchers.Main).launch {
            bridge.initialMatch(script, onProgress = { p, msg ->
                progressBar.progress = p; tvStatus.text = msg
            }, onSuccess = {
                progressBar.visibility = View.GONE
                btnMatch.isEnabled = true; btnStitch.isEnabled = true; btnImport.isEnabled = true; btnCalibrate.isEnabled = true
                tvStatus.text = "首次对齐完成！点击 🔄 智能校对 持续优化"
                tvStatus.setTextColor(Color.parseColor("#10B981"))
                refreshCards()
                updateStats()
            }, onError = { err ->
                progressBar.visibility = View.GONE
                btnMatch.isEnabled = true; btnStitch.isEnabled = true; btnImport.isEnabled = true
                tvStatus.text = "对齐失败：$err"
                tvStatus.setTextColor(Color.parseColor("#EF4444"))
            })
        }
    }

    // ================= 智能校对（多轮迭代） =================
    private fun runCalibration() {
        if (isCalibrating || bridge.allMatches.isEmpty()) return
        isCalibrating = true
        btnCalibrate.isEnabled = false
        btnMatch.isEnabled = false
        btnStitch.isEnabled = false
        tvStatus.text = "AI 校准中（第 ${calibrateRound + 1} 轮）..."
        tvStatus.setTextColor(Color.parseColor("#F59E0B"))

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = bridge.smartCalibrateOnce()
                withContext(Dispatchers.Main) {
                    calibrateRound++
                    refreshCards()
                    updateStats()
                    isCalibrating = false
                    btnCalibrate.isEnabled = true
                    btnMatch.isEnabled = true
                    btnStitch.isEnabled = true

                    val msg = if (result.improvedCount == 0) {
                        "第 ${calibrateRound} 轮：已达局部最优，请锁定绿项后再校对"
                    } else {
                        "第 ${calibrateRound} 轮：改进 ${result.improvedCount} 项 | 🟢绿 ${result.stillGreen} 🔴红 ${result.stillRed}"
                    }
                    tvStatus.text = msg
                    tvStatus.setTextColor(if (result.improvedCount > 0) Color.parseColor("#10B981") else Color.parseColor("#F59E0B"))
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    tvStatus.text = "校准失败：${e.message}"
                    tvStatus.setTextColor(Color.parseColor("#EF4444"))
                    isCalibrating = false
                    btnCalibrate.isEnabled = true
                    btnMatch.isEnabled = true
                    btnStitch.isEnabled = true
                }
            }
        }
    }

    private fun lockGreens() {
        val count = bridge.lockGreenItems()
        Toast.makeText(this, if (count > 0) "已锁定 $count 个绿项" else "没有未锁定的绿项", Toast.LENGTH_SHORT).show()
        refreshCards()
        updateStats()
    }

    private fun unlockAll() {
        val count = bridge.unlockAll()
        Toast.makeText(this, "已解锁 $count 项", Toast.LENGTH_SHORT).show()
        refreshCards()
        updateStats()
    }

    private fun updateStats() {
        if (bridge.allMatches.isEmpty()) {
            tvStats.text = "等待首次对齐..."
            return
        }
        val green = bridge.allMatches.count { it.score >= AndroidBridge.GREEN_THRESHOLD }
        val locked = bridge.allMatches.count { it.locked }
        tvStats.text = "总计 ${bridge.allMatches.size} 段 | 🟢绿 $green 🔴红 ${bridge.allMatches.size - green} | 🔒锁定 $locked"
    }

    // ================= 红绿卡片渲染 =================
    private fun refreshCards() {
        if (!::cardContainer.isInitialized) return
        cardContainer.removeAllViews()
        if (bridge.allMatches.isEmpty()) {
            val hint = TextView(this).apply {
                text = "请先导入素材并点击 🧠 智能剧情对齐"
                setTextColor(Color.GRAY); textSize = 12f; gravity = Gravity.CENTER
                setPadding(0, 40, 0, 40)
            }
            cardContainer.addView(hint)
            return
        }
        for ((i, m) in bridge.allMatches.withIndex()) {
            cardContainer.addView(createClipCard(i, m))
        }
    }

    private fun createClipCard(index: Int, m: ClipMatch): View {
        val isGreen = m.score >= AndroidBridge.GREEN_THRESHOLD
        val scoreColor = when {
            m.locked -> "#38BDF8"
            isGreen -> "#10B981"
            m.score >= AndroidBridge.YELLOW_THRESHOLD -> "#F59E0B"
            else -> "#EF4444"
        }
        val bgColor = if (m.locked) "#1E293B" else "#0F172A"
        val lockIcon = if (m.locked) "🔒" else if (isGreen) "✅" else "❌"

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor(bgColor))
            setPadding(16, 10, 16, 10)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 6 }
        }

        val header = TextView(this).apply {
            text = "$lockIcon 第${index+1}段 · 匹配度 ${String.format("%.2f", m.score)} · 坐标 ${m.coord}"
            setTextColor(Color.parseColor(scoreColor))
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
        }
        val heardLine = TextView(this).apply {
            text = "🎤 视频台词：${if (m.heardText.isBlank()) "(无声音)" else m.heardText.take(60)}"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            setPadding(0, 4, 0, 2)
        }
        val scriptLine = TextView(this).apply {
            text = "📖 剧本匹配：${if (m.scriptText.isBlank()) "(未匹配)" else m.scriptText.take(60)}"
            setTextColor(Color.parseColor("#7DD3FC"))
            textSize = 11f
        }

        val lockBtn = Button(this).apply {
            text = if (m.locked) "🔓 解锁" else "🔒 锁定"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10f)
            setPadding(16, 4, 16, 4)
            setBackgroundColor(Color.parseColor(scoreColor))
            setTextColor(Color.WHITE)
            setOnClickListener {
                bridge.toggleLock(index)
                refreshCards()
                updateStats()
            }
        }
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, 4, 0, 0) }
        btnRow.addView(lockBtn)

        card.addView(header)
        card.addView(heardLine)
        card.addView(scriptLine)
        card.addView(btnRow)
        return card
    }

    // ================= 渲染 =================
    private fun startStitching() {
        if (bridge.allMatches.isEmpty()) { Toast.makeText(this, "请先完成对齐", Toast.LENGTH_SHORT).show(); return }
        btnStitch.isEnabled = false; btnMatch.isEnabled = false; btnImport.isEnabled = false; btnCalibrate.isEnabled = false
        btnSave.visibility = View.GONE
        progressBar.visibility = View.VISIBLE; progressBar.progress = 0
        tvStatus.text = "正在渲染原画质视频..."

        CoroutineScope(Dispatchers.Main).launch {
            bridge.stitchVideo(bridge.buildEpisodesJson(), onProgress = { p, msg ->
                progressBar.progress = p; tvStatus.text = msg
            }, onSuccess = { finalFilePath ->
                progressBar.visibility = View.GONE
                btnStitch.isEnabled = true; btnMatch.isEnabled = true; btnImport.isEnabled = true; btnCalibrate.isEnabled = true
                btnSave.visibility = View.VISIBLE; btnSave.tag = finalFilePath
                tvStatus.text = "渲染完成！请保存至相册"
                tvStatus.setTextColor(Color.parseColor("#10B981"))
            }, onError = { err ->
                progressBar.visibility = View.GONE
                btnStitch.isEnabled = true; btnMatch.isEnabled = true; btnImport.isEnabled = true; btnCalibrate.isEnabled = true
                tvStatus.text = "渲染失败：$err"
                tvStatus.setTextColor(Color.parseColor("#EF4444"))
            })
        }
    }

    private fun saveToGallery() {
        val filePath = btnSave.tag as? String ?: return
        val sourceFile = File(filePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) return
        btnSave.isEnabled = false
        tvStatus.text = "正在保存 MP4..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "LingXu_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵序织影")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val resolver = contentResolver
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val uri = resolver.insert(collection, contentValues)
                uri?.let {
                    resolver.openOutputStream(it)?.use { output -> FileInputStream(sourceFile).use { input -> input.copyTo(output) } }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        contentValues.clear(); contentValues.put(MediaStore.Video.Media.IS_PENDING, 0); resolver.update(uri, contentValues, null, null)
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "视频已保存至相册", Toast.LENGTH_LONG).show()
                    btnSave.visibility = View.GONE; btnSave.isEnabled = true
                    tvStatus.text = "视频已保存至相册"
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    btnSave.isEnabled = true
                    Toast.makeText(this@MainActivity, "保存失败", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}