package com.lingxu.zhiying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

class ClipMatch(
    var id: Int,
    var clipName: String,
    var heardText: String,
    var heardClean: String,
    var scriptText: String,
    var coord: Int,      
    var score: Float,    
    var locked: Boolean = false,
    var rawOcr: String = "",
    var rawAsr: String = "",
    var visualHash: String = "",
    var firstFrameHash: String = "",
    var lastFrameHash: String = "",
    var durationSec: Float = 0f
)

data class CalibrateResult(val improvedCount: Int, val stillRed: Int, val stillGreen: Int)

data class ScriptLine(val speaker: String, val text: String)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.60f
        const val YELLOW_THRESHOLD = 0.20f
        const val IMPROVE_EPSILON = 0.03f
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()

    private var scriptLines: List<ScriptLine> = emptyList()
    private var fullScriptText: String = ""
    private var enableZoom = true
    private var enableAudioBoost = true

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null
    private val textRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    
    // 【大模型保留】Gemma 2B
    private var llmInference: LlmInference? = null
    private var isLlmReady = false

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                initASR()
                initLLM()
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            }
        }
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        for (file in listOf("model.int8.onnx", "tokens.txt", "gemma-2b-it-gpu-int4.bin")) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try { assets.open("models/$file").use { input -> FileOutputStream(outFile).use { output -> input.copyTo(output) } } } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    // 【大模型初始化】
    private fun initLLM() {
        try {
            val modelFile = File(modelDir, "gemma-2b-it-gpu-int4.bin")
            if (modelFile.exists()) {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath)
                    .setMaxTokens(512)
                    .build()
                llmInference = LlmInference.createFromOptions(context, options)
                isLlmReady = true
            }
        } catch (e: Throwable) { isLlmReady = false }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach {
                    if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_") || it.name.startsWith("ocr_") || it.name.startsWith("asr_")) it.delete()
                }
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) { }
        }
    }

    fun resetMatches() { allMatches.clear(); scriptLines = emptyList(); fullScriptText = "" }

    private fun cleanAndFilterText(text: String): String {
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
    }

    private fun parseScriptToSentences(raw: String) {
        fullScriptText = raw
        val lines = mutableListOf<ScriptLine>()
        val bracketRegex = Regex("""^\s*[【\[]([^】\]\s]{1,6})[】\]]\s*(.+)$""")
        val colonRegex = Regex("""^\s*([\u4e00-\u9fa5A-Za-z]{1,6})\s*[:：]\s*(.+)$""")
        
        raw.lines().forEach { rawLine ->
            var line = rawLine.trim()
            if (line.isEmpty()) return@forEach
            
            var speaker = ""
            val bs = bracketRegex.find(line)
            if (bs != null) {
                speaker = bs.groupValues[1].trim()
                line = bs.groupValues[2]
            } else {
                val cs = colonRegex.find(line)
                if (cs != null) {
                    speaker = cs.groupValues[1].trim()
                    line = cs.groupValues[2]
                }
            }
            
            val parts = line.split(Regex("[。！？!?；;\\n]"))
            for (p in parts) {
                val clean = cleanAndFilterText(p)
                if (clean.isNotEmpty()) lines.add(ScriptLine(speaker, clean))
            }
        }
        scriptLines = lines
    }

    private fun autoDetectAndOcr(frameFile: File): String {
        val bitmap = BitmapFactory.decodeFile(frameFile.absolutePath) ?: return ""
        val imgW = bitmap.width
        val imgH = bitmap.height
        
        val topArr = floatArrayOf(0.0f, 0.35f, 0.65f)
        val botArr = floatArrayOf(0.35f, 0.70f, 1.0f)
        
        val allResults = mutableListOf<String>()
        for (i in 0..2) {
            val startPct = topArr[i]
            val endPct = botArr[i]
            
            val yStart = (imgH * startPct).toInt()
            val yEnd = (imgH * endPct).toInt()
            val cropH = yEnd - yStart
            if (cropH <= 10) continue
            val validRects = detectSubtitleBands(bitmap, yStart, cropH)
            for (rect in validRects) {
                val text = ocrWithDynamicScale(bitmap, rect)
                val clean = cleanAndFilterText(text)
                if (clean.isNotEmpty() && !allResults.contains(clean)) allResults.add(clean)
            }
        }
        bitmap.recycle()
        return allResults.joinToString("")
    }

    private fun detectSubtitleBands(bmp: Bitmap, zoneYStart: Int, zoneH: Int): List<Rect> {
        val rects = mutableListOf<Rect>()
        val w = bmp.width
        val sliceHeight = 10
        var currentBandStart = -1
        for (y in 0 until zoneH step sliceHeight) {
            var brightnessSum = 0L; var highPixelCount = 0
            for (x in 0 until w step 5) {
                val pixel = bmp.getPixel(x, zoneYStart + y)
                val r = (pixel shr 16 and 0xff); val g = (pixel shr 8 and 0xff); val b = (pixel and 0xff)
                val brightness = (r + g + b) / 3
                brightnessSum += brightness
                if (brightness > 200) highPixelCount++
            }
            val avgBrightness = brightnessSum / (w / 5)
            val highPixelRatio = highPixelCount.toFloat() / (w / 5)
            val isSubtitleRow = (avgBrightness < 180 && highPixelRatio > 0.02f) || (highPixelRatio > 0.05f)
            if (isSubtitleRow) { if (currentBandStart == -1) currentBandStart = y }
            else {
                if (currentBandStart != -1) {
                    val bandEnd = y
                    val realYStart = (zoneYStart + currentBandStart - 10).coerceAtLeast(0)
                    val realYEnd = (zoneYStart + bandEnd + 10).coerceAtMost(bmp.height)
                    if (realYEnd - realYStart > 15) rects.add(Rect(0, realYStart, w, realYEnd))
                    currentBandStart = -1
                }
            }
        }
        if (currentBandStart != -1) {
            val realYStart = (zoneYStart + currentBandStart - 10).coerceAtLeast(0)
            val realYEnd = (zoneYStart + zoneH + 10).coerceAtMost(bmp.height)
            if (realYEnd - realYStart > 15) rects.add(Rect(0, realYStart, w, realYEnd))
        }
        return rects
    }

    private fun ocrWithDynamicScale(fullBmp: Bitmap, rect: Rect): String {
        try {
            val crop = Bitmap.createBitmap(fullBmp, rect.left, rect.top, rect.width(), rect.height())
            val cropH = crop.height
            var scale = 1
            if (cropH < 80) scale = (80f / cropH).toInt().coerceIn(2, 4)
            val finalBmp = if (scale > 1) {
                val scaled = Bitmap.createScaledBitmap(crop, crop.width * scale, cropH * scale, false)
                if (scaled != crop) crop.recycle()
                scaled
            } else crop
            val image = InputImage.fromBitmap(finalBmp, 0)
            val visionText = Tasks.await(textRecognizer.process(image))
            val result = visionText.textBlocks.flatMap { it.lines }.joinToString("") { it.text }
            if (finalBmp != crop && !finalBmp.isRecycled) finalBmp.recycle()
            return result
        } catch (e: Throwable) { return "" }
    }

    // 最原始的顺序调用，绝不使用高阶数据类
    private fun extractAllData(videoFile: File): String {
        val tempDir = File(workDir, "ocr_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        val framesTextList = mutableListOf<List<String>>()
        var firstHash = ""
        var lastHash = ""
        var durationSec = 0f
        try {
            val probe = FFmpegKit.execute("-i \"${videoFile.absolutePath}\"")
            val probeOut = probe.output ?: ""
            Regex("Duration: (\\d+):(\\d+):(\\d+\\.\\d+)").find(probeOut)?.let {
                durationSec = it.groupValues[1].toFloat() * 3600 + it.groupValues[2].toFloat() * 60 + it.groupValues[3].toFloat()
            }
            val session = FFmpegKit.execute("-y -i \"${videoFile.absolutePath}\" -vf fps=1 -q:v 2 \"${tempDir.absolutePath}/frame_%04d.jpg\"")
            if (ReturnCode.isSuccess(session.returnCode)) {
                val frames = tempDir.listFiles()?.sortedBy { it.name } ?: emptyList()
                var processed = 0
                for ((fi, frame) in frames.withIndex()) {
                    val fullBitmap = BitmapFactory.decodeFile(frame.absolutePath) ?: continue
                    val resized = Bitmap.createScaledBitmap(fullBitmap, 8, 8, true)
                    val pixels = IntArray(64)
                    resized.getPixels(pixels, 0, 8, 0, 0, 8, 8)
                    var avg = 0
                    for (p in pixels) {
                        avg = avg + (((p shr 16 and 0xff) + (p shr 8 and 0xff) + (p and 0xff)) / 3)
                    }
                    avg = avg / 64
                    val sb = StringBuilder()
                    for (p in pixels) {
                        val g = ((p shr 16 and 0xff) + (p shr 8 and 0xff) + (p and 0xff)) / 3
                        if (g >= avg) {
                            sb.append("1")
                        } else {
                            sb.append("0")
                        }
                    }
                    if (resized != fullBitmap) resized.recycle()
                    if (fi == 0) firstHash = sb.toString()
                    if (fi == frames.size - 1) lastHash = sb.toString()
                    
                    val subtitleText = try { autoDetectAndOcr(frame) } catch (e: Throwable) { "" }
                    val currentFrameTexts = mutableListOf<String>()
                    val cleanText = cleanAndFilterText(subtitleText)
                    if (cleanText.length >= 2) {
                        currentFrameTexts.add(cleanText)
                    }
                    framesTextList.add(currentFrameTexts)
                    if (++processed % 20 == 0) System.gc()
                }
                val textFreq = mutableMapOf<String, Int>()
                framesTextList.forEach { ft -> ft.distinct().forEach { t -> textFreq[t] = (textFreq[t] ?: 0) + 1 } }
                val finalValidTexts = mutableListOf<String>()
                for ((text, freq) in textFreq) {
                    if (freq < frames.size * 0.3) {
                        finalValidTexts.add(text)
                    }
                }
                val finalText = finalValidTexts.distinct().joinToString("").trim()
                
                return "$finalText###$firstHash###$lastHash###$durationSec"
            }
        } catch (e: Throwable) {
        } finally {
            tempDir.listFiles()?.forEach { it.delete() }
            tempDir.delete()
        }
        return "######0"
    }

    private fun extractFullAsr(videoFile: File, durationSec: Float): String {
        val recognizer = asrRecognizer ?: return ""
        if (durationSec <= 0f) return ""
        val wavFile = File(workDir, "asr_${System.currentTimeMillis()}.wav")
        try {
            val audioFilter = if (enableAudioBoost) {
                listOf("highpass=f=180", "lowpass=f=3600", "afftdn=nf=-25",
                    "acompressor=threshold=-20dB:ratio=3:attack=20:release=200",
                    "loudnorm=I=-16:LRA=11:TP=-1.5").joinToString(",")
            } else { "highpass=f=200,lowpass=f=3400,volume=1.8" }
            
            val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"$audioFilter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
            if (!ReturnCode.isSuccess(session.returnCode) || !wavFile.exists()) return ""
            
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get().toFloat() / 32768.0f }

            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000)
            recognizer.decode(stream)
            val result = recognizer.getResult(stream)
            stream.release()
            
            return result.text ?: ""
        } catch (e: Throwable) { return "" } finally { if (wavFile.exists()) wavFile.delete() }
    }

    private fun findSentenceIndex(text: String, hintIdx: Int, isOcr: Boolean): Int {
        if (text.isEmpty() || scriptLines.isEmpty()) return hintIdx
        
        var bestIdx = -1
        var maxScore = 0f
        
        val startSearch = maxOf(0, hintIdx - 2)
        val endSearch = minOf(scriptLines.size, hintIdx + 8)
        
        for (i in startSearch until endSearch) {
            val line = scriptLines[i]
            var score = 0f
            
            if (text.contains(line.text) && line.text.length > 2) {
                score = 1.0f
            } else if (line.text.contains(text) && text.length > 2) {
                score = 1.0f
            } else {
                val lcs = lcsLength(text, line.text)
                val maxLen = maxOf(text.length, line.text.length)
                score = lcs.toFloat() / maxLen.toFloat()
            }
            
            if (isOcr && score < 0.6f) {
                score = score * 0.8f
            }
            if (!isOcr && score < 0.5f) {
                score = score * 0.9f
            }
            
            val distancePenalty = if (i >= hintIdx) (i - hintIdx) * 0.02f else (hintIdx - i) * 0.05f
            val finalScore = score - distancePenalty
            
            if (finalScore > maxScore) {
                maxScore = finalScore
                bestIdx = i
            }
        }
        
        if (bestIdx != -1) {
            return bestIdx
        }
        return hintIdx
    }

    // 【大模型仲裁辅助】
    private suspend fun llmArbitrate(ocr: String, asr: String, candidates: List<ScriptLine>, prevCtx: String, nextCtx: String): Int {
        val llm = llmInference ?: return -1
        if (candidates.isEmpty()) return -1
        return withContext(Dispatchers.Default) {
            try {
                val sb = StringBuilder()
                for (i in candidates.indices) {
                    sb.append(i + 1).append(". ").append(candidates[i].text).append("\n")
                }
                val optionsText = sb.toString()
                
                val prompt = "你是影视台词大师。当前画面字幕:[$ocr] 语音台词:[$asr]。上下文前:[$prevCtx] 后:[$nextCtx]。\n请从以下候选剧本中选出最匹配的编号(1-${candidates.size})，只输出数字：\n$optionsText"
                val response = llm.generateResponse(prompt)
                val match = Regex("[1-9]").find(response)
                if (match != null) {
                    val idx = match.value.toInt() - 1
                    if (idx in candidates.indices) idx else -1
                } else -1
            } catch (e: Throwable) { -1 }
        }
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) dp[cur][j] = if (s1[i - 1] == s2[j - 1]) dp[prev][j - 1] + 1 else maxOf(dp[prev][j], dp[cur][j - 1])
        }
        return dp[m % 2][n]
    }

    private fun naturalCompare(a: String, b: String): Int {
        val regex = Regex("(\\d+)|(\\D+)")
        val aParts = regex.findAll(a).map { it.value }.toList()
        val bParts = regex.findAll(b).map { it.value }.toList()
        for (i in 0 until minOf(aParts.size, bParts.size)) {
            val p1 = aParts[i]; val p2 = bParts[i]
            val isNum1 = p1.all { it.isDigit() }; val isNum2 = p2.all { it.isDigit() }
            if (isNum1 && isNum2) { val cmp = (p1.toLongOrNull() ?: 0L).compareTo(p2.toLongOrNull() ?: 0L); if (cmp != 0) return cmp }
            else { val cmp = p1.compareTo(p2); if (cmp != 0) return cmp }
        }
        return aParts.size - bParts.size
    }

    suspend fun initialMatch(script: String, forceAI: Boolean, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sortedClips = uploadedClips.toList().sortedWith { o1, o2 -> naturalCompare(o1, o2) }
            if (sortedClips.isEmpty()) throw Exception("没有找到视频文件")
            parseScriptToSentences(script)
            allMatches.clear()
            val totalClips = sortedClips.size

            if (scriptLines.isEmpty()) {
                for ((index, clip) in sortedClips.withIndex()) {
                    allMatches.add(ClipMatch(index, clip, "【极速直拼】", "", "【直接拼接】", index, 1.0f, true))
                }
                withContext(Dispatchers.Main) { onSuccess() }; return
            }

            val ocrResults = mutableListOf<String>()
            val asrResults = mutableListOf<String>()
            val hashResults = mutableListOf<String>()
            val durationResults = mutableListOf<Float>()
            
            for ((index, clip) in sortedClips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / totalClips * 100).toInt(), "采集信号 ${index + 1}/${totalClips}: ${clip.take(15)}")
                }
                val videoFile = File(uploadDir, clip)
                val combinedData = withContext(Dispatchers.IO) { extractAllData(videoFile) }
                
                val parts = combinedData.split("###")
                val ocrText = if (parts.size > 0) parts[0] else ""
                val firstHash = if (parts.size > 1) parts[1] else ""
                val lastHash = if (parts.size > 2) parts[2] else ""
                val durationSec = if (parts.size > 3) parts[3].toFloatOrNull() ?: 0f else 0f
                
                val asrText = withContext(Dispatchers.IO) { extractFullAsr(videoFile, durationSec) }
                
                ocrResults.add(ocrText)
                asrResults.add(asrText)
                hashResults.add("$firstHash###$lastHash")
                durationResults.add(durationSec)
                delay(5)
            }

            var currentScriptPos = 0
            for ((index, clip) in sortedClips.withIndex()) {
                val firstHash = hashResults[index].split("###").getOrNull(0) ?: ""
                val lastHash = hashResults[index].split("###").getOrNull(1) ?: ""
                val durationSec = durationResults[index]
                
                val cleanOcr = cleanAndFilterText(ocrResults[index])
                val cleanAsr = cleanAndFilterText(asrResults[index])

                val ocrIdx = findSentenceIndex(cleanOcr, currentScriptPos, true)
                val asrIdx = findSentenceIndex(cleanAsr, currentScriptPos, false)
                
                var finalIdx = currentScriptPos
                var finalScore = 0f

                if (abs(ocrIdx - asrIdx) <= 1 && cleanOcr.isNotEmpty() && cleanAsr.isNotEmpty()) {
                    finalIdx = minOf(ocrIdx, asrIdx)
                    finalScore = 1.0f
                } else if (cleanOcr.isNotEmpty() && cleanAsr.isEmpty()) {
                    finalIdx = ocrIdx; finalScore = 0.8f
                } else if (cleanAsr.isNotEmpty() && cleanOcr.isEmpty()) {
                    finalIdx = asrIdx; finalScore = 0.8f
                } else {
                    finalIdx = minOf(ocrIdx, asrIdx); finalScore = 0.5f
                }

                val matchedSentence = if (finalIdx in scriptLines.indices) scriptLines[finalIdx].text else ""

                allMatches.add(ClipMatch(
                    index, clip,
                    buildDisplayText(cleanOcr, cleanAsr),
                    if (cleanOcr.isNotBlank()) cleanOcr else cleanAsr,
                    matchedSentence, finalIdx, finalScore, false,
                    cleanOcr, cleanAsr,
                    firstHash, firstHash, lastHash,
                    durationSec
                ))
                
                currentScriptPos = finalIdx + 1 
            }
            
            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    private fun buildDisplayText(ocr: String, asr: String): String {
        val a = if (ocr.isNotBlank()) "【画面】${ocr.take(30)}" else ""
        val b = if (asr.isNotBlank()) "【语音】${asr.take(30)}" else ""
        return if (a.isBlank() && b.isBlank()) "无有效台词" else "$a\n$b"
    }

    private fun visualPlacementForSilentClip(clip: ClipMatch): Int {
        var prevAnchor: ClipMatch? = null
        var nextAnchor: ClipMatch? = null
        val idx = allMatches.indexOf(clip)
        if (idx < 0) return clip.coord
        
        for (i in idx - 1 downTo 0) {
            if (allMatches[i].locked || allMatches[i].score >= GREEN_THRESHOLD) {
                if (allMatches[i].rawOcr.isNotBlank() || allMatches[i].rawAsr.isNotBlank()) {
                    prevAnchor = allMatches[i]; break
                }
            }
        }
        for (i in idx + 1 until allMatches.size) {
            if (allMatches[i].locked || allMatches[i].score >= GREEN_THRESHOLD) {
                if (allMatches[i].rawOcr.isNotBlank() || allMatches[i].rawAsr.isNotBlank()) {
                    nextAnchor = allMatches[i]; break
                }
            }
        }
        
        if (prevAnchor == null && nextAnchor == null) return clip.coord
        
        var scoreAfterPrev = 0f
        if (prevAnchor != null && clip.firstFrameHash.length == 64) {
            scoreAfterPrev = adjacencyScore(prevAnchor.lastFrameHash, clip.firstFrameHash)
        }
        
        var scoreBeforeNext = 0f
        if (nextAnchor != null && clip.lastFrameHash.length == 64) {
            scoreBeforeNext = adjacencyScore(clip.lastFrameHash, nextAnchor.firstFrameHash)
        }
        
        var finalPos = clip.coord
        if (scoreAfterPrev > scoreBeforeNext + 0.15f) {
            if (prevAnchor != null) finalPos = prevAnchor.coord + 1
        } else if (scoreBeforeNext > scoreAfterPrev + 0.15f) {
            if (nextAnchor != null) finalPos = nextAnchor.coord
        }
        return finalPos
    }

    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptLines.isEmpty()) return@withContext CalibrateResult(0, 0, 0)
        var improved = 0

        for (i in allMatches.indices) {
            val m = allMatches[i]
            if (m.locked) continue
            
            if (m.rawOcr.isBlank() && m.rawAsr.isBlank()) {
                val newCoord = visualPlacementForSilentClip(m)
                if (newCoord != m.coord) {
                    m.coord = newCoord
                    m.score = 0.85f
                    improved++
                }
                continue
            }
            
            var bestOcrIdx = m.coord
            var ocrScore = 0f
            var bestAsrIdx = m.coord
            var asrScore = 0f
            
            for (j in scriptLines.indices) {
                val line = scriptLines[j]
                var oScore = if (m.rawOcr.isNotBlank()) {
                    if (m.rawOcr.contains(line.text) || line.text.contains(m.rawOcr)) 1.0f 
                    else lcsLength(m.rawOcr, line.text).toFloat() / maxOf(m.rawOcr.length, line.text.length).toFloat()
                } else 0f
                
                var aScore = if (m.rawAsr.isNotBlank()) {
                    if (m.rawAsr.contains(line.text) || line.text.contains(m.rawAsr)) 1.0f 
                    else lcsLength(m.rawAsr, line.text).toFloat() / maxOf(m.rawAsr.length, line.text.length).toFloat()
                } else 0f

                if (oScore > ocrScore) { ocrScore = oScore; bestOcrIdx = j }
                if (aScore > asrScore) { asrScore = aScore; bestAsrIdx = j }
            }
            
            var finalIdx = m.coord
            var finalScore = 0f
            
            if (ocrScore > 0.4f && asrScore > 0.4f && abs(bestOcrIdx - bestAsrIdx) <= 1) {
                finalIdx = minOf(bestOcrIdx, bestAsrIdx); finalScore = 1.0f 
            } else if (ocrScore > 0.5f && asrScore < 0.2f) {
                finalIdx = bestOcrIdx; finalScore = ocrScore
            } else if (asrScore > 0.5f && ocrScore < 0.2f) {
                finalIdx = bestAsrIdx; finalScore = asrScore
            } else {
                if (ocrScore > asrScore) { finalIdx = bestOcrIdx; finalScore = ocrScore }
                else { finalIdx = bestAsrIdx; finalScore = asrScore }
            }
            
            if (finalScore < 0.8f && isLlmReady) {
                val startC = maxOf(0, bestOcrIdx - 2)
                val endC = minOf(scriptLines.size - 1, bestOcrIdx + 3)
                val candidates = mutableListOf<ScriptLine>()
                for (k in startC..endC) candidates.add(scriptLines[k])
                
                val prevCtx = if (bestOcrIdx > 0) scriptLines[bestOcrIdx - 1].text else ""
                val nextCtx = if (bestOcrIdx < scriptLines.size - 1) scriptLines[bestOcrIdx + 1].text else ""
                
                val llmChoice = llmArbitrate(m.rawOcr, m.rawAsr, candidates, prevCtx, nextCtx)
                if (llmChoice != -1) {
                    finalIdx = startC + llmChoice
                    finalScore = 1.0f
                }
            }
            
            val matchedSentence = if (finalIdx in scriptLines.indices) scriptLines[finalIdx].text else ""
            
            if (finalScore > m.score + IMPROVE_EPSILON || (finalScore > 0.8f && finalIdx != m.coord)) {
                m.coord = finalIdx
                m.score = finalScore
                m.scriptText = matchedSentence
                improved++
            }
        }

        val sortedByScore = allMatches.indices.sortedByDescending { allMatches[it].score }
        val usedCoords = mutableSetOf<Int>()
        for (idx in sortedByScore) {
            val m = allMatches[idx]
            if (m.locked || m.score < YELLOW_THRESHOLD) continue
            if (usedCoords.contains(m.coord)) {
                m.score = m.score * 0.5f
            } else {
                usedCoords.add(m.coord)
            }
        }
        
        for (i in 1 until allMatches.size) {
            if (allMatches[i].locked || allMatches[i - 1].locked) continue
            if (allMatches[i].coord < allMatches[i - 1].coord) {
                allMatches[i].score = minOf(allMatches[i].score, 0.55f)
            }
        }

        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
            allMatches[i].locked = true
            count++
        }
        return count
    }

    fun forceVisualRepairRedItems(): Int {
        return 0
    }

    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) if (allMatches[i].locked) {
            allMatches[i].locked = false
            count++
        }
        return count
    }

    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index].locked = !allMatches[index].locked
        return allMatches[index].locked
    }

    fun moveUp(index: Int) {
        if (index > 0 && index < allMatches.size) { val item = allMatches.removeAt(index); allMatches.add(index - 1, item) }
    }

    fun moveDown(index: Int) {
        if (index >= 0 && index < allMatches.size - 1) { val item = allMatches.removeAt(index); allMatches.add(index + 1, item) }
    }

    suspend fun recalculateMatchAt(index: Int) {
        if (index !in allMatches.indices) return
        val m = allMatches[index]
        if (m.locked) return

        if (m.rawOcr.isBlank() && m.rawAsr.isBlank()) {
            var prevAdj = 0f; var nextAdj = 0f
            if (index > 0 && m.firstFrameHash.length == 64 && allMatches[index - 1].lastFrameHash.length == 64)
                prevAdj = adjacencyScore(allMatches[index - 1].lastFrameHash, m.firstFrameHash)
            if (index < allMatches.size - 1 && m.lastFrameHash.length == 64 && allMatches[index + 1].firstFrameHash.length == 64)
                nextAdj = adjacencyScore(m.lastFrameHash, allMatches[index + 1].firstFrameHash)
            val avgAdj = (prevAdj + nextAdj) / 2f
            m.score = if (avgAdj > 0.5f) 0.85f else 0.3f
            return
        }

        val ocrIdx = findSentenceIndex(m.rawOcr, m.coord, true)
        val asrIdx = findSentenceIndex(m.rawAsr, m.coord, false)
        
        var finalScore = 0f
        var finalIdx = m.coord
        
        if (abs(ocrIdx - asrIdx) <= 1 && m.rawOcr.isNotEmpty() && m.rawAsr.isNotEmpty()) {
            finalIdx = minOf(ocrIdx, asrIdx); finalScore = 1.0f
        } else if (m.rawOcr.isNotEmpty() && m.rawAsr.isEmpty()) {
            finalIdx = ocrIdx; finalScore = 0.8f
        } else if (m.rawAsr.isNotEmpty() && m.rawOcr.isEmpty()) {
            finalIdx = asrIdx; finalScore = 0.8f
        } else {
            finalIdx = minOf(ocrIdx, asrIdx); finalScore = 0.5f
        }
        
        val matchedSentence = if (finalIdx in scriptLines.indices) scriptLines[finalIdx].text else ""
        m.coord = finalIdx
        m.score = finalScore
        m.scriptText = matchedSentence
    }

    fun buildEpisodesJsonByUIOrder(): String {
        if (allMatches.isEmpty()) return "[]"
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "V174 完美版")
        val scenesArr = JsonArray(); val clipsArr = JsonArray()
        allMatches.forEachIndexed { idx, m ->
            scenesArr.add(JsonPrimitive("第 ${idx + 1} 段 · ${String.format("%.2f", m.score)}"))
            clipsArr.add(JsonPrimitive(m.clipName))
        }
        epObj.add("scenes", scenesArr); epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue
                withContext(Dispatchers.Main) { onProgress(10, "准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }
                withContext(Dispatchers.Main) { onProgress(40, "极速拼接尝试...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "重编码拼接...") }
                    session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${outFile.absolutePath}\"")
                    if (!ReturnCode.isSuccess(session.returnCode)) throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}