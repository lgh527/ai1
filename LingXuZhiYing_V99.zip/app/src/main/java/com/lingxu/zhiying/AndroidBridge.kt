package com.lingxu.zhiying

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.Collator
import java.util.Locale

data class ClipMatch(
    val id: Int,
    val clipName: String,
    val heardText: String,
    val heardClean: String,
    var scriptText: String,
    var coord: Int,
    var score: Float,
    var locked: Boolean = false
)

data class CalibrateResult(
    val improvedCount: Int,
    val stillRed: Int,
    val stillGreen: Int
)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.50f
        const val YELLOW_THRESHOLD = 0.25f
        const val IMPROVE_EPSILON = 0.01f
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()

    private var scriptClean: String = ""
    private var scriptFull: String = ""

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var tfliteInterpreter: Interpreter? = null
    private var asrRecognizer: OfflineRecognizer? = null
    private val vocabMap = mutableMapOf<String, Int>()

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                loadVocab()
                withContext(Dispatchers.Main) { initTFLite(); initASR(); _modelsReadyFlow.value = true }
            } catch (e: Throwable) { _modelsReadyFlow.value = false }
        }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach { if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_")) it.delete() }
                // 清理上传目录，防止同名覆盖
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) { }
        }
    }

    fun resetMatches() {
        allMatches.clear()
        scriptClean = ""
        scriptFull = ""
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        val files = listOf("model.int8.onnx", "tokens.txt", "minilm.tflite")
        for (file in files) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try {
                    val input = assets.open("models/$file")
                    val output = FileOutputStream(outFile)
                    input.copyTo(output); input.close(); output.close()
                } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun loadVocab() {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            if (!tokensFile.exists()) return
            tokensFile.forEachLine { line ->
                val parts = line.trim().split(" ")
                if (parts.size >= 2) vocabMap[parts[0]] = parts[1].toIntOrNull() ?: 0
            }
        } catch (e: Throwable) { }
    }

    private fun initTFLite() {
        try {
            val modelFile = File(modelDir, "minilm.tflite")
            if (!modelFile.exists()) return
            val modelBuffer = loadModelFile(modelFile)
            tfliteInterpreter = Interpreter(modelBuffer, Interpreter.Options().apply { setNumThreads(4) })
        } catch (e: Throwable) { }
    }

    private fun loadModelFile(file: File): MappedByteBuffer {
        val inputStream = FileInputStream(file)
        val channel = inputStream.channel
        return channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
    }

    private fun cleanAndFilterText(text: String): String {
        return text.replace(Regex("[^\\u4e00-\\u9fa5a-zA-Z0-9]"), "")
    }

    private fun lcsLength(s1: String, s2: String): Int {
        val m = s1.length; val n = s2.length
        if (m == 0 || n == 0) return 0
        val dp = Array(2) { IntArray(n + 1) }
        for (i in 1..m) {
            val cur = i % 2; val prev = (i - 1) % 2
            for (j in 1..n) {
                if (s1[i - 1] == s2[j - 1]) dp[cur][j] = dp[prev][j - 1] + 1
                else dp[cur][j] = maxOf(dp[prev][j], dp[cur][j - 1])
            }
        }
        return dp[m % 2][n]
    }

    data class PosScore(val pos: Int, val score: Float, val window: String)

    private fun findBestPositionInRange(heard: String, script: String, searchStart: Int, searchEnd: Int, isCalibration: Boolean = false): PosScore {
        val heardLen = heard.length
        if (heardLen == 0) return PosScore(searchStart, 0f, "")

        val windowSize = heardLen + 20
        var bestScore = -1f
        var bestPos = searchStart
        var bestWindow = ""

        var pos = searchStart
        val maxPos = minOf(searchEnd, script.length - windowSize)
        
        val step = if (isCalibration) 1 else 2
        
        while (pos <= maxPos) {
            val window = script.substring(pos, pos + windowSize)
            val lcs = lcsLength(heard, window)
            val score = lcs.toFloat() / heardLen 
            
            if (score > bestScore) {
                bestScore = score
                bestPos = pos
                bestWindow = window
            }
            pos += step
        }
        
        if (bestScore == -1f) {
            val actualWindow = script.substring(searchStart, minOf(searchStart + windowSize, script.length))
            bestScore = lcsLength(heard, actualWindow).toFloat() / heardLen
            bestPos = searchStart
            bestWindow = actualWindow
        }
        
        return PosScore(bestPos, bestScore, bestWindow)
    }

    // 【核心修复】纯数字自然排序引擎，彻底杜绝 10 排在 2 前面
    private fun naturalCompare(a: String, b: String): Int {
        val regex = Regex("(\\d+)|(\\D+)")
        val aParts = regex.findAll(a).map { it.value }.toList()
        val bParts = regex.findAll(b).map { it.value }.toList()
        val len = minOf(aParts.size, bParts.size)
        for (i in 0 until len) {
            val p1 = aParts[i]
            val p2 = bParts[i]
            val isNum1 = p1.all { it.isDigit() }
            val isNum2 = p2.all { it.isDigit() }
            if (isNum1 && isNum2) {
                val n1 = p1.toLongOrNull() ?: 0L
                val n2 = p2.toLongOrNull() ?: 0L
                val cmp = n1.compareTo(n2)
                if (cmp != 0) return cmp
            } else {
                val cmp = p1.compareTo(p2)
                if (cmp != 0) return cmp
            }
        }
        return aParts.size - bParts.size
    }

    private fun isFileNameSequential(files: List<String>): Boolean {
        var foundCount = 0
        for (f in files) {
            val nums = Regex("\\d+").findAll(f).map { it.value.toLongOrNull() ?: 0L }.toList()
            if (nums.isNotEmpty()) foundCount++
        }
        return foundCount >= files.size * 0.8
    }

    suspend fun initialMatch(script: String, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sortedClips = uploadedClips.toList().sortedWith { o1, o2 ->
                naturalCompare(o1, o2) // 使用纯数字自然排序
            }
            
            if (sortedClips.isEmpty()) throw Exception("没有找到视频文件")

            scriptFull = script
            scriptClean = cleanAndFilterText(script)
            if (scriptClean.isEmpty()) throw Exception("剧本内容为空")

            allMatches.clear()
            val totalClips = sortedClips.size

            val isDirectSequence = isFileNameSequential(sortedClips)

            var currentScriptPos = 0 

            for ((index, clip) in sortedClips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / totalClips * 100).toInt(), "扫描 ${index + 1}/${totalClips}: ${clip.take(15)}")
                }
                
                val remainClips = totalClips - index
                val remainLen = scriptClean.length - currentScriptPos
                val expectedLen = remainLen / remainClips

                if (isDirectSequence) {
                    val finalCoord = currentScriptPos
                    val actualEnd = minOf(finalCoord + expectedLen, scriptClean.length)
                    val finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, actualEnd) else ""
                    
                    allMatches.add(
                        ClipMatch(
                            id = index,
                            clipName = clip,
                            heardText = "【文件名序列直通】",
                            heardClean = "",
                            scriptText = finalWindow,
                            coord = finalCoord,
                            score = 0.8f,
                            locked = false
                        )
                    )
                    currentScriptPos = actualEnd
                    delay(5)
                    continue
                }

                val videoFile = File(uploadDir, clip)
                val wavFile = File(workDir, "temp_${System.currentTimeMillis()}.wav")
                
                val session = FFmpegKit.execute(
                    "-y -vn -i \"${videoFile.absolutePath}\" -t 30 -af \"highpass=f=200, lowpass=f=3400, volume=2.5\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\""
                )
                
                var text = ""
                if (ReturnCode.isSuccess(session.returnCode)) {
                    text = recognizeAudio(wavFile)
                    wavFile.delete()
                }
                val cleanText = cleanAndFilterText(text)

                var finalCoord = currentScriptPos
                var finalScore = 0f
                var finalWindow = ""

                val searchStart = currentScriptPos
                val searchEnd = minOf(scriptClean.length, currentScriptPos + expectedLen * 3)

                if (cleanText.length >= 2) {
                    val best = findBestPositionInRange(cleanText, scriptClean, searchStart, searchEnd, false)
                    
                    if (best.score >= 0.25f) {
                        finalCoord = best.pos
                        finalScore = best.score
                        finalWindow = best.window
                        currentScriptPos = finalCoord + (best.window.length / 2)
                    } else {
                        finalCoord = currentScriptPos
                        finalScore = 0f 
                        finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, minOf(finalCoord + cleanText.length + 30, scriptClean.length)) else ""
                        currentScriptPos = minOf(scriptClean.length, currentScriptPos + maxOf(expectedLen, 20))
                    }
                } else {
                    finalCoord = currentScriptPos
                    finalScore = 0f 
                    finalWindow = if (finalCoord < scriptClean.length) scriptClean.substring(finalCoord, minOf(finalCoord + 50, scriptClean.length)) else ""
                    currentScriptPos = minOf(scriptClean.length, currentScriptPos + maxOf(expectedLen, 20))
                }

                allMatches.add(
                    ClipMatch(
                        id = index,
                        clipName = clip,
                        heardText = text,
                        heardClean = cleanText,
                        scriptText = finalWindow,
                        coord = finalCoord,
                        score = finalScore,
                        locked = false
                    )
                )
                delay(5)
            }

            val finalSorted = allMatches.sortedBy { it.coord }
            allMatches.clear()
            allMatches.addAll(finalSorted)

            withContext(Dispatchers.Main) { onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    suspend fun smartCalibrateOnce(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptClean.isEmpty()) {
            return@withContext CalibrateResult(0, 0, 0)
        }

        var improved = 0
        val n = allMatches.size
        var i = 0

        while (i < n) {
            if (allMatches[i].locked) {
                i++
                continue
            }

            val rangeStart = i
            while (i < n && !allMatches[i].locked) {
                i++
            }
            val rangeEnd = i - 1

            var lowerBound = 0
            for (j in rangeStart - 1 downTo 0) {
                if (allMatches[j].locked) {
                    lowerBound = allMatches[j].coord + allMatches[j].scriptText.length
                    break
                }
            }

            var upperBound = scriptClean.length
            for (j in rangeEnd + 1 until n) {
                if (allMatches[j].locked) {
                    upperBound = allMatches[j].coord
                    break
                }
            }

            if (upperBound <= lowerBound) upperBound = lowerBound + 50

            for (idx in rangeStart..rangeEnd) {
                val m = allMatches[idx]
                
                if (m.heardClean.length >= 2) {
                    val best = findBestPositionInRange(m.heardClean, scriptClean, lowerBound, upperBound, true)
                    
                    if (best.score > m.score + IMPROVE_EPSILON && best.score >= 0.3f) {
                        allMatches[idx] = m.copy(
                            scriptText = best.window,
                            coord = best.pos,
                            score = best.score
                        )
                        improved++
                    }
                }
            }
        }

        val finalSorted = allMatches.sortedBy { it.coord }
        allMatches.clear()
        allMatches.addAll(finalSorted)

        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
                allMatches[i] = allMatches[i].copy(locked = true)
                count++
            }
        }
        return count
    }

    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) {
            if (allMatches[i].locked) {
                allMatches[i] = allMatches[i].copy(locked = false)
                count++
            }
        }
        return count
    }

    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index] = allMatches[index].copy(locked = !allMatches[index].locked)
        return allMatches[index].locked
    }

    fun buildEpisodesJson(): String {
        if (allMatches.isEmpty()) return "[]"
        val sorted = allMatches.sortedBy { it.coord }
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "AI 校准后对齐结果")
        val scenesArr = JsonArray()
        val clipsArr = JsonArray()
        sorted.forEachIndexed { idx, m ->
            scenesArr.add("第 ${idx + 1} 段 · 匹配度${String.format("%.2f", m.score)}")
            clipsArr.add(m.clipName)
        }
        epObj.add("scenes", scenesArr)
        epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }

    private fun recognizeAudio(wavFile: File): String {
        val recognizer = asrRecognizer ?: return ""
        return try {
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get() / 32768.0f }
            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000)
            recognizer.decode(stream)
            val result = recognizer.getResult(stream)
            stream.release()
            result.text
        } catch (e: Throwable) { "" }
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue

                withContext(Dispatchers.Main) { onProgress(10, "正在准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")

                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }

                withContext(Dispatchers.Main) { onProgress(40, "正在尝试极速原画质拼接...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")

                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "格式差异，启动 H.264 重编码拼接(较慢)...") }
                    session = FFmpegKit.execute(
                        "-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${outFile.absolutePath}\""
                    )
                    if (!ReturnCode.isSuccess(session.returnCode)) {
                        throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                    }
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) {
                onProgress(100, "渲染完成")
                onSuccess(lastOutputPath)
            }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}