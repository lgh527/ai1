package com.lingxu.zhiying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.google.android.gms.tasks.Tasks
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.k2fsa.sherpa.onnx.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class ClipMatch(
    var id: Int,
    var clipName: String,
    var heardText: String,
    var heardClean: String,
    var scriptText: String,
    var coord: Int,      
    var score: Float,    
    var locked: Boolean = false,
    var rawOcr: String = "",
    var rawAsr: String = "",
    var visualHash: String = "",
    var firstFrameHash: String = "",
    var lastFrameHash: String = "",
    var durationSec: Float = 0f
)

data class CalibrateResult(val improvedCount: Int, val stillRed: Int, val stillGreen: Int)
data class ScriptLine(val speaker: String, val text: String)

class AndroidBridge(private val context: Context, private val onToast: (String) -> Unit) {
    companion object {
        const val GREEN_THRESHOLD = 0.60f
        const val IMPROVE_EPSILON = 0.03f
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val workDir = context.filesDir
    val uploadDir = File(workDir, "uploads").apply { mkdirs() }
    private val modelDir = File(workDir, "models").apply { mkdirs() }

    val uploadedClips = mutableListOf<String>()
    val allMatches = mutableListOf<ClipMatch>()
    
    private var scriptLines: List<ScriptLine> = emptyList()
    private var fullScriptText: String = ""
    private var enableZoom = true
    private var enableAudioBoost = true

    private val _modelsReadyFlow = MutableStateFlow(false)
    val modelsReadyFlow = _modelsReadyFlow.asStateFlow()

    private var asrRecognizer: OfflineRecognizer? = null
    private val textRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    private var llmInference: LlmInference? = null
    private var isLlmReady = false

    private val pinyinMap = mapOf(
        '在' to "zai", '再' to "zai", '载' to "zai", '崽' to "zai",
        '的' to "de", '地' to "di", '得' to "de", '底' to "di",
        '做' to "zuo", '作' to "zuo", '坐' to "zuo", '座' to "zuo",
        '是' to "shi", '事' to "shi", '十' to "shi", '实' to "shi", '时' to "shi",
        '看' to "kan", '瞰' to "kan", '砍' to "kan",
        '向' to "xiang", '像' to "xiang", '象' to "xiang", '相' to "xiang",
        '真' to "zhen", '珍' to "zhen", '针' to "zhen",
        '打' to "da", '大' to "da", '达' to "da",
        '你' to "ni", '泥' to "ni", '尼' to "ni",
        '我' to "wo", '窝' to "wo",
        '他' to "ta", '她' to "ta", '它' to "ta",
        '一' to "yi", '已' to "yi", '以' to "yi", '易' to "yi",
        '不' to "bu", '步' to "bu", '部' to "bu",
        '爱' to "ai", '哎' to "ai", '唉' to "ai",
        '情' to "qing", '请' to "qing", '清' to "qing", '轻' to "qing",
        '心' to "xin", '新' to "xin", '辛' to "xin", '欣' to "xin",
        '想' to "xiang", '响' to "xiang", '享' to "xiang",
        '说' to "shuo", '硕' to "shuo",
        '话' to "hua", '画' to "hua", '花' to "hua"
    )

    init {
        scope.launch {
            try {
                copyAssetsToFiles()
                initASR()
                initLLM()
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { _modelsReadyFlow.value = true }
            }
        }
    }

    fun setEnhanceOptions(zoom: Boolean, audio: Boolean) {
        enableZoom = zoom
        enableAudioBoost = audio
    }

    private fun copyAssetsToFiles() {
        val assets = context.assets
        for (file in listOf("model.int8.onnx", "tokens.txt", "gemma-2b-it-gpu-int4.bin")) {
            val outFile = File(modelDir, file)
            if (!outFile.exists()) {
                try { assets.open("models/$file").use { input -> FileOutputStream(outFile).use { output -> input.copyTo(output) } } } catch (e: Throwable) { }
            }
        }
    }

    private fun initASR() {
        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    senseVoice = OfflineSenseVoiceModelConfig(
                        model = File(modelDir, "model.int8.onnx").absolutePath,
                        language = "auto", useInverseTextNormalization = true
                    ),
                    tokens = File(modelDir, "tokens.txt").absolutePath, numThreads = 4, debug = false
                )
            )
            asrRecognizer = OfflineRecognizer(config = config)
        } catch (e: Throwable) { }
    }

    private fun initLLM() {
        try {
            val modelFile = File(modelDir, "gemma-2b-it-gpu-int4.bin")
            if (modelFile.exists()) {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath)
                    .setMaxTokens(512)
                    .build()
                llmInference = LlmInference.createFromOptions(context, options)
                isLlmReady = true
            }
        } catch (e: Throwable) { isLlmReady = false }
    }

    fun cleanTempFiles() {
        scope.launch {
            try {
                workDir.listFiles()?.forEach {
                    if (it.name.startsWith("temp_") || it.name.startsWith("concat_list_") || it.name.startsWith("ocr_") || it.name.startsWith("asr_")) it.delete()
                }
                uploadDir.listFiles()?.forEach { it.delete() }
            } catch (e: Exception) { }
        }
    }

    fun resetMatches() { allMatches.clear(); scriptLines = emptyList(); fullScriptText = "" }

    private fun cleanAndFilterText(text: String): String {
        return text.replace(Regex("[^\\u4e00-\\u9fa5]"), "")
    }

    private fun parseScriptToSentences(raw: String) {
        fullScriptText = raw
        val lines = mutableListOf<ScriptLine>()
        val bracketRegex = Regex("""^\s*[【\[]([^】\]\s]{1,6})[】\]]\s*(.+)$""")
        val colonRegex = Regex("""^\s*([\u4e00-\u9fa5A-Za-z]{1,6})\s*[:：]\s*(.+)$""")
        raw.lines().forEach { rawLine ->
            var line = rawLine.trim()
            if (line.isEmpty()) return@forEach
            var speaker = ""
            val bs = bracketRegex.find(line)
            if (bs != null) {
                speaker = bs.groupValues[1].trim()
                line = bs.groupValues[2]
            } else {
                val cs = colonRegex.find(line)
                if (cs != null) {
                    speaker = cs.groupValues[1].trim()
                    line = cs.groupValues[2]
                }
            }
            val parts = line.split(Regex("[。！？!?；;\\n]"))
            for (p in parts) {
                val clean = cleanAndFilterText(p)
                if (clean.isNotEmpty()) lines.add(ScriptLine(speaker, clean))
            }
        }
        scriptLines = lines
    }

    private fun autoDetectAndOcr(frameFile: File): String {
        val bitmap = BitmapFactory.decodeFile(frameFile.absolutePath) ?: return ""
        val imgW = bitmap.width
        val imgH = bitmap.height
        val topArr = floatArrayOf(0.0f, 0.33f, 0.66f)
        val botArr = floatArrayOf(0.4f, 0.73f, 1.0f) 
        val allResults = mutableListOf<String>()
        for (i in 0..2) {
            val startPct = topArr[i]
            val endPct = botArr[i]
            val yStart = (imgH * startPct).toInt()
            val yEnd = (imgH * endPct).toInt()
            val cropH = yEnd - yStart
            if (cropH <= 10) continue
            val validRects = detectSubtitleBands(bitmap, yStart, cropH)
            for (rect in validRects) {
                val text = ocrWithDynamicScale(bitmap, rect)
                val clean = cleanAndFilterText(text)
                if (clean.isNotEmpty() && !allResults.contains(clean)) allResults.add(clean)
            }
        }
        bitmap.recycle()
        return allResults.joinToString("")
    }

    private fun detectSubtitleBands(bmp: Bitmap, zoneYStart: Int, zoneH: Int): List<Rect> {
        val rects = mutableListOf<Rect>()
        val w = bmp.width
        val sliceHeight = 10
        var currentBandStart = -1
        for (y in 0 until zoneH step sliceHeight) {
            var brightnessSum = 0L; var highPixelCount = 0
            for (x in 0 until w step 5) {
                val pixel = bmp.getPixel(x, zoneYStart + y)
                val r = (pixel shr 16 and 0xff); val g = (pixel shr 8 and 0xff); val b = (pixel and 0xff)
                val brightness = (r + g + b) / 3
                brightnessSum += brightness
                if (brightness > 200) highPixelCount++
            }
            val avgBrightness = brightnessSum / (w / 5)
            val highPixelRatio = highPixelCount.toFloat() / (w / 5)
            val isSubtitleRow = (avgBrightness < 180 && highPixelRatio > 0.02f) || (highPixelRatio > 0.05f)
            if (isSubtitleRow) { if (currentBandStart == -1) currentBandStart = y }
            else {
                if (currentBandStart != -1) {
                    val bandEnd = y
                    val realYStart = (zoneYStart + currentBandStart - 10).coerceAtLeast(0)
                    val realYEnd = (zoneYStart + bandEnd + 10).coerceAtMost(bmp.height)
                    if (realYEnd - realYStart > 15) rects.add(Rect(0, realYStart, w, realYEnd))
                    currentBandStart = -1
                }
            }
        }
        if (currentBandStart != -1) {
            val realYStart = (zoneYStart + currentBandStart - 10).coerceAtLeast(0)
            val realYEnd = (zoneYStart + zoneH + 10).coerceAtMost(bmp.height)
            if (realYEnd - realYStart > 15) rects.add(Rect(0, realYStart, w, realYEnd))
        }
        return rects
    }

    private fun ocrWithDynamicScale(fullBmp: Bitmap, rect: Rect): String {
        try {
            val crop = Bitmap.createBitmap(fullBmp, rect.left, rect.top, rect.width(), rect.height())
            val cropH = crop.height
            var scale = 1
            if (cropH < 80) scale = (80f / cropH).toInt().coerceIn(2, 4)
            val finalBmp = if (scale > 1) {
                val scaled = Bitmap.createScaledBitmap(crop, crop.width * scale, cropH * scale, false)
                if (scaled != crop) crop.recycle()
                scaled
            } else crop
            val image = InputImage.fromBitmap(finalBmp, 0)
            val visionText = Tasks.await(textRecognizer.process(image))
            val result = visionText.textBlocks.flatMap { it.lines }.joinToString("") { it.text }
            if (finalBmp != crop && !finalBmp.isRecycled) finalBmp.recycle()
            return result
        } catch (e: Throwable) { return "" }
    }

    private fun extractAllData(videoFile: File): String {
        val tempDir = File(workDir, "ocr_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        val framesTextList = mutableListOf<List<String>>()
        var firstHash = ""
        var lastHash = ""
        var durationSec = 0f
        try {
            val probe = FFmpegKit.execute("-i \"${videoFile.absolutePath}\"")
            val probeOut = probe.output ?: ""
            Regex("Duration: (\\d+):(\\d+):(\\d+\\.\\d+)").find(probeOut)?.let {
                durationSec = it.groupValues[1].toFloat() * 3600 + it.groupValues[2].toFloat() * 60 + it.groupValues[3].toFloat()
            }
            val session = FFmpegKit.execute("-y -i \"${videoFile.absolutePath}\" -vf fps=2 -q:v 2 \"${tempDir.absolutePath}/frame_%04d.jpg\"")
            if (ReturnCode.isSuccess(session.returnCode)) {
                val frames = tempDir.listFiles()?.sortedBy { it.name } ?: emptyList()
                var processed = 0
                for ((fi, frame) in frames.withIndex()) {
                    val fullBitmap = BitmapFactory.decodeFile(frame.absolutePath) ?: continue
                    val resized = Bitmap.createScaledBitmap(fullBitmap, 8, 8, true)
                    val pixels = IntArray(64)
                    resized.getPixels(pixels, 0, 8, 0, 0, 8, 8)
                    var avg = 0
                    for (p in pixels) {
                        avg = avg + (((p shr 16 and 0xff) + (p shr 8 and 0xff) + (p and 0xff)) / 3)
                    }
                    avg = avg / 64
                    val sb = StringBuilder()
                    for (p in pixels) {
                        val g = ((p shr 16 and 0xff) + (p shr 8 and 0xff) + (p and 0xff)) / 3
                        if (g >= avg) sb.append("1") else sb.append("0")
                    }
                    if (resized != fullBitmap) resized.recycle()
                    if (fi == 0) firstHash = sb.toString()
                    if (fi == frames.size - 1) lastHash = sb.toString()
                    
                    val subtitleText = try { autoDetectAndOcr(frame) } catch (e: Throwable) { "" }
                    val currentFrameTexts = mutableListOf<String>()
                    val cleanText = cleanAndFilterText(subtitleText)
                    if (cleanText.length >= 2) currentFrameTexts.add(cleanText)
                    framesTextList.add(currentFrameTexts)
                    if (++processed % 20 == 0) System.gc()
                }
                val validTexts = mutableListOf<String>()
                framesTextList.forEach { ft ->
                    for (t in ft) {
                        if (!validTexts.contains(t)) validTexts.add(t)
                    }
                }
                val finalText = validTexts.joinToString("")
                return "$finalText###$firstHash###$lastHash###$durationSec"
            }
        } catch (e: Throwable) {
        } finally {
            tempDir.listFiles()?.forEach { it.delete() }
            tempDir.delete()
        }
        return "######0"
    }

    private fun extractFullAsr(videoFile: File, durationSec: Float): String {
        val recognizer = asrRecognizer ?: return ""
        if (durationSec <= 0f) return ""
        val wavFile = File(workDir, "asr_${System.currentTimeMillis()}.wav")
        try {
            val audioFilter = if (enableAudioBoost) {
                listOf("highpass=f=180", "lowpass=f=3600", "afftdn=nf=-25",
                    "acompressor=threshold=-20dB:ratio=3:attack=20:release=200",
                    "loudnorm=I=-16:LRA=11:TP=-1.5").joinToString(",")
            } else { "highpass=f=200,lowpass=f=3400,volume=1.8" }
            
            val session = FFmpegKit.execute("-y -vn -i \"${videoFile.absolutePath}\" -af \"$audioFilter\" -ar 16000 -ac 1 -c:a pcm_s16le \"${wavFile.absolutePath}\"")
            if (!ReturnCode.isSuccess(session.returnCode) || !wavFile.exists()) return ""
            
            val bytes = wavFile.readBytes()
            if (bytes.size <= 44) return ""
            val shortBuffer = ByteBuffer.wrap(bytes, 44, bytes.size - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val audio = FloatArray(shortBuffer.remaining()) { shortBuffer.get().toFloat() / 32768.0f }

            val stream = recognizer.createStream()
            stream.acceptWaveform(audio, 16000)
            recognizer.decode(stream)
            val result = recognizer.getResult(stream)
            stream.release()
            
            return result.text ?: ""
        } catch (e: Throwable) { return "" } finally { if (wavFile.exists()) wavFile.delete() }
    }

    private fun getBigrams(str: String): Set<String> {
        val set = mutableSetOf<String>()
        for (i in 0 until str.length - 1) set.add(str.substring(i, i + 2))
        return set
    }

    private fun bigramSimilarity(s1: String, s2: String): Float {
        if (s1.length < 2 || s2.length < 2) return 0f
        val set1 = getBigrams(s1)
        val set2 = getBigrams(s2)
        if (set1.isEmpty() || set2.isEmpty()) return 0f
        var intersection = 0
        for (s in set1) if (set2.contains(s)) intersection++
        val union = set1.size + set2.size - intersection
        return intersection.toFloat() / union.toFloat()
    }

    private fun pinyinSimilarity(s1: String, s2: String): Float {
        if (s1.isEmpty() || s2.isEmpty()) return 0f
        var matchCount = 0
        val minLen = minOf(s1.length, s2.length)
        for (i in 0 until minLen) {
            val p1 = pinyinMap[s1[i]] ?: s1[i].toString()
            val p2 = pinyinMap[s2[i]] ?: s2[i].toString()
            val init1 = if (p1.isNotEmpty()) p1[0] else ' '
            val final1 = if (p1.length > 1) p1.substring(1) else ""
            val init2 = if (p2.isNotEmpty()) p2[0] else ' '
            val final2 = if (p2.length > 1) p2.substring(1) else ""
            if (p1 == p2) matchCount += 1.0f
            else if (init1 == init2 && init1 != ' ') matchCount += 0.5f
            else if (final1 == final2 && final1.isNotEmpty()) matchCount += 0.5f
        }
        return matchCount.toFloat() / maxOf(s1.length, s2.length)
    }

    private fun calcMatchScore(ocr: String, asr: String, lineText: String, durationSec: Float): Float {
        val cleanOcr = cleanAndFilterText(ocr)
        val cleanAsr = cleanAndFilterText(asr)
        val cleanLine = cleanAndFilterText(lineText)
        if (cleanLine.isEmpty()) return 0f

        var maxScore = 0f
        val asrWeight = if (cleanAsr.length > 3) 0.7f else 0.3f
        val ocrWeight = if (cleanOcr.length > 3) 0.5f else 0.2f

        if (cleanAsr.isNotEmpty()) {
            val biScore = bigramSimilarity(cleanAsr, cleanLine)
            val pyScore = pinyinSimilarity(cleanAsr, cleanLine)
            var score = maxOf(biScore, pyScore) * asrWeight + 0.25f
            if (durationSec > 0) {
                val expectedChars = durationSec * 3.5f
                val charDiff = abs(expectedChars - cleanLine.length)
                if (charDiff > expectedChars * 0.8f) score *= 0.5f
            }
            maxScore = maxOf(maxScore, score)
        }
        if (cleanOcr.isNotEmpty()) {
            val biScore = bigramSimilarity(cleanOcr, cleanLine)
            val pyScore = pinyinSimilarity(cleanOcr, cleanLine)
            var score = maxOf(biScore, pyScore) * ocrWeight + 0.15f
            maxScore = maxOf(maxScore, score)
        }
        if (cleanOcr.isNotEmpty() && cleanAsr.isNotEmpty()) {
            val combined = cleanOcr + cleanAsr
            val score = bigramSimilarity(combined, cleanLine) + 0.15f
            maxScore = maxOf(maxScore, score)
        }
        return maxScore.coerceIn(0f, 1f)
    }

    private fun naturalCompare(a: String, b: String): Int {
        val regex = Regex("(\\d+)|(\\D+)")
        val aParts = regex.findAll(a).map { it.value }.toList()
        val bParts = regex.findAll(b).map { it.value }.toList()
        for (i in 0 until minOf(aParts.size, bParts.size)) {
            val p1 = aParts[i]; val p2 = bParts[i]
            val isNum1 = p1.all { it.isDigit() }; val isNum2 = p2.all { it.isDigit() }
            if (isNum1 && isNum2) { val cmp = (p1.toLongOrNull() ?: 0L).compareTo(p2.toLongOrNull() ?: 0L); if (cmp != 0) return cmp }
            else { val cmp = p1.compareTo(p2); if (cmp != 0) return cmp }
        }
        return aParts.size - bParts.size
    }

    suspend fun initialMatch(script: String, forceAI: Boolean, onProgress: (Int, String) -> Unit, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            val sortedClips = uploadedClips.toList().sortedWith { o1, o2 -> naturalCompare(o1, o2) }
            if (sortedClips.isEmpty()) throw Exception("没有找到视频文件")
            parseScriptToSentences(script)
            allMatches.clear()
            val totalClips = sortedClips.size

            if (scriptLines.isEmpty()) {
                for ((index, clip) in sortedClips.withIndex()) {
                    allMatches.add(ClipMatch(index, clip, "【极速直拼】", "", "【直接拼接】", index, 1.0f, true))
                }
                withContext(Dispatchers.Main) { onSuccess() }; return
            }

            val clipFeatures = mutableListOf<Triple<String, String, String>>()
            val clipDurations = mutableListOf<Float>()
            for ((index, clip) in sortedClips.withIndex()) {
                withContext(Dispatchers.Main) {
                    onProgress(((index + 1).toFloat() / totalClips * 50).toInt(), "特征提取 ${index + 1}/${totalClips}: ${clip.take(15)}")
                }
                val videoFile = File(uploadDir, clip)
                val combinedData = withContext(Dispatchers.IO) { extractAllData(videoFile) }
                val parts = combinedData.split("###")
                val ocrText = if (parts.size > 0) parts[0] else ""
                val firstHash = if (parts.size > 1) parts[1] else ""
                val lastHash = if (parts.size > 2) parts[2] else ""
                val durationSec = if (parts.size > 3) parts[3].toFloatOrNull() ?: 0f else 0f
                val asrText = withContext(Dispatchers.IO) { extractFullAsr(videoFile, durationSec) }
                clipFeatures.add(Triple(cleanAndFilterText(ocrText), cleanAndFilterText(asrText), "$firstHash###$lastHash"))
                clipDurations.add(durationSec)
            }

            withContext(Dispatchers.Main) { onProgress(60, "智脑计算中：因果强制推演...") }
            val assignedCoords = IntArray(totalClips) { -1 }
            val assignedScores = FloatArray(totalClips) { 0f }

            val scoreMatrix = Array(totalClips) { FloatArray(scriptLines.size) }
            for (i in 0 until totalClips) {
                val (ocr, asr, _) = clipFeatures[i]
                for (j in scriptLines.indices) {
                    scoreMatrix[i][j] = calcMatchScore(ocr, asr, scriptLines[j].text, clipDurations[i])
                }
            }

            val dp = Array(totalClips) { FloatArray(scriptLines.size) { -99999f } }
            val path = Array(totalClips) { IntArray(scriptLines.size) { -1 } }
            for (j in scriptLines.indices) dp[0][j] = scoreMatrix[0][j]

            for (i in 1 until totalClips) {
                for (j in scriptLines.indices) {
                    val currentScore = scoreMatrix[i][j]
                    var maxPrev = -99999f
                    var bestPrevJ = -1
                    for (k in 0..j) { 
                        if (dp[i - 1][k] > maxPrev) {
                            maxPrev = dp[i - 1][k]
                            bestPrevJ = k
                        }
                    }
                    if (bestPrevJ != -1) {
                        val gap = j - bestPrevJ
                        val penalty = if (gap > 2) (gap - 2) * 0.2f else 0f
                        dp[i][j] = maxPrev + currentScore - penalty
                        path[i][j] = bestPrevJ
                    } else {
                        dp[i][j] = currentScore
                    }
                }
            }

            var maxTotalScore = -99999f
            var bestEndJ = -1
            for (j in scriptLines.indices) {
                if (dp[totalClips - 1][j] > maxTotalScore) {
                    maxTotalScore = dp[totalClips - 1][j]
                    bestEndJ = j
                }
            }

            if (bestEndJ != -1) {
                var currJ = bestEndJ
                for (i in totalClips - 1 downTo 0) {
                    assignedCoords[i] = currJ
                    assignedScores[i] = scoreMatrix[i][currJ]
                    currJ = if (i > 0) path[i][currJ] else -1
                    if (currJ == -1 && i > 0) currJ = maxOf(0, assignedCoords[i] - 1)
                }
            } else {
                for (i in 0 until totalClips) {
                    val fallbackIdx = minOf(i, scriptLines.size - 1)
                    assignedCoords[i] = fallbackIdx
                    assignedScores[i] = scoreMatrix[i][fallbackIdx]
                }
            }

            val resultMatches = mutableListOf<ClipMatch>()
            for (i in 0 until totalClips) {
                val (ocr, asr, hashStr) = clipFeatures[i]
                var coord = assignedCoords[i]
                var score = assignedScores[i]
                var finalScriptText = if (coord in scriptLines.indices) scriptLines[coord].text else ""

                if (isLlmReady && score in 0.2f..0.65f && scriptLines.isNotEmpty()) {
                    withContext(Dispatchers.Main) { onProgress(80, "大模型综合判断中 (片段 ${i+1})...") }
                    val startC = maxOf(0, coord - 3)
                    val endC = minOf(scriptLines.size - 1, coord + 3)
                    val candidates = mutableListOf<String>()
                    for (k in startC..endC) candidates.add("编号${k}: ${scriptLines[k].text}")
                    val prevCtx = if (coord > 1) scriptLines[coord - 2].text + scriptLines[coord - 1].text else "开头"
                    val nextCtx = if (coord < scriptLines.size - 2) scriptLines[coord + 1].text + scriptLines[coord + 2].text else "结尾"
                    val prompt = """
                        你是首席影视对轴导演。当前视频提取的台词画面是：[$ocr]，语音识别是：[$asr]。
                        这段视频所在的剧情段落，上文是：[$prevCtx]，下文是：[$nextCtx]。
                        请结合音形义，从以下候选剧本中，挑出最符合当前视频真实内容的一句。只输出“编号数字”：
                        ${candidates.joinToString("\n")}
                    """.trimIndent()
                    
                    try {
                        val llmResult = llmInference?.generateResponse(prompt) ?: ""
                        val chosenIdx = Regex("\\d+").find(llmResult)?.value?.toIntOrNull()
                        if (chosenIdx != null && chosenIdx in startC..endC) {
                            coord = chosenIdx
                            score = 0.98f
                            finalScriptText = scriptLines[coord].text
                        }
                    } catch (e: Throwable) {}
                }

                val hashParts = hashStr.split("###")
                val fHash = if (hashParts.isNotEmpty()) hashParts[0] else ""
                val lHash = if (hashParts.size > 1) hashParts[1] else ""
                val displayText = buildString {
                    if (ocr.isNotBlank()) append("【画面】").append(ocr).append("\n")
                    if (asr.isNotBlank()) append("【语音】").append(asr)
                }

                resultMatches.add(ClipMatch(
                    i, sortedClips[i],
                    displayText,
                    if (ocr.isNotBlank()) ocr else asr,
                    finalScriptText, coord, score, false,
                    ocr, asr,
                    fHash, fHash, lHash,
                    clipDurations[i]
                ))
            }

            resultMatches.sortWith(compareBy({ it.coord }, { -it.score }))
            allMatches.addAll(resultMatches)
            for (i in allMatches.indices) allMatches[i].id = i
            withContext(Dispatchers.Main) { onProgress(100, "智脑对齐完成"); onSuccess() }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }

    private fun hammingDistance(h1: String, h2: String): Int {
        if (h1.length != 64 || h2.length != 64) return 64
        var d = 0
        for (i in 0 until 64) if (h1[i] != h2[i]) d++
        return d
    }

    private fun adjacencyScore(prevLast: String, currFirst: String): Float {
        if (prevLast.length != 64 || currFirst.length != 64) return 0.5f
        return 1f - hammingDistance(prevLast, currFirst) / 64f
    }

    private fun visualPlacementForSilentClip(clip: ClipMatch): Int {
        var prevAnchor: ClipMatch? = null
        var nextAnchor: ClipMatch? = null
        val idx = allMatches.indexOf(clip)
        if (idx < 0) return clip.coord
        
        for (i in idx - 1 downTo 0) {
            if (allMatches[i].locked || allMatches[i].score >= GREEN_THRESHOLD) {
                if (allMatches[i].rawOcr.isNotBlank() || allMatches[i].rawAsr.isNotBlank()) {
                    prevAnchor = allMatches[i]; break
                }
            }
        }
        for (i in idx + 1 until allMatches.size) {
            if (allMatches[i].locked || allMatches[i].score >= GREEN_THRESHOLD) {
                if (allMatches[i].rawOcr.isNotBlank() || allMatches[i].rawAsr.isNotBlank()) {
                    nextAnchor = allMatches[i]; break
                }
            }
        }
        
        if (prevAnchor == null && nextAnchor == null) return clip.coord
        
        var scoreAfterPrev = 0f
        if (prevAnchor != null && clip.firstFrameHash.length == 64) {
            scoreAfterPrev = adjacencyScore(prevAnchor.lastFrameHash, clip.firstFrameHash)
        }
        var scoreBeforeNext = 0f
        if (nextAnchor != null && clip.lastFrameHash.length == 64) {
            scoreBeforeNext = adjacencyScore(clip.lastFrameHash, nextAnchor.firstFrameHash)
        }
        
        var finalPos = clip.coord
        if (scoreAfterPrev > scoreBeforeNext + 0.15f) {
            if (prevAnchor != null) finalPos = prevAnchor.coord + 1
        } else if (scoreBeforeNext > scoreAfterPrev + 0.15f) {
            if (nextAnchor != null) finalPos = nextAnchor.coord
        }
        return finalPos
    }

    suspend fun smartCalibrateFast(): CalibrateResult = withContext(Dispatchers.Default) {
        if (allMatches.isEmpty() || scriptLines.isEmpty()) return@withContext CalibrateResult(0, 0, 0)
        var improved = 0

        val anchors = allMatches.filter { it.locked || it.score >= GREEN_THRESHOLD }.sortedBy { it.coord }
        val anchorCoords = anchors.map { it.coord }.toSet()
        val problemClips = allMatches.filter { !it.locked && it.score < 0.99f }.toMutableList()
        val emptyCoords = scriptLines.indices.filter { it !in anchorCoords }.toMutableList()

        if (problemClips.isEmpty() || emptyCoords.isEmpty()) return@withContext CalibrateResult(0, 0, 0)

        val scoreMatrix = Array(problemClips.size) { FloatArray(emptyCoords.size) }
        for (i in problemClips.indices) {
            val m = problemClips[i]
            for (j in emptyCoords.indices) {
                var baseScore = calcMatchScore(m.rawOcr, m.rawAsr, scriptLines[emptyCoords[j]].text, m.durationSec)
                baseScore += (Math.random().toFloat() * 0.05f)
                scoreMatrix[i][j] = baseScore
            }
        }

        val dp = Array(problemClips.size) { FloatArray(emptyCoords.size) { -99999f } }
        val path = Array(problemClips.size) { IntArray(emptyCoords.size) { -1 } }
        for (j in emptyCoords.indices) dp[0][j] = scoreMatrix[0][j]

        for (i in 1 until problemClips.size) {
            for (j in emptyCoords.indices) {
                val currScore = scoreMatrix[i][j]
                var maxPrev = -99999f
                var bestK = -1
                for (k in 0..j) { 
                    if (dp[i - 1][k] > maxPrev) {
                        maxPrev = dp[i - 1][k]
                        bestK = k
                    }
                }
                if (bestK != -1) {
                    val gap = j - bestK
                    val penalty = if (gap > 1) (gap - 1) * 0.3f else 0f
                    dp[i][j] = maxPrev + currScore - penalty
                    path[i][j] = bestK
                } else {
                    dp[i][j] = currScore
                }
            }
        }

        var maxTotal = -99999f
        var bestEndJ = -1
        for (j in emptyCoords.indices) {
            if (dp[problemClips.size - 1][j] > maxTotal) {
                maxTotal = dp[problemClips.size - 1][j]
                bestEndJ = j
            }
        }

        if (bestEndJ != -1) {
            var currJ = bestEndJ
            for (i in problemClips.size - 1 downTo 0) {
                val m = problemClips[i]
                val newCoord = emptyCoords[currJ]
                val newScore = scoreMatrix[i][currJ]
                if (m.coord != newCoord || newScore > m.score) {
                    m.coord = newCoord
                    m.score = newScore
                    m.scriptText = scriptLines[newCoord].text
                    improved++
                }
                currJ = if (i > 0) path[i][currJ] else -1
                if (currJ == -1 && i > 0) currJ = maxOf(0, currJ)
            }
        }

        for (m in allMatches) {
            if (!m.locked && m.rawOcr.isBlank() && m.rawAsr.isBlank()) {
                val newCoord = visualPlacementForSilentClip(m)
                if (newCoord != m.coord) {
                    m.coord = newCoord
                    m.score = 0.85f
                    improved++
                }
            }
        }

        allMatches.sortWith(compareBy({ it.coord }, { -it.score }))
        for (i in allMatches.indices) allMatches[i].id = i
        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    suspend fun smartCalibrateDeep(fastResult: CalibrateResult): CalibrateResult = withContext(Dispatchers.Default) {
        if (!isLlmReady) return@withContext fastResult
        if (allMatches.isEmpty() || scriptLines.isEmpty()) return@withContext fastResult
        var improved = 0

        val problemClips = allMatches.filter { !it.locked && it.score < GREEN_THRESHOLD }.toMutableList()
        if (problemClips.isEmpty()) return@withContext fastResult

        for (m in problemClips) {
            val startC = maxOf(0, m.coord - 4) 
            val endC = minOf(scriptLines.size - 1, m.coord + 4)
            val candidates = mutableListOf<String>()
            for (k in startC..endC) candidates.add("编号${k}: ${scriptLines[k].text}")
            val prevCtx = if (m.coord > 2) scriptLines[m.coord - 2].text + scriptLines[m.coord - 1].text else "开头"
            val nextCtx = if (m.coord < scriptLines.size - 2) scriptLines[m.coord + 1].text + scriptLines[m.coord + 2].text else "结尾"
            
            val prompt = """
                你是极度严苛的影视校对大师。当前视频画面：[$m.rawOcr]，语音：[$m.rawAsr]。
                基于上下文：上文[$prevCtx]，下文[$nextCtx]。
                请结合文字学（同音、形近）从下列候选剧本挑出最合理的一句，只输出数字编号：
                ${candidates.joinToString("\n")}
            """.trimIndent()
            
            try {
                val llmResult = llmInference?.generateResponse(prompt) ?: ""
                val chosen = Regex("\\d+").find(llmResult)?.value?.toIntOrNull()
                if (chosen != null && chosen in startC..endC) {
                    val conflict = allMatches.any { it !== m && it.coord == chosen && (it.locked || it.score >= GREEN_THRESHOLD) }
                    if (!conflict) {
                        m.coord = chosen
                        m.score = 0.95f
                        m.scriptText = scriptLines[chosen].text
                        improved++
                    }
                }
            } catch (e: Throwable) {}
        }

        allMatches.sortWith(compareBy({ it.coord }, { -it.score }))
        for (i in allMatches.indices) allMatches[i].id = i
        val green = allMatches.count { it.score >= GREEN_THRESHOLD }
        CalibrateResult(improved, allMatches.size - green, green)
    }

    fun lockGreenItems(): Int {
        var count = 0
        for (i in allMatches.indices) if (!allMatches[i].locked && allMatches[i].score >= GREEN_THRESHOLD) {
            allMatches[i].locked = true
            count++
        }
        return count
    }

    fun forceVisualRepairRedItems(): Int = 0

    fun unlockAll(): Int {
        var count = 0
        for (i in allMatches.indices) if (allMatches[i].locked) {
            allMatches[i].locked = false
            count++
        }
        return count
    }

    fun toggleLock(index: Int): Boolean {
        if (index !in allMatches.indices) return false
        allMatches[index].locked = !allMatches[index].locked
        return allMatches[index].locked
    }

    suspend fun smartMicroAdjustRipple(fromIndex: Int, toIndex: Int) {
        if (fromIndex !in allMatches.indices || toIndex !in allMatches.indices) return
        val fromItem = allMatches[fromIndex]
        val toItem = allMatches[toIndex]
        
        val tempCoord = fromItem.coord
        val tempScript = fromItem.scriptText
        fromItem.coord = toItem.coord
        fromItem.scriptText = toItem.scriptText
        fromItem.score = 0.99f
        toItem.coord = tempCoord
        toItem.scriptText = tempScript
        toItem.score = 0.99f
        
        allMatches[fromIndex] = toItem
        allMatches[toIndex] = fromItem
        
        allMatches.sortWith(compareBy({ it.coord }, { -it.score }))
        for (i in allMatches.indices) allMatches[i].id = i
        
        val newFromIndex = allMatches.indexOf(fromItem)
        val newToIndex = allMatches.indexOf(toItem)
        val centerIndex = (newFromIndex + newToIndex) / 2
        val startZone = maxOf(0, centerIndex - 3)
        val endZone = minOf(allMatches.size - 1, centerIndex + 3)
        val zoneClips = allMatches.subList(startZone, endZone + 1).toMutableList()

        var leftAnchorCoord = -1
        for (i in startZone - 1 downTo 0) {
            if (allMatches[i].locked || allMatches[i].score >= GREEN_THRESHOLD) {
                leftAnchorCoord = allMatches[i].coord
                break
            }
        }
        var rightAnchorCoord = scriptLines.size
        for (i in endZone + 1 until allMatches.size) {
            if (allMatches[i].locked || allMatches[i].score >= GREEN_THRESHOLD) {
                rightAnchorCoord = allMatches[i].coord
                break
            }
        }

        val availableCoords = mutableListOf<Int>()
        for (c in (leftAnchorCoord + 1) until rightAnchorCoord) {
            availableCoords.add(c)
        }
        if (availableCoords.isEmpty()) return

        val unpinnedClips = zoneClips.filter { it !== fromItem && it !== toItem }
        if (unpinnedClips.isEmpty() || unpinnedClips.size > availableCoords.size) return

        val localScoreMatrix = Array(unpinnedClips.size) { FloatArray(availableCoords.size) }
        for (i in unpinnedClips.indices) {
            val clip = unpinnedClips[i]
            for (j in availableCoords.indices) {
                localScoreMatrix[i][j] = calcMatchScore(clip.rawOcr, clip.rawAsr, scriptLines[availableCoords[j]].text, clip.durationSec)
            }
        }

        val localDp = Array(unpinnedClips.size) { FloatArray(availableCoords.size) { -99999f } }
        val localPath = Array(unpinnedClips.size) { IntArray(availableCoords.size) { -1 } }
        for (j in availableCoords.indices) localDp[0][j] = localScoreMatrix[0][j]

        for (i in 1 until unpinnedClips.size) {
            for (j in availableCoords.indices) {
                val currScore = localScoreMatrix[i][j]
                var maxPrev = -99999f
                var bestK = -1
                for (k in 0..j) { 
                    if (localDp[i - 1][k] > maxPrev) {
                        maxPrev = localDp[i - 1][k]
                        bestK = k
                    }
                }
                if (bestK != -1) {
                    val gap = j - bestK
                    val penalty = if (gap > 1) (gap - 1) * 0.3f else 0f
                    localDp[i][j] = maxPrev + currScore - penalty
                    localPath[i][j] = bestK
                } else {
                    localDp[i][j] = currScore
                }
            }
        }

        var maxTotal = -99999f
        var bestEndJ = -1
        for (j in availableCoords.indices) {
            if (localDp[unpinnedClips.size - 1][j] > maxTotal) {
                maxTotal = localDp[unpinnedClips.size - 1][j]
                bestEndJ = j
            }
        }

        if (bestEndJ != -1) {
            var currJ = bestEndJ
            for (i in unpinnedClips.size - 1 downTo 0) {
                val clip = unpinnedClips[i]
                clip.coord = availableCoords[currJ]
                clip.score = localScoreMatrix[i][currJ]
                clip.scriptText = scriptLines[clip.coord].text
                currJ = if (i > 0) localPath[i][currJ] else -1
                if (currJ == -1 && i > 0) currJ = maxOf(0, currJ)
            }
        }

        allMatches.sortWith(compareBy({ it.coord }, { -it.score }))
        for (i in allMatches.indices) allMatches[i].id = i
    }

    fun buildEpisodesJsonByUIOrder(): String {
        if (allMatches.isEmpty()) return "[]"
        val epObj = JsonObject()
        epObj.addProperty("episode_id", 1)
        epObj.addProperty("title", "完美版")
        val scenesArr = JsonArray(); val clipsArr = JsonArray()
        allMatches.forEachIndexed { idx, m ->
            scenesArr.add(JsonPrimitive("第 ${idx + 1} 段 · ${String.format("%.2f", m.score)}"))
            clipsArr.add(JsonPrimitive(m.clipName))
        }
        epObj.add("scenes", scenesArr); epObj.add("clips", clipsArr)
        val root = JsonArray(); root.add(epObj)
        return root.toString()
    }

    suspend fun stitchVideo(episodesJson: String, onProgress: (Int, String) -> Unit, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        try {
            val rootArr = JsonParser.parseString(episodesJson).asJsonArray
            var lastOutputPath = ""
            for (epIdx in 0 until rootArr.size()) {
                val epObj = rootArr.get(epIdx).asJsonObject
                val epId = epObj.get("episode_id").asInt
                val clipsArr = epObj.getAsJsonArray("clips")
                if (clipsArr.size() == 0) continue
                withContext(Dispatchers.Main) { onProgress(10, "准备素材...") }
                val listFile = File(workDir, "concat_list_${epId}_${System.currentTimeMillis()}.txt")
                val outFile = File(workDir, "lingxu_ep_${epId}_${System.currentTimeMillis()}.mp4")
                listFile.bufferedWriter().use { out ->
                    for (i in 0 until clipsArr.size()) {
                        val file = File(uploadDir, clipsArr.get(i).asString)
                        if (file.exists()) out.write("file '${file.absolutePath}'\n")
                    }
                }
                withContext(Dispatchers.Main) { onProgress(40, "极速拼接尝试...") }
                var session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c copy \"${outFile.absolutePath}\"")
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    withContext(Dispatchers.Main) { onProgress(60, "重编码拼接...") }
                    session = FFmpegKit.execute("-y -f concat -safe 0 -i \"${listFile.absolutePath}\" -c:v libx264 -crf 18 -preset veryfast -c:a aac -f mp4 \"${outFile.absolutePath}\"")
                    if (!ReturnCode.isSuccess(session.returnCode)) throw Exception("拼接失败: ${(session.output ?: "").takeLast(100)}")
                }
                listFile.delete()
                lastOutputPath = outFile.absolutePath
            }
            withContext(Dispatchers.Main) { onProgress(100, "完成"); onSuccess(lastOutputPath) }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { onError(e.message ?: "未知错误") }
        }
    }
}