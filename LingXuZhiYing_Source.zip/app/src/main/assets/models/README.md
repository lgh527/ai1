# 模型文件下载说明

要让 ASR 语音识别和 LLM 校对功能完全可用，需要把下面两个模型放到本目录。

## 1. SenseVoice ASR

需要两个文件：
- `model.int8.onnx`
- `tokens.txt`

来源（HuggingFace 镜像）：
https://hf-mirror.com/csukuangfj/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-2024-07-17/tree/main

## 2. Gemma 2B LLM

需要一个文件：
- `gemma-2b-it-gpu-int4.bin`（约 1.35 GB）

来源（Kaggle）：
https://www.kaggle.com/models/google/gemma/tfLite/gemma-2b-it-gpu-int4

## 说明

不放模型也能正常编译、安装、运行。只是：
- 没有 SenseVoice：ASR 语音识别走降级（仅依赖 OCR + 拼音相似度）
- 没有 Gemma：大模型校对走降级（仅依赖 DP 算法 + OCR/ASR）

功能不会崩溃，因为代码中已有 try-catch 兜底。